#version 150

#moj_import <okyware:common.glsl>

in vec2 FragCoord;
in vec4 FragColor;

uniform vec2 Size;
uniform vec4 ColorModulator;

out vec4 OutColor;

// Proper moon SDF
float sdMoon(vec2 p, float d, float ra, float rb) {
    p.y = abs(p.y);
    float a = (ra*ra - rb*rb + d*d)/(2.0*d);
    float b = sqrt(max(ra*ra-a*a,0.0));
    if( d*(p.x*b-p.y*a) > d*d*max(b-p.y,0.0) )
          return length(p-vec2(a,b));
    return max( (length(p          )-ra),
               -(length(p-vec2(d,0.0))-rb));
}

// 4-pointed star SDF
float sdStar4(vec2 p, float r, float rf) {
    p = abs(p);
    p = (p.y > p.x) ? p.yx : p.xy;
    vec2 v1 = vec2(r, 0.0);
    vec2 v2 = vec2(r * rf, r * rf);
    vec2 pa = p - v1;
    vec2 ba = v2 - v1;
    float h = clamp(dot(pa, ba) / dot(ba, ba), 0.0, 1.0);
    return length(pa - ba * h) * sign(p.y * ba.x - p.x * ba.y);
}

void main() {
    // Map coordinate to 80x80 space (SVG viewBox)
    // We use Size.x to ensure the uniform isn't optimized out
    vec2 p = FragCoord * 80.0 * (Size.x / Size.x);
    
    // Moon parameters tuned to match SVG
    // Outer radius 33.33, Inner radius 33.33, distance between centers ~25
    // We shift the coordinate system so the moon is centered at (40,40)
    vec2 moonP = p - vec2(40.0, 40.0);
    // Rotate 180 degrees if needed? SVG moon is open to the right.
    // My sdMoon is open to the left by default.
    moonP.x = -moonP.x; 
    float moon = sdMoon(moonP, 25.0, 33.33, 33.33);
    
    // Stars from SVG
    // Star 1 (Big): Center(64.8, 15.2)
    // Star 2 (Small): Center(51.9, 31.3)
    float star1 = sdStar4(p - vec2(64.8, 15.2), 8.5, 0.25);
    float star2 = sdStar4(p - vec2(51.9, 31.3), 5.5, 0.25);
    
    float d = min(moon, min(star1, star2));
    
    // Antialiasing
    float smoothness = 0.5;
    float alpha = 1.0 - smoothstep(-smoothness, smoothness, d);
    
    // Moon opacity is 0.5 in SVG
    float finalAlpha = alpha;
    // We check if we are inside the moon part specifically
    if (moon < 0.1 && star1 > 0.1 && star2 > 0.1) {
        finalAlpha *= 0.5;
    }

    vec4 finalColor = vec4(FragColor.rgb, FragColor.a * finalAlpha);
    OutColor = finalColor * ColorModulator;
    
    if (OutColor.a < 0.01) discard;
}
