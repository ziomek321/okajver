package okyware.wtf.base.modules;

import com.darkmagician6.eventapi.EventManager;
import com.darkmagician6.eventapi.EventTarget;
import lombok.Getter;
import org.lwjgl.glfw.GLFW;
import okyware.wtf.base.events.impl.input.EventKey;
import okyware.wtf.client.modules.api.Module;
import okyware.wtf.client.modules.impl.combat.*;
import okyware.wtf.client.modules.impl.misc.*;
import okyware.wtf.client.modules.impl.movement.*;
import okyware.wtf.client.modules.impl.player.FastBreak;
import okyware.wtf.client.modules.impl.player.NoDelay;
import okyware.wtf.client.modules.impl.render.*;
import okyware.wtf.utility.interfaces.IMinecraft;
import okyware.wtf.client.modules.impl.player.AutoTool;
import okyware.wtf.client.modules.impl.player.AutoArmor;
import okyware.wtf.client.modules.impl.player.Blink;
import okyware.wtf.client.modules.impl.player.ChestStealer;
import okyware.wtf.client.modules.impl.player.NoFall;
import okyware.wtf.client.modules.impl.player.FakeLag;
import okyware.wtf.client.modules.impl.combat.AutoWeb;
import java.util.*;

@Getter
public final class ModuleManager implements IMinecraft {

    private final List<Module> modules = new ArrayList<>();

    public ModuleManager() {
        init();
        EventManager.register(this);
    }

    private void init() {
        registerCombat();
        registerMovement();
        registerRender();
        registerPlayer();
        registerMisc();
    }

    private void registerCombat() {
        registerModule(AutoTrap.INSTANCE);
        registerModule(Backtrack.INSTANCE);
        registerModule(Meow.INSTANCE);
        registerModule(AutoClicker.INSTANCE);
        registerModule(AimAssist.INSTANCE);
        registerModule(SilentAim.INSTANCE);
        registerModule(AntiBot.INSTANCE);
        registerModule(Aura.INSTANCE);
        registerModule(MaceSpoof.INSTANCE);
        registerModule(ElytraTarget.INSTANCE);
        registerModule(AutoSwap.INSTANCE);

        registerModule(AutoTotem.INSTANCE);
        registerModule(AutoCrystal.INSTANCE);
        registerModule(SelfTrap.INSTANCE);
        registerModule(Velocity.INSTANCE);
        registerModule(Criticals.INSTANCE);
        registerModule(AutoGapple.INSTANCE);
        registerModule(TriggerBot.INSTANCE);
        registerModule(BlockHit.INSTANCE);
        registerModule(Spinbot.INSTANCE);
        registerModule(AutoWeb.INSTANCE);
        registerModule(HitPush.INSTANCE);
        registerModule(HvH.INSTANCE);
    }

    private void registerMovement() {
        registerModule(Speed.INSTANCE);
        registerModule(AutoSprint.INSTANCE);
        registerModule(ElytraBooster.INSTANCE);
        registerModule(ElytraRecast.INSTANCE);
        registerModule(GuiWalk.INSTANCE);
        registerModule(NoSlow.INSTANCE);
        registerModule(Strafe.INSTANCE);
        registerModule(TargetStrafe.INSTANCE);
        registerModule(Scaffold.INSTANCE);
        registerModule(Flight.INSTANCE);
        registerModule(BoatFly.INSTANCE);
        registerModule(HighJump.INSTANCE);
        registerModule(NoWeb.INSTANCE);
        registerModule(Spider.INSTANCE);
    }

    private void registerRender() {
        registerModule(Interface.INSTANCE);
        Interface.INSTANCE.setToggled(true);
        registerModule(AntiInvisible.INSTANCE);
        registerModule(Menu.INSTANCE);
        registerModule(Cosmetics.INSTANCE);
        registerModule(NoRender.INSTANCE);
        registerModule(Predictions.INSTANCE);
        registerModule(BlockESP.INSTANCE);
        registerModule(SwingAnimation.INSTANCE);
        registerModule(Crosshair.INSTANCE);
        registerModule(ViewModel.INSTANCE);
        registerModule(WorldTweaks.INSTANCE);
        registerModule(EntityESP.INSTANCE);
        registerModule(JumpCircles.INSTANCE);
        registerModule(ChinaHat.INSTANCE);
        registerModule(Nametags.INSTANCE);
        registerModule(HitParticles.INSTANCE);
        registerModule(TargetESP.INSTANCE);
        registerModule(PlaceHighlight.INSTANCE);
        registerModule(Trails.INSTANCE);
        registerModule(Chams.INSTANCE);
        registerModule(KillEffect.INSTANCE);
        registerModule(PopChams.INSTANCE);
        registerModule(HitBubbles.INSTANCE);
        registerModule(Particles.INSTANCE);
        registerModule(ShaderHands.INSTANCE);
        registerModule(CustomSky.INSTANCE);
    }

    private void registerPlayer() {
        registerModule(AutoTool.INSTANCE);
        registerModule(AutoArmor.INSTANCE);

        registerModule(NoDelay.INSTANCE);
        registerModule(FastBreak.INSTANCE);
        registerModule(NoFall.INSTANCE);
        registerModule(ChestStealer.INSTANCE);
        registerModule(Blink.INSTANCE);
        registerModule(FakeLag.INSTANCE);
    }

    private void registerMisc() {

        registerModule(ElytraHelper.INSTANCE);
        registerModule(ItemScroller.INSTANCE);
        registerModule(ClickAction.INSTANCE);
        registerModule(FreeCam.INSTANCE);
        registerModule(CameraTweaks.INSTANCE);
        registerModule(NoInteract.INSTANCE);
        registerModule(NameProtect.INSTANCE);
        registerModule(okyware.wtf.client.modules.impl.misc.ClientSound.INSTANCE);
        registerModule(okyware.wtf.client.modules.impl.misc.VisualRange.INSTANCE);
        registerModule(AntiLogout.INSTANCE);
        registerModule(FakePlayer.INSTANCE);
    }

    private void registerModule(Module module) {
        modules.add(module);
    }
    public Module getModule(String name) {
        return modules.stream()
                .filter(module -> module.getName().equalsIgnoreCase(name))
                .findFirst()
                .orElse(null);
    }

    public Set<Module> getActiveModules() {
        Set<Module> active = new HashSet<>();
        for (Module module : modules) {
            if (module.isEnabled()) active.add(module);
        }
        return active;
    }
    @EventTarget
    public void onKey(EventKey event) {

        if (mc.currentScreen != null || event.getAction() != GLFW.GLFW_PRESS) return;

        for (Module module : modules) {
            if (module.getKeyCode() == event.getKeyCode()
                    && module.getKeyCode() != GLFW.GLFW_KEY_UNKNOWN) {
                module.toggle();
            }
        }
    }
}
