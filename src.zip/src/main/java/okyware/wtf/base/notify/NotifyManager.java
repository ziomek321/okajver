package okyware.wtf.base.notify;

import com.darkmagician6.eventapi.EventManager;
import net.minecraft.text.Text;
import okyware.wtf.client.modules.api.Module;

public class NotifyManager {
    private static NotifyManager instance;

    public NotifyManager() {
        EventManager.register(this);
    }

    public static NotifyManager getInstance() {
        if (instance == null) instance = new NotifyManager();
        return instance;
    }

    public void setNotifyComponent(Object component) {}
    public void addNotification(Module module, boolean enabled) {}
    public void addNotification(String icon, Text module) {}
}
