package okyware.wtf.base.events.impl.player;


import com.darkmagician6.eventapi.events.Event;


public class EventJump implements Event {

}

