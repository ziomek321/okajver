package okyware.wtf.base.events.impl.server;


import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.component.Component;
import net.minecraft.text.Text;
import okyware.wtf.base.events.callables.EventCancellable;
import okyware.wtf.utility.render.display.base.CustomDrawContext;


@Getter
@Setter
@AllArgsConstructor
public class EventChatReceive extends EventCancellable {

    private Text message;


}