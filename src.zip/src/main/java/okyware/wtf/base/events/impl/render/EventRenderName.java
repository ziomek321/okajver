package okyware.wtf.base.events.impl.render;


import okyware.wtf.base.events.callables.EventCancellable;
import lombok.AllArgsConstructor;
import lombok.Getter;

@Getter
@AllArgsConstructor
public final class EventRenderName extends EventCancellable {

}