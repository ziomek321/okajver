package okyware.wtf.base.events.callables;

import com.darkmagician6.eventapi.events.Event;
import com.darkmagician6.eventapi.events.Typed;


public abstract class EventTyped implements Event, Typed {

    private final byte type;

    
    protected EventTyped(byte eventType) {
        type = eventType;
    }


    @Override
    public byte getType() {
        return type;
    }

}
