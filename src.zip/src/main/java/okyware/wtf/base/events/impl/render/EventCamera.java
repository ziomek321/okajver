package okyware.wtf.base.events.impl.render;

import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;
import lombok.experimental.FieldDefaults;
import okyware.wtf.base.events.callables.EventCancellable;
import okyware.wtf.utility.game.player.rotation.Rotation;


@Getter
@Setter
@AllArgsConstructor
@FieldDefaults(level = AccessLevel.PRIVATE)
public class EventCamera extends EventCancellable {
    boolean cameraClip;
    float distance;
    Rotation angle;
    float offsetX;
    float offsetY;
    
    public EventCamera(boolean cameraClip, float distance, Rotation angle) {
        this.cameraClip = cameraClip;
        this.distance = distance;
        this.angle = angle;
        this.offsetX = 0;
        this.offsetY = 0;
    }
}
