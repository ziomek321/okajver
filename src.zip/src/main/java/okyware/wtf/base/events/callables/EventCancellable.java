package okyware.wtf.base.events.callables;

import com.darkmagician6.eventapi.events.Cancellable;
import com.darkmagician6.eventapi.events.Event;


public abstract class EventCancellable implements Event, Cancellable {

    private boolean cancelled;

    protected EventCancellable() {
    }

    
    @Override
    public boolean isCancelled() {
        return cancelled;
    }

    
    @Override
    public void setCancelled(boolean state) {
        cancelled = state;
    }
    public void cancel() {
        cancelled = true;
    }

}
