package okyware.wtf.base.events.impl.player;



import lombok.Getter;
import lombok.RequiredArgsConstructor;
import lombok.Setter;
import okyware.wtf.base.events.callables.EventCancellable;

@Getter
@Setter
@RequiredArgsConstructor
public class EventSlowWalking extends EventCancellable {



}