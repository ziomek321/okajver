package okyware.wtf.base.events.impl.player;


import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.Getter;
import lombok.Setter;
import okyware.wtf.base.events.callables.EventCancellable;

@Getter
@Setter
@AllArgsConstructor
public class EventRotate extends EventCancellable {
}
