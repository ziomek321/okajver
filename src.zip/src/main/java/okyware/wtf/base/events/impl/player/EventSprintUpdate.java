package okyware.wtf.base.events.impl.player;

import okyware.wtf.base.events.callables.EventCancellable;

public class EventSprintUpdate  extends EventCancellable {
}
