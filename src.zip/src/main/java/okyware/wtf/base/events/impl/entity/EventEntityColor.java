package okyware.wtf.base.events.impl.entity;

import lombok.*;
import net.minecraft.entity.LivingEntity;
import okyware.wtf.base.events.callables.EventCancellable;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class EventEntityColor extends EventCancellable {
    private int color;
    private boolean invisible;
    private LivingEntity entity;

    public EventEntityColor(int color) {
        this.color = color;
    }
}
