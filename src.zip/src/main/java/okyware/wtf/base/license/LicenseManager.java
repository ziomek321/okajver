package okyware.wtf.base.license;

import net.minecraft.client.MinecraftClient;
import net.minecraft.util.Identifier;
import lombok.Getter;

@Getter
public class LicenseManager {
    public static final LicenseManager INSTANCE = new LicenseManager();
    public String getNickname() { return MinecraftClient.getInstance().getSession().getUsername(); }
    public String getUid() { return "0"; }
    public Identifier getAvatar() { return Identifier.of("okyware", "default.png"); }
    public void verify() {}
    public String getToken() { return ""; }
}
