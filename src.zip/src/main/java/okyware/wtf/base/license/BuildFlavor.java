package okyware.wtf.base.license;
public class BuildFlavor {
    public static final boolean HWID_ENABLED = false;
}
