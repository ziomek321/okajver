package okyware.wtf.base.config;

import com.darkmagician6.eventapi.EventManager;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import lombok.Getter;
import okyware.wtf.Okyware;
import okyware.wtf.base.license.LicenseManager;

import java.io.*;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Base64;
import java.util.List;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

@Getter
public class ConfigManager {
    public static final File configDirectory = new File(Okyware.DIRECTORY, "configs");
    ScheduledExecutorService scheduler = Executors.newSingleThreadScheduledExecutor();
    private final String shifr = "config";
    private final List<CloudConfig> cloudConfigs = new ArrayList<>();
    @Getter
    private volatile boolean cloudLoading = false;

    public ConfigManager() {
        configDirectory.mkdirs();
        loadConfig("current_config");
        EventManager.register(this);
        scheduler.scheduleAtFixedRate(() -> {
            try {
                saveConfig("current_config");
            } catch (Exception e) {}
        }, 5, 5, TimeUnit.MINUTES);
        
        refreshCloudConfigs();
    }

    public void refreshCloudConfigs() {
        cloudLoading = true;
        new Thread(() -> {
            try {
                URL url = new URL("https://stardlc.wtf/api/configs/list");
                HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                conn.setRequestMethod("GET");
                conn.setRequestProperty("Authorization", "Bearer " + LicenseManager.INSTANCE.getToken());
                if (conn.getResponseCode() == 200) {
                    BufferedReader br = new BufferedReader(new InputStreamReader(conn.getInputStream()));
                    JsonArray array = JsonParser.parseReader(br).getAsJsonArray();
                    synchronized (cloudConfigs) {
                        cloudConfigs.clear();
                        for (JsonElement el : array) {
                            JsonObject obj = el.getAsJsonObject();
                            int id = obj.has("id") ? obj.get("id").getAsInt()
                                    : (obj.has("ID") ? obj.get("ID").getAsInt() : -1);
                            String cname = obj.has("name") ? obj.get("name").getAsString()
                                    : (obj.has("Name") ? obj.get("Name").getAsString() : "?");
                            String server = obj.has("server") ? obj.get("server").getAsString()
                                    : (obj.has("Server") ? obj.get("Server").getAsString() : "none");
                            boolean pub = obj.has("is_public") ? obj.get("is_public").getAsBoolean()
                                    : (obj.has("IsPublic") && obj.get("IsPublic").getAsBoolean());
                            String author = obj.has("author") && !obj.get("author").isJsonNull()
                                    ? obj.get("author").getAsString() : "";
                            cloudConfigs.add(new CloudConfig(id, cname, server, pub, author));
                        }
                    }
                }
            } catch (Exception e) {
                System.err.println("[Okyware] Failed to fetch cloud configs: " + e.getMessage());
            } finally {
                cloudLoading = false;
            }
        }).start();
    }

    public void loadCloudConfig(int id) {
        new Thread(() -> {
            try {
                URL url = new URL("https://stardlc.wtf/api/configs/get/" + id);
                HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                conn.setRequestMethod("GET");
                conn.setRequestProperty("Authorization", "Bearer " + LicenseManager.INSTANCE.getToken());
                if (conn.getResponseCode() == 200) {
                    BufferedReader br = new BufferedReader(new InputStreamReader(conn.getInputStream()));
                    JsonObject obj = JsonParser.parseReader(br).getAsJsonObject();
                    if (obj.has("data")) {
                        String data = obj.get("data").getAsString();
                        JsonObject configJson = JsonParser.parseString(data).getAsJsonObject();
                        
                        net.minecraft.client.MinecraftClient.getInstance().execute(() -> {
                            Config temp = new Config("temp_cloud_load");
                            temp.load(configJson);
                            try { temp.getFile().delete(); } catch (Exception ignored) {}
                        });
                    }
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }).start();
    }

    public void saveToCloud(String name) {
        saveToCloud(name, false);
    }

    public void saveToCloud(String name, boolean isPublic) {
        new Thread(() -> {
            try {
                Config config = findConfig(name);
                if (config == null) config = new Config(name);
                String data = new GsonBuilder().setPrettyPrinting().create().toJson(config.save());

                URL url = new URL("https://stardlc.wtf/api/configs/save");
                HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                conn.setRequestMethod("POST");
                conn.setRequestProperty("Content-Type", "application/json");
                conn.setRequestProperty("Authorization", "Bearer " + LicenseManager.INSTANCE.getToken());
                conn.setDoOutput(true);

                JsonObject body = new JsonObject();
                body.addProperty("name", name);
                body.addProperty("data", data);
                body.addProperty("server", config.getServerIP());
                body.addProperty("is_public", isPublic);

                try (OutputStream os = conn.getOutputStream()) {
                    os.write(body.toString().getBytes(StandardCharsets.UTF_8));
                }
                if (conn.getResponseCode() == 200) {
                    refreshCloudConfigs();
                }
            } catch (Exception ignored) {
            }
        }).start();
    }

    public boolean loadConfig(String configName) {
        if (configName == null) return false;
        Config config = findConfig(configName);
        if (config == null) return false;
        
        File file = config.getFile();
        if (!file.exists()) return false;

        try (BufferedReader reader = new BufferedReader(new FileReader(file))) {
            StringBuilder content = new StringBuilder();
            String line;
            while ((line = reader.readLine()) != null) content.append(line);
            
            String rawData = content.toString();
            if (rawData.isEmpty()) return false;
            
            if (!rawData.trim().startsWith("{")) {
                try {
                    byte[] encryptedData = Base64.getDecoder().decode(rawData);
                    byte[] decryptedData = okyware.wtf.utility.crypt.CryptUtility.decryptData(encryptedData, shifr);
                    rawData = new String(decryptedData, StandardCharsets.UTF_8);
                } catch (Exception e) { return false; }
            }

            JsonObject object = JsonParser.parseString(rawData).getAsJsonObject();
            config.load(object);
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    public boolean saveConfig(String configName) {
        try {
            Config config = findConfig(configName);
            if (config == null) config = new Config(configName);
            String json = new GsonBuilder().setPrettyPrinting().create().toJson(config.save());
            try (FileWriter writer = new FileWriter(config.getFile())) {
                writer.write(json);
                return true;
            }
        } catch (Exception e) {
            return false;
        }
    }

    public boolean deleteConfig(String configName) {
        Config config = findConfig(configName);
        if (config == null) return false;
        return config.getFile().delete();
    }

    public Config findConfig(String configName) {
        if (configName == null) return null;
        File f1 = new File(configDirectory, configName + ".json");
        File f2 = new File(configDirectory, configName + "." + Okyware.NAME.toLowerCase());
        if (f1.exists() || f2.exists()) return new Config(configName);
        return null;
    }

    public List<String> configNames() {
        File[] files = configDirectory.listFiles();
        List<String> names = new ArrayList<>();
        if (files != null) {
            for (File file : files) {
                String name = file.getName();
                if (name.endsWith(".json") || name.endsWith("." + Okyware.NAME.toLowerCase())) {
                    String bare = name.substring(0, name.lastIndexOf('.'));
                    if (bare.equals("temp_cloud_load") || bare.startsWith("temp_")) {
                        file.delete();
                        continue;
                    }
                    if (bare.equals("current_config")) {
                        continue;
                    }
                    if (!names.contains(bare)) {
                        names.add(bare);
                    }
                }
            }
        }
        return names;
    }

    public void save() {
        this.scheduler.shutdown();
        saveConfig("current_config");
    }

    public List<CloudConfig> getCloudConfigs() {
        synchronized (cloudConfigs) { return new ArrayList<>(cloudConfigs); }
    }

    public CloudConfig findCloudConfig(String name) {
        synchronized (cloudConfigs) {
            for (CloudConfig c : cloudConfigs) if (c.name().equalsIgnoreCase(name)) return c;
        }
        return null;
    }

    public void deleteCloudConfig(int id) {
        new Thread(() -> {
            try {
                URL url = new URL("https://stardlc.wtf/api/configs/delete/" + id);
                HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                conn.setRequestMethod("DELETE");
                conn.setRequestProperty("Authorization", "Bearer " + LicenseManager.INSTANCE.getToken());
                if (conn.getResponseCode() == 200) refreshCloudConfigs();
            } catch (Exception ignored) {
            }
        }).start();
    }

    public record CloudConfig(int id, String name, String server, boolean isPublic, String author) {}
}
