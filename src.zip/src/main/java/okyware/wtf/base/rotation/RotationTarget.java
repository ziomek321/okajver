package okyware.wtf.base.rotation;



import okyware.wtf.base.rotation.mods.config.api.RotationConfig;
import okyware.wtf.utility.game.player.rotation.Rotation;

import java.util.function.Supplier;


public record RotationTarget(Rotation targetRotation, Supplier<Rotation> rotation, RotationConfig rotationConfigBack) {
}
