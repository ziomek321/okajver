package okyware.wtf.base.rotation.mods.config;


import okyware.wtf.base.rotation.mods.config.api.RotationConfig;
import okyware.wtf.base.rotation.mods.config.api.RotationModeType;

public class InstantRotationConfig extends RotationConfig {
    @Override
    public RotationModeType getType() {
        return RotationModeType.INSTANT;
    }
}
