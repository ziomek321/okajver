package okyware.wtf.base.rotation.mods;


import okyware.wtf.base.rotation.deeplearnig.MinaraiModel;
import okyware.wtf.base.rotation.mods.api.RotationMode;
import okyware.wtf.base.rotation.mods.config.AiRotationConfig;
import okyware.wtf.utility.game.player.rotation.Rotation;
import okyware.wtf.utility.game.player.rotation.RotationDelta;

public class AIRotationMode extends RotationMode {
    private Rotation lerpTargetRotation = Rotation.ZERO;
    public Rotation process(AiRotationConfig config, Rotation targetRotation) {
        if (stardlc.getDeepLearningManager() == null || stardlc.getDeepLearningManager().getModel() == null) return targetRotation;

        RotationDelta prevDelta = stardlc.getRotationManager().getPreviousRotation().rotationDeltaTo(stardlc.getRotationManager().getCurrentRotation());

        Rotation currentRotation = stardlc.getRotationManager().getCurrentRotation();
        if(Math.abs(targetRotation.rotationDeltaTo(lerpTargetRotation).getDeltaYaw())>80 ){
            lerpTargetRotation = targetRotation;
        }
        for (int i = 0; i < 3; i++) {
            Rotation newOut = process(config, currentRotation, targetRotation, prevDelta, i == config.getTick() - 1);
            prevDelta = currentRotation.rotationDeltaTo(newOut);
            currentRotation = newOut;
        }

        if(currentRotation.rotationDeltaTo(lerpTargetRotation).isInRange(10)){
            lerpTargetRotation = targetRotation;
        }

        return currentRotation;
    }
    private Rotation process(AiRotationConfig config, Rotation currentRotation,Rotation targetRotation,RotationDelta prevDelta, boolean tickUpdate) {


        MinaraiModel model = stardlc.getDeepLearningManager().getSlowModel();
        try {

            RotationDelta deltaLerpTarget = currentRotation.rotationDeltaTo(lerpTargetRotation);


            if(Math.copySign(1,prevDelta.getDeltaYaw())!=Math.copySign(1, deltaLerpTarget.getDeltaYaw())) {
              
              
            }


            
            float[] input = new float[]{prevDelta.getDeltaYaw(), prevDelta.getDeltaPitch(), deltaLerpTarget.getDeltaYaw(), deltaLerpTarget.getDeltaPitch()};

          
        if (model == null) return currentRotation;
            float[] result = model.predict(input);



            float diffYaw = result[0];
            float diffPitch = result[1];

            RotationDelta newDelta = new RotationDelta(diffYaw, diffPitch);



            return  currentRotation.add(newDelta);

        } catch (
                Exception e) {
            e.printStackTrace();
        }
        return currentRotation;
    }

    public void resetLerp(Rotation targetRotation) {
        this.lerpTargetRotation = targetRotation;
    }
}
