package okyware.wtf.base.rotation.deeplearnig;

import lombok.Getter;

@Getter
public class DeepLearningManager {
    private MinaraiModel model;
    private MinaraiModel speedModer;
    private MinaraiModel slowModel;

    public DeepLearningManager() {
        try {
            model = new MinaraiModel("model");
            model.load();
            slowModel = new MinaraiModel("slow");
            slowModel.load();
            speedModer = new MinaraiModel("tf-0100");
            speedModer.load();
        } catch (Exception e) {
            System.out.println(" Deep learning models failed to load: " + e.getMessage());
        }
    }
}
