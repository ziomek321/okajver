package okyware.wtf.base.rotation.mods.api;


import okyware.wtf.utility.interfaces.IClient;

public abstract class RotationMode  implements IClient {
}
