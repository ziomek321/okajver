package okyware.wtf.base.comand.impl;

import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import net.minecraft.command.CommandSource;
import org.lwjgl.glfw.GLFW;
import okyware.wtf.Okyware;
import okyware.wtf.base.comand.api.CommandAbstract;
import okyware.wtf.base.comand.impl.args.ModuleArgumentType;
import okyware.wtf.client.modules.api.Module;
import okyware.wtf.utility.game.other.MessageUtil;

import static com.mojang.brigadier.Command.SINGLE_SUCCESS;

public class BindCommand extends CommandAbstract {
    public BindCommand() {
        super("bind");
    }

    @Override
    public void execute(LiteralArgumentBuilder<CommandSource> builder) {
        builder.then(arg("module", ModuleArgumentType.create())
                .then(arg("key", StringArgumentType.word())
                        .executes(context -> {
                            String moduleName = ((okyware.wtf.client.modules.api.Module) context.getArgument("module", Object.class)).getName();
                            String keyName = context.getArgument("key", String.class);

                            Module module = Okyware.getInstance().getModuleManager().getModule(moduleName);
                            if (module == null) {
                                MessageUtil.displayMessage(MessageUtil.LogLevel.INFO, "§cModule not found: " + moduleName);
                                return SINGLE_SUCCESS;
                            }

                            if (keyName.equalsIgnoreCase("none") || keyName.equalsIgnoreCase("unbind")) {
                                module.setKeyCode(-1);
                                MessageUtil.displayMessage(MessageUtil.LogLevel.INFO, "§aUnbound " + module.getName());
                                return SINGLE_SUCCESS;
                            }

                            int keyCode = getKeyCode(keyName.toUpperCase());
                            if (keyCode == -1) {
                                MessageUtil.displayMessage(MessageUtil.LogLevel.INFO, "§cUnknown key: " + keyName);
                                return SINGLE_SUCCESS;
                            }

                            module.setKeyCode(keyCode);
                            MessageUtil.displayMessage(MessageUtil.LogLevel.INFO, "§aBound " + module.getName() + " to " + keyName.toUpperCase());
                            return SINGLE_SUCCESS;
                        })));

        builder.then(arg("module", ModuleArgumentType.create())
                .executes(context -> {
                    String moduleName = ((okyware.wtf.client.modules.api.Module) context.getArgument("module", Object.class)).getName();
                    Module module = Okyware.getInstance().getModuleManager().getModule(moduleName);
                    if (module == null) {
                        MessageUtil.displayMessage(MessageUtil.LogLevel.INFO, "§cModule not found: " + moduleName);
                    } else {
                        String key = module.getKeyCode() == -1 ? "None" : GLFW.glfwGetKeyName(module.getKeyCode(), 0);
                        if (key == null) key = "Key " + module.getKeyCode();
                        MessageUtil.displayMessage(MessageUtil.LogLevel.INFO, "§e" + module.getName() + " §7is bound to §f" + key);
                    }
                    return SINGLE_SUCCESS;
                }));
    }

    private int getKeyCode(String name) {
        return switch (name) {
            case "A" -> GLFW.GLFW_KEY_A; case "B" -> GLFW.GLFW_KEY_B; case "C" -> GLFW.GLFW_KEY_C;
            case "D" -> GLFW.GLFW_KEY_D; case "E" -> GLFW.GLFW_KEY_E; case "F" -> GLFW.GLFW_KEY_F;
            case "G" -> GLFW.GLFW_KEY_G; case "H" -> GLFW.GLFW_KEY_H; case "I" -> GLFW.GLFW_KEY_I;
            case "J" -> GLFW.GLFW_KEY_J; case "K" -> GLFW.GLFW_KEY_K; case "L" -> GLFW.GLFW_KEY_L;
            case "M" -> GLFW.GLFW_KEY_M; case "N" -> GLFW.GLFW_KEY_N; case "O" -> GLFW.GLFW_KEY_O;
            case "P" -> GLFW.GLFW_KEY_P; case "Q" -> GLFW.GLFW_KEY_Q; case "R" -> GLFW.GLFW_KEY_R;
            case "S" -> GLFW.GLFW_KEY_S; case "T" -> GLFW.GLFW_KEY_T; case "U" -> GLFW.GLFW_KEY_U;
            case "V" -> GLFW.GLFW_KEY_V; case "W" -> GLFW.GLFW_KEY_W; case "X" -> GLFW.GLFW_KEY_X;
            case "Y" -> GLFW.GLFW_KEY_Y; case "Z" -> GLFW.GLFW_KEY_Z;
            case "0" -> GLFW.GLFW_KEY_0; case "1" -> GLFW.GLFW_KEY_1; case "2" -> GLFW.GLFW_KEY_2;
            case "3" -> GLFW.GLFW_KEY_3; case "4" -> GLFW.GLFW_KEY_4; case "5" -> GLFW.GLFW_KEY_5;
            case "6" -> GLFW.GLFW_KEY_6; case "7" -> GLFW.GLFW_KEY_7; case "8" -> GLFW.GLFW_KEY_8;
            case "9" -> GLFW.GLFW_KEY_9;
            case "LSHIFT", "LEFT_SHIFT" -> GLFW.GLFW_KEY_LEFT_SHIFT;
            case "RSHIFT", "RIGHT_SHIFT" -> GLFW.GLFW_KEY_RIGHT_SHIFT;
            case "LCTRL", "LEFT_CONTROL", "CTRL" -> GLFW.GLFW_KEY_LEFT_CONTROL;
            case "RCTRL", "RIGHT_CONTROL" -> GLFW.GLFW_KEY_RIGHT_CONTROL;
            case "LALT", "LEFT_ALT", "ALT" -> GLFW.GLFW_KEY_LEFT_ALT;
            case "RALT", "RIGHT_ALT" -> GLFW.GLFW_KEY_RIGHT_ALT;
            case "TAB" -> GLFW.GLFW_KEY_TAB; case "CAPS", "CAPSLOCK" -> GLFW.GLFW_KEY_CAPS_LOCK;
            case "SPACE" -> GLFW.GLFW_KEY_SPACE; case "ENTER" -> GLFW.GLFW_KEY_ENTER;
            case "BACKSPACE" -> GLFW.GLFW_KEY_BACKSPACE; case "DELETE" -> GLFW.GLFW_KEY_DELETE;
            case "HOME" -> GLFW.GLFW_KEY_HOME; case "END" -> GLFW.GLFW_KEY_END;
            case "INSERT" -> GLFW.GLFW_KEY_INSERT;
            case "F1" -> GLFW.GLFW_KEY_F1; case "F2" -> GLFW.GLFW_KEY_F2; case "F3" -> GLFW.GLFW_KEY_F3;
            case "F4" -> GLFW.GLFW_KEY_F4; case "F5" -> GLFW.GLFW_KEY_F5; case "F6" -> GLFW.GLFW_KEY_F6;
            case "F7" -> GLFW.GLFW_KEY_F7; case "F8" -> GLFW.GLFW_KEY_F8; case "F9" -> GLFW.GLFW_KEY_F9;
            case "F10" -> GLFW.GLFW_KEY_F10; case "F11" -> GLFW.GLFW_KEY_F11; case "F12" -> GLFW.GLFW_KEY_F12;
            default -> -1;
        };
    }
}
