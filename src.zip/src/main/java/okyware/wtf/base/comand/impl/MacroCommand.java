package okyware.wtf.base.comand.impl;

import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import net.minecraft.command.CommandSource;
import okyware.wtf.base.comand.api.CommandAbstract;
import okyware.wtf.base.comand.impl.args.MacroArgumentType;
import okyware.wtf.base.comand.impl.args.CommandArgumentType;
import okyware.wtf.utility.game.other.MessageUtil;

import static com.mojang.brigadier.Command.SINGLE_SUCCESS;

public class MacroCommand extends CommandAbstract {
    public MacroCommand() {
        super("macro");
    }

    @Override
    public void execute(LiteralArgumentBuilder<CommandSource> builder) {
        builder.then(arg("name", MacroArgumentType.create())
            .then(arg("bind", MacroArgumentType.create())
            .then(arg("command", CommandArgumentType.create())
            .executes(context -> {
                String name = context.getArgument("name", String.class);
                String bind = context.getArgument("bind", String.class);
                String command = context.getArgument("command", String.class);
                
                
                
                MessageUtil.displayMessage(MessageUtil.LogLevel.INFO,
                    "§aMacro " + name + " created for key " + bind + " with command " + command);
                return SINGLE_SUCCESS;
            }))));

        builder.then(literal("help").executes(context -> {
            MessageUtil.displayMessage(MessageUtil.LogLevel.INFO,
                "§6Usage: §r.macro <name> <bind> <command>");
            MessageUtil.displayMessage(MessageUtil.LogLevel.INFO,
                "§6Examples:§r");
            MessageUtil.displayMessage(MessageUtil.LogLevel.INFO,
                "§e.macro hata h /home 1 §7- create macro hata for key h with command /home 1");
            MessageUtil.displayMessage(MessageUtil.LogLevel.INFO,
                "§e.macro tp T /tp 100 64 100 §7- create macro tp for key T with command /tp 100 64 100");
            MessageUtil.displayMessage(MessageUtil.LogLevel.INFO,
                "§e.macro list §7- list all macros");
            return SINGLE_SUCCESS;
        }));
    }
}
