package okyware.wtf.base.comand;

import com.mojang.brigadier.CommandDispatcher;
import lombok.Getter;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientCommandSource;
import net.minecraft.command.CommandSource;
import org.jetbrains.annotations.NotNull;
import okyware.wtf.base.comand.api.CommandAbstract;
import okyware.wtf.base.comand.impl.FriendCommand;
import okyware.wtf.base.comand.impl.MacroCommand;
import okyware.wtf.base.comand.impl.ClipCommand;
import okyware.wtf.base.comand.impl.ConfigCommand;
import okyware.wtf.base.comand.impl.RCTCommand;
import okyware.wtf.base.comand.impl.VClipCommand;
import okyware.wtf.base.comand.impl.BindCommand;


import java.util.ArrayList;
import java.util.List;

@Getter
public class CommandManager {
    private String prefix = ".";


    private final CommandDispatcher<CommandSource> dispatcher = new CommandDispatcher<>();

    private final CommandSource source = new ClientCommandSource(null, MinecraftClient.getInstance());

    private final List<CommandAbstract> commands = new ArrayList<>();

    public CommandManager() {


        registerCommand(new FriendCommand());
        registerCommand(new MacroCommand());
        registerCommand(new ClipCommand());
        registerCommand(new ConfigCommand());
        registerCommand(new RCTCommand());
        registerCommand(new VClipCommand());
        registerCommand(new BindCommand());

    }


    public void registerCommand(CommandAbstract command) {
        if (command == null) return;

        command.register(dispatcher);
        this.commands.add(command);
    }
}