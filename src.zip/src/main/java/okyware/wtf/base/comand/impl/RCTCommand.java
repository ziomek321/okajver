package okyware.wtf.base.comand.impl;

import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import net.minecraft.command.CommandSource;
import net.minecraft.util.Formatting;
import okyware.wtf.Okyware;
import okyware.wtf.base.comand.api.CommandAbstract;
import okyware.wtf.base.notify.NotifyManager;
import okyware.wtf.base.repository.RCTRepository;
import okyware.wtf.utility.game.server.ServerHandler;
import okyware.wtf.utility.interfaces.IClient;

import static com.mojang.brigadier.Command.SINGLE_SUCCESS;

public class RCTCommand extends CommandAbstract implements IClient {
    private final RCTRepository repository;

    public RCTCommand() {
        super("rct");
        repository = Okyware.getInstance().getRCTRepository();
    }

    @Override
    public void execute(LiteralArgumentBuilder<CommandSource> builder) {
        builder.executes(context -> {
            ServerHandler serverHandler = Okyware.getInstance().getServerHandler();
            
            if (!serverHandler.isHolyWorld()) {
                NotifyManager.getInstance().addNotification("[RCT]", net.minecraft.text.Text.literal(" Does not work on this " + Formatting.RED + "server"));
                return SINGLE_SUCCESS;
            }

            if (serverHandler.isPvp()) {
                NotifyManager.getInstance().addNotification("️[RCT]", net.minecraft.text.Text.literal(" You are in mode " + Formatting.RED + "пвп"));
                return SINGLE_SUCCESS;
            }

            repository.reconnect(serverHandler.getAnarchy());
            return SINGLE_SUCCESS;
        });

        builder.then(CommandAbstract.arg("anarchy", com.mojang.brigadier.arguments.IntegerArgumentType.integer(1, 63)).executes(context -> {
            ServerHandler serverHandler = Okyware.getInstance().getServerHandler();
            
            if (!serverHandler.isHolyWorld()) {
                NotifyManager.getInstance().addNotification("[RCT]", net.minecraft.text.Text.literal(" Does not work on this " + Formatting.RED + "server"));
                return SINGLE_SUCCESS;
            }

            if (serverHandler.isPvp()) {
                NotifyManager.getInstance().addNotification("[RCT]️", net.minecraft.text.Text.literal(" You are in mode " + Formatting.RED + "пвп"));
                return SINGLE_SUCCESS;
            }

            int anarchy = context.getArgument("anarchy", Integer.class);
            repository.reconnect(anarchy);
            return SINGLE_SUCCESS;
        }));
    }
}
