package okyware.wtf.base.comand.impl;

import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import net.minecraft.command.CommandSource;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.player.PlayerEntity;
import okyware.wtf.base.comand.api.CommandAbstract;
import okyware.wtf.base.comand.impl.args.CoordinateArgumentType;
import okyware.wtf.utility.game.other.MessageUtil;

import static com.mojang.brigadier.Command.SINGLE_SUCCESS;

public class ClipCommand extends CommandAbstract {
    public ClipCommand() {
        super("clip");
    }

    @Override
    public void execute(LiteralArgumentBuilder<CommandSource> builder) {
        builder.then(literal("vclip")
            .then(arg("distance", CoordinateArgumentType.create())
            .executes(context -> {
                double distance = context.getArgument("distance", Double.class);
                PlayerEntity player = MinecraftClient.getInstance().player;
                if (player != null) {
                    player.setPosition(player.getX(), player.getY() + distance + 0.1, player.getZ());
                    
                    MessageUtil.displayMessage(MessageUtil.LogLevel.INFO,
                        "§aVertical clip by " + distance + " blocks");
                }
                return SINGLE_SUCCESS;
            })));
        builder.then(literal("hclip")
            .then(arg("distance", CoordinateArgumentType.create())
            .executes(context -> {
                double distance = context.getArgument("distance", Double.class);
                PlayerEntity player = MinecraftClient.getInstance().player;
                
                if (player != null) {
                    double yaw = Math.toRadians(player.getYaw());
                    player.setPosition(player.getX() - Math.sin(yaw) * distance, player.getY() + 0.1, player.getZ() + Math.cos(yaw) * distance);
                    MessageUtil.displayMessage(MessageUtil.LogLevel.INFO,
                        "§aHorizontal clip by " + distance + " blocks");
                }
                return SINGLE_SUCCESS;
            })));
        builder.then(literal("up")
            .then(arg("distance", CoordinateArgumentType.create())
            .executes(context -> {
                double distance = context.getArgument("distance", Double.class);
                PlayerEntity player = MinecraftClient.getInstance().player;
                
                if (player != null) {
                    player.setPosition(player.getX(), player.getY() + distance + 0.1, player.getZ());
                    MessageUtil.displayMessage(MessageUtil.LogLevel.INFO,
                        "§aClip up by " + distance + " blocks");
                }
                return SINGLE_SUCCESS;
            })));

        builder.then(literal("down")
            .then(arg("distance", CoordinateArgumentType.create())
            .executes(context -> {
                double distance = context.getArgument("distance", Double.class);
                PlayerEntity player = MinecraftClient.getInstance().player;
                
                if (player != null) {
                    player.setPosition(player.getX(), player.getY() - distance + 0.1, player.getZ());
                    MessageUtil.displayMessage(MessageUtil.LogLevel.INFO,
                        "§aClip down by " + distance + " blocks");
                }
                return SINGLE_SUCCESS;
            })));

        builder.then(literal("forward")
            .then(arg("distance", CoordinateArgumentType.create())
            .executes(context -> {
                double distance = context.getArgument("distance", Double.class);
                PlayerEntity player = MinecraftClient.getInstance().player;
                
                if (player != null) {
                    double yaw = Math.toRadians(player.getYaw());
                    player.setPosition(player.getX() - Math.sin(yaw) * distance, player.getY() + 0.1, player.getZ() + Math.cos(yaw) * distance);
                    MessageUtil.displayMessage(MessageUtil.LogLevel.INFO,
                        "§aClip forward by " + distance + " blocks");
                }
                return SINGLE_SUCCESS;
            })));

        builder.then(literal("back")
            .then(arg("distance", CoordinateArgumentType.create())
            .executes(context -> {
                double distance = context.getArgument("distance", Double.class);
                PlayerEntity player = MinecraftClient.getInstance().player;
                
                if (player != null) {
                    double yaw = Math.toRadians(player.getYaw());
                    player.setPosition(player.getX() + Math.sin(yaw) * distance, player.getY() + 0.1, player.getZ() - Math.cos(yaw) * distance);
                    MessageUtil.displayMessage(MessageUtil.LogLevel.INFO,
                        "§aClip back by " + distance + " blocks");
                }
                return SINGLE_SUCCESS;
            })));

        builder.then(literal("help").executes(context -> {
            MessageUtil.displayMessage(MessageUtil.LogLevel.INFO,
                "§6Usage: §r.clip <vclip/hclip/up/down/forward/back/help> [distance]");
            MessageUtil.displayMessage(MessageUtil.LogLevel.INFO,
                "§6Examples:§r");
            MessageUtil.displayMessage(MessageUtil.LogLevel.INFO,
                "§e.clip vclip 10 §7- vertical clip 10 blocks");
            MessageUtil.displayMessage(MessageUtil.LogLevel.INFO,
                "§e.clip hclip 5 §7- horizontal clip 5 blocks");
            MessageUtil.displayMessage(MessageUtil.LogLevel.INFO,
                "§e.clip up 3 §7- clip up 3 blocks");
            return SINGLE_SUCCESS;
        }));
    }
}
