package okyware.wtf.base.comand.impl;


import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import net.minecraft.command.CommandSource;
import okyware.wtf.Okyware;
import okyware.wtf.base.comand.api.CommandAbstract;
import okyware.wtf.base.comand.impl.args.FriendArgumentType;
import okyware.wtf.base.comand.impl.args.PlayerArgumentType;
import okyware.wtf.utility.game.other.MessageUtil;

import static com.mojang.brigadier.Command.SINGLE_SUCCESS;

public class StaffCommand extends CommandAbstract {
    public StaffCommand() {
        super("friend");
    }

    @Override
    public void execute(LiteralArgumentBuilder<CommandSource> builder) {
        builder.then(literal("add").then(arg("player", PlayerArgumentType.create()).executes(context -> {
            String name = context.getArgument("player", String.class);
            if(Okyware.getInstance().getStaffManager().getItems().contains(name)) {
                MessageUtil.displayMessage(MessageUtil.LogLevel.WARN, "Already added " + name);
                return SINGLE_SUCCESS;
            }
            Okyware.getInstance().getStaffManager().add(name);
            MessageUtil.displayMessage(MessageUtil.LogLevel.INFO, "Added " + name);
            return SINGLE_SUCCESS;
        })));


        builder.then(literal("remove").then(arg("player", FriendArgumentType.create()).executes(context -> {
            String nickname = context.getArgument("player", String.class);

            Okyware.getInstance().getStaffManager().remove(nickname);
            MessageUtil.displayMessage(MessageUtil.LogLevel.INFO,nickname + " removed from staff");
            return SINGLE_SUCCESS;
        })));
        builder.then(literal("list").executes(commandContext -> {



            MessageUtil.displayMessage(MessageUtil.LogLevel.INFO,Okyware.getInstance().getStaffManager().getItems().toString() );



            return SINGLE_SUCCESS;
        }));
    }

}
