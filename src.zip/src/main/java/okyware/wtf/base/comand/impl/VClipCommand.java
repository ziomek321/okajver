package okyware.wtf.base.comand.impl;

import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import net.minecraft.block.Blocks;
import net.minecraft.command.CommandSource;
import net.minecraft.network.packet.c2s.play.PlayerMoveC2SPacket;
import net.minecraft.util.math.BlockPos;
import okyware.wtf.base.comand.api.CommandAbstract;
import okyware.wtf.base.comand.impl.args.CoordinateArgumentType;
import okyware.wtf.utility.game.other.MessageUtil;

import static com.mojang.brigadier.Command.SINGLE_SUCCESS;

public class VClipCommand extends CommandAbstract {
    public VClipCommand() {
        super("vclip");
    }

    @Override
    public void execute(LiteralArgumentBuilder<CommandSource> builder) {
        builder.then(literal("down").executes(context -> {
            if (mc.player == null || mc.world == null) return SINGLE_SUCCESS;
            for (int i = 1; i < 255; i++) {
                BlockPos pos = BlockPos.ofFloored(mc.player.getPos()).add(0, -i, 0);
                if (mc.world.getBlockState(pos).isOf(Blocks.BEDROCK)) {
                    MessageUtil.displayMessage(MessageUtil.LogLevel.INFO, "§cNowhere to clip!");
                    return SINGLE_SUCCESS;
                }
                if (mc.world.getBlockState(pos).isAir()) {
                    clip(-i - 1);
                    return SINGLE_SUCCESS;
                }
            }
            return SINGLE_SUCCESS;
        }));

        builder.then(literal("up").executes(context -> {
            if (mc.player == null || mc.world == null) return SINGLE_SUCCESS;
            for (int i = 4; i < 255; i++) {
                if (mc.world.getBlockState(BlockPos.ofFloored(mc.player.getPos()).add(0, i, 0)).isAir()) {
                    clip(i + 1);
                    return SINGLE_SUCCESS;
                }
            }
            return SINGLE_SUCCESS;
        }));

        builder.then(arg("distance", CoordinateArgumentType.create()).executes(context -> {
            if (mc.player == null) return SINGLE_SUCCESS;
            double distance = context.getArgument("distance", Double.class);
            clip(distance);
            MessageUtil.displayMessage(MessageUtil.LogLevel.INFO, "§aVClip " + distance + " blocks");
            return SINGLE_SUCCESS;
        }));
    }

    private void clip(double offset) {
        mc.player.networkHandler.sendPacket(new PlayerMoveC2SPacket.PositionAndOnGround(
                mc.player.getX(), mc.player.getY() + offset, mc.player.getZ(), false, false));
        mc.player.setPosition(mc.player.getX(), mc.player.getY() + offset, mc.player.getZ());
    }
}
