package okyware.wtf.base.comand.impl;

import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import net.minecraft.command.CommandSource;
import okyware.wtf.Okyware;
import okyware.wtf.base.comand.api.CommandAbstract;

import okyware.wtf.utility.game.other.MessageUtil;

import static com.mojang.brigadier.Command.SINGLE_SUCCESS;
import static com.mojang.brigadier.arguments.StringArgumentType.string;

public class ConfigCommand extends CommandAbstract {
    public ConfigCommand() {
        super("config");
    }

    @Override
    public void execute(LiteralArgumentBuilder<CommandSource> builder) {

        builder.then(literal("save").then(arg("name", string()).executes(context -> {
            String configName = StringArgumentType.getString(context, "name");
            boolean success = Okyware.getInstance().getConfigManager().saveConfig(configName);
            if (success) {
                MessageUtil.displayMessage(MessageUtil.LogLevel.INFO,
                    "§aConfig '" + configName + "' сохранена");
            } else {
                MessageUtil.displayMessage(MessageUtil.LogLevel.WARN,
                    "§cError saving config '" + configName + "'");
            }
            return SINGLE_SUCCESS;
        })));

        builder.then(literal("load").then(arg("name", string()).executes(context -> {
            String configName = StringArgumentType.getString(context, "name");
            boolean success = Okyware.getInstance().getConfigManager().loadConfig(configName);
            if (success) {
                MessageUtil.displayMessage(MessageUtil.LogLevel.INFO,
                    "§aConfig '" + configName + "' загружена");
            } else {
                MessageUtil.displayMessage(MessageUtil.LogLevel.WARN,
                    "§cError loading config '" + configName + "'");
            }
            return SINGLE_SUCCESS;
        })));

        builder.then(literal("delete").then(arg("name", string()).executes(context -> {
            String configName = StringArgumentType.getString(context, "name");
            boolean success = Okyware.getInstance().getConfigManager().deleteConfig(configName);
            if (success) {
                MessageUtil.displayMessage(MessageUtil.LogLevel.INFO,
                    "§aConfig '" + configName + "' удалена");
            } else {
                MessageUtil.displayMessage(MessageUtil.LogLevel.WARN,
                    "§cError deleting config '" + configName + "'");
            }
            return SINGLE_SUCCESS;
        })));

        builder.then(literal("list").executes(context -> {
            var configs = Okyware.getInstance().getConfigManager().configNames();
            if (configs.isEmpty()) {
                MessageUtil.displayMessage(MessageUtil.LogLevel.INFO, "§7No saved configs");
            } else {
                MessageUtil.displayMessage(MessageUtil.LogLevel.INFO, "§aAvailable configs:");
                for (String config : configs) {
                    MessageUtil.displayMessage(MessageUtil.LogLevel.INFO, "§7- " + config);
                }
            }
            return SINGLE_SUCCESS;
        }));
        
        builder.then(literal("reset").executes(context -> {
            boolean success = Okyware.getInstance().getConfigManager().deleteConfig("current_config");
            for (okyware.wtf.client.modules.api.Module m : Okyware.getInstance().getModuleManager().getModules()) {
                if (m.isEnabled()) m.setToggled(false);
            }
            MessageUtil.displayMessage(MessageUtil.LogLevel.INFO,
                "§aConfig reset. Modules disabled. Restart the game to reset settings to default.");
            return SINGLE_SUCCESS;
        }));

        builder.executes(context -> {
            MessageUtil.displayMessage(MessageUtil.LogLevel.INFO,
                "§6Usage: §r.config <list/save/load/delete/reset/help> [name]");
            return SINGLE_SUCCESS;
        });

        builder.then(literal("help").executes(context -> {
            MessageUtil.displayMessage(MessageUtil.LogLevel.INFO,
                "§6Usage: §r.config <list/save/load/delete/reset/help> [name]");
            MessageUtil.displayMessage(MessageUtil.LogLevel.INFO,
                "§6Commands:§r");
            MessageUtil.displayMessage(MessageUtil.LogLevel.INFO,
                "§e.config save <name> §7- save config with name");
            MessageUtil.displayMessage(MessageUtil.LogLevel.INFO,
                "§e.config load <name> §7- load config by name");
            MessageUtil.displayMessage(MessageUtil.LogLevel.INFO,
                "§e.config delete <name> §7- delete config");
            MessageUtil.displayMessage(MessageUtil.LogLevel.INFO,
                "§e.config list §7- list all configs");
            MessageUtil.displayMessage(MessageUtil.LogLevel.INFO,
                "§e.config reset §7- reset current config");
            return SINGLE_SUCCESS;
        }));
    }
}
