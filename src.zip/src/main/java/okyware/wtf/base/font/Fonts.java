package okyware.wtf.base.font;

import lombok.experimental.UtilityClass;

@UtilityClass
public class Fonts {

    

    public final MsdfFont BOLD = MsdfFont.builder().atlas("lexend-bold").data("lexend-bold").build();
    public final MsdfFont MEDIUM = MsdfFont.builder().atlas("lexend").data("lexend").build();

    public final MsdfFont REGULAR = MsdfFont.builder().atlas("lexend-regular").data("lexend-regular").build();
    public final MsdfFont SEMIBOLD = MsdfFont.builder().atlas("lexend-semibold").data("lexend-semibold").build();
    public final MsdfFont ROUND_BOLD = MsdfFont.builder().atlas("lexend-bold").data("lexend-bold").build();
    public final MsdfFont ICONS = MsdfFont.builder().atlas("icons").data("icons").build();

}