package okyware.wtf.client.hud.elements.component;

import okyware.wtf.Okyware;
import okyware.wtf.base.font.Font;
import okyware.wtf.base.font.Fonts;
import okyware.wtf.base.theme.Theme;
import okyware.wtf.client.hud.elements.draggable.DraggableHudElement;
import okyware.wtf.client.modules.impl.render.Interface;
import okyware.wtf.utility.render.display.base.BorderRadius;
import okyware.wtf.utility.render.display.base.CustomDrawContext;
import okyware.wtf.utility.render.display.base.color.ColorRGBA;
import okyware.wtf.utility.render.display.shader.DrawUtil;

public class BpsComponent extends DraggableHudElement {

    public BpsComponent(String name, float initialX, float initialY, float windowWidth, float windowHeight,
            float offsetX, float offsetY, Align align) {
        super(name, initialX, initialY, windowWidth, windowHeight, offsetX, offsetY, align);
    }

    @Override
    public void render(CustomDrawContext ctx) {
        if (mc.player == null) return;

        double speed = Math.hypot(mc.player.getX() - mc.player.prevX, mc.player.getZ() - mc.player.prevZ);
        String value = String.format("%.2f", speed * 20F).replace(",", ".");
        String suffix = " bps";

        Theme theme = Okyware.getInstance().getThemeManager().getCurrentTheme();
        Font font = Fonts.MEDIUM.getFont(7);
        ColorRGBA valueColor = theme.getWhite();
        ColorRGBA suffixColor = theme.getGrayLight();

        float valueW = font.width(value);
        float suffixW = font.width(suffix);
        float padX = 6f;
        float padY = 4f;
        this.width = valueW + suffixW + padX * 2;
        this.height = font.height() + padY * 2;

        BorderRadius radius = BorderRadius.all(4);
        if (Interface.INSTANCE.isBlur()) {
            DrawUtil.drawBlurHud(ctx.getMatrices(), x, y, width, height, 21, radius, ColorRGBA.WHITE);
        }
        ctx.drawRoundedRect(x, y, width, height, radius, Interface.INSTANCE.fadeBackdrop(Interface.INSTANCE.getBgColor()));
        if (Interface.INSTANCE.isBorders()) {
            ctx.drawRoundedBorder(x, y, width, height, 0.5f, radius, new ColorRGBA(255, 255, 255, 25));
        }

        float textX = x + padX;
        float textY = y + (height - font.height()) / 2f;
        ctx.drawText(font, value, textX, textY, valueColor);
        ctx.drawText(font, suffix, textX + valueW, textY, suffixColor);
    }
}
