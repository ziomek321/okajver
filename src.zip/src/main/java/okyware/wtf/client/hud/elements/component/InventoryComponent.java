package okyware.wtf.client.hud.elements.component;

import net.minecraft.item.ItemStack;
import okyware.wtf.Okyware;
import okyware.wtf.base.animations.base.Animation;
import okyware.wtf.base.animations.base.Easing;
import okyware.wtf.base.font.Font;
import okyware.wtf.base.font.Fonts;
import okyware.wtf.base.theme.Theme;
import okyware.wtf.client.hud.elements.draggable.DraggableHudElement;
import okyware.wtf.utility.mixin.accessors.DrawContextAccessor;
import okyware.wtf.utility.render.display.base.BorderRadius;
import okyware.wtf.utility.render.display.base.CustomDrawContext;
import okyware.wtf.utility.render.display.base.color.ColorRGBA;
import okyware.wtf.utility.render.display.shader.DrawUtil;

public class InventoryComponent extends DraggableHudElement {

    private final Animation toggleAnimation = new Animation(300, Easing.SINE_IN_OUT);
    private final Animation inventoryChangeAnimation = new Animation(150, Easing.SINE_IN_OUT);
    private String lastInventoryHash = "";
    private float lastWidth = 0f;
    private float lastHeight = 0f;

    public InventoryComponent(String name, float initialX, float initialY, float windowWidth, float windowHeight, float offsetX, float offsetY, Align align) {
        super(name,initialX, initialY,windowWidth,windowHeight,offsetX,offsetY,align);

    }

    @Override
    public void render(CustomDrawContext ctx) {
        if (mc.player == null) {
            toggleAnimation.update(0);
            if (toggleAnimation.getValue() > 0.01f) {
                renderInventory(ctx, toggleAnimation.getValue());
            }
            return;
        }

        toggleAnimation.update(1);
        if (toggleAnimation.getValue() <= 0.01f) return;

        String currentInventoryHash = "";
        for (int i = 9; i < 36; i++) {
            ItemStack stack = mc.player.getInventory().getStack(i);
            currentInventoryHash += stack.getItem().toString() + stack.getCount();
        }
        
        if (!currentInventoryHash.equals(lastInventoryHash)) {
            inventoryChangeAnimation.update(0);
            lastInventoryHash = currentInventoryHash;
        }
        inventoryChangeAnimation.update(1);

        renderInventory(ctx, toggleAnimation.getValue() * inventoryChangeAnimation.getValue());
    }

    private void renderInventory(CustomDrawContext ctx, float animationValue) {
        if (mc.player == null) {
            Theme theme = Okyware.getInstance().getThemeManager().getCurrentTheme();
            ColorRGBA bgColor = theme.getForegroundColor();
            
            ctx.getMatrices().push();
            ctx.getMatrices().translate(x + lastWidth / 2f, y + lastHeight / 2f, 0f);
            ctx.getMatrices().scale(animationValue, animationValue, 1f);
            ctx.getMatrices().translate(-(x + lastWidth / 2f), -(y + lastHeight / 2f), 0f);
            
            ctx.drawRoundedRect(x, y, lastWidth, lastHeight, BorderRadius.all(4f), new ColorRGBA(20, 20, 25, 120));
            
            ctx.getMatrices().pop();
            return;
        }

        Font countFont = Fonts.MEDIUM.getFont(6);
        float slotSize = 20;
        float borderRadius = 4f;
        Theme theme = Okyware.getInstance().getThemeManager().getCurrentTheme();


        ColorRGBA graySlotColor = theme.getForegroundColor();
        ColorRGBA themeSlotColor = theme.getForegroundLight();

        int columns = 9;
        int rows = 3;
        float gridWidth = columns * slotSize;
        float gridHeight = rows * slotSize;

        this.width = gridWidth;
        this.height = gridHeight;
        
        lastWidth = width;
        lastHeight = height;

        ctx.getMatrices().push();
        ctx.getMatrices().translate(x + width / 2f, y + height / 2f, 0f);
        ctx.getMatrices().scale(animationValue, animationValue, 1f);
        ctx.getMatrices().translate(-(x + width / 2f), -(y + height / 2f), 0f);
        if (okyware.wtf.client.modules.impl.render.Interface.INSTANCE.isBlur()) {
            DrawUtil.drawBlur(ctx.getMatrices(), x, y, gridWidth, gridHeight, 15f, BorderRadius.all(4f), ColorRGBA.WHITE);
        }

        ctx.drawRoundedRect(x, y, gridWidth, gridHeight, BorderRadius.all(4f), new ColorRGBA(20, 20, 25, 120));

        for (int row = 0; row < rows; row++) {
            for (int col = 0; col < columns; col++) {
                int slotIndex = 9 + row * 9 + col;
                ItemStack stack = mc.player.getInventory().getStack(slotIndex);
                
                float slotX = (x + col * slotSize);
                float slotY =(y + row * slotSize);
                
                if (!stack.isEmpty()) {
                    ctx.pushMatrix();
                    ctx.getMatrices().translate(slotX+(slotSize-12.8)/2, slotY+(slotSize-12.8)/2, 0f);
                    ctx.getMatrices().scale(0.8f, 0.8f, 1f);

                    ctx.drawItem(stack, 0,0);

                    ((DrawContextAccessor) ctx).callDrawItemBar(stack,0,0);
                    ((DrawContextAccessor) ctx).callDrawCooldownProgress(stack,0,0);
                    ctx.popMatrix();

                }
            }
        }
      
        if (!okyware.wtf.client.modules.impl.render.Interface.INSTANCE.isTransparentBackdrop()) {
            ctx.drawRoundedBorder(x, y,gridWidth,gridHeight,0.1f,BorderRadius.all(4),theme.getForegroundStroke());
            DrawUtil.drawRoundedCorner(ctx.getMatrices(), x, y,gridWidth,gridHeight,0.1f,20f,theme.getColor(),BorderRadius.all(4));
        }

        ctx.getMatrices().pop();
    }



}
