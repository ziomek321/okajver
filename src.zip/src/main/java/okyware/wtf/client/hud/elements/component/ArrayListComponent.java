package okyware.wtf.client.hud.elements.component;
 
import okyware.wtf.Okyware;
import okyware.wtf.base.animations.base.Animation;
import okyware.wtf.base.animations.base.Easing;
import okyware.wtf.base.font.Font;
import okyware.wtf.base.font.Fonts;
import okyware.wtf.client.hud.elements.draggable.DraggableHudElement;
import okyware.wtf.client.modules.api.Module;
import okyware.wtf.client.modules.api.setting.Setting;
import okyware.wtf.client.modules.api.setting.impl.ColorSetting;
import okyware.wtf.client.modules.api.setting.impl.NumberSetting;
import okyware.wtf.utility.render.display.base.BorderRadius;
import okyware.wtf.utility.render.display.base.CustomDrawContext;
import okyware.wtf.utility.render.display.base.color.ColorRGBA;
import okyware.wtf.utility.render.display.shader.DrawUtil;
import okyware.wtf.client.modules.impl.render.Interface;
 
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
 
public class ArrayListComponent extends DraggableHudElement {
    private final Map<Module, Animation> moduleAnimations = new HashMap<>();
    private final Map<Module, Animation> yAnimations = new HashMap<>();
    private final Animation widthAnimation = new Animation(300, 40f, Easing.QUAD_OUT);
 
    private final ColorSetting bgColor = new ColorSetting("Background Color", new ColorRGBA(0, 0, 0, 140));
    private final NumberSetting roundness = new NumberSetting("Roundness", 1.5f, 0.0f, 2.2f, 0.1f);
    private final okyware.wtf.client.modules.api.setting.impl.ModeSetting design = new okyware.wtf.client.modules.api.setting.impl.ModeSetting("Design", "Stacked", "Separate");
 
    @Override
    public List<Setting> getSettings() {
        return List.of(bgColor, roundness, design);
    }
 
    public ArrayListComponent(String name, float initialX, float initialY, float windowWidth, float windowHeight,
            float offsetX, float offsetY, Align align) {
        super(name, initialX, initialY, windowWidth, windowHeight, offsetX, offsetY, align);
    }
 
    @Override
    public void render(CustomDrawContext ctx) {
        Font font = Fonts.MEDIUM.getFont(8.5f);
        List<Module> allModules = Okyware.getInstance().getModuleManager().getModules();
 
        for (Module module : allModules) {
            moduleAnimations.computeIfAbsent(module, m -> new Animation(350, 0, Easing.BACK_OUT))
                    .update(module.isEnabled() ? 1f : 0f);
        }
 
        List<Module> visibleModules = allModules.stream()
                .filter(m -> m.isEnabled() || !moduleAnimations.get(m).isDone() || moduleAnimations.get(m).getValue() > 0.001f)
                .sorted((m1, m2) -> Float.compare(font.width(m2.getName()), font.width(m1.getName())))
                .collect(Collectors.toList());
 
        if (visibleModules.isEmpty()) {
            this.width = 60f;
            this.height = 1f;
            return;
        }
 
        float padX = 7f;
        float padY = 3.5f;
        float pillHeight = font.height() + padY * 2f;
        float gap = design.is("Separate") ? 2f : 0f;
        float cornerR = roundness.getCurrent();
 
        
        float maxWidth = 0f;
        for (Module module : visibleModules) {
            float pw = font.width(module.getName()) + padX * 2f;
            if (pw > maxWidth) maxWidth = pw;
        }
        float targetWidth = Math.max(maxWidth, 40f);
        widthAnimation.animateTo(targetWidth);
        this.width = widthAnimation.update();
 
        
        ColorRGBA backgroundCol = bgColor.getColor();
 
        float currentY = y;
        for (int i = 0; i < visibleModules.size(); i++) {
            Module module = visibleModules.get(i);
            float anim = moduleAnimations.get(module).getValue();
            String name = module.getName();
 
            float targetY = currentY;
            Animation yAnim = yAnimations.computeIfAbsent(module, m -> new Animation(300, targetY, Easing.QUAD_OUT));
            yAnim.animateTo(targetY);
            float animatedY = yAnim.update();
 
            
            float pillWidth = font.width(name) + padX * 2f;
 
            
            float pillX = x + this.width - pillWidth;
 
            
            float alpha = Math.max(0f, Math.min(1f, anim));
 
            
            
            BorderRadius radius;
            if (design.is("Separate")) {
                radius = new BorderRadius(cornerR, cornerR, cornerR, cornerR);
            } else {
                
                
                radius = new BorderRadius(cornerR, 0f, 0f, cornerR);
            }
 
            
            ColorRGBA finalBg = Interface.INSTANCE.fadeBackdrop(backgroundCol.mulAlpha(alpha));
 
            
            float scale = Math.max(0f, anim);
            float cx = pillX + pillWidth / 2f;
            float cy = animatedY + pillHeight / 2f;
            ctx.pushMatrix();
            ctx.getMatrices().translate(cx, cy, 0f);
            ctx.getMatrices().scale(scale, scale, 1f);
            ctx.getMatrices().translate(-cx, -cy, 0f);
 
            if (Interface.INSTANCE.isBlur()) {
                DrawUtil.drawBlur(ctx.getMatrices(), pillX, animatedY, pillWidth, pillHeight, 12 * alpha, radius, ColorRGBA.WHITE.mulAlpha(alpha));
            }
            ctx.drawRoundedRect(pillX, animatedY, pillWidth, pillHeight, radius, finalBg);
 
            
            float textX = pillX + padX;
            ctx.drawText(font, name, textX, animatedY + (pillHeight - font.height()) / 2f + 0.5f, ColorRGBA.WHITE.mulAlpha(alpha * 0.9f));
 
            
            if (Interface.INSTANCE.isBorders()) {
                ctx.drawRoundedBorder(pillX, animatedY, pillWidth, pillHeight, 0.5f, radius, new ColorRGBA(255, 255, 255, (int) (20 * alpha)));
            }
 
            ctx.popMatrix();
 
            currentY += (pillHeight + gap) * Math.max(0f, Math.min(1f, anim));
        }
 
        this.height = Math.max(1f, currentY - y);
    }
}
