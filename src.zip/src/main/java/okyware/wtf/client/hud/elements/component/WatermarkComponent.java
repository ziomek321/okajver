package okyware.wtf.client.hud.elements.component;
import net.minecraft.util.Identifier;

import okyware.wtf.Okyware;
import okyware.wtf.base.font.Font;
import okyware.wtf.base.font.Fonts;
import okyware.wtf.base.license.LicenseManager;
import okyware.wtf.base.theme.Theme;
import okyware.wtf.client.hud.elements.HudElement;
import okyware.wtf.client.hud.elements.draggable.DraggableHudElement;
import okyware.wtf.client.modules.impl.render.Interface;
import okyware.wtf.client.modules.api.setting.Setting;
import okyware.wtf.client.modules.api.setting.impl.BooleanSetting;
import okyware.wtf.client.modules.api.setting.impl.ModeSetting;
import okyware.wtf.client.modules.api.setting.impl.NumberSetting;
import okyware.wtf.utility.game.other.TextUtil;
import okyware.wtf.utility.render.display.base.BorderRadius;
import okyware.wtf.utility.render.display.base.CustomDrawContext;
import okyware.wtf.utility.render.display.base.color.ColorRGBA;
import okyware.wtf.utility.render.display.shader.DrawUtil;

import java.util.ArrayList;
import java.util.List;

public class WatermarkComponent extends DraggableHudElement {
    private final List<HudElement> elements = new ArrayList<>();

    
    
    private int prevFps = -1;
    private int currFps = -1;
    private long fpsChangedAt = 0L;
    private final BooleanSetting showName = new BooleanSetting("Show Name", true);
    private final BooleanSetting showFps = new BooleanSetting("Show FPS", true);
    private final BooleanSetting showUid = new BooleanSetting("Show UID", false);

    private static final long FPS_SLIDE_MS = 250;

    @Override
    public List<Setting> getSettings() {
        return List.of(showName, showFps, showUid);
    }

    private String fpsString() {
        int now = mc.getCurrentFps();
        if (currFps == -1) {
            currFps = prevFps = now;
        } else if (now != currFps) {
            prevFps = currFps;
            currFps = now;
            fpsChangedAt = System.currentTimeMillis();
        }
        return String.valueOf(currFps);
    }

    private float fpsSlideProgress() {
        long elapsed = System.currentTimeMillis() - fpsChangedAt;
        if (elapsed >= FPS_SLIDE_MS) return 1f;
        return elapsed / (float) FPS_SLIDE_MS;
    }

    public WatermarkComponent(String name, float initialX, float initialY, float windowWidth, float windowHeight,
            float offsetX, float offsetY, Align align) {
        super(name, initialX, initialY, windowWidth, windowHeight, offsetX, offsetY, align);
    }

    @Override
    public void render(CustomDrawContext ctx) {
        float iconSize = 10f;
        float iconTextSpacing = 5f;
        float cellPadding = 6f;
        Theme theme = Okyware.getInstance().getThemeManager().getCurrentTheme();

        ColorRGBA iconColor = theme.getColor();
        ColorRGBA textColor = theme.getWhite();
        Font font = Fonts.MEDIUM.getFont(6.5f);

        elements.clear();
        
        elements.add(new HudElement(" ", () -> "", ""));

        
        int fpsIndex = -1;
        int nameIndex = -1;
        int uidIndex = -1;
        int infoIndex = 1;

        if (showName.isEnabled()) {
            nameIndex = infoIndex;
            elements.add(new HudElement("2", () -> LicenseManager.INSTANCE.getNickname()));
            infoIndex++;
        }
        if (showFps.isEnabled()) {
            fpsIndex = infoIndex;
            elements.add(new HudElement("G", this::fpsString, "fps"));
            infoIndex++;
        }
        if (showUid.isEnabled()) {
            uidIndex = infoIndex;
            elements.add(new HudElement("2", () -> "UID: " + LicenseManager.INSTANCE.getUid()));
            infoIndex++;
        }

        for (HudElement el : elements) {
            el.calculateWidth(font, iconSize, cellPadding, iconTextSpacing);
        }

        final int finalFpsIndex = fpsIndex;
        final int finalNameIndex = nameIndex;
        final int finalUidIndex = uidIndex;

        float infoWidth = 0;
        for (int i = 1; i < elements.size(); i++) {
            infoWidth += elements.get(i).getWidth();
        }
        infoWidth += 10;

        float totalHeight = 20;
        this.width = infoWidth;
        this.height = totalHeight;

        drawBackground(ctx, x, y, infoWidth, totalHeight);

        float currentX = x + 2;
        for (int i = 1; i < elements.size(); i++) {
            HudElement el = elements.get(i);
            if (i == finalFpsIndex) {
                drawFpsCell(ctx, currentX, y, totalHeight, el.getWidth(), iconSize, iconTextSpacing, iconColor, textColor, font);
            } else if (i == finalNameIndex) {
                drawLogo2Cell(ctx, currentX, y, totalHeight, el.getWidth(), iconSize, iconTextSpacing, iconColor, textColor, font, LicenseManager.INSTANCE.getNickname(), "");
            } else if (i == finalUidIndex) {
                drawLogo2Cell(ctx, currentX, y, totalHeight, el.getWidth(), iconSize, iconTextSpacing, iconColor, textColor, font, "UID: " + LicenseManager.INSTANCE.getUid(), "");
            } else {
                el.drawContent(ctx, currentX, y, totalHeight, iconSize, iconTextSpacing, iconColor, textColor, font);
            }
            currentX += el.getWidth();
        }

    }

    private void drawFpsCell(CustomDrawContext ctx, float blockX, float blockY, float blockHeight, float cellWidth,
                             float iconSize, float iconTextSpacing, ColorRGBA iconColor, ColorRGBA textColor, Font font) {
        Font iconFont = Fonts.ICONS.getFont(8);
        String prefix = "fps";
        String newText = String.valueOf(currFps);
        String oldText = String.valueOf(prevFps);

        float textWidth = font.width(newText) + font.width(prefix) + 1;
        float contentBlockWidth = font.width("G") + iconTextSpacing + iconTextSpacing / 2 + textWidth;
        float contentX = blockX + (cellWidth - contentBlockWidth) / 2f;
        float iconY = blockY + (blockHeight - iconFont.height()) / 2f;
        float textY = blockY + (blockHeight - font.height()) / 2f;

        ctx.drawText(iconFont, "G", contentX, textY, iconColor);
        contentX += iconSize + iconTextSpacing;

        float prog = fpsSlideProgress();
        float lineH = font.height() + 2;
        
        ctx.enableScissor((int) contentX - 1, (int) blockY, (int) (contentX + font.width(newText) + 2), (int) (blockY + blockHeight));
        if (prog < 1f) {
            float yOld = textY + lineH * prog;
            float yNew = textY - lineH + lineH * prog;
            ctx.drawText(font, oldText, contentX, yOld, textColor);
            ctx.drawText(font, newText, contentX, yNew, textColor);
        } else {
            ctx.drawText(font, newText, contentX, textY, textColor);
        }
        ctx.disableScissor();

        ctx.drawText(font, prefix, contentX + font.width(newText) + 1, textY,
                Okyware.getInstance().getThemeManager().getCurrentTheme().getGrayLight());
    }

    private void drawLogo2Cell(CustomDrawContext ctx, float blockX, float blockY, float blockHeight, float cellWidth,
                               float iconSize, float iconTextSpacing, ColorRGBA iconColor, ColorRGBA textColor, Font font, String text, String prefix) {
        float textWidth = font.width(text) + (prefix.isEmpty() ? 0 : font.width(prefix) + 1);
        float contentBlockWidth = font.width("2") + iconTextSpacing + iconTextSpacing / 2 + textWidth;
        float contentX = blockX + (cellWidth - contentBlockWidth) / 2f;
        float textY = blockY + (blockHeight - font.height()) / 2f;

        Font logoFont = Fonts.ICONS.getFont(10f);
        float logoY = blockY + (blockHeight - logoFont.height()) / 2f;

        ctx.drawText(logoFont, "\u1000", contentX, logoY, iconColor);
        contentX += iconSize + iconTextSpacing;

        ctx.drawText(font, text, contentX, textY, textColor);
        if (!prefix.isEmpty()) {
            ctx.drawText(font, prefix, contentX + font.width(text) + 1, textY, Okyware.getInstance().getThemeManager().getCurrentTheme().getGrayLight());
        }
    }

    @Override
    public void rightClick() {
        
    }

    private void drawBackground(CustomDrawContext ctx, float bx, float by, float bw, float bh) {
        BorderRadius radius = BorderRadius.all(4.0f);
        DrawUtil.drawBlur(ctx.getMatrices(), bx, by, bw, bh, 15f, radius, ColorRGBA.WHITE);
        ctx.drawRoundedRect(bx, by, bw, bh, radius, new ColorRGBA(20, 20, 25, 120));
    }
}
