package okyware.wtf.client.hud.elements.component;

import okyware.wtf.Okyware;
import okyware.wtf.base.font.Font;
import okyware.wtf.base.font.Fonts;
import okyware.wtf.base.theme.Theme;
import okyware.wtf.client.hud.elements.draggable.DraggableHudElement;
import okyware.wtf.client.modules.api.Module;
import okyware.wtf.client.modules.impl.render.Interface;
import okyware.wtf.client.modules.api.setting.Setting;
import okyware.wtf.client.modules.api.setting.impl.ColorSetting;
import okyware.wtf.client.modules.api.setting.impl.NumberSetting;
import okyware.wtf.utility.render.display.base.BorderRadius;
import okyware.wtf.utility.render.display.base.CustomDrawContext;
import okyware.wtf.utility.render.display.base.color.ColorRGBA;
import okyware.wtf.utility.render.display.shader.DrawUtil;
import net.minecraft.client.gui.screen.ChatScreen;

import java.util.List;
import java.util.stream.Collectors;

public class KeybindsComponent extends DraggableHudElement {

    private final ColorSetting bgColor = new ColorSetting("Background Color", new ColorRGBA(0, 0, 0, 180));
    private final NumberSetting roundness = new NumberSetting("Roundness", 4.0f, 0.0f, 10.0f, 0.5f);

    @Override
    public List<Setting> getSettings() {
        return List.of(bgColor, roundness);
    }

    public KeybindsComponent(String name, float initialX, float initialY, float windowWidth, float windowHeight, float offsetX, float offsetY, Align align) {
        super(name, initialX, initialY, windowWidth, windowHeight, offsetX, offsetY, align);
    }

    @Override
    public void render(CustomDrawContext ctx) {
        List<Module> boundModules = Okyware.getInstance().getModuleManager().getModules().stream()
                .filter(m -> m.getKeyCode() > 0)
                .collect(Collectors.toList());

        if (boundModules.isEmpty() && !(mc.currentScreen instanceof ChatScreen)) return;

        Font font = Fonts.MEDIUM.getFont(7.5f);
        float padX = 8f;
        float padY = 6f;
        float headerHeight = 20f;
        float itemHeight = 16f;

        Font keyFont = Fonts.SEMIBOLD.getFont(7.5f);
        float maxWidth = 80f;
        for (Module m : boundModules) {
            String keyName = "";
            try {
                keyName = okyware.wtf.utility.render.display.Keyboard.getKeyName(m.getKeyCode()).toUpperCase().replace("_", " ");
            } catch (Exception ignored) {}
            
            float w = font.width(m.getName()) + keyFont.width(keyName) + 35f;
            if (w > maxWidth) maxWidth = w;
        }

        this.width = maxWidth;
        this.height = headerHeight + boundModules.size() * itemHeight + 4;

        Theme theme = Okyware.getInstance().getThemeManager().getCurrentTheme();
        ColorRGBA blackBg = bgColor.getColor();
        BorderRadius radius = BorderRadius.all(roundness.getCurrent());

        
        if (Interface.INSTANCE.isBlur()) {
            DrawUtil.drawBlur(ctx.getMatrices(), x, y, width, height, 15f, radius, ColorRGBA.WHITE);
        }
        ctx.drawRoundedRect(x, y, width, height, radius, new ColorRGBA(20, 20, 25, 120));
        
        if (Interface.INSTANCE.isBorders()) {
            ctx.drawRoundedBorder(x, y, width, height, 0.5f, radius, new ColorRGBA(255, 255, 255, 20));
        }

        
        ctx.drawRoundedRect(x, y, width, headerHeight, BorderRadius.top(roundness.getCurrent(), roundness.getCurrent()), theme.getForegroundColor().mulAlpha(0.6f));
        Font iconFont = Fonts.ICONS.getFont(10);
        float iconX = x + 6f;
        float iconY = y + (headerHeight - iconFont.height()) / 2f;

        Font customIconFont = Fonts.ICONS.getFont(10);
        float iconW = customIconFont.width("\u1001"); 
        ctx.drawText(customIconFont, "\u1001", iconX, iconY, theme.getWhite());
        ctx.drawText(font, "Keybinds", iconX + iconW + 6f, y + (headerHeight - font.height()) / 2f, theme.getWhite());

        
        float currentY = y + headerHeight + 2;
        for (Module m : boundModules) {
            String keyName = "";
            try {
                keyName = okyware.wtf.utility.render.display.Keyboard.getKeyName(m.getKeyCode()).toUpperCase().replace("_", " ");
            } catch (Exception ignored) {}

            ColorRGBA nameColor = m.isEnabled() ? theme.getWhite().mulAlpha(0.9f) : theme.getGray().mulAlpha(0.8f);
            ctx.drawText(font, m.getName(), x + padX, currentY + (itemHeight - font.height()) / 2f, nameColor);

            float keyW = keyFont.width(keyName);
            float keyBadgePadX = 6f; 
            float keyBadgePadY = 3.5f; 
            float keyBadgeX = x + width - padX - keyW - keyBadgePadX;
            float keyBadgeY = currentY + (itemHeight - font.height()) / 2f - keyBadgePadY;
            ctx.drawRoundedRect(keyBadgeX, keyBadgeY, keyW + keyBadgePadX * 2, font.height() + keyBadgePadY * 2, BorderRadius.all(3), new ColorRGBA(255, 255, 255, 40));
            ctx.drawText(keyFont, keyName, x + width - padX - keyW, currentY + (itemHeight - font.height()) / 2f, theme.getWhite());
            
            currentY += itemHeight;
        }
    }
}
