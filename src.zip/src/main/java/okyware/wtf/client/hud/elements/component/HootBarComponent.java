package okyware.wtf.client.hud.elements.component;

import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.hud.PlayerListHud;
import net.minecraft.client.render.RenderTickCounter;
import net.minecraft.component.DataComponentTypes;
import net.minecraft.item.ItemStack;
import net.minecraft.text.MutableText;
import net.minecraft.text.Text;
import net.minecraft.util.Colors;
import net.minecraft.util.Formatting;
import net.minecraft.util.math.ColorHelper;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.profiler.Profilers;
import okyware.wtf.Okyware;
import okyware.wtf.base.animations.base.Animation;
import okyware.wtf.base.animations.base.Easing;
import okyware.wtf.base.font.Font;
import okyware.wtf.base.font.Fonts;
import okyware.wtf.base.theme.Theme;
import okyware.wtf.client.hud.elements.draggable.DraggableHudElement;
import okyware.wtf.utility.mixin.accessors.DrawContextAccessor;
import okyware.wtf.utility.mixin.accessors.InGameHudAccessor;
import okyware.wtf.utility.render.display.base.BorderRadius;
import okyware.wtf.utility.render.display.base.CustomDrawContext;
import okyware.wtf.utility.render.display.base.color.ColorRGBA;
import okyware.wtf.utility.render.display.shader.DrawUtil;

import java.util.ArrayList;
import java.util.List;

public class HootBarComponent extends DraggableHudElement {
    List<HotBarSlot> slots = new ArrayList<>();
    private final Animation selectedSlotX = new Animation(180, 0, Easing.QUAD_IN_OUT);

    public HootBarComponent(String name, float initialX, float initialY, float windowWidth, float windowHeight, float offsetX, float offsetY, Align align) {
        super(name,initialX, initialY,windowWidth,windowHeight,offsetX,offsetY,align);
        float itemSize = 24;
        width = itemSize * 9;
        height = itemSize;
        for (int i = 0; i < 9; i++) {
            slots.add(new HotBarSlot(i));
        }
    }

    private void drawSelectedHighlight(CustomDrawContext ctx, float posX, float posY, Theme theme) {
        float slotW = 24f;
        selectedSlotX.update(mc.player.getInventory().selectedSlot * slotW);
        float hx = posX + selectedSlotX.getValue();
        
        BorderRadius br;
        float t = selectedSlotX.getValue() / slotW;
        if (t < 0.05f) br = BorderRadius.left(6, 6);
        else if (t > 7.95f) br = BorderRadius.right(6, 6);
        else br = BorderRadius.ZERO;
        ctx.drawRoundedRect(hx, posY, slotW, slotW, br, theme.getColor().mulAlpha(0.55f));
    }

    @Override
    public void render(CustomDrawContext ctx) {

        x= (ctx.getScaledWindowWidth()-width )/2;
        float posX = getX();
        float posY = getY();

        Theme theme = Okyware.getInstance().getThemeManager().getCurrentTheme();

        if(mc.interactionManager.hasCreativeInventory()) {
            renderHeldItemTooltip(ctx,posY-35);
            renderOverlayMessage(ctx,mc.getRenderTickCounter(),posY-35-9);
            Font font = Fonts.MEDIUM.getFont(7);
            drawXpBar(ctx, posX, posY, width);

            DrawUtil.drawBlurHud(ctx.getMatrices(), x, y, width, height, 21, BorderRadius.all(4), ColorRGBA.WHITE);

            
            ItemStack offHand = mc.player.getOffHandStack();
            if(!offHand.isEmpty()) {
                float offHandX=posX - height - 12;
                float offHandY=posY;
                DrawUtil.drawBlurHud(ctx.getMatrices(),offHandX, offHandY, height, height, 21, BorderRadius.all(4), ColorRGBA.WHITE);

                
                ctx.pushMatrix();
                ctx.getMatrices().translate(offHandX + (24 - 12.8) / 2f, offHandY + (24 - 12.8) / 2f, 1);
                ctx.getMatrices().scale(0.8f, 0.8f, 0.8f);
                ctx.drawItem(offHand, 0, 0);

                ((DrawContextAccessor) ctx).callDrawItemBar(offHand, 0, 0);
                ((DrawContextAccessor) ctx).callDrawCooldownProgress(offHand, 0, 0);


                ctx.popMatrix();

                if (offHand.getCount() > 1) {
                    String countText = "x" + String.valueOf(offHand.getCount());
                    float countWidth = font.width(countText);
                    float countX = offHandX + 24 - countWidth - 1f;
                    float countY = offHandY + 24 - font.height() - 3;

                    ctx.drawText(font, countText, countX, countY,  theme.getGray());
                }
            }

            
            for (int i = 0; i < slots.size(); i++) {
                float sx = posX + i * height;
                BorderRadius sr = i == 0 ? BorderRadius.left(6, 6) : i == 8 ? BorderRadius.right(6, 6) : BorderRadius.ZERO;
                ctx.drawRoundedRect(sx, posY, height, height, sr, new ColorRGBA(0, 0, 0, 178));
            }
            drawSelectedHighlight(ctx, posX, posY, theme);

            float xSlot = posX;
            for (HotBarSlot slot : slots) {
                slot.render(ctx, xSlot, posY, theme);
                xSlot += height;
            }


            
            return;
        }

        if(mc.interactionManager.hasStatusBars()) {
            ctx.pushMatrix();
            ctx.getMatrices().translate(-(ctx.getScaledWindowWidth() / 2 - 91), -(ctx.getScaledWindowHeight() - 39), 0);
            ctx.getMatrices().scale(1, 1, 1);
            ctx.getMatrices().translate(posX, 0, 0);


            ctx.getMatrices().translate(0, posY - 15, 0);

            if (!mc.interactionManager.hasCreativeInventory()) {
                ((InGameHudAccessor) mc.inGameHud).invokeRenderStatusBars(ctx);
            }

            ctx.popMatrix();

            renderHeldItemTooltip(ctx,posY-35);
            renderOverlayMessage(ctx,mc.getRenderTickCounter(),posY-35-9);
            Font font = Fonts.MEDIUM.getFont(7);
            drawXpBar(ctx, posX, posY, width);

            DrawUtil.drawBlurHud(ctx.getMatrices(), x, y, width, height, 21, BorderRadius.all(4), ColorRGBA.WHITE);

            
            ItemStack offHand = mc.player.getOffHandStack();
            if(!offHand.isEmpty()) {
                float offHandX=posX - height - 12;
                float offHandY=posY;
                DrawUtil.drawBlurHud(ctx.getMatrices(),offHandX, offHandY, height, height, 21, BorderRadius.all(4), ColorRGBA.WHITE);

                
                ctx.pushMatrix();
                ctx.getMatrices().translate(offHandX + (24 - 12.8) / 2f, offHandY + (24 - 12.8) / 2f, 1);
                ctx.getMatrices().scale(0.8f, 0.8f, 0.8f);
                ctx.drawItem(offHand, 0, 0);

                ((DrawContextAccessor) ctx).callDrawItemBar(offHand, 0, 0);
                ((DrawContextAccessor) ctx).callDrawCooldownProgress(offHand, 0, 0);


                ctx.popMatrix();

                if (offHand.getCount() > 1) {
                    String countText = "x" + String.valueOf(offHand.getCount());
                    float countWidth = font.width(countText);
                    float countX = offHandX + 24 - countWidth - 1f;
                    float countY = offHandY + 24 - font.height() - 3;

                    ctx.drawText(font, countText, countX, countY,  theme.getGray());
                }
            }

            
            for (int i = 0; i < slots.size(); i++) {
                float sx = posX + i * height;
                BorderRadius sr = i == 0 ? BorderRadius.left(6, 6) : i == 8 ? BorderRadius.right(6, 6) : BorderRadius.ZERO;
                ctx.drawRoundedRect(sx, posY, height, height, sr, new ColorRGBA(0, 0, 0, 178));
            }
            drawSelectedHighlight(ctx, posX, posY, theme);

            float xSlot = posX;
            for (HotBarSlot slot : slots) {
                slot.render(ctx, xSlot, posY, theme);
                xSlot += height;
            }


            

        }
    }


    class HotBarSlot {
        private final Animation animationEnable = new Animation(150, 0, Easing.QUAD_IN_OUT);
        private final BorderRadius borderRadius;
        private final int index;

        public HotBarSlot(int index) {
            borderRadius = index == 0 ? BorderRadius.left(6, 6) : index == 8 ? BorderRadius.right(6, 6) : BorderRadius.ZERO;
            this.index = index;
        }

        public void render(CustomDrawContext ctx, float x, float y, Theme theme) {
            
            
            ItemStack stack = mc.player.getInventory().main.get(index);
            if (!stack.isEmpty()) {
                ctx.pushMatrix();
                ctx.getMatrices().translate(x + (24 - 12.8) / 2f, y + (24 - 12.8) / 2f, 1);
                ctx.getMatrices().scale(0.8f, 0.8f, 0.8f);
                ctx.drawItem(stack, 0, 0);

                ((DrawContextAccessor) ctx).callDrawItemBar(stack, 0, 0);
                ((DrawContextAccessor) ctx).callDrawCooldownProgress(stack, 0, 0);
                ctx.popMatrix();
            }
        }

    }

    private void renderHeldItemTooltip(CustomDrawContext context,float y) {
        Profilers.get().push("selectedItemName");

        if (mc.inGameHud.heldItemTooltipFade > 0 && !mc.inGameHud.currentStack.isEmpty()) {
            MutableText mutableText = Text.empty().append(mc.inGameHud.currentStack.getName()).formatted(mc.inGameHud.currentStack.getRarity().getFormatting());
            if (mc.inGameHud.currentStack.contains(DataComponentTypes.CUSTOM_NAME)) {
                mutableText.formatted(Formatting.ITALIC);
            }

            int i = mc.textRenderer.getWidth(mutableText);
            int j = (context.getScaledWindowWidth() - i) / 2;
            int k = (int) y;
            if (!mc.interactionManager.hasStatusBars() || mc.interactionManager.hasCreativeInventory()) {
                k += 14;
            }

            int l = (int)((float)mc.inGameHud.heldItemTooltipFade * 256.0F / 10.0F);
            if (l > 255) {
                l = 255;
            }

            if (l > 0) {
                context.getMatrices().push();
                context.getMatrices().translate(j, k, 0);

                Theme theme = Okyware.getInstance().getThemeManager().getCurrentTheme();
                context.drawTextWithBackground(mc.inGameHud.getTextRenderer(), mutableText, 0, 0, i, ColorHelper.withAlpha(l, Colors.WHITE) );

                context.getMatrices().pop();
            }
        }

        Profilers.get().pop();
    }
    public final void renderOverlayMessage(CustomDrawContext context, RenderTickCounter tickCounter,float y) {
        TextRenderer textRenderer = mc.inGameHud.getTextRenderer();
        if (mc.inGameHud.overlayMessage != null && mc.inGameHud.overlayRemaining > 0) {
            Profilers.get().push("overlayMessage");
            float f = (float)mc.inGameHud.overlayRemaining - tickCounter.getTickDelta(false);
            int i = (int)(f * 255.0F / 20.0F);
            if (i > 255) {
                i = 255;
            }

            if (i > 8) {
                context.getMatrices().push();
                context.getMatrices().translate((float)(context.getScaledWindowWidth() / 2), y, 0.0F);
                int j;
                if (mc.inGameHud.overlayTinted) {
                    j = MathHelper.hsvToArgb(f / 50.0F, 0.7F, 0.6F, i);
                } else {
                    j = ColorHelper.withAlpha(i, -1);
                }

                int k = textRenderer.getWidth(mc.inGameHud.overlayMessage);

                context.getMatrices().translate(-k / 2f, -4,0);
                context.drawTextWithBackground(textRenderer, mc.inGameHud.overlayMessage, 0, 0, k,j);

                context.getMatrices().pop();
            }

            Profilers.get().pop();
        }
    }

    @Override
    protected void renderXLine(CustomDrawContext ctx, SheetCode nearest) {
    }

    private void drawXpBar(CustomDrawContext ctx, float x, float y, float width) {
        if (mc.player == null) return;
        float progress = mc.player.experienceProgress;
        
        if (progress > 0) {
            float barHeight = 6f; 
            float barY = y - 14;  
            
            
            ctx.drawRoundedRect(x, barY, width, barHeight, BorderRadius.all(2), new ColorRGBA(0, 0, 0, 150));
            
            ctx.drawRoundedRect(x, barY, width * progress, barHeight, BorderRadius.all(2), ColorRGBA.GREEN);
        }
    }
}
