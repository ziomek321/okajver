package okyware.wtf.client.hud.elements.component;

import okyware.wtf.client.hud.elements.draggable.DraggableHudElement;
import okyware.wtf.utility.render.display.base.CustomDrawContext;
import okyware.wtf.client.modules.api.setting.Setting;
import java.util.List;
import java.util.Collections;

public class MusicInfoComponent extends DraggableHudElement {
    public MusicInfoComponent(String name, float x, float y, float ww, float wh, float ox, float oy, Align align) {
        super(name, x, y, ww, wh, ox, oy, align);
    }
    @Override public List<Setting> getSettings() { return Collections.emptyList(); }
    @Override public void render(CustomDrawContext ctx) {}
    @Override public void rightClick() {}
}
