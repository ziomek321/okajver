package okyware.wtf.client.hud.elements.component;

import net.minecraft.client.gui.screen.ChatScreen;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.MathHelper;
import okyware.wtf.Okyware;
import okyware.wtf.base.animations.base.Animation;
import okyware.wtf.base.animations.base.Easing;
import okyware.wtf.base.font.Font;
import okyware.wtf.base.font.Fonts;
import okyware.wtf.base.theme.Theme;
import okyware.wtf.client.hud.elements.draggable.DraggableHudElement;
import okyware.wtf.client.modules.api.setting.Setting;
import okyware.wtf.client.modules.api.setting.impl.ModeSetting;
import okyware.wtf.client.modules.impl.combat.Aura;
import okyware.wtf.utility.game.player.PlayerIntersectionUtil;
import okyware.wtf.utility.render.display.base.BorderRadius;
import okyware.wtf.utility.render.display.base.CustomDrawContext;
import okyware.wtf.utility.render.display.base.color.ColorRGBA;
import okyware.wtf.utility.render.display.base.Gradient;
import okyware.wtf.utility.render.display.shader.DrawUtil;

import java.util.List;

public class TargetHudComponent extends DraggableHudElement {

    private final Animation healthAnimation = new Animation(400, Easing.QUAD_IN_OUT);
    private final Animation absorptionAnimation = new Animation(400, Easing.QUAD_IN_OUT);
    private final Animation toggleAnimation = new Animation(250, Easing.BACK_OUT);
    private LivingEntity target;

    private final Identifier headDefault = Identifier.of("okyware", "textures/target/default.png");

    @Override
    public List<Setting> getSettings() {
        return List.of();
    }

    public TargetHudComponent(String name, float initialX, float initialY, float windowWidth, float windowHeight, float offsetX, float offsetY, Align align) {
        super(name, initialX, initialY, windowWidth, windowHeight, offsetX, offsetY, align);
    }

    @Override
    public void render(CustomDrawContext ctx) {
        this.width = 105f;
        this.height = 32f;
        Aura aura = Aura.INSTANCE;

        LivingEntity target = aura.getTarget();
        boolean editing = mc.currentScreen instanceof ChatScreen;
        if (target == null && editing && mc.player != null) {
            target = mc.player;
        }

        setTarget(target);

        toggleAnimation.update(target != null ? 1f : 0f);
        float anim = toggleAnimation.getValue();
        if (anim <= 0.001f) return;

        renderRockstarTargetHud(ctx, this.target, anim);
    }

    private void renderRockstarTargetHud(CustomDrawContext ctx, LivingEntity target, float animation) {
        float posX = x, posY = y;
        float width = 105f, height = 32f;
        float headSize = 22f, padding = 5f;

        Theme theme = Okyware.getInstance().getThemeManager().getCurrentTheme();
        ColorRGBA bgColor = new ColorRGBA(25, 24, 30, (int) (180 * animation));

        ctx.getMatrices().push();
        
        ctx.getMatrices().translate(posX + width / 2f, posY + height / 2f, 0f);
        ctx.getMatrices().scale(animation, animation, 1f);
        ctx.getMatrices().translate(-(posX + width / 2f), -(posY + height / 2f), 0f);

        BorderRadius radius = BorderRadius.all(4);
        
        ctx.drawBlur(posX, posY, width, height, 10f, radius, ColorRGBA.WHITE.mulAlpha(animation));
        ctx.drawRoundedRect(posX, posY, width, height, radius, new ColorRGBA(20, 20, 25, (int) (120 * animation)));
        
        float headX = posX + padding;
        float headY = posY + (height - headSize) / 2f;
        if (target instanceof PlayerEntity player) {
            Identifier skin = mc.getSkinProvider().getSkinTextures(player.getGameProfile()).texture();
            DrawUtil.drawPlayerHeadWithRoundedShader(
                    ctx.getMatrices(),
                    skin,
                    headX, headY, headSize,
                    BorderRadius.all(3f), ColorRGBA.WHITE.mulAlpha(animation)
            );
        } else {
            ctx.drawRoundedTexture(headDefault, headX, headY, headSize, headSize, BorderRadius.all(3f), ColorRGBA.WHITE.mulAlpha(animation));
        }

        
        Font nameFont = Fonts.MEDIUM.getFont(7f);
        Font hpFont = Fonts.SEMIBOLD.getFont(6.5f);
        
        String name = target.getName().getString();
        float hp = PlayerIntersectionUtil.getHealth(target);
        float maxHp = target.getMaxHealth();
        
        ctx.drawText(nameFont, name, headX + headSize + padding, headY + 2, ColorRGBA.WHITE.mulAlpha(animation));

        String hpText = String.format("%.1f", hp);
        ctx.drawText(hpFont, hpText, posX + width - padding - hpFont.width(hpText), headY + 2, theme.getColor().mulAlpha(animation));

        
        float barX = headX + headSize + padding;
        float barY = posY + height - padding - 5f;
        float barWidth = width - (headSize + padding * 3);
        float barHeight = 5f;
        
        
        BorderRadius barRadius = BorderRadius.all(1f);
        
        ctx.drawRoundedRect(barX, barY, barWidth, barHeight, barRadius, new ColorRGBA(255, 255, 255, (int) (30 * animation)));
        
        float hpPercent = MathHelper.clamp(hp / maxHp, 0, 1);
        float animatedHpWidth = healthAnimation.update(barWidth * hpPercent);
        
        if (animatedHpWidth > 1f) {
            ctx.drawRoundedRect(barX, barY, animatedHpWidth, barHeight, barRadius, theme.getColor().mulAlpha(animation));
        }

        
        float absorption = target.getAbsorptionAmount();
        float absPercent = MathHelper.clamp(absorption / 20f, 0, 1);
        float animatedAbsWidth = absorptionAnimation.update(barWidth * absPercent);
        if (animatedAbsWidth > 1f) {
            ctx.drawRoundedRect(barX + barWidth - animatedAbsWidth, barY, animatedAbsWidth, barHeight, barRadius, new ColorRGBA(255, 220, 81, (int) (255 * animation)));
        }

        
        if (target instanceof PlayerEntity player) {
            renderArmorIcons(ctx, player, posX, posY + height + 2f, animation);
        }

        ctx.getMatrices().pop();
    }

    private void renderArmorIcons(CustomDrawContext ctx, PlayerEntity player, float x, float y, float anim) {
        List<ItemStack> items = new java.util.ArrayList<>();
        items.add(player.getOffHandStack());
        items.add(player.getInventory().armor.get(0));
        items.add(player.getInventory().armor.get(1));
        items.add(player.getInventory().armor.get(2));
        items.add(player.getInventory().armor.get(3));
        items.add(player.getMainHandStack());
        items.removeIf(ItemStack::isEmpty);

        if (items.isEmpty()) return;

        float itemSize = 12f;
        float spacing = 2f;
        
        ctx.getMatrices().push();
        ctx.getMatrices().translate(x, y, 0);
        ctx.getMatrices().scale(0.8f, 0.8f, 1f);

        for (int i = 0; i < items.size(); i++) {
            ItemStack stack = items.get(i);
            ctx.drawItem(stack, i * 18, 0);
        }
        ctx.getMatrices().pop();
    }

    public void setTarget(LivingEntity target) {
        if (target != null) {
            this.target = target;
        } else if (toggleAnimation.getValue() == 0) {
            this.target = null;
        }
    }

    @Override
    public void rightClick() {
    }

}
