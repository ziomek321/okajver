package okyware.wtf.client.screens.menu.settings.impl.popup;

import okyware.wtf.Okyware;
import okyware.wtf.base.font.Font;
import okyware.wtf.base.font.Fonts;
import okyware.wtf.base.theme.Theme;
import okyware.wtf.base.config.ConfigManager;
import okyware.wtf.base.license.LicenseManager;
import com.google.gson.JsonObject;
import okyware.wtf.client.screens.menu.settings.api.MenuPopupSetting;
import okyware.wtf.utility.game.other.MouseButton;
import okyware.wtf.utility.render.display.base.BorderRadius;
import okyware.wtf.utility.render.display.base.ChangeRect;
import okyware.wtf.utility.render.display.base.UIContext;
import okyware.wtf.utility.interfaces.IMinecraft;
import okyware.wtf.utility.render.display.base.color.ColorRGBA;
import okyware.wtf.utility.render.display.shader.DrawUtil;

import java.io.File;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;

public class CreateConfigPopup extends MenuPopupSetting implements IMinecraft {
    private String configName = "";
    private boolean cloud = false;
    private boolean isPublic = false;
    private boolean focused = false;
    private boolean visibilityOpen = false;

    private final okyware.wtf.base.animations.base.Animation cloudSwitchAnim = new okyware.wtf.base.animations.base.Animation(250, 0, okyware.wtf.base.animations.base.Easing.QUAD_OUT);
    private final okyware.wtf.base.animations.base.Animation visibilityOpenAnim = new okyware.wtf.base.animations.base.Animation(220, 0, okyware.wtf.base.animations.base.Easing.QUAD_OUT);

    private static final float VIS_X_OFFSET = 40f;
    private static final float VIS_WIDTH = 70f;
    private static final float VIS_ROW_HEIGHT = 14f;
    private float visBaseY = 0;

    public CreateConfigPopup(ChangeRect bounds) {
        super(bounds);
        this.animationScale = new okyware.wtf.base.animations.base.Animation(300, 0.01f, okyware.wtf.base.animations.base.Easing.BACK_OUT);
        this.animationScale.animateTo(1.0f);
    }

    @Override
    public void render(UIContext ctx, float mouseX, float mouseY, float alpha, Theme theme) {
        animationScale.update();
        float anim = animationScale.getValue();
        if (anim <= 0.01f) return;

        float width = 180;
        float height = cloud ? 110 : 85;
        float x = (mc.getWindow().getScaledWidth() - width) / 2f;
        float y = (mc.getWindow().getScaledHeight() - height) / 2f;
        
        bounds.setX(x);
        bounds.setY(y);
        bounds.setWidth(width);
        bounds.setHeight(height);

        ctx.pushMatrix();
        ctx.getMatrices().translate(x + width / 2f, y + height / 2f, 0);
        ctx.getMatrices().scale(anim, anim, 1);
        ctx.getMatrices().translate(-(x + width / 2f), -(y + height / 2f), 0);

        
        DrawUtil.drawShadow(ctx.getMatrices(), x, y, width, height, 25 * anim, BorderRadius.all(6), ColorRGBA.BLACK.mulAlpha(alpha * 0.6f));
        ctx.drawRoundedRect(x, y, width, height, BorderRadius.all(6), theme.getForegroundColor().mulAlpha(alpha * 0.98f));
        
        
        ctx.drawText(Fonts.MEDIUM.getFont(7), "Create Config", x + 10, y + 8, theme.getWhite().mulAlpha(alpha));
        
        
        boolean xHovered = mouseX >= x + width - 20 && mouseX <= x + width - 5 && mouseY >= y + 5 && mouseY <= y + 18;
        ctx.drawText(Fonts.MEDIUM.getFont(8), "X", x + width - 16, y + 8, xHovered ? ColorRGBA.RED.mulAlpha(alpha) : theme.getGrayLight().mulAlpha(alpha));

        
        float inputY = y + 26;
        Font labelFont = Fonts.MEDIUM.getFont(6);
        ctx.drawRoundedRect(x + 10, inputY, width - 20, 16, BorderRadius.all(3), focused ? theme.getForegroundLight().mulAlpha(alpha) : theme.getForegroundColor().mulAlpha(alpha));
        ctx.drawText(Fonts.MEDIUM.getFont(7), configName.isEmpty() && !focused ? "Name..." : configName + (focused && (System.currentTimeMillis() / 500 % 2 == 0) ? "_" : ""), x + 14, inputY + 4, theme.getWhite().mulAlpha(alpha * (configName.isEmpty() && !focused ? 0.5f : 1.0f)));

        
        float cloudY = inputY + 22;
        ctx.drawText(labelFont, "Cloud", x + 10, cloudY + 3, theme.getGrayLight().mulAlpha(alpha));
        
        float switchX = x + 40;
        float switchY = cloudY + 2;
        cloudSwitchAnim.update(cloud ? 1f : 0f);
        float switchProgress = cloudSwitchAnim.getValue();
        ColorRGBA switchColor = theme.getGray().mix(theme.getColor(), switchProgress).mulAlpha(alpha);
        ctx.drawRoundedRect(switchX, switchY, 20, 10, BorderRadius.all(5), switchColor);
        ctx.drawRoundedRect(switchX + 1 + (10 * switchProgress), switchY + 1, 8, 8, BorderRadius.all(4), theme.getWhite().mulAlpha(alpha));

        
        if (cloud || !cloudSwitchAnim.isDone()) {
            float publicY = cloudY + 18;
            visBaseY = publicY;
            float visAlpha = alpha * switchProgress;
            ctx.drawText(labelFont, "Visibility", x + 10, publicY + 3, theme.getGrayLight().mulAlpha(visAlpha));

            float dropX = x + VIS_X_OFFSET + 30;
            String visibilityText = isPublic ? "Public" : "Private";
            boolean headHovered = mouseX >= dropX && mouseX <= dropX + VIS_WIDTH && mouseY >= publicY && mouseY <= publicY + VIS_ROW_HEIGHT;
            ColorRGBA headColor = theme.getForegroundColor().mix(theme.getForegroundLight(), headHovered ? 1f : 0f).mulAlpha(visAlpha);
            ctx.drawRoundedRect(dropX, publicY, VIS_WIDTH, VIS_ROW_HEIGHT, BorderRadius.all(3), headColor);
            DrawUtil.drawRoundedBorder(ctx.getMatrices(), dropX, publicY, VIS_WIDTH, VIS_ROW_HEIGHT, 0.5f,
                    BorderRadius.all(3), theme.getForegroundStroke().mulAlpha(visAlpha));
            ctx.drawText(labelFont, visibilityText, dropX + 4, publicY + 3.5f, theme.getWhite().mulAlpha(visAlpha));

            visibilityOpenAnim.update(visibilityOpen ? 1f : 0f);
            float openProgress = visibilityOpenAnim.getValue();

            ctx.pushMatrix();
            ctx.getMatrices().translate(dropX + VIS_WIDTH - 8, publicY + 7, 0);
            ctx.getMatrices().multiply(new org.joml.Quaternionf().rotateZ((float) Math.toRadians(180f * openProgress)));
            ctx.getMatrices().translate(-(dropX + VIS_WIDTH - 8), -(publicY + 7), 0);
            ctx.drawText(labelFont, "▼", dropX + VIS_WIDTH - 10, publicY + 4, theme.getGrayLight().mulAlpha(visAlpha));
            ctx.popMatrix();

            if (openProgress > 0.01f) {
                float panelH = VIS_ROW_HEIGHT * 2 * openProgress;
                float panelY = publicY + VIS_ROW_HEIGHT + 2;
                ctx.drawRoundedRect(dropX, panelY, VIS_WIDTH, panelH, BorderRadius.all(3),
                        theme.getForegroundColor().mulAlpha(visAlpha * openProgress));
                DrawUtil.drawRoundedBorder(ctx.getMatrices(), dropX, panelY, VIS_WIDTH, panelH, 0.5f,
                        BorderRadius.all(3), theme.getForegroundStroke().mulAlpha(visAlpha * openProgress));

                ctx.enableScissor((int) dropX, (int) panelY, (int) (dropX + VIS_WIDTH), (int) (panelY + panelH));
                String[] options = {"Private", "Public"};
                for (int i = 0; i < options.length; i++) {
                    float oy = panelY + i * VIS_ROW_HEIGHT;
                    boolean optHover = mouseX >= dropX && mouseX <= dropX + VIS_WIDTH && mouseY >= oy && mouseY <= oy + VIS_ROW_HEIGHT;
                    if (optHover) {
                        ctx.drawRoundedRect(dropX + 1, oy + 1, VIS_WIDTH - 2, VIS_ROW_HEIGHT - 2, BorderRadius.all(2),
                                theme.getForegroundLight().mulAlpha(visAlpha * openProgress));
                    }
                    boolean selected = (i == 1) == isPublic;
                    ColorRGBA optColor = selected ? theme.getColor() : theme.getWhite();
                    ctx.drawText(labelFont, options[i], dropX + 4, oy + 3.5f,
                            optColor.mulAlpha(visAlpha * openProgress));
                }
                ctx.disableScissor();
            }
        }

        
        float btnW = 45;
        float btnH = 14;
        float btnX = x + width - btnW - 10;
        float btnY = y + height - btnH - 8;
        boolean btnHovered = mouseX >= btnX && mouseX <= btnX + btnW && mouseY >= btnY && mouseY <= btnY + btnH;
        
        ctx.drawRoundedRect(btnX, btnY, btnW, btnH, BorderRadius.all(4), btnHovered ? theme.getColor().mulAlpha(alpha) : theme.getColor().mulAlpha(alpha * 0.8f));
        
        String btnText = "Create";
        Font btnFont = Fonts.MEDIUM.getFont(7);
        float tw = btnFont.width(btnText);
        ctx.drawText(btnFont, btnText, btnX + (btnW - tw) / 2f, btnY + (btnH - btnFont.height()) / 2f + 0.5f, theme.getWhite().mulAlpha(alpha));

        ctx.popMatrix();
    }

    @Override
    public void onMouseClicked(double mouseX, double mouseY, MouseButton button) {
        float x = bounds.getX();
        float y = bounds.getY();
        float width = bounds.getWidth();
        float height = bounds.getHeight();

        
        if (mouseX >= x + width - 20 && mouseX <= x + width - 5 && mouseY >= y + 5 && mouseY <= y + 18) {
            animationScale.animateTo(0.01f);
            return;
        }

        
        focused = mouseX >= x + 10 && mouseX <= x + width - 10 && mouseY >= y + 28 && mouseY <= y + 44;

        
        if (mouseX >= x + 40 && mouseX <= x + 60 && mouseY >= y + 50 && mouseY <= y + 60) {
            cloud = !cloud;
        }

        
        if (cloud) {
            float dropX = x + VIS_X_OFFSET + 30;
            float headY = visBaseY;
            boolean headClicked = mouseX >= dropX && mouseX <= dropX + VIS_WIDTH && mouseY >= headY && mouseY <= headY + VIS_ROW_HEIGHT;
            if (headClicked) {
                visibilityOpen = !visibilityOpen;
            } else if (visibilityOpen) {
                float panelY = headY + VIS_ROW_HEIGHT + 2;
                String[] options = {"Private", "Public"};
                boolean consumed = false;
                for (int i = 0; i < options.length; i++) {
                    float oy = panelY + i * VIS_ROW_HEIGHT;
                    if (mouseX >= dropX && mouseX <= dropX + VIS_WIDTH && mouseY >= oy && mouseY <= oy + VIS_ROW_HEIGHT) {
                        isPublic = (i == 1);
                        visibilityOpen = false;
                        consumed = true;
                        break;
                    }
                }
                if (!consumed) visibilityOpen = false;
            }
        }

        
        float btnW = 45;
        float btnX = x + width - btnW - 10;
        float btnY = y + height - 22;
        if (mouseX >= btnX && mouseX <= btnX + btnW && mouseY >= btnY && mouseY <= btnY + 14) {
            if (!configName.isEmpty()) {
                Okyware.getInstance().getConfigManager().saveConfig(configName);
                okyware.wtf.base.notify.NotifyManager.getInstance().addNotification("4", net.minecraft.text.Text.literal("Created config: " + configName));
                if (cloud) {
                    Okyware.getInstance().getConfigManager().saveToCloud(configName, isPublic);
                    okyware.wtf.base.notify.NotifyManager.getInstance().addNotification("4",
                            net.minecraft.text.Text.literal("Uploading " + (isPublic ? "public" : "private") + " config: " + configName));
                }
            }
            animationScale.animateTo(0.01f);
        }
    }

    @Override
    public boolean charTyped(char chr, int modifiers) {
        if (focused) {
            if (chr >= ' ' && chr <= '~') {
                configName += chr;
            }
            return true;
        }
        return false;
    }

    @Override
    public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
        if (focused) {
            if (keyCode == 259) { 
                if (!configName.isEmpty()) {
                    configName = configName.substring(0, configName.length() - 1);
                }
                return true;
            }
            if (keyCode == 257 || keyCode == 335) { 
                focused = false;
                return true;
            }
        }
        return false;
    }

    @Override public float getWidth() { return bounds.getWidth(); }
    @Override public float getHeight() { return bounds.getHeight(); }
    @Override public boolean isVisible() { return true; }
}
