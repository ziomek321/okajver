package okyware.wtf.client.screens.menu;

import lombok.Getter;
import lombok.Setter;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.client.util.math.Vector2f;
import net.minecraft.util.math.MathHelper;
import org.lwjgl.glfw.GLFW;
import okyware.wtf.Okyware;
import okyware.wtf.base.animations.base.Animation;
import okyware.wtf.base.animations.base.Easing;
import okyware.wtf.base.font.Font;
import okyware.wtf.base.font.Fonts;
import okyware.wtf.base.theme.Theme;
import okyware.wtf.client.modules.impl.render.Interface;
import okyware.wtf.client.screens.menu.elements.api.AbstractMenuElement;
import okyware.wtf.client.screens.menu.elements.impl.MenuConfigItemElement;
import okyware.wtf.client.screens.menu.elements.impl.MenuModuleElement;
import okyware.wtf.client.screens.menu.elements.impl.MenuThemeElement;
import okyware.wtf.client.screens.menu.settings.impl.popup.CreateConfigPopup;
import okyware.wtf.client.screens.menu.settings.impl.popup.ModuleSettingsPopup;
import okyware.wtf.client.modules.api.Category;
import okyware.wtf.client.screens.menu.panels.HeaderPanel;
import okyware.wtf.client.screens.menu.panels.SidebarPanel;
import okyware.wtf.client.screens.menu.settings.api.MenuPopupSetting;
import okyware.wtf.utility.render.display.ScrollHandler;
import okyware.wtf.utility.game.other.render.CustomScreen;
import okyware.wtf.utility.game.other.MouseButton;
import okyware.wtf.utility.math.MathUtil;
import okyware.wtf.utility.render.display.TextBox;
import okyware.wtf.utility.render.display.base.BorderRadius;
import okyware.wtf.utility.render.display.base.ChangeRect;
import okyware.wtf.utility.render.display.base.UIContext;
import okyware.wtf.utility.render.display.base.color.ColorRGBA;
import okyware.wtf.utility.render.display.base.Rect;
import okyware.wtf.utility.render.display.shader.DrawUtil;

import java.util.*;

public class MenuScreen extends CustomScreen {

    private Category selectedCategory = Category.COMBAT;
    private Category realSelectedCategory = Category.COMBAT;
    
    public enum ConfigTab { LOCAL, CLOUD }
    private ConfigTab selectedConfigTab = ConfigTab.LOCAL;
    private final java.util.Map<String, MenuConfigItemElement> configItemCache = new java.util.HashMap<>();
    private final java.util.Map<String, MenuThemeElement> themeItemCache = new java.util.HashMap<>();
    private final Animation configTabAnimation = new Animation(250, 0, Easing.CUBIC_IN_OUT);
    private Rect localTabBounds, cloudTabBounds;
    @Getter
    private float boxX, boxY;
    @Getter
    @Setter
    private int columns = 2;
    @Getter
    private float boxWidth = 500;
    @Getter
    private float boxHeight = 350;

    private boolean dragging;
    private float dragOffsetX, dragOffsetY;

    private final Animation sidebarAnimation = new Animation(300, 1.0f, Easing.CUBIC_IN_OUT);
    private boolean isSidebarExpanded = true;

    private final Animation animationClose = new Animation(300, 0f, Easing.BAKEK_SIZE);
    private boolean initialized;

    private TextBox searchField;

    private final ScrollHandler scrollHandler = new ScrollHandler();

    @Getter
    @Setter
    private boolean closing = false;
    private long openTime;
    private SidebarPanel sidebarPanel;
    private HeaderPanel headerPanel;

    private int scaledScissorX = 0;
    private int scaledScissorY = 0;
    private int scaledScissorEndX = 2000;
    private int scaledScissorEndY = 2000;

    private final Animation animationColums;
    private final Animation animationScrollHeight;
    private final Animation animationChangeCategory;
    private boolean draggingScrollbar = false;
    private float scrollClickOffset = 0;

    private Set<MenuPopupSetting> popupSettings = new HashSet<>();
    List<AbstractMenuElement> modules = new ArrayList<>();

    public MenuScreen() {
        animationColums = new Animation(300, columns == 2 ? 1 : 0, Easing.CUBIC_IN_OUT);
        animationChangeCategory = new Animation(150, 1, Easing.CUBIC_IN_OUT);
        animationScrollHeight = new Animation(150, 1, Easing.QUAD_IN_OUT);
    }

    public void initialize() {
        modules.addAll(Okyware.getInstance().getModuleManager().getModules().stream().map(MenuModuleElement::new).toList());

    }

    @Override
    protected void init() {
        closing = false;
        columns = 2;
        animationColums.setValue(columns == 2 ? 1 : 0);

        boxWidth = MathHelper.lerp(animationColums.getValue(), 460, 500);

        boxHeight = MathHelper.lerp(animationColums.getValue(), 310, 350);

        boxX = (this.width - boxWidth) / 2f;
        boxY = (this.height - boxHeight) / 2f;
        animationClose.setValue(0f);
        animationClose.update(1f);
        this.closing = false;
        this.openTime = System.currentTimeMillis();
        if (!initialized) {
            this.searchField = new TextBox(new Vector2f(boxX + boxWidth - 128 - 8, boxY + 8), Fonts.MEDIUM.getFont(7), "Search", 100);
            this.sidebarPanel = new SidebarPanel(
                    this.sidebarAnimation,
                    this.isSidebarExpanded,
                    category -> {

                        this.headerPanel.resetAnim(realSelectedCategory, category);
                        realSelectedCategory = category;

                        this.scrollHandler.setTargetValue(0.0F);
                        this.searchField.setSelectAll(true);
                        this.searchField.setSelected(true);
                        this.searchField.keyPressed(GLFW.GLFW_KEY_BACKSPACE, 0, 0);
                        this.searchField.setSelected(false);
                    },
                    () -> {
                    }
            );

            this.headerPanel = new HeaderPanel(
                    this.searchField,
                    () -> Okyware.getInstance().getThemeManager().switchTheme()
            );
        }
        initialized = true;
    }

    @Override
    public void tick() {

        if (closing && animationClose.getValue() == 0.0F) {
            this.close();
        }
        super.tick();
    }

    @Override
    public void removed() {
        super.removed();
    }
    
    @Override
    public boolean shouldCloseOnEsc() {
        return false;
    }

    public boolean isFinish() {
        return animationClose.getValue() == 0.0F && closing;
    }

    public float getProgress() {
        return Math.min(Math.max(animationClose.getValue(), 0), 1);
    }

    public void renderTop(UIContext ctx, float mouseX, float mouseY) {
        if (!initialized) return;

        animationColums.update(columns == 2 ? 1 : 0);

        boxWidth = MathHelper.lerp(animationColums.getValue(), 460, 500);

        boxHeight = MathHelper.lerp(animationColums.getValue(), 310, 350);

        float progress = animationClose.update(closing ? 0.0F : 1.0F);

        progress = Math.min(Math.max(progress, 0), 1);
        float sidebarProgress = sidebarAnimation.update();
        float scale = 0.85f + 0.15f * progress;
        Theme theme = Okyware.getInstance().getThemeManager().getCurrentTheme();
        MatrixStack ms = ctx.getMatrices();

        ctx.pushMatrix();

        float scaleX = boxX + boxWidth / 2f;
        float scaleY = boxY + boxHeight / 2f;

        ms.translate(scaleX, scaleY, 1);
        ms.scale(scale, scale, 1);
        ms.translate(-scaleX, -scaleY, 1);

        ColorRGBA primary = theme.getColor().mulAlpha(progress);
        ColorRGBA baseBg = theme.getBackgroundColor().mulAlpha(progress);
        ColorRGBA selectedColor = theme.getWhite().mulAlpha(progress);
        ColorRGBA textColor = theme.getWhite().mulAlpha(progress);

        if (Interface.INSTANCE.isBlur()) {
            DrawUtil.drawBlur(ctx.getMatrices(), boxX, boxY, boxWidth, boxHeight, 20 * progress * progress, BorderRadius.all(9), ColorRGBA.WHITE.mulAlpha(progress * 2));
        }
        ctx.drawRoundedRect(boxX, boxY, boxWidth, boxHeight, BorderRadius.all(9), baseBg);
        float widthScroll = 2;
        sidebarPanel.render(ctx, boxX, boxY, boxHeight, progress, theme, realSelectedCategory, primary, textColor, selectedColor);

        float sidebarWidth = 30f + (88f - 30f) * sidebarProgress;
        float contentStartX = boxX + 8f + sidebarWidth + 8f;
        float sidebarY = boxY + 8f;
        float contentY = boxY + 22f + 8f + 8f;

        headerPanel.render(ctx, contentStartX, sidebarY, boxX, columns, boxWidth, progress, theme, realSelectedCategory);
        
        if (realSelectedCategory == Category.CONFIG) {
            float tabW = 48;
            float tabH = 18;
            float totalTabW = (tabW * 2 + 10);
            
            float contentWidth = boxX + boxWidth - 8 - contentStartX - 8;
            float tabX = contentStartX + (contentWidth - totalTabW) / 2f;
            float tabY = sidebarY + 30;
            
            Font tabFont = Fonts.MEDIUM.getFont(7.5f);
            
            configTabAnimation.animateTo(selectedConfigTab == ConfigTab.LOCAL ? 0 : 1);
            float tabAnim = configTabAnimation.update();
            
            float bgX = tabX + tabAnim * (tabW + 10);
            ctx.drawRoundedRect(tabX, tabY, totalTabW, tabH, BorderRadius.all(4), theme.getForegroundColor().mulAlpha(progress * 0.35f));
            ctx.drawRoundedRect(bgX, tabY, tabW, tabH, BorderRadius.all(4), theme.getForegroundColor().mulAlpha(progress * 0.55f));
            DrawUtil.drawRoundedBorder(ctx.getMatrices(), bgX, tabY, tabW, tabH, 0.5f, BorderRadius.all(4), theme.getWhite().mulAlpha(progress * 0.4f));
            
            localTabBounds = new Rect(tabX, tabY, tabW, tabH);
            ColorRGBA localColor = selectedConfigTab == ConfigTab.LOCAL ? theme.getWhite().mulAlpha(progress) : theme.getWhite().mulAlpha(progress * 0.7f);
            ctx.drawText(tabFont, "Local", tabX + (tabW - tabFont.width("Local")) / 2f, tabY + (tabH - tabFont.height()) / 2f + 1, localColor);
            
            float cloudX = tabX + tabW + 10;
            cloudTabBounds = new Rect(cloudX, tabY, tabW, tabH);
            ColorRGBA cloudColor = selectedConfigTab == ConfigTab.CLOUD ? theme.getWhite().mulAlpha(progress) : theme.getWhite().mulAlpha(progress * 0.7f);
            ctx.drawText(tabFont, "Cloud", cloudX + (tabW - tabFont.width("Cloud")) / 2f, tabY + (tabH - tabFont.height()) / 2f + 1, cloudColor);
            
            contentY += 28; 
        }
        float visibleHeight = boxHeight - (22f + 8f + 8f + 8f);
        float scrollProgress = scrollHandler.getMax() == 0 ? 0f : (float) (scrollHandler.getValue() / scrollHandler.getMax());
        float scrollHeight = Math.max(visibleHeight * (visibleHeight / (float) (visibleHeight + scrollHandler.getMax())), 20);
        scrollHeight = Math.min(visibleHeight, animationScrollHeight.update(scrollHeight));
        float denom = Math.max(1f, (visibleHeight - scrollHeight));
        float scrollY = contentY +denom * scrollProgress;
        scrollY = Math.min(contentY + visibleHeight, scrollY);
        ctx.drawRoundedRect(boxX + boxWidth - 8 - widthScroll, contentY, widthScroll, visibleHeight, BorderRadius.all(0.5f), theme.getForegroundColor().mulAlpha(progress));
        if(scrollY+scrollHeight>visibleHeight+contentY) {
            ctx.drawRoundedRect(boxX + boxWidth - 8 - widthScroll, contentY, widthScroll, (visibleHeight), BorderRadius.all(1f), theme.getForegroundStroke().mulAlpha(progress));

        }else ctx.drawRoundedRect(boxX + boxWidth - 8 - widthScroll, scrollY, widthScroll, (scrollHeight), BorderRadius.all(1f), theme.getForegroundStroke().mulAlpha(progress));
        float contentWidth = boxWidth - (contentStartX - boxX) - 16f;
        this.scaledScissorX = (int) contentStartX;
        this.scaledScissorY = (int) ((int) boxY + (22f + 8f + 8f));
        this.scaledScissorEndX = (int) (boxX + boxWidth);
        this.scaledScissorEndY = (int) ((int) boxY + boxHeight);
        ctx.enableScissor(this.scaledScissorX, this.scaledScissorY, this.scaledScissorEndX, this.scaledScissorEndY);
        animationChangeCategory.setEasing(Easing.QUAD_IN_OUT);
        float categoryAlpha = animationChangeCategory.update(selectedCategory == realSelectedCategory ? 1 : 0);

        renderModules(ctx, mouseX, mouseY, progress * Math.max(categoryAlpha, 0.01f), (int) contentStartX, contentWidth, (int) contentY);

        if (realSelectedCategory == Category.CONFIG && selectedConfigTab == ConfigTab.CLOUD
                && Okyware.getInstance().getConfigManager().isCloudLoading()) {
            float spinnerSize = 16;
            float cx = contentStartX + contentWidth / 2f;
            float cy = contentY + 40;
            float angle = (System.currentTimeMillis() % 1000) / 1000f * 360f;
            ctx.getMatrices().push();
            ctx.getMatrices().translate(cx, cy, 0);
            ctx.getMatrices().multiply(net.minecraft.util.math.RotationAxis.POSITIVE_Z.rotationDegrees(angle));
            ctx.getMatrices().translate(-cx, -cy, 0);
            DrawUtil.drawRoundedBorder(ctx.getMatrices(), cx - spinnerSize / 2, cy - spinnerSize / 2,
                    spinnerSize, spinnerSize, 1.5f, BorderRadius.all(spinnerSize / 2),
                    theme.getForegroundStroke().mulAlpha(progress));
            DrawUtil.drawRoundedBorder(ctx.getMatrices(), cx - spinnerSize / 2, cy - spinnerSize / 2,
                    spinnerSize, spinnerSize / 2, 1.5f, BorderRadius.all(spinnerSize / 2),
                    theme.getColor().mulAlpha(progress));
            ctx.getMatrices().pop();
        }

        ctx.disableScissor();
        List<MenuPopupSetting> removes = new ArrayList<>();
        for (MenuPopupSetting setting : popupSettings) {

            setting.render(ctx, mouseX, mouseY, progress, theme);
            if (setting.getAnimationScale().getValue() == 0) {
                removes.add(setting);
            }
        }
        popupSettings.removeAll(removes);
        if (animationChangeCategory.getValue() == 0) {
            selectedCategory = realSelectedCategory;
        }

        if (draggingScrollbar) {
            float scrollbarY = boxY + 22f + 8f + 8f;
            float newY = (float) mouseY - scrollbarY - scrollClickOffset;

            float scrollRatio = newY / denom;
            scrollHandler.setTargetValue(-(scrollRatio * scrollHandler.getMax()));

        }
        ctx.popMatrix();
    }

    @Override
    public void onMouseClicked(double mouseX, double mouseY, MouseButton button) {

        if (!popupSettings.isEmpty()) {
            for (MenuPopupSetting setting : popupSettings) {
                if (setting.getBounds().contains(mouseX, mouseY)) {
                    setting.onMouseClicked(mouseX, mouseY, button);
                    return;
                } else {
                    setting.getAnimationScale().update(0);

                }
            }
        }
        if (isClosing()) return;
        if (headerPanel.handleMouseClicked(mouseX, mouseY)) {
            if (headerPanel.searchBarBounds.contains(mouseX, mouseY)) {
                searchField.setSelected(true);
            }
            if (headerPanel.plusButtonBounds != null && headerPanel.plusButtonBounds.contains(mouseX, mouseY)) {
                addPopupMenuSetting(new CreateConfigPopup(new ChangeRect((float)mouseX, (float)mouseY, 200, 140)));
            }
            if (headerPanel.refreshButtonBounds != null && headerPanel.refreshButtonBounds.contains(mouseX, mouseY)) {
                Okyware.getInstance().getConfigManager().refreshCloudConfigs();
                configItemCache.clear();
            }
            return;
        }

        if (sidebarPanel.handleMouseClicked(mouseX, mouseY)) {
            return;
        }

        if (realSelectedCategory == Category.CONFIG) {
            if (localTabBounds != null && localTabBounds.contains(mouseX, mouseY)) {
                selectedConfigTab = ConfigTab.LOCAL;
                return;
            }
            if (cloudTabBounds != null && cloudTabBounds.contains(mouseX, mouseY)) {
                selectedConfigTab = ConfigTab.CLOUD;
                return;
            }
        }

        if (!initialized || searchField == null) return;
        if (searchField.isSelected()) {
            searchField.setSelected(false);
        }
        if (button.getButtonIndex() == GLFW.GLFW_MOUSE_BUTTON_LEFT) {
            if (MathUtil.isHovered(mouseX, mouseY, boxX, boxY, boxWidth, 20)) {
                dragOffsetX = (float) mouseX - boxX;
                dragOffsetY = (float) mouseY - boxY;
                return;
            }
        }
        if (!animationClose.isDone()) return;
        float scrollbarX = boxX + boxWidth - 8 - 2;
        float scrollbarY = boxY + 22f + 8f + 8f;
        float visibleHeight = boxHeight - (22f + 8f + 8f);
        if (button.getButtonIndex() == GLFW.GLFW_MOUSE_BUTTON_LEFT) {
            if (MathUtil.isHovered(mouseX, mouseY, scrollbarX, scrollbarY, 2, visibleHeight)) {
                draggingScrollbar = true;
                return;
            }
        }
        if (!MathUtil.isHoveredByCords(mouseX, mouseY, scaledScissorX, scaledScissorY, scaledScissorEndX, scaledScissorEndY)) {
            return;
        }

        getVisibleModules().forEach(menuModule -> menuModule.onMouseClicked(mouseX, mouseY, button));

        super.onMouseClicked(mouseX, mouseY, button);
    }

    @Override
    public boolean charTyped(char chr, int modifiers) {
        if (!initialized || searchField == null) return super.charTyped(chr, modifiers);
        if (searchField.isSelected()) {
            return searchField.charTyped(chr, modifiers);
        }
        boolean popupHandled = false;
        for (MenuPopupSetting setting : popupSettings) {
            if (setting.charTyped(chr, modifiers)) popupHandled = true;
        }
        if (popupHandled) return true;
        for (AbstractMenuElement module : getVisibleModules()) {
            if (module.charTyped(chr, modifiers)) {
                return true;
            }
        }
        return super.charTyped(chr, modifiers);
    }

    @Override
    public void onMouseReleased(double mouseX, double mouseY, MouseButton button) {
        for (MenuPopupSetting setting : popupSettings) {
            setting.onMouseReleased(mouseX, mouseY, button);
        }
        if (button.getButtonIndex() == GLFW.GLFW_MOUSE_BUTTON_LEFT) {
            dragging = false;
            draggingScrollbar = false;
        }
        for (AbstractMenuElement module : getVisibleModules()) {
            module.onMouseReleased(mouseX, mouseY, button);
        }
        super.onMouseReleased(mouseX, mouseY, button);
    }

    @Override
    public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
        if (!initialized || searchField == null) return super.keyPressed(keyCode, scanCode, modifiers);
        boolean returnCheck = false;
        ;
        for (MenuPopupSetting setting : popupSettings) {
            if (setting.keyPressed(keyCode, scanCode, modifiers)) {
                searchField.setSelected(false);
                returnCheck = true;
            }
            ;
        }
        if (returnCheck) {
            return true;
        }
        if (searchField.isSelected()) {
            if (keyCode == GLFW.GLFW_KEY_ESCAPE) {
                searchField.setSelected(false);
                return true;
            }
            return searchField.keyPressed(keyCode, scanCode, modifiers);
        }
        boolean result = false;
        for (AbstractMenuElement module : getVisibleModules()) {
            if (module.keyPressed(keyCode, scanCode, modifiers)) {
                result = true;
            }
        }
        if (result) {
            return true;
        }
        if ((keyCode == GLFW.GLFW_KEY_ESCAPE || (keyCode == okyware.wtf.client.modules.impl.render.Menu.INSTANCE.getKeyCode() && !okyware.wtf.client.modules.impl.render.Menu.INSTANCE.isEnabled())) && !closing) {
            if (keyCode != GLFW.GLFW_KEY_ESCAPE && System.currentTimeMillis() - openTime < 50) {
                return true;
            }
            onMouseReleased(0, 0, MouseButton.LEFT);
            onMouseReleased(0, 0, MouseButton.RIGHT);
            onMouseReleased(0, 0, MouseButton.MIDDLE);
            for (MenuPopupSetting setting : popupSettings) {
                setting.getAnimationScale().setTargetValue(0);
            }
            closing = true;
            return true;
        }
        return super.keyPressed(keyCode, scanCode, modifiers);
    }

    @Override
    public boolean mouseScrolled(double mouseX, double mouseY, double horizontalAmount, double verticalAmount) {
        if (!popupSettings.isEmpty()) {
            for (MenuPopupSetting setting : popupSettings) {
                setting.mouseScrolled(mouseX, mouseY, horizontalAmount, verticalAmount);
            }
            return true;
        }
        float visibleHeight = boxHeight - (22f + 8f + 8f);

        float baseStep = (float) Math.max(20f, Math.min(60f, (scrollHandler.getMax() / visibleHeight) * 10));
        scrollHandler.scroll(verticalAmount * baseStep / 1.5);
        return super.mouseScrolled(mouseX, mouseY, horizontalAmount, verticalAmount);
    }

    @Override
    public void onMouseDragged(double mouseX, double mouseY, MouseButton button, double deltaX, double deltaY) {

        if (button.getButtonIndex() == GLFW.GLFW_MOUSE_BUTTON_LEFT) {
            if (dragging) {
                boxX = (float) mouseX - dragOffsetX;
                boxY = (float) mouseY - dragOffsetY;
                return;
            }
        }
        for (AbstractMenuElement module : getVisibleModules()) {
            module.onMouseDragged(mouseX, mouseY, button, deltaX, deltaY);
        }

        super.onMouseDragged(mouseX, mouseY, button, deltaX, deltaY);
    }

    @Override
    public void close() {
        ;
        super.close();
    }
    private void renderModules(UIContext ctx, float mouseX, float mouseY, float alpha, float contentStartX, float contentWidth, float startY) {

        List<AbstractMenuElement> modulesToRender = getVisibleModules();
        int columns = this.columns;
        float padding = 6f;
        float scrollbarWidth = 6f;
        float maxContentWidth = contentWidth - scrollbarWidth;
        float moduleWidth = (maxContentWidth - padding * (columns - 1)) / columns;

        Font font = Fonts.MEDIUM.getFont(7);
        double[] columnHeights = new double[columns];
        for (AbstractMenuElement module : modulesToRender) {
            int col = 0;
            for (int j = 1; j < columns; j++) {
                if (columnHeights[j] < columnHeights[col]) {
                    col = j;
                }
            }
            float x = contentStartX + col * (moduleWidth + padding);

            float slideOffset = (1 - animationChangeCategory.getValue()) * 25f;
            float y = (float) (startY + columnHeights[col] - scrollHandler.getValue() + slideOffset);
            module.render(ctx, mouseX, mouseY, font, x, y, moduleWidth, alpha, col);

            columnHeights[col] += module.getHeight() + padding;

        }

        scrollHandler.update();
        double maxY = Arrays.stream(columnHeights).max().orElse(0);
        float visibleHeight = boxHeight - (22f + 8f + 8f);

        scrollHandler.setMax(Math.max(0, maxY - visibleHeight) + (maxY > visibleHeight ? 4 : 0));

    }

    private List<AbstractMenuElement> getVisibleModules() {
        if (realSelectedCategory == Category.CONFIG) {
            List<AbstractMenuElement> configs = new ArrayList<>();
            java.util.Set<String> liveKeys = new java.util.HashSet<>();
            if (selectedConfigTab == ConfigTab.LOCAL) {
                for (String name : Okyware.getInstance().getConfigManager().configNames()) {
                    String key = "L:" + name;
                    liveKeys.add(key);
                    MenuConfigItemElement el = configItemCache.get(key);
                    if (el == null) {
                        el = new MenuConfigItemElement(name, false);
                        configItemCache.put(key, el);
                    }
                    configs.add(el);
                }
            } else if (selectedConfigTab == ConfigTab.CLOUD) {
                for (okyware.wtf.base.config.ConfigManager.CloudConfig cloud : Okyware.getInstance().getConfigManager().getCloudConfigs()) {
                    String key = "C:" + cloud.id();
                    liveKeys.add(key);
                    MenuConfigItemElement el = configItemCache.get(key);
                    if (el == null) {
                        el = new MenuConfigItemElement(cloud.name(), true, cloud.id(), cloud.server(), cloud.author());
                        configItemCache.put(key, el);
                    }
                    configs.add(el);
                }
            }
            configItemCache.keySet().removeIf(k -> !liveKeys.contains(k));
            if (searchField != null && !searchField.isEmpty()) {
                String search = searchField.getText().toLowerCase();
                return configs.stream().filter(m -> m.getName().toLowerCase().contains(search)).toList();
            }
            return configs;
        } else if (realSelectedCategory == Category.THEME) {
            List<AbstractMenuElement> themes = new ArrayList<>();
            for (Theme theme : Okyware.getInstance().getThemeManager().getThemes()) {
                MenuThemeElement el = themeItemCache.get(theme.getName());
                if (el == null) {
                    el = new MenuThemeElement(theme);
                    themeItemCache.put(theme.getName(), el);
                }
                themes.add(el);
            }
            if (searchField != null && !searchField.isEmpty()) {
                String search = searchField.getText().toLowerCase();
                return themes.stream().filter(m -> m.getName().toLowerCase().contains(search)).toList();
            }
            return themes;
        }
        return this.modules.stream()
                .filter(m -> searchField == null || searchField.isEmpty() ? m.getCategory() == realSelectedCategory : m.getName().toLowerCase().contains(searchField.getText().toLowerCase()))
                .sorted(Comparator.comparing(menuModule -> menuModule.getName(), String.CASE_INSENSITIVE_ORDER))
                .toList();
    }

    public void addPopupMenuSetting(MenuPopupSetting setting) {
        popupSettings.add(setting);
    }

    public void removePopupMenuSetting(MenuPopupSetting setting) {
        popupSettings.remove(setting);
    }

    public void setBinding(okyware.wtf.client.modules.api.Module module) {
        for (AbstractMenuElement element : modules) {
            if (element instanceof MenuModuleElement mme && mme.getModule() == module) {
                mme.setBinding(true);
                break;
            }
        }
    }

    @Override
    public void render(UIContext context, float mouseX, float mouseY) {

    }

}