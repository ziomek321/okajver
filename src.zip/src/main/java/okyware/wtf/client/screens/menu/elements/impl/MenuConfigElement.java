package okyware.wtf.client.screens.menu.elements.impl;

import okyware.wtf.Okyware;
import okyware.wtf.base.animations.base.Animation;
import okyware.wtf.base.animations.base.Easing;
import okyware.wtf.base.config.ConfigManager;
import okyware.wtf.base.font.Font;
import okyware.wtf.base.font.Fonts;
import okyware.wtf.client.modules.api.Category;
import okyware.wtf.client.modules.api.setting.impl.ButtonSetting;
import okyware.wtf.client.modules.api.setting.impl.StringSetting;
import okyware.wtf.client.screens.menu.elements.api.AbstractMenuElement;
import okyware.wtf.client.screens.menu.settings.api.MenuSetting;
import okyware.wtf.client.screens.menu.settings.impl.MenuButtonSetting;
import okyware.wtf.client.screens.menu.settings.impl.MenuStringSetting;
import okyware.wtf.utility.game.other.MouseButton;
import okyware.wtf.utility.render.display.base.BorderRadius;
import okyware.wtf.utility.render.display.base.Rect;
import okyware.wtf.utility.render.display.base.UIContext;
import okyware.wtf.utility.render.display.base.color.ColorRGBA;
import okyware.wtf.utility.render.display.shader.DrawUtil;
import okyware.wtf.base.theme.Theme;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class MenuConfigElement extends AbstractMenuElement {
    private final StringSetting configName;
    private final MenuButtonSetting saveButton;
    private final MenuButtonSetting loadButton;
    private final List<MenuSetting> settings = new ArrayList<>();

    private final Animation animation;
    private final Animation animationPosition;
    private final Animation animationY;
    private Rect bounds;

    private int lastColum = -1;
    private boolean animated = false;

    public MenuConfigElement() {
        animation = new Animation(200, 1, Easing.LINEAR);
        animationPosition = new Animation(150, 1, Easing.QUAD_IN_OUT);
        animationY = new Animation(150, 1, Easing.QUAD_IN_OUT);

        this.configName = new StringSetting("Config Name", "default");

        this.saveButton = new MenuButtonSetting(new ButtonSetting("Save Config", () -> {
            ConfigManager configManager = Okyware.getInstance().getConfigManager();
            configManager.saveConfig(this.configName.getValue());
            okyware.wtf.base.notify.NotifyManager.getInstance().addNotification("4", net.minecraft.text.Text.literal("Saved config: " + this.configName.getValue()));
        }));

        this.loadButton = new MenuButtonSetting(new ButtonSetting("Load Config", () -> {
            ConfigManager configManager = Okyware.getInstance().getConfigManager();
            configManager.loadConfig(this.configName.getValue());
            okyware.wtf.base.notify.NotifyManager.getInstance().addNotification("4", net.minecraft.text.Text.literal("Loaded config: " + this.configName.getValue()));
        }));

        settings.add(new MenuStringSetting(this.configName));
        settings.add(saveButton);
        settings.add(loadButton);
    }

    @Override
    public void render(UIContext ctx, float mouseX, float mouseY, Font font, float x, float y, float moduleWidth, float alpha, int colum) {
        if (lastColum == -1) lastColum = colum;
        if (lastColum != colum) {
            animated = true;
            animationPosition.animateTo(x);
            animationY.animateTo(y);
            lastColum = colum;
        }
        if (animated) {
            x = animationPosition.update(x);
            y = animationY.update(y);
            if (animationPosition.isDone() && animationY.isDone()) animated = false;
        } else {
            animationPosition.reset(x);
            animationY.reset(y);
        }

        animation.update(1);

        float moduleHeight = 22;
        Theme theme = Okyware.getInstance().getThemeManager().getCurrentTheme();
        ColorRGBA moduleBg = theme.getForegroundColor().mulAlpha(alpha);

        boolean hasSettings = hasSettings();
        float settingAreaHeight = getHeight();
        ColorRGBA settingBg = theme.getForegroundDark().mulAlpha(alpha);
        bounds = new Rect(x, y, moduleWidth, moduleHeight);

        if (hasSettings) {
            ctx.drawRoundedRect(x, y, moduleWidth, settingAreaHeight, BorderRadius.all(8), settingBg);
            ctx.drawRoundedRect(x, y, moduleWidth, moduleHeight, BorderRadius.top(8, 8), moduleBg);
            DrawUtil.drawRoundedBorder(ctx.getMatrices(), x, y, moduleWidth, settingAreaHeight, -0.1f,
                    BorderRadius.all(8), theme.getForegroundStroke().mulAlpha(alpha));
        } else {
            ctx.drawRoundedRect(x, y, moduleWidth, moduleHeight, BorderRadius.all(8), moduleBg);
            DrawUtil.drawRoundedBorder(ctx.getMatrices(), x, y, moduleWidth, moduleHeight, -0.1f,
                    BorderRadius.all(8), theme.getForegroundStroke().mulAlpha(alpha));
        }

        ColorRGBA enabledColor = theme.getGray().mix(theme.getColor(), animation.getValue()).mulAlpha(alpha);
        ColorRGBA textColor = theme.getGrayLight().mix(theme.getWhite(), animation.getValue()).mulAlpha(alpha);
        float iconSize = 14f;
        float iconX = x + 8;
        float iconY = y + (moduleHeight - iconSize) / 2f;
        DrawUtil.drawMSDFIcon(ctx.getMatrices(), Okyware.id("icons/config.png"), iconX, iconY, iconSize, iconSize, 4f, 0.4f, 0.2f, enabledColor);
        ctx.drawText(font, getName(), iconX + iconSize + 6, y + 9, textColor);

        float keyBoxWidth = 22.5f;
        float keyBoxX = x + moduleWidth - keyBoxWidth;
        ColorRGBA badgeColor = theme.getColor().mulAlpha(alpha);

        ctx.drawRoundedRect(keyBoxX, y, keyBoxWidth, moduleHeight,
                hasSettings ? BorderRadius.topRight(8) : new BorderRadius(0, 6, 6, 0), badgeColor);

        float padding = 8;
        float startY = y + moduleHeight + padding;
        ColorRGBA descriptionColor = theme.getWhiteGray().mix(theme.getGrayLight(), animation.getValue()).mulAlpha(alpha);
        
        for (MenuSetting setting : settings) {
            setting.render(ctx, mouseX, mouseY, x, startY, moduleWidth, alpha, animation.getValue(),
                    enabledColor, textColor, descriptionColor, theme);
            startY += setting.getHeight() + 8;
        }

        if (hasSettings) {
            DrawUtil.drawRoundedBorder(ctx.getMatrices(), x, y, moduleWidth, settingAreaHeight, -0.1f,
                    BorderRadius.all(8), theme.getForegroundStroke().mulAlpha(alpha));
        }
    }

    @Override
    public float getHeight() {
        return (float) (22 + (hasSettings() ? settings.stream().mapToDouble(MenuSetting::getHeight).sum() + 8 + (8 * settings.size()) : 0));
    }

    private boolean hasSettings() {
        return !settings.isEmpty();
    }

    @Override
    public void onMouseClicked(double mouseX, double mouseY, MouseButton button) {
        for (MenuSetting setting : settings) {
            setting.onMouseClicked(mouseX, mouseY, button);
        }
    }

    @Override
    public void onMouseReleased(double mouseX, double mouseY, MouseButton button) {
        for (MenuSetting setting : settings) {
            setting.onMouseReleased(mouseX, mouseY, button);
        }
    }

    @Override
    public void onMouseDragged(double mouseX, double mouseY, MouseButton button, double deltaX, double deltaY) {
    }

    @Override
    public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
        boolean result = false;
        for (MenuSetting setting : settings) {
            if (setting.keyPressed(keyCode, scanCode, modifiers)) result = true;
        }
        return result;
    }
    
    @Override
    public boolean charTyped(char chr, int modifiers) {
        boolean result = false;
        for (MenuSetting setting : settings) {
            if (setting.charTyped(chr, modifiers)) result = true;
        }
        return result;
    }

    @Override
    public boolean mouseScrolled(double mouseX, double mouseY, double horizontalAmount, double verticalAmount) {
        return false;
    }

    @Override
    public Category getCategory() {
        return Category.RENDER;
    }

    @Override
    public String getName() {
        return "Config Manager";
    }
}
