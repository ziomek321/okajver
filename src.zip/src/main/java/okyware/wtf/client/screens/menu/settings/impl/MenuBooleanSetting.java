package okyware.wtf.client.screens.menu.settings.impl;

import lombok.Getter;
import okyware.wtf.base.animations.base.Animation;
import okyware.wtf.base.animations.base.Easing;
import okyware.wtf.base.font.Font;
import okyware.wtf.base.font.Fonts;
import okyware.wtf.base.theme.Theme;
import okyware.wtf.client.screens.menu.settings.api.MenuSetting;


import okyware.wtf.client.modules.api.setting.impl.BooleanSetting;
import okyware.wtf.utility.game.other.MouseButton;
import okyware.wtf.utility.render.display.base.BorderRadius;
import okyware.wtf.utility.render.display.base.Rect;
import okyware.wtf.utility.render.display.base.UIContext;
import okyware.wtf.utility.render.display.base.color.ColorRGBA;

public class MenuBooleanSetting extends MenuSetting {
    @Getter
    private final BooleanSetting setting;
    private final Animation animation = new Animation(300, Easing.QUARTIC_OUT);
    private Rect bounds;

    public MenuBooleanSetting(BooleanSetting setting) {

        this.setting = setting;
    }

    @Override
    public void render(UIContext ctx, float mouseX, float mouseY, float x, float settingY, float moduleWidth, float alpha, float animEnable, ColorRGBA themeColor, ColorRGBA textColor, ColorRGBA descriptionColor, Theme theme) {
        float settingHeight = 24;
        float settingX = x + 8;
        Font settingFont = Fonts.MEDIUM.getFont(7);
        Font descFont = Fonts.MEDIUM.getFont(6);
        float textY = settingY + (8 - settingFont.height()) / 2 - 0.5f;

        ctx.drawText(settingFont, setting.getName(), x + 8, textY, textColor);

        animation.animateTo(setting.isEnabled() ? 1.0f : 0.0f);
        float progress = animation.update();

        float toggleSize = 8;
        float toggleX = x + moduleWidth - toggleSize - 8;
        float toggleY = settingY;

        ColorRGBA colorEnable = theme.getWhiteGray().mix(theme.getColor(),animEnable);
        ColorRGBA colorToggle = theme.getForegroundLight().mix(colorEnable,animation.getValue()).mulAlpha(alpha);
        ColorRGBA borderColor = theme.getForegroundLightStroke().mix(new ColorRGBA(0,0,0,0),animation.getValue()).mulAlpha(alpha);
        ColorRGBA golochakaColor = theme.getGrayLight().mix(theme.getWhite(),animEnable);
        ColorRGBA golochakaFinalColor = new ColorRGBA(0,0,0,0).mix(golochakaColor,animation.getValue()).mulAlpha(alpha);

        ctx.drawRoundedRect(toggleX, toggleY, toggleSize, toggleSize, BorderRadius.all(2), colorToggle);
        ctx.drawRoundedBorder(toggleX, toggleY, toggleSize, toggleSize,-0.1f, BorderRadius.all(2),borderColor);
        
        Font iconFont = Fonts.ICONS.getFont(6);
        ctx.drawText(iconFont,"S",toggleX+2,toggleY+1,golochakaFinalColor);
        bounds = new Rect(toggleX, toggleY, toggleSize, toggleSize);


    }


    @Override
    public void onMouseClicked(double mouseX, double mouseY, MouseButton button) {
        if (bounds != null && bounds.contains(mouseX, mouseY) && button == MouseButton.LEFT) {
            setting.toggle();
        }
    }

    @Override
    public float getWidth() {
        return 0;
    }

    @Override
    public float getHeight() {
        return 8;
    }

    @Override
    public boolean isVisible() {
        return setting.getVisible().get();
    }
}
