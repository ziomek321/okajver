package okyware.wtf.client.screens.menu.settings.impl.popup;

import net.minecraft.client.MinecraftClient;
import okyware.wtf.Okyware;
import okyware.wtf.base.font.Font;
import okyware.wtf.base.font.Fonts;
import okyware.wtf.base.theme.Theme;
import okyware.wtf.client.screens.menu.settings.api.MenuPopupSetting;
import okyware.wtf.client.screens.menu.settings.api.MenuSetting;
import okyware.wtf.client.screens.menu.settings.impl.*;
import okyware.wtf.client.modules.api.setting.Setting;
import okyware.wtf.client.modules.api.setting.impl.*;
import okyware.wtf.utility.game.other.MouseButton;
import okyware.wtf.utility.render.display.base.BorderRadius;
import okyware.wtf.utility.render.display.base.ChangeRect;
import okyware.wtf.utility.render.display.base.UIContext;
import okyware.wtf.utility.render.display.base.color.ColorRGBA;
import okyware.wtf.utility.render.display.shader.DrawUtil;

import java.util.ArrayList;
import java.util.List;

public class HudSettingsPopup extends MenuPopupSetting {
    private final String title;
    private final List<MenuSetting> menuSettings = new ArrayList<>();
    private float scrollY = 0;

    public HudSettingsPopup(ChangeRect bounds, String title, List<Setting> baseSettings) {
        super(bounds);
        this.title = title;
        this.animationScale = new okyware.wtf.base.animations.base.Animation(300, 0.01f, okyware.wtf.base.animations.base.Easing.BACK_OUT);
        this.animationScale.update(1);

        for (Setting setting : baseSettings) {
            if (setting instanceof NumberSetting sliderSetting) {
                menuSettings.add(new MenuSliderSetting(sliderSetting));
            } else if (setting instanceof ModeSetting modeSetting) {
                menuSettings.add(new MenuModeSetting(modeSetting));
            } else if (setting instanceof MultiBooleanSetting selectSetting) {
                menuSettings.add(new MenuSelectSetting(selectSetting));
            } else if (setting instanceof BooleanSetting booleanSetting) {
                menuSettings.add(new MenuBooleanSetting(booleanSetting));
            } else if (setting instanceof ColorSetting colorSetting) {
                menuSettings.add(new MenuColorSetting(colorSetting));
            } else if (setting instanceof ButtonSetting buttonSetting) {
                menuSettings.add(new MenuButtonSetting(buttonSetting));
            } else if (setting instanceof ItemSelectSetting itemSelectSetting) {
                menuSettings.add(new MenuItemSetting(itemSelectSetting));
            } else if (setting instanceof KeySetting keySetting) {
                menuSettings.add(new MenuKeySetting(keySetting));
            } else if (setting instanceof StringSetting stringSetting) {
                menuSettings.add(new MenuStringSetting(stringSetting));
            }
        }
    }

    @Override
    public void render(UIContext ctx, float mouseX, float mouseY, float alpha, Theme theme) {
        animationScale.update();
        float anim = animationScale.getValue();
        if (anim <= 0.01f) return;

        float totalHeight = 12; 
        for (MenuSetting setting : menuSettings) {
            if (setting.isVisible()) totalHeight += setting.getHeight() + 8;
        }
        
        bounds.setWidth(130);
        bounds.setHeight(totalHeight);

        float x = bounds.getX();
        float y = bounds.getY();
        float width = bounds.getWidth();
        float height = bounds.getHeight();

        ctx.pushMatrix();
        ctx.getMatrices().translate(x + width / 2f, y + height / 2f, 0);
        ctx.getMatrices().scale(anim, anim, 1);
        ctx.getMatrices().translate(-(x + width / 2f), -(y + height / 2f), 0);

        
        if (okyware.wtf.client.modules.impl.render.Interface.INSTANCE.isBlur()) {
            DrawUtil.drawBlur(ctx.getMatrices(), x, y, width, height, 15 * anim, BorderRadius.all(6), ColorRGBA.WHITE.mulAlpha(alpha));
        }
        ctx.drawRoundedRect(x, y, width, height, BorderRadius.all(6), theme.getForegroundDark().mulAlpha(alpha * 0.95f));
        DrawUtil.drawRoundedBorder(ctx.getMatrices(), x, y, width, height, 0.5f, BorderRadius.all(6), theme.getForegroundStroke().mulAlpha(alpha));

        
        float startY = y + 8 - scrollY;
        ctx.enableScissor((int) x, (int) y, (int) (x + width), (int) (y + height));
        
        ColorRGBA textColor = theme.getWhite().mulAlpha(alpha);
        ColorRGBA descriptionColor = theme.getGrayLight().mulAlpha(alpha);

        for (MenuSetting setting : menuSettings) {
            if (!setting.isVisible()) continue;
            setting.render(ctx, mouseX, mouseY, x + 4, startY, width - 8, alpha, 1f, theme.getColor().mulAlpha(alpha), textColor, descriptionColor, theme);
            startY += setting.getHeight() + 8;
        }
        ctx.disableScissor();

        ctx.popMatrix();
    }

    @Override
    public void onMouseClicked(double mouseX, double mouseY, MouseButton button) {
        float x = bounds.getX();
        float y = bounds.getY();
        float width = bounds.getWidth();
        float height = bounds.getHeight();
        

        for (MenuSetting setting : menuSettings) {
            if (setting.isVisible()) {
                setting.onMouseClicked(mouseX, mouseY, button);
            }
        }
    }

    @Override
    public void onMouseReleased(double mouseX, double mouseY, MouseButton button) {
        for (MenuSetting setting : menuSettings) {
            setting.onMouseReleased(mouseX, mouseY, button);
        }
    }

    @Override
    public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
        for (MenuSetting setting : menuSettings) {
            if (setting.keyPressed(keyCode, scanCode, modifiers)) return true;
        }
        return false;
    }

    @Override
    public boolean charTyped(char chr, int modifiers) {
        for (MenuSetting setting : menuSettings) {
            if (setting.charTyped(chr, modifiers)) return true;
        }
        return false;
    }

    @Override
    public boolean mouseScrolled(double mouseX, double mouseY, double horizontalAmount, double verticalAmount) {
        scrollY -= verticalAmount * 15;
        if (scrollY < 0) scrollY = 0;
        return true;
    }

    @Override
    public float getWidth() { return bounds.getWidth(); }
    @Override
    public float getHeight() { return bounds.getHeight(); }
    @Override
    public boolean isVisible() { return true; }

    public boolean isClosing() { return animationScale.getValue() <= 0.01f; }
}
