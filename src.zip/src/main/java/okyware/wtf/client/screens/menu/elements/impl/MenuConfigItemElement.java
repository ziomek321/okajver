package okyware.wtf.client.screens.menu.elements.impl;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ServerInfo;
import net.minecraft.client.texture.NativeImage;
import net.minecraft.client.texture.NativeImageBackedTexture;
import net.minecraft.util.Identifier;
import okyware.wtf.Okyware;
import okyware.wtf.base.animations.base.Animation;
import okyware.wtf.base.animations.base.Easing;
import okyware.wtf.base.config.ConfigManager;
import okyware.wtf.base.font.Font;
import okyware.wtf.base.font.Fonts;
import okyware.wtf.base.theme.Theme;
import okyware.wtf.client.modules.api.Category;
import okyware.wtf.client.screens.menu.elements.api.AbstractMenuElement;
import okyware.wtf.utility.game.other.MouseButton;
import okyware.wtf.utility.render.display.base.BorderRadius;
import okyware.wtf.utility.render.display.base.Rect;
import okyware.wtf.utility.render.display.base.UIContext;
import okyware.wtf.utility.render.display.base.color.ColorRGBA;
import okyware.wtf.utility.render.display.shader.DrawUtil;

import java.lang.reflect.Method;
import java.util.Base64;
import java.util.HashMap;
import java.util.Map;

public class MenuConfigItemElement extends AbstractMenuElement {
    private final String configName;
    private final boolean isCloud;
    private final int cloudId;
    private String serverIP = "none";
    private String author = "";
    
    private final Animation animation;
    private final Animation animationPosition;
    private final Animation animationY;
    private final Animation clickAnim = new Animation(150, 0, Easing.QUAD_IN_OUT);
    private String lastStatus = "";
    private long statusTime = 0;
    private Rect bounds;
    private Rect loadBtnBounds;
    private Rect saveBtnBounds;
    private Rect deleteBtnBounds;
    private Rect uploadBtnBounds;
    
    private int lastColum = -1;
    private boolean animated = false;
    
    private static final Map<String, Identifier> serverIconCache = new HashMap<>();
    private static final java.util.Set<String> pingingNow = java.util.concurrent.ConcurrentHashMap.newKeySet();

    public MenuConfigItemElement(String configName, boolean isCloud) {
        this(configName, isCloud, -1, null, "");
    }

    public MenuConfigItemElement(String configName, boolean isCloud, String serverIP) {
        this(configName, isCloud, -1, serverIP, "");
    }

    public MenuConfigItemElement(String configName, boolean isCloud, int cloudId, String serverIP) {
        this(configName, isCloud, cloudId, serverIP, "");
    }

    public MenuConfigItemElement(String configName, boolean isCloud, int cloudId, String serverIP, String author) {
        this.configName = configName;
        this.isCloud = isCloud;
        this.cloudId = cloudId;
        this.author = author == null ? "" : author;
        this.animation = new Animation(200, 1, Easing.LINEAR);
        this.animationPosition = new Animation(150, 1, Easing.QUAD_IN_OUT);
        this.animationY = new Animation(150, 1, Easing.QUAD_IN_OUT);

        if (serverIP != null) {
            this.serverIP = serverIP;
        } else if (!isCloud) {
            okyware.wtf.base.config.Config c = Okyware.getInstance().getConfigManager().findConfig(configName);
            if (c != null) this.serverIP = c.getServerIP();
        }
    }

    @Override
    public void render(UIContext ctx, float mouseX, float mouseY, Font font, float x, float y, float moduleWidth, float alpha, int colum) {
        if (lastColum == -1) lastColum = colum;
        if (lastColum != colum) {
            animated = true;
            animationPosition.animateTo(x);
            animationY.animateTo(y);
            lastColum = colum;
        }
        if (animated) {
            x = animationPosition.update(x);
            y = animationY.update(y);
            if (animationPosition.isDone() && animationY.isDone()) animated = false;
        } else {
            animationPosition.reset(x);
            animationY.reset(y);
        }

        float moduleHeight = 70;
        Theme theme = Okyware.getInstance().getThemeManager().getCurrentTheme();
        ColorRGBA textColor = theme.getWhite().mulAlpha(alpha);
        boolean cardHover = mouseX >= x && mouseX <= x + moduleWidth && mouseY >= y && mouseY <= y + moduleHeight;

        bounds = new Rect(x, y, moduleWidth, moduleHeight);

        ColorRGBA cardBg = theme.getForegroundColor().mix(theme.getForegroundLight(), cardHover ? 0.25f : 0f).mulAlpha(alpha);
        DrawUtil.drawBlur(ctx.getMatrices(), x, y, moduleWidth, moduleHeight, 15f, BorderRadius.all(10), ColorRGBA.WHITE.mulAlpha(alpha));
        ctx.drawRoundedRect(x, y, moduleWidth, moduleHeight, BorderRadius.all(10), cardBg);
        DrawUtil.drawRoundedBorder(ctx.getMatrices(), x, y, moduleWidth, moduleHeight, -0.5f,
                BorderRadius.all(10), theme.getForegroundStroke().mulAlpha(alpha));

        
        float pad = 10;
        float iconSize = 22;
        float iconX = x + pad;
        float iconY = y + pad;
        String iconIp = serverIP;
        if ((iconIp == null || iconIp.equals("none") || iconIp.isEmpty()) && MinecraftClient.getInstance().getCurrentServerEntry() != null) {
            iconIp = MinecraftClient.getInstance().getCurrentServerEntry().address;
        }
        Identifier serverIcon = getServerIcon(iconIp);
        if (serverIcon != null) {
            DrawUtil.drawRoundedTextureSmooth(ctx.getMatrices(), serverIcon,
                    iconX, iconY, iconSize, iconSize, BorderRadius.all(5),
                    ColorRGBA.WHITE.mulAlpha(alpha));
        } else {
            ctx.drawRoundedRect(iconX, iconY, iconSize, iconSize, BorderRadius.all(5),
                    theme.getForegroundDark().mulAlpha(alpha));
            Identifier msdfIcon = Okyware.id("icons/config.png");
            DrawUtil.drawMSDFIcon(ctx.getMatrices(), msdfIcon,
                    iconX + 4, iconY + 4, iconSize - 8, iconSize - 8,
                    4f, 0.4f, 0.2f, theme.getColor().mulAlpha(alpha));
        }

        String displayText = configName;
        if (System.currentTimeMillis() - statusTime < 1500) {
            displayText = lastStatus;
        }
        Font nameFont = Fonts.MEDIUM.getFont(9);
        Font ipFont = Fonts.MEDIUM.getFont(6);

        float nameY = iconY + 1;
        float nameX = iconX + iconSize + 8;
        ctx.drawText(nameFont, displayText, nameX, nameY, textColor);

        String ipText = (serverIP == null || serverIP.equals("none") || serverIP.isEmpty()) ? "no server" : serverIP;
        float ipY = nameY + nameFont.height() + 2;
        ctx.drawRoundedRect(nameX, ipY + 2, 3, 3, BorderRadius.all(1.5f),
                theme.getColor().mulAlpha(alpha * 0.9f));
        ctx.drawText(ipFont, ipText, nameX + 6, ipY, theme.getGrayLight().mulAlpha(alpha));

        if (isCloud && author != null && !author.isEmpty()) {
            float authorY = ipY + ipFont.height() + 1;
            ctx.drawText(ipFont, "by " + author, nameX, authorY, theme.getGrayLight().mulAlpha(alpha * 0.85f));
        }

        
        float divY = y + moduleHeight - 22;
        ctx.drawRoundedRect(x + pad, divY, moduleWidth - pad * 2, 0.5f, BorderRadius.ZERO,
                theme.getForegroundStroke().mulAlpha(alpha * 0.6f));

        
        float btnH = 14;
        float btnW = 32;
        float btnGap = 5;
        Font btnFont = Fonts.MEDIUM.getFont(6f);
        float btnY = divY + 4;
        float bx = x + moduleWidth - pad - btnW;

        if (!isCloud) {
            deleteBtnBounds = new Rect(bx, btnY, btnW, btnH);
            boolean delHover = deleteBtnBounds.contains(mouseX, mouseY);
            renderBtn(ctx, deleteBtnBounds, "Del",
                    delHover ? ColorRGBA.RED.mulAlpha(alpha) : theme.getForegroundDark().mulAlpha(alpha),
                    theme.getWhite().mulAlpha(alpha), btnFont);

            bx -= (btnW + btnGap);
            uploadBtnBounds = new Rect(bx, btnY, btnW, btnH);
            boolean upHover = uploadBtnBounds.contains(mouseX, mouseY);
            renderBtn(ctx, uploadBtnBounds, "Up",
                    upHover ? theme.getColor().mix(ColorRGBA.WHITE, 0.2f).mulAlpha(alpha) : theme.getForegroundDark().mulAlpha(alpha),
                    theme.getWhite().mulAlpha(alpha), btnFont);

            bx -= (btnW + btnGap);
            loadBtnBounds = new Rect(bx, btnY, btnW, btnH);
            boolean loadHover = loadBtnBounds.contains(mouseX, mouseY);
            renderBtn(ctx, loadBtnBounds, "Load",
                    loadHover ? theme.getColor().mix(ColorRGBA.WHITE, 0.2f).mulAlpha(alpha) : theme.getColor().mulAlpha(alpha),
                    theme.getWhite().mulAlpha(alpha), btnFont);
        } else {
            deleteBtnBounds = new Rect(bx, btnY, btnW, btnH);
            boolean delHover = deleteBtnBounds.contains(mouseX, mouseY);
            renderBtn(ctx, deleteBtnBounds, "Del",
                    delHover ? ColorRGBA.RED.mulAlpha(alpha) : theme.getForegroundDark().mulAlpha(alpha),
                    theme.getWhite().mulAlpha(alpha), btnFont);

            bx -= (btnW + btnGap);
            loadBtnBounds = new Rect(bx, btnY, btnW, btnH);
            boolean loadHover = loadBtnBounds.contains(mouseX, mouseY);
            renderBtn(ctx, loadBtnBounds, "Load",
                    loadHover ? theme.getColor().mix(ColorRGBA.WHITE, 0.2f).mulAlpha(alpha) : theme.getColor().mulAlpha(alpha),
                    theme.getWhite().mulAlpha(alpha), btnFont);
        }
    }

    private void renderBtn(UIContext ctx, Rect b, String text, ColorRGBA bg, ColorRGBA textCol, Font font) {
        ctx.drawRoundedRect(b.x(), b.y(), b.width(), b.height(), BorderRadius.all(5), bg);
        DrawUtil.drawRoundedBorder(ctx.getMatrices(), b.x(), b.y(), b.width(), b.height(), 0.5f, BorderRadius.all(5), Okyware.getInstance().getThemeManager().getCurrentTheme().getForegroundStroke().mulAlpha(bg.getAlpha()));
        ctx.drawText(font, text, b.x() + (b.width() - font.width(text)) / 2f, b.y() + (b.height() - font.height()) / 2f + 0.5f, textCol);
    }

    private static final java.io.File SERVER_ICON_DIR = new java.io.File(Okyware.DIRECTORY, "server_icons");

    private static final java.util.Set<String> debuggedOnce = java.util.concurrent.ConcurrentHashMap.newKeySet();

    private Identifier getServerIcon(String ip) {
        if (ip == null || ip.equals("none") || ip.isEmpty()) return null;
        if (serverIconCache.containsKey(ip)) return serverIconCache.get(ip);

        boolean firstTime = debuggedOnce.add(ip);
        MinecraftClient mc = MinecraftClient.getInstance();

        ServerInfo current = mc.getCurrentServerEntry();
        if (current != null && current.address != null && addressMatches(current.address, ip)) {
            byte[] fav = tryGetFavicon(current);
            if (firstTime) System.out.println("[Okyware][ServerIcon] '" + ip + "' current entry favicon=" + (fav == null ? "null" : fav.length + " bytes"));
            Identifier id = registerServerIcon(ip, fav, true);
            if (id != null) return id;
        } else if (firstTime) {
            System.out.println("[Okyware][ServerIcon] '" + ip + "' current entry " + (current == null ? "null" : "address=" + current.address));
        }

        net.minecraft.client.option.ServerList serverList = new net.minecraft.client.option.ServerList(mc);
        serverList.loadFile();
        boolean foundInList = false;
        for (int i = 0; i < serverList.size(); i++) {
            ServerInfo info = serverList.get(i);
            if (info.address != null && addressMatches(info.address, ip)) {
                foundInList = true;
                byte[] fav = tryGetFavicon(info);
                if (firstTime) System.out.println("[Okyware][ServerIcon] '" + ip + "' saved-list match '" + info.address + "' favicon=" + (fav == null ? "null" : fav.length + " bytes"));
                Identifier id = registerServerIcon(ip, fav, true);
                if (id != null) return id;
            }
        }
        if (firstTime && !foundInList) {
            System.out.println("[Okyware][ServerIcon] '" + ip + "' not present in saved server list (" + serverList.size() + " entries)");
        }

        java.io.File diskFile = new java.io.File(SERVER_ICON_DIR, sanitize(ip) + ".png");
        if (diskFile.exists()) {
            try {
                byte[] iconBytes = java.nio.file.Files.readAllBytes(diskFile.toPath());
                if (firstTime) System.out.println("[Okyware][ServerIcon] '" + ip + "' disk cache hit (" + iconBytes.length + " bytes)");
                Identifier id = registerServerIcon(ip, iconBytes, false);
                if (id != null) return id;
            } catch (Exception ignored) {}
        }

        if (firstTime) System.out.println("[Okyware][ServerIcon] '" + ip + "' falling back to SLP ping");
        kickOffSlpPing(ip);
        return null;
    }

    private static boolean addressMatches(String a, String b) {
        if (a == null || b == null) return false;
        String na = stripPort(a).toLowerCase().trim();
        String nb = stripPort(b).toLowerCase().trim();
        if (na.equals(nb)) return true;
        return a.trim().equalsIgnoreCase(b.trim());
    }

    private static String stripPort(String addr) {
        int colon = addr.lastIndexOf(':');
        if (colon > 0 && addr.indexOf(':') == colon) {
            String tail = addr.substring(colon + 1);
            try { Integer.parseInt(tail); return addr.substring(0, colon); } catch (NumberFormatException ignored) {}
        }
        return addr;
    }

    private void kickOffSlpPing(String ip) {
        if (!pingingNow.add(ip)) return;
        new Thread(() -> {
            try {
                byte[] favicon = okyware.wtf.utility.server.ServerStatusPinger.fetchFavicon(ip);
                if (favicon != null && favicon.length > 0) {
                    System.out.println("[Okyware][ServerIcon] SLP ping fetched " + favicon.length + " bytes from " + ip);
                    SERVER_ICON_DIR.mkdirs();
                    try {
                        java.nio.file.Files.write(new java.io.File(SERVER_ICON_DIR, sanitize(ip) + ".png").toPath(), favicon);
                    } catch (Exception ignored) {}
                    final byte[] bytes = favicon;
                    MinecraftClient.getInstance().execute(() -> registerServerIcon(ip, bytes, false));
                } else {
                    System.out.println("[Okyware][ServerIcon] SLP ping returned no favicon for " + ip);
                }
            } catch (Exception e) {
                System.err.println("[Okyware][ServerIcon] SLP ping failed for " + ip + ": " + e);
            } finally {
                pingingNow.remove(ip);
            }
        }, "Okyware-SLP-" + ip).start();
    }

    private Identifier registerServerIcon(String ip, byte[] iconBytes, boolean persist) {
        if (iconBytes == null || iconBytes.length == 0) return null;
        try {
            NativeImage image = NativeImage.read(iconBytes);
            MinecraftClient mc = MinecraftClient.getInstance();
            Identifier id = Okyware.id("server_icon/" + sanitize(ip));
            NativeImageBackedTexture tex = new NativeImageBackedTexture(image);
            tex.setFilter(true, true);
            mc.getTextureManager().registerTexture(id, tex);
            serverIconCache.put(ip, id);

            if (persist) {
                try {
                    SERVER_ICON_DIR.mkdirs();
                    java.io.File out = new java.io.File(SERVER_ICON_DIR, sanitize(ip) + ".png");
                    if (!out.exists()) {
                        java.nio.file.Files.write(out.toPath(), iconBytes);
                    }
                } catch (Exception ignored) {}
            }
            return id;
        } catch (Exception ignored) {
            return null;
        }
    }

    private static String sanitize(String ip) {
        return ip.replaceAll("[^a-zA-Z0-9]", "_").toLowerCase();
    }

    private byte[] tryGetFavicon(ServerInfo info) {
        try {
            
            for (Method m : info.getClass().getMethods()) {
                if (m.getName().toLowerCase().contains("favicon") || m.getName().toLowerCase().contains("icon")) {
                    if (m.getReturnType() == byte[].class) {
                        return (byte[]) m.invoke(info);
                    }
                }
            }
            
            for (java.lang.reflect.Field f : info.getClass().getFields()) {
                if (f.getName().toLowerCase().contains("favicon") || f.getName().toLowerCase().contains("icon")) {
                    if (f.getType() == byte[].class) {
                        return (byte[]) f.get(info);
                    }
                }
            }
        } catch (Exception ignored) {}
        return null;
    }

    @Override public float getHeight() { return 70; }
    @Override public void onMouseClicked(double mouseX, double mouseY, MouseButton button) {
        if (button == MouseButton.LEFT) {
            ConfigManager configManager = Okyware.getInstance().getConfigManager();
            if (loadBtnBounds != null && loadBtnBounds.contains(mouseX, mouseY)) {
                if (isCloud) {
                    if (cloudId > 0) {
                        configManager.loadCloudConfig(cloudId);
                        lastStatus = "Loading...";
                        statusTime = System.currentTimeMillis();
                        okyware.wtf.base.notify.NotifyManager.getInstance().addNotification("4", net.minecraft.text.Text.literal("Loading cloud config: " + configName));
                    } else {
                        lastStatus = "No id!";
                        statusTime = System.currentTimeMillis();
                    }
                } else {
                    boolean ok = configManager.loadConfig(configName);
                    lastStatus = ok ? "Loaded!" : "Load fail";
                    statusTime = System.currentTimeMillis();
                    okyware.wtf.base.notify.NotifyManager.getInstance().addNotification("4", net.minecraft.text.Text.literal((ok ? "Loaded config: " : "Failed to load: ") + configName));
                }
            } else if (uploadBtnBounds != null && uploadBtnBounds.contains(mouseX, mouseY)) {
                configManager.saveToCloud(configName);
                lastStatus = "Uploaded!";
                statusTime = System.currentTimeMillis();
            } else if (deleteBtnBounds != null && deleteBtnBounds.contains(mouseX, mouseY)) {
                if (isCloud) {
                    if (cloudId > 0) {
                        configManager.deleteCloudConfig(cloudId);
                        okyware.wtf.base.notify.NotifyManager.getInstance().addNotification("4",
                                net.minecraft.text.Text.literal("Deleting cloud config: " + configName));
                    }
                } else {
                    boolean ok = configManager.deleteConfig(configName);
                    okyware.wtf.base.notify.NotifyManager.getInstance().addNotification("4",
                            net.minecraft.text.Text.literal((ok ? "Deleted config: " : "Failed to delete: ") + configName));
                }
            }
        }
    }
    @Override public void onMouseReleased(double mouseX, double mouseY, MouseButton button) {}
    @Override public void onMouseDragged(double mouseX, double mouseY, MouseButton button, double deltaX, double deltaY) {}
    @Override public boolean keyPressed(int keyCode, int scanCode, int modifiers) { return false; }
    @Override public boolean charTyped(char chr, int modifiers) { return false; }
    @Override public boolean mouseScrolled(double mouseX, double mouseY, double horizontalAmount, double verticalAmount) { return false; }
    @Override public Category getCategory() { return Category.CONFIG; }
    @Override public String getName() { return configName; }
}
