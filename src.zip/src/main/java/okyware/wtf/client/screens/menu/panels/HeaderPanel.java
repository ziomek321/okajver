package okyware.wtf.client.screens.menu.panels;

import net.minecraft.util.math.MathHelper;
import okyware.wtf.Okyware;
import okyware.wtf.base.animations.base.Animation;
import okyware.wtf.base.animations.base.Easing;
import okyware.wtf.base.font.Font;
import okyware.wtf.base.font.Fonts;
import okyware.wtf.base.theme.Theme;
import okyware.wtf.client.modules.api.Category;
import okyware.wtf.utility.render.display.TextBox;
import okyware.wtf.utility.render.display.base.BorderRadius;
import okyware.wtf.utility.render.display.base.CustomSprite;
import okyware.wtf.utility.render.display.base.Rect;
import okyware.wtf.utility.render.display.base.UIContext;
import okyware.wtf.utility.render.display.base.color.ColorRGBA;
import okyware.wtf.utility.render.display.shader.DrawUtil;
import okyware.wtf.client.modules.api.Module;

public class HeaderPanel {

    public Rect themeButtonBounds;
    public Rect searchBarBounds;
    public Rect plusButtonBounds;
    public Rect refreshButtonBounds;

    private final TextBox searchField;
    private final Runnable onThemeSwitch;
    private Category lastCategory = Category.COMBAT;
    private final Animation animation = new Animation(300, 1, Easing.QUAD_IN_OUT);

    public HeaderPanel(TextBox searchField, Runnable onThemeSwitch) {
        this.searchField = searchField;
        this.onThemeSwitch = onThemeSwitch;
    }

    public void render(UIContext ctx, float contentStartX, float sidebarY,
                       float boxX, int columns,float boxWidth, float progress,
                       Theme theme, Category selectedCategory) {
        animation.update(1);
        ColorRGBA textColor = theme.getWhite().mulAlpha(progress);
        float x = contentStartX;
        
        if (false) {
            float searchW = 128, searchH = 22, pad = 8;
            float searchX = boxX + boxWidth - pad - searchW;
            
            float createW = 45;
            float createH = 22;
            float createX = searchX - pad - createW;
            
            this.plusButtonBounds = new Rect(createX, sidebarY, createW, createH);
            
            ctx.drawRoundedRect(createX, sidebarY, createW, createH, BorderRadius.all(7), theme.getForegroundColor().mulAlpha(progress));
            
            Font font = Fonts.MEDIUM.getFont(7);
            ctx.drawText(font, "Create", createX + (createW - font.width("Create")) / 2f, sidebarY + (createH - font.height()) / 2f, theme.getWhite().mulAlpha(progress));

            float refreshW = 52;
            float refreshX = createX - pad - refreshW;
            this.refreshButtonBounds = new Rect(refreshX, sidebarY, refreshW, createH);
            ctx.drawRoundedRect(refreshX, sidebarY, refreshW, createH, BorderRadius.all(7), theme.getForegroundColor().mulAlpha(progress));
            ctx.drawText(font, "Refresh", refreshX + (refreshW - font.width("Refresh")) / 2f, sidebarY + (createH - font.height()) / 2f, theme.getWhite().mulAlpha(progress));
        } else {
            this.plusButtonBounds = null;
            this.refreshButtonBounds = null;
        }
        
        renderSearchBar(ctx, boxX, sidebarY, boxWidth, progress, theme);
    }

    private float renderBreadcrumbs(UIContext ctx, float startX, float y,
                                    float progress, Theme theme,
                                    Category selectedCategory,
                                    ColorRGBA textColor) {
        String name = selectedCategory.getName();
        Font font = Fonts.MEDIUM.getFont(7);
        Font icon7 = Fonts.ICONS.getFont(7);
        Font icon6 = Fonts.ICONS.getFont(5);

        float homeIcon = 7, arrowIcon = 6, catIcon = 7;
        float pad = 8, gap = 4, tgap = 2;
        float textW = MathHelper.lerp(animation.getValue(), font.width(lastCategory.getName()), font.width(name));
        float width = pad * 2 + homeIcon + gap + arrowIcon  + catIcon + tgap + textW;
        float h = 22;

        ColorRGBA bar = theme.getForegroundColor().mulAlpha(progress);
        ctx.drawRoundedRect(startX, y, width, h, BorderRadius.all(7), bar);
        float cx = startX + pad;
        float vy = y + h / 2f;
        ctx.drawText(icon7, "7", cx, vy - icon7.height() / 2 - .5f, theme.getColor().mulAlpha(progress));
        cx += icon7.width("7") + gap;
        ctx.drawText(icon6, "A", cx + 1, vy - icon6.height() / 2 - .3f, theme.getForegroundGray().mulAlpha(progress));
        cx += icon6.width("A") + gap;
        ctx.enableScissor((int) startX+20, (int) y, (int) (startX + width), (int) (y + h));

        float offset = (1-animation.getValue())*font.width(name)*2;
        float offset2 = (animation.getValue())*font.width(lastCategory.getName());

        ctx.drawText(font, name, cx+offset, vy - font.height() / 2f, textColor.mulAlpha(animation.getValue()));
        ctx.drawText(font, lastCategory.getName(), cx-offset2, vy - font.height() / 2f, textColor.mulAlpha(1-animation.getValue()));
        ctx.disableScissor();
        return startX + width;
    }

    private void renderSearchBar(UIContext ctx, float boxX, float y,
                                 float boxWidth, float progress, Theme theme) {

        float w = 128, h = 22, pad = 8;
        float x = boxX + boxWidth - pad - w;
        this.searchBarBounds = new Rect(x, y, w, h);

        ColorRGBA bar = theme.getBackgroundColor().mulAlpha(progress);
        ctx.drawRoundedRect(x, y, w, h, BorderRadius.all(6), bar);

        Font font = Fonts.MEDIUM.getFont(7);
        String txt = searchField.getText();
        boolean empty = txt.isEmpty() && !searchField.isSelected();
        float ty = y + (h - font.height()) / 2f;
        if (empty) {
            ctx.drawText(font, "Search", x + 8, ty, theme.getWhite().mulAlpha(progress * 0.5f));
        } else {
            ctx.enableScissor((int) x + 8, (int) ty - 10, (int) Math.ceil(x + 8 + 128), (int) Math.ceil(ty) + 10);
            searchField.render(ctx, x + 8, ty, theme.getWhite().mulAlpha(progress),
                    theme.getWhite().mulAlpha(progress * 0.5f));
            ctx.disableScissor();
        }
    }

    public void resetAnim(Category last, Category next) {

        animation.reset(0);

        this.lastCategory = last;
    }

    public boolean handleMouseClicked(double mouseX, double mouseY) {
        return searchBarBounds != null && searchBarBounds.contains(mouseX, mouseY) || (plusButtonBounds != null && plusButtonBounds.contains(mouseX, mouseY)) || (refreshButtonBounds != null && refreshButtonBounds.contains(mouseX, mouseY));
    }
}
