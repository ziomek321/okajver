package okyware.wtf.client.screens.menu.panels;

import lombok.Getter;
import okyware.wtf.base.animations.base.Animation;
import okyware.wtf.base.animations.base.Easing;
import okyware.wtf.base.font.Font;
import okyware.wtf.base.font.Fonts;
import okyware.wtf.base.theme.Theme;
import okyware.wtf.client.modules.api.Category;
import okyware.wtf.utility.math.MathUtil;
import okyware.wtf.utility.render.display.base.*;
import okyware.wtf.utility.render.display.base.color.ColorRGBA;

import okyware.wtf.utility.render.display.shader.DrawUtil;
import java.util.*;
import java.util.function.Consumer;

public class SidebarPanel {

    @Getter
    private final Map<Category, Rect> categoryBounds = new HashMap<>();
    @Getter
    private Rect sidebarToggleButtonBounds = new Rect(0, 0, 0, 0);
    private Rect animRect = new Rect(0, 0, 0, 0);
    private Animation animationChange = new Animation(200, 1, Easing.QUAD_IN_OUT);
    private final Animation sidebarAnimation;
    private final boolean isSidebarExpanded;

    private final Consumer<Category> onCategorySelect;
    private final Runnable onSidebarToggle;
    private final List<SideBarCategory> categories = new ArrayList<>();

    public SidebarPanel(Animation sidebarAnimation, boolean isSidebarExpanded, Consumer<Category> onCategorySelect, Runnable onSidebarToggle) {
        this.sidebarAnimation = sidebarAnimation;
        this.isSidebarExpanded = isSidebarExpanded;
        this.onCategorySelect = onCategorySelect;
        this.onSidebarToggle = onSidebarToggle;
        categories.addAll(Arrays.stream(Category.values()).filter(c -> c != Category.THEME).map(SideBarCategory::new).toList());
    }

    public void render(UIContext ctx, float boxX, float boxY, float height, float progress, Theme theme, Category selectedCategory, ColorRGBA primary, ColorRGBA textColor, ColorRGBA selectedColor) {
        float sidebarProgress = sidebarAnimation.update();
        float collapsedSidebarWidth = 30f;
        float expandedSidebarWidth = 88;
        float sidebarWidth = collapsedSidebarWidth + (expandedSidebarWidth - collapsedSidebarWidth) * sidebarProgress;
        float sidebarPadding = 8;
        float sidebarX = boxX + sidebarPadding;
        float sidebarY = boxY + sidebarPadding;
        float sidebarHeight = height - sidebarPadding * 2;

        categoryBounds.clear();

        Font logoFont = Fonts.SEMIBOLD.getFont(10);
        String logoText = "OK*YWARE";
        float logoWidth = logoFont.width(logoText);
        float logoX = sidebarX + (sidebarWidth - logoWidth) / 2f;
        float logoY = sidebarY + 14;
        
        ctx.drawText(logoFont, logoText, logoX, logoY, ColorRGBA.WHITE.mulAlpha(progress));

        ctx.pushMatrix();
        ctx.enableScissor((int) sidebarX, (int) sidebarY,
                (int) (sidebarX + sidebarWidth), (int) (sidebarY + sidebarHeight));

        float textAlpha = Math.min(1f, sidebarProgress * 2f);
        ColorRGBA catTextColor = textColor.mulAlpha(textAlpha);
        ColorRGBA textColorDisable = theme.getGrayLight().mulAlpha(progress * textAlpha);
        ColorRGBA iconColorDisable = new ColorRGBA(120, 120, 120).mulAlpha(progress);

        float iconSize = 9f;
        float padding = 12f;
        float startY = sidebarY + 40;

        {
            int idx = 0;
            for (SideBarCategory sideBarCategory : categories) {
                if (selectedCategory == sideBarCategory.getCategory()) {
                    float categoryY = startY + idx * (iconSize + padding);
                    animRect = new Rect(
                        MathUtil.interpolate(animRect.x(), sidebarX + 4, animationChange.getValue()),
                        MathUtil.interpolate(animRect.y(), categoryY, animationChange.getValue()),
                        sidebarWidth - 8, iconSize + 11
                    );
                    ctx.drawRoundedRect(animRect.x(), animRect.y(), sidebarWidth - 8, iconSize + 11,
                            BorderRadius.all(4), new ColorRGBA(51, 75, 59).mulAlpha(progress));
                    break;
                }
                idx++;
            }
        }
        animationChange.animateTo(1f);
        animationChange.update();

        int index = 0;
        for (SideBarCategory sideBarCategory : categories) {
            float categoryY = startY + index * (iconSize + padding);
            sideBarCategory.render(ctx, sidebarX + 4, categoryY, sidebarWidth - 8, iconSize + 11,
                    sidebarProgress, selectedCategory == sideBarCategory.getCategory(),
                    catTextColor, textColorDisable, iconColorDisable, ColorRGBA.WHITE.mulAlpha(progress));
            categoryBounds.put(sideBarCategory.getCategory(), new Rect(sidebarX + 4, categoryY, sidebarWidth - 8, iconSize + 11));
            index++;
        }

        ctx.disableScissor();
        ctx.popMatrix();
    }

    public boolean handleMouseClicked(double mouseX, double mouseY) {
        for (Map.Entry<Category, Rect> entry : categoryBounds.entrySet()) {
            if (entry.getValue().contains(mouseX, mouseY)) {
                animationChange.animateTo(0);
                animationChange.setValue(0);
                onCategorySelect.accept(entry.getKey());
                return true;
            }
        }
        return false;
    }
}
