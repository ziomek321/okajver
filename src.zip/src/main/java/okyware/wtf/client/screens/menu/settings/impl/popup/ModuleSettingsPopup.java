package okyware.wtf.client.screens.menu.settings.impl.popup;

import net.minecraft.client.MinecraftClient;
import okyware.wtf.client.screens.menu.MenuScreen;
import okyware.wtf.Okyware;
import okyware.wtf.base.font.Font;
import okyware.wtf.base.font.Fonts;
import okyware.wtf.base.theme.Theme;
import okyware.wtf.client.modules.api.Module;
import okyware.wtf.client.screens.menu.settings.api.MenuPopupSetting;
import okyware.wtf.client.screens.menu.settings.api.MenuSetting;
import okyware.wtf.utility.game.other.MouseButton;
import okyware.wtf.utility.render.display.base.BorderRadius;
import okyware.wtf.utility.render.display.base.ChangeRect;
import okyware.wtf.utility.render.display.base.UIContext;
import okyware.wtf.utility.render.display.base.color.ColorRGBA;
import okyware.wtf.utility.render.display.shader.DrawUtil;

import java.util.List;
import java.util.Objects;

public class ModuleSettingsPopup extends MenuPopupSetting {
    private final Module module;
    private final List<MenuSetting> settings;
    private float scrollY = 0;

    public ModuleSettingsPopup(ChangeRect bounds, Module module, List<MenuSetting> settings) {
        super(bounds);
        this.module = module;
        this.settings = settings;
        this.animationScale = new okyware.wtf.base.animations.base.Animation(300, 0.01f, okyware.wtf.base.animations.base.Easing.BACK_OUT);
        this.animationScale.update(1);
    }

    @Override
    public void render(UIContext ctx, float mouseX, float mouseY, float alpha, Theme theme) {
        animationScale.update();
        float anim = animationScale.getValue();
        if (anim <= 0.01f) return;

        float x = bounds.getX();
        float y = bounds.getY();
        float width = bounds.getWidth();
        float height = bounds.getHeight();

        ctx.pushMatrix();
        ctx.getMatrices().translate(x + width / 2f, y + height / 2f, 0);
        ctx.getMatrices().scale(anim, anim, 1);
        ctx.getMatrices().translate(-(x + width / 2f), -(y + height / 2f), 0);

        
        if (okyware.wtf.client.modules.impl.render.Interface.INSTANCE.isBlur()) {
            DrawUtil.drawBlur(ctx.getMatrices(), x, y, width, height, 15 * anim, BorderRadius.all(6), ColorRGBA.WHITE.mulAlpha(alpha));
        }
        ctx.drawRoundedRect(x, y, width, height, BorderRadius.all(6), theme.getBackgroundColor().mulAlpha(alpha * 0.95f));
        DrawUtil.drawRoundedBorder(ctx.getMatrices(), x, y, width, height, 0.5f, BorderRadius.all(6), theme.getForegroundStroke().mulAlpha(alpha));

        
        Font titleFont = Fonts.MEDIUM.getFont(8);
        ColorRGBA headerBg = theme.getForegroundColor().mulAlpha(alpha);
        if (okyware.wtf.client.modules.impl.render.Interface.INSTANCE.isBlur()) {
            DrawUtil.drawBlur(ctx.getMatrices(), x, y, width, 22, 10 * anim, BorderRadius.top(6, 6), ColorRGBA.WHITE.mulAlpha(alpha));
        }
        ctx.drawRoundedRect(x, y, width, 22, BorderRadius.top(6, 6), okyware.wtf.client.modules.impl.render.Interface.INSTANCE.fadeBackdrop(headerBg));
        ctx.drawText(titleFont, module.getName(), x + 10, y + (22 - titleFont.height()) / 2f, theme.getWhite().mulAlpha(alpha));

        
        Font iconFont = Fonts.ICONS.getFont(6);
        float closeX = x + width - 18;
        float closeY = y + (22 - iconFont.height()) / 2f;
        ctx.drawText(iconFont, "M", closeX, closeY, theme.getWhiteGray().mulAlpha(alpha));

        
        float startY = y + 22 + 10 - scrollY;
        ctx.enableScissor((int) x, (int) (y + 22), (int) (x + width), (int) (y + height));
        
        ColorRGBA textColor = theme.getWhite().mulAlpha(alpha);
        ColorRGBA descriptionColor = theme.getGrayLight().mulAlpha(alpha);

        
        String keyText = "n/a";
        int keyCode = module.getKeyCode();
        if (keyCode != -1 && keyCode != 0) {
            try {
                String name = okyware.wtf.utility.render.display.Keyboard.getKeyName(keyCode);
                if (name != null && !name.isBlank()) {
                    keyText = name.toUpperCase();
                }
            } catch (Exception ignored) {}
        }
        
        ctx.drawText(titleFont, "Bind", x + 10, startY + 4, textColor);
        float bindBoxWidth = titleFont.width(keyText) + 12;
        float bindBoxX = x + width - bindBoxWidth - 10;
        
        
        
        
        ctx.drawRoundedRect(bindBoxX, startY, bindBoxWidth, 16, BorderRadius.all(4), theme.getForegroundLight().mulAlpha(alpha));
        ctx.drawText(titleFont, keyText, bindBoxX + (bindBoxWidth - titleFont.width(keyText)) / 2f, startY + (16 - titleFont.height()) / 2f, theme.getWhite().mulAlpha(alpha));
        
        startY += 24;

        for (MenuSetting setting : settings) {
            if (!setting.isVisible()) continue;
            setting.render(ctx, mouseX, mouseY, x + 8, startY, width - 16, alpha, 1f, theme.getColor().mulAlpha(alpha), textColor, descriptionColor, theme);
            startY += setting.getHeight() + 8;
        }
        ctx.disableScissor();

        ctx.popMatrix();
    }

    @Override
    public void onMouseClicked(double mouseX, double mouseY, MouseButton button) {
        float x = bounds.getX();
        float y = bounds.getY();
        float width = bounds.getWidth();
        float height = bounds.getHeight();
        
        
        if (button == MouseButton.LEFT && mouseX >= x + width - 25 && mouseX <= x + width && mouseY >= y && mouseY <= y + 22) {
            animationScale.update(0);
            return;
        }

        
        float startY = y + 22 + 10 - scrollY;
        if (mouseX >= x && mouseX <= x + width && mouseY >= startY && mouseY <= startY + 16) {
             if (MinecraftClient.getInstance().currentScreen instanceof MenuScreen menu) {
                 menu.setBinding(module);
             }
        }

        for (MenuSetting setting : settings) {
            if (setting.isVisible()) {
                setting.onMouseClicked(mouseX, mouseY, button);
            }
        }
    }

    @Override
    public void onMouseReleased(double mouseX, double mouseY, MouseButton button) {
        for (MenuSetting setting : settings) {
            setting.onMouseReleased(mouseX, mouseY, button);
        }
    }

    @Override
    public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
        for (MenuSetting setting : settings) {
            if (setting.keyPressed(keyCode, scanCode, modifiers)) return true;
        }
        return false;
    }

    @Override
    public boolean charTyped(char chr, int modifiers) {
        for (MenuSetting setting : settings) {
            if (setting.charTyped(chr, modifiers)) return true;
        }
        return false;
    }

    @Override
    public boolean mouseScrolled(double mouseX, double mouseY, double horizontalAmount, double verticalAmount) {
        scrollY -= verticalAmount * 15;
        if (scrollY < 0) scrollY = 0;
        return true;
    }

    @Override
    public float getWidth() { return bounds.getWidth(); }
    @Override
    public float getHeight() { return bounds.getHeight(); }
    @Override
    public boolean isVisible() { return true; }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o instanceof ModuleSettingsPopup that) {
            return module == that.module;
        }
        return false;
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(module);
    }
}
