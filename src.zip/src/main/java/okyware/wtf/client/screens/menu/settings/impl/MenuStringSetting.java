package okyware.wtf.client.screens.menu.settings.impl;

import lombok.Getter;
import net.minecraft.client.util.math.Vector2f;
import org.lwjgl.glfw.GLFW;
import okyware.wtf.base.font.Font;
import okyware.wtf.base.font.Fonts;
import okyware.wtf.base.theme.Theme;
import okyware.wtf.client.modules.api.setting.impl.StringSetting;
import okyware.wtf.client.screens.menu.settings.api.MenuSetting;
import okyware.wtf.utility.game.other.MouseButton;
import okyware.wtf.utility.render.display.TextBox;
import okyware.wtf.utility.render.display.base.BorderRadius;
import okyware.wtf.utility.render.display.base.Rect;
import okyware.wtf.utility.render.display.base.UIContext;
import okyware.wtf.utility.render.display.base.color.ColorRGBA;

public class MenuStringSetting extends MenuSetting {
    @Getter
    private final StringSetting setting;
    private TextBox textBox;
    private Rect bounds;

    public MenuStringSetting(StringSetting setting) {
        this.setting = setting;
    }

    private TextBox box() {
        if (textBox == null) {
            textBox = new TextBox(new Vector2f(0, 0), Fonts.MEDIUM.getFont(7), setting.getDefaultValue(), 80);
            textBox.setText(setting.getValue() == null ? "" : setting.getValue());
            textBox.setMaxLength(setting.getMaxLength());
        }
        return textBox;
    }

    @Override
    public void render(UIContext ctx, float mouseX, float mouseY, float x, float settingY, float moduleWidth, float alpha, float animEnable, ColorRGBA themeColor, ColorRGBA textColor, ColorRGBA descriptionColor, Theme theme) {
        Font settingFont = Fonts.MEDIUM.getFont(7);
        float settingX = x + 8;
        float textY = settingY + (8 - settingFont.height()) / 2 - 0.5f;

        ctx.drawText(settingFont, setting.getName(), x + 8 + 10, textY, textColor);
        ctx.drawText(Fonts.ICONS.getFont(5.5f), "L", settingX + 1.2f, textY, theme.getGray().mix(theme.getColor(), animEnable).mulAlpha(alpha));

        float boxW = 90;
        float boxH = 10;
        float boxX = x + moduleWidth - boxW - 8;
        float boxY = settingY - 1;

        ColorRGBA boxBg = theme.getForegroundLight().mulAlpha(alpha);
        ColorRGBA borderColor = theme.getForegroundLightStroke().mulAlpha(alpha);
        ctx.drawRoundedRect(boxX, boxY, boxW, boxH, BorderRadius.all(2), boxBg);
        ctx.drawRoundedBorder(boxX, boxY, boxW, boxH, -0.1f, BorderRadius.all(2), borderColor);

        box().setWidth(boxW - 6);
        ctx.enableScissor((int) (boxX + 3), (int) boxY, (int) (boxX + boxW - 3), (int) (boxY + boxH));
        box().render(ctx, boxX + 3, boxY + 2, textColor, theme.getGrayLight().mulAlpha(alpha * 0.6f));
        ctx.disableScissor();

        bounds = new Rect(boxX, boxY, boxW, boxH);
        setting.setValue(box().getText());
    }

    @Override
    public void onMouseClicked(double mouseX, double mouseY, MouseButton button) {
        if (button != MouseButton.LEFT) return;
        if (bounds != null && bounds.contains(mouseX, mouseY)) {
            box().setSelected(true);
        } else {
            box().setSelected(false);
        }
    }

    @Override
    public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
        if (box().isSelected()) {
            if (keyCode == GLFW.GLFW_KEY_ESCAPE || keyCode == GLFW.GLFW_KEY_ENTER) {
                box().setSelected(false);
                return true;
            }
            box().keyPressed(keyCode, scanCode, modifiers);
            setting.setValue(box().getText());
            return true;
        }
        return false;
    }

    @Override
    public boolean charTyped(char chr, int modifiers) {
        if (box().isSelected()) {
            box().charTyped(chr, modifiers);
            setting.setValue(box().getText());
            return true;
        }
        return false;
    }

    @Override
    public float getWidth() {
        return 0;
    }

    @Override
    public float getHeight() {
        return 10;
    }

    @Override
    public boolean isVisible() {
        return setting.getVisible().get();
    }
}
