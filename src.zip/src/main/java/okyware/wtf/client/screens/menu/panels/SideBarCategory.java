package okyware.wtf.client.screens.menu.panels;

import lombok.Getter;
import okyware.wtf.base.animations.base.Animation;
import okyware.wtf.base.animations.base.Easing;
import okyware.wtf.base.font.Font;
import okyware.wtf.base.font.Fonts;
import okyware.wtf.client.modules.api.Category;
import okyware.wtf.utility.render.display.base.UIContext;
import okyware.wtf.utility.render.display.base.color.ColorRGBA;
import okyware.wtf.utility.render.display.shader.DrawUtil;

public class SideBarCategory {
    @Getter
    private final Category category;
    private final Animation animationSwitch;

    public SideBarCategory(Category category) {
        this.category = category;
        animationSwitch = new Animation(200, category == Category.COMBAT ? 1 : 0, Easing.LINEAR);
    }

    public void render(UIContext ctx, float x, float y, float width, float height, float sidebarProgress,
            boolean selected, ColorRGBA textColor, ColorRGBA textColorDisable, ColorRGBA iconColorDisable,
            ColorRGBA primary) {
        animationSwitch.animateTo(selected ? 1 : 0);
        animationSwitch.update();

        ColorRGBA iconColor = iconColorDisable.mix(primary, animationSwitch.getValue());
        ColorRGBA textCol = textColorDisable.mix(textColor, animationSwitch.getValue());

        Font font = Fonts.ICONS.getFont(12);
        float offestY = (height - font.height()) / 2;
        float iconWidth = font.width(category.getIcon());

        if (category == Category.THEME) {
            Font palleteFont = Fonts.ICONS.getFont(14f);
            float pxOffset = (14f - font.height()) / 2f;
            ctx.drawText(palleteFont, "\u1002", x + 8 - 1, y + offestY + 1f - pxOffset, iconColor);
        } else {
            ctx.drawText(font, category.getIcon(), x + 8, y + offestY + 1f, iconColor);
        }

        Font categoryFont = Fonts.MEDIUM.getFont(7);
        ctx.drawText(categoryFont, category.getName(), x + 8 + iconWidth + 6, y + (height - categoryFont.height()) / 2, textCol);
    }
}
