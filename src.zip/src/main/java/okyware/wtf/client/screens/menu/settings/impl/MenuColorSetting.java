package okyware.wtf.client.screens.menu.settings.impl;

import lombok.Getter;
import net.minecraft.client.gui.widget.TextFieldWidget;
import net.minecraft.text.Text;
import okyware.wtf.Okyware;
import okyware.wtf.base.font.Font;
import okyware.wtf.base.font.Fonts;
import okyware.wtf.base.theme.Theme;
import okyware.wtf.client.modules.api.setting.impl.ColorSetting;
import okyware.wtf.client.screens.menu.MenuScreen;
import okyware.wtf.client.screens.menu.settings.api.MenuSetting;
import okyware.wtf.client.screens.menu.settings.impl.popup.MenuColorPopupSetting;
import okyware.wtf.utility.game.other.MouseButton;
import okyware.wtf.utility.render.display.base.BorderRadius;
import okyware.wtf.utility.render.display.base.ChangeRect;
import okyware.wtf.utility.render.display.base.Rect;
import okyware.wtf.utility.render.display.base.UIContext;
import okyware.wtf.utility.render.display.base.color.ColorRGBA;

import static okyware.wtf.utility.interfaces.IMinecraft.mc;

public class MenuColorSetting  extends MenuSetting {
    @Getter
    private final ColorSetting setting;


    private Rect bounds;
    private ChangeRect boundsColor;


    public MenuColorSetting(ColorSetting setting) {

        this.setting = setting;
        boundsColor = new ChangeRect(0,0,156/2f,96/2f);
    }

    @Override
    public void render(UIContext ctx, float mouseX, float mouseY, float x, float settingY, float moduleWidth, float alpha, float animEnable, ColorRGBA themeColor, ColorRGBA textColor, ColorRGBA descriptionColor, Theme theme) {
        float settingHeight = 24;
        float settingX = x + 8;
        Font settingFont = Fonts.MEDIUM.getFont(7);
        Font descFont = Fonts.MEDIUM.getFont(6);
        float textY = settingY + (8 - settingFont.height()) / 2 - 0.5f;

        ctx.drawText(settingFont, setting.getName(), x + 8, textY, textColor);

        float toggleSize = 8;
        float toggleX = x + moduleWidth - toggleSize - 8;
        float toggleY = settingY;

        ColorRGBA colorEnable = theme.getWhiteGray().mix(setting.getColor(),animEnable).mulAlpha(alpha);
        ctx.drawRoundedBorder(toggleX-0.8f, toggleY-0.8f, toggleSize+0.8f*2, toggleSize+0.8f*2,0.1f, BorderRadius.all(3), themeColor);

        ctx.drawRoundedRect(toggleX, toggleY, toggleSize, toggleSize, BorderRadius.all(3), colorEnable);

        
        bounds = new Rect(toggleX, toggleY, toggleSize, toggleSize);
        boundsColor.setX(toggleX+20);
        boundsColor.setY(toggleY+toggleSize-boundsColor.getHeight()/2);


    }


    @Override
    public void onMouseClicked(double mouseX, double mouseY, MouseButton button) {
        if(bounds!=null&&bounds.contains(mouseX, mouseY)) {
            if (mc.currentScreen instanceof okyware.wtf.client.screens.menu.MenuScreen) {
                Okyware.getInstance().getMenuScreen().addPopupMenuSetting(new MenuColorPopupSetting(boundsColor,this.setting));
            } else if (mc.currentScreen instanceof net.minecraft.client.gui.screen.ChatScreen) {
                okyware.wtf.client.modules.impl.render.Interface.INSTANCE.setCurrentColorPopup(new MenuColorPopupSetting(boundsColor,this.setting));
            }
        }
    }

    @Override
    public float getWidth() {
        return 0;
    }

    @Override
    public float getHeight() {
        return 8;
    }

    @Override
    public boolean isVisible() {
        return true;
    }
}
