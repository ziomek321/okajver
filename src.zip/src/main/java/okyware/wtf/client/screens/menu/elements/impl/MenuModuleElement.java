package okyware.wtf.client.screens.menu.elements.impl;

import lombok.Getter;
import lombok.Setter;
import org.lwjgl.glfw.GLFW;
import okyware.wtf.Okyware;
import okyware.wtf.base.animations.base.Animation;
import okyware.wtf.base.animations.base.Easing;
import okyware.wtf.base.font.Font;
import okyware.wtf.base.font.Fonts;
import okyware.wtf.client.modules.api.Category;
import okyware.wtf.client.modules.api.Module;
import okyware.wtf.base.theme.Theme;
import okyware.wtf.client.screens.menu.elements.api.AbstractMenuElement;
import okyware.wtf.client.screens.menu.MenuScreen;
import okyware.wtf.client.screens.menu.settings.impl.popup.ModuleSettingsPopup;
import okyware.wtf.client.screens.menu.settings.api.MenuSetting;
import okyware.wtf.client.screens.menu.settings.impl.*;
import okyware.wtf.client.modules.api.setting.Setting;
import okyware.wtf.client.modules.api.setting.impl.*;
import okyware.wtf.utility.game.other.MouseButton;
import net.minecraft.client.MinecraftClient;
import okyware.wtf.utility.render.display.Keyboard;
import okyware.wtf.utility.render.display.base.ChangeRect;
import okyware.wtf.utility.render.display.base.BorderRadius;
import okyware.wtf.utility.render.display.base.Rect;
import okyware.wtf.utility.render.display.base.UIContext;
import okyware.wtf.utility.render.display.base.color.ColorRGBA;
import okyware.wtf.utility.render.display.shader.DrawUtil;

import java.util.ArrayList;
import java.util.List;

public class MenuModuleElement extends AbstractMenuElement {

    private int countDescLines(Font descFont, float maxDescWidth) {
        String desc = module.getDescription();
        if (desc == null || desc.isEmpty()) return 0;
        int lines = 0;
        StringBuilder line = new StringBuilder();
        for (String word : desc.split(" ")) {
            String trial = line.length() == 0 ? word : line + " " + word;
            if (descFont.width(trial) <= maxDescWidth) {
                line.setLength(0);
                line.append(trial);
            } else {
                if (line.length() > 0) lines++;
                line.setLength(0);
                line.append(word);
            }
        }
        if (line.length() > 0) lines++;
        return lines;
    }

    @Getter
    private final Module module;
    private final List<MenuSetting> settings = new ArrayList<>();
    private final Animation animation;
    private final Animation animationPosition;
    private final Animation animationY;
    private Rect bounds;
    private Rect boundsBind;
    @Getter @Setter
    private boolean binding = false;
    private int lastColum = -1;

    public MenuModuleElement(Module module) {
        this.module = module;
        animation = new Animation(200, module.isEnabled() ? 1 : 0, Easing.LINEAR);
        animationPosition = new Animation(150, 1, Easing.QUAD_IN_OUT);
        animationY = new Animation(150, 1, Easing.QUAD_IN_OUT);

        for (Setting setting : module.getSettings()) {
            if (setting instanceof NumberSetting sliderSetting) {
                settings.add(new MenuSliderSetting(sliderSetting));
            } else if (setting instanceof ModeSetting modeSetting) {
                settings.add(new MenuModeSetting(modeSetting));
            } else if (setting instanceof MultiBooleanSetting selectSetting) {
                settings.add(new MenuSelectSetting(selectSetting));
            } else if (setting instanceof BooleanSetting booleanSetting) {
                settings.add(new MenuBooleanSetting(booleanSetting));
            } else if (setting instanceof ColorSetting colorSetting) {
                settings.add(new MenuColorSetting(colorSetting));
            }
            else if (setting instanceof ButtonSetting buttonSetting) {
                settings.add(new MenuButtonSetting(buttonSetting));
            }
            else if (setting instanceof ItemSelectSetting itemSelectSetting) {
                settings.add(new MenuItemSetting(itemSelectSetting));
            }
            else if (setting instanceof KeySetting keySetting) {
                settings.add(new MenuKeySetting(keySetting));
            }
            else if (setting instanceof StringSetting stringSetting) {
                settings.add(new MenuStringSetting(stringSetting));
            }
        }
    }

    @Override
    public boolean charTyped(char chr, int modifiers) {
        boolean result = false;
        for (MenuSetting setting : settings) {
            if (setting.charTyped(chr, modifiers)) result = true;
        }
        return result;
    }

    boolean animated = false;

    @Override
    public void render(UIContext ctx, float mouseX, float mouseY, Font font, float x, float y, float moduleWidth, float alpha, int colum) {
        if (lastColum == -1) lastColum = colum;
        if (lastColum != colum) {
            animated = true;
            animationPosition.animateTo(x);
            animationY.animateTo(y);
            lastColum = colum;
        }
        if (animated) {
            x = animationPosition.update(x);
            y = animationY.update(y);
            if (animationPosition.isDone() && animationY.isDone()) animated = false;
        } else {
            animationPosition.reset(x);
            animationY.reset(y);
        }

        animation.animateTo(module.isEnabled() ? 1 : 0);
        animation.update();
        Font descFontMeasure = Fonts.MEDIUM.getFont(6);
        int descLineCount = countDescLines(descFontMeasure, moduleWidth - 18 - 8);
        float headerHeight = 32 + Math.max(0, descLineCount - 1) * (descFontMeasure.height() + 1);
        Theme theme = Okyware.getInstance().getThemeManager().getCurrentTheme();
        ColorRGBA moduleBg = theme.getForegroundColor().mulAlpha(alpha);

        boolean hasSettings = hasSettings();
        float settingsHeight = 0;
        if (expanded && hasSettings) {
            for (MenuSetting setting : settings) {
                if (setting.isVisible()) settingsHeight += setting.getHeight() + 8;
            }
            settingsHeight += 22;
        }
        
        float totalHeight = headerHeight + (expanded && hasSettings ? settingsHeight + 4 : 0);
        ColorRGBA settingBg = theme.getForegroundDark().mulAlpha(alpha);
        bounds = new Rect(x, y, moduleWidth, headerHeight);

        if (expanded && hasSettings) {
            ctx.drawRoundedRect(x, y, moduleWidth, totalHeight, BorderRadius.all(4), settingBg);
            ctx.drawRoundedRect(x, y, moduleWidth, headerHeight, BorderRadius.top(4, 4), moduleBg);
        } else {
            ctx.drawRoundedRect(x, y, moduleWidth, headerHeight, BorderRadius.all(4), moduleBg);
        }

        ColorRGBA enabledColor = theme.getGray().mix(theme.getColor(), animation.getValue()).mulAlpha(alpha);
        ColorRGBA textColor = new ColorRGBA(178, 178, 178).mix(new ColorRGBA(242, 242, 242), animation.getValue()).mulAlpha(alpha);
        
        Font iconFont = Fonts.ICONS.getFont(5.5f);
        float iconY = y + 8 + (font.height() - iconFont.height()) / 2f;
        ctx.drawText(font, module.getName(), x + 8, y + 8, textColor);

        String desc = module.getDescription();
        java.util.List<String> descLines = new java.util.ArrayList<>();
        if (desc != null && !desc.isEmpty()) {
            Font descFont = Fonts.MEDIUM.getFont(6);
            float maxDescWidth = moduleWidth - 18 - 8;
            StringBuilder line = new StringBuilder();
            for (String word : desc.split(" ")) {
                String trial = line.length() == 0 ? word : line + " " + word;
                if (descFont.width(trial) <= maxDescWidth) {
                    line.setLength(0);
                    line.append(trial);
                } else {
                    if (line.length() > 0) descLines.add(line.toString());
                    line.setLength(0);
                    line.append(word);
                }
            }
            if (line.length() > 0) descLines.add(line.toString());
            float dy = y + 8 + font.height() + 5;
            for (String l : descLines) {
                ctx.drawText(descFont, l, x + 8, dy, new ColorRGBA(60, 60, 60).mulAlpha(alpha));
                dy += descFont.height() + 1;
            }
        }

        if (expanded) {
            float startY = y + headerHeight + 6;
            
            String keyText = "n/a";
            int keyCode = module.getKeyCode();
            if (keyCode != -1 && keyCode != 0) {
                try {
                    String name = Keyboard.getKeyName(keyCode);
                    if (name != null && !name.isBlank()) {
                        keyText = name.toUpperCase();
                    }
                } catch (Exception ignored) {}
            }

            ctx.drawText(font, "Bind", x + 10, startY + (16 - font.height()) / 2f, textColor);
            
            float bindBoxWidth = font.width(keyText) + 16;
            if (binding) {
                keyText = "...";
                bindBoxWidth = font.width(keyText) + 16;
            }
            float bindBoxX = x + moduleWidth - bindBoxWidth - 10;
            
            ColorRGBA bindBg = theme.getForegroundLight().mulAlpha(alpha);
            if (binding) {
                float pulse = (float) (Math.sin(System.currentTimeMillis() / 150.0) * 0.5 + 0.5);
                bindBg = theme.getSecondColor().mix(theme.getSecondColor().darker(0.2f), pulse).mulAlpha(alpha);
            }
            
            ctx.drawRoundedRect(bindBoxX, startY, bindBoxWidth, 16, BorderRadius.all(4), bindBg);
            ctx.drawText(font, keyText, bindBoxX + (bindBoxWidth - font.width(keyText)) / 2f, startY + (16 - font.height()) / 2f, theme.getWhite().mulAlpha(alpha));
            
            boundsBind = new Rect(bindBoxX, startY, bindBoxWidth, 16);
            startY += 22;

            ColorRGBA accent = theme.getColor().mulAlpha(alpha);
            ColorRGBA descColor = theme.getGrayLight().mulAlpha(alpha);
            for (MenuSetting setting : settings) {
                if (!setting.isVisible()) continue;
                setting.render(ctx, mouseX, mouseY, x + 8, startY, moduleWidth - 16, alpha, 1f, accent, textColor, descColor, theme);
                startY += setting.getHeight() + 8;
            }
        }
    }

    private void drawScrollingText(UIContext ctx, Font font, String text,
            float x, float y, float maxWidth, ColorRGBA color) {
        float textW = font.width(text);

        if (textW <= maxWidth) {
            float centeredX = x + (maxWidth - textW) / 2f;
            ctx.drawText(font, text, centeredX, y, color);
            return;
        }

        float scrollMax = textW - maxWidth;

        float pauseMs = 700f;
        float slideMs = 1400f;
        float total = pauseMs + slideMs + pauseMs + slideMs;

        long now = System.currentTimeMillis();
        float t = now % (long) total;

        float offset;
        if (t < pauseMs) {

            offset = 0f;
        } else if (t < pauseMs + slideMs) {

            float k = (t - pauseMs) / slideMs;

            k = k * k * (3f - 2f * k);
            offset = k * scrollMax;
        } else if (t < pauseMs + slideMs + pauseMs) {

            offset = scrollMax;
        } else {

            float k = (t - pauseMs - slideMs - pauseMs) / slideMs;
            k = k * k * (3f - 2f * k);
            offset = scrollMax * (1f - k);
        }

        ctx.drawText(font, text, x - offset, y, color);
    }

    private boolean expanded = false;

    @Override
    public float getHeight() {
        Font descFontMeasure = Fonts.MEDIUM.getFont(6);
        if (bounds != null) {
            return bounds.height() + (expanded && hasSettings() ? getSettingsHeight() + 4 : 0);
        }
        return 32;
    }
    
    private float getSettingsHeight() {
        float h = 22;
        for (MenuSetting setting : settings) {
            if (setting.isVisible()) h += setting.getHeight() + 8;
        }
        return h;
    }

    public boolean hasSettings() {
        return true; 
    }

    @Override
    public void onMouseClicked(double mouseX, double mouseY, MouseButton button) {
        if (bounds != null && bounds.contains(mouseX, mouseY)) {
            if (button.getButtonIndex() > 2 && binding) {
                binding = false;
                this.module.setKeyCode(button.getButtonIndex());
            }

            if (button == MouseButton.LEFT) {
                module.toggle();
            } else if (button == MouseButton.RIGHT) {
                if (MinecraftClient.getInstance().currentScreen instanceof MenuScreen menu) {
                    float popupWidth = 160;
                    float popupHeight = 220;
                    float px = menu.getBoxX() + menu.getBoxWidth() + 10;
                    float py = menu.getBoxY();
                    menu.addPopupMenuSetting(new ModuleSettingsPopup(new ChangeRect(px, py, popupWidth, popupHeight), module, settings));
                }
            } else if (button == MouseButton.MIDDLE) {
                binding = !binding;
            }
        }
    }

    @Override
    public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
        if (binding) {
            if (keyCode == GLFW.GLFW_KEY_ESCAPE || keyCode == GLFW.GLFW_KEY_DELETE || keyCode == GLFW.GLFW_KEY_BACKSPACE) {
                module.setKeyCode(-1);
            } else {
                module.setKeyCode(keyCode);
            }
            binding = false;
            return true;
        }
        boolean result = false;
        for (MenuSetting setting : settings) {
            if(setting.keyPressed(keyCode, scanCode, modifiers)) {
               result = true;
            }
        }
        return result;
    }

    @Override
    public boolean mouseScrolled(double mouseX, double mouseY, double horizontalAmount, double verticalAmount) {
        return true;
    }

    @Override
    public Category getCategory() {
        return module.getCategory();
    }

    @Override
    public String getName() {
        return module.getName();
    }

    @Override
    public void onMouseReleased(double mouseX, double mouseY, MouseButton button) {
        for (MenuSetting setting : settings) {
            setting.onMouseReleased(mouseX, mouseY, button);
        }
    }

    @Override
    public void onMouseDragged(double mouseX, double mouseY, MouseButton button, double deltaX, double deltaY) {

    }
}
