package okyware.wtf.client.screens.menu.settings.impl;


import lombok.Getter;
import org.lwjgl.glfw.GLFW;
import okyware.wtf.base.animations.base.Animation;
import okyware.wtf.base.animations.base.Easing;
import okyware.wtf.base.font.Font;
import okyware.wtf.base.font.Fonts;
import okyware.wtf.base.theme.Theme;
import okyware.wtf.client.hud.elements.component.KeybindsComponent;
import okyware.wtf.client.modules.api.setting.impl.KeySetting;
import okyware.wtf.client.screens.menu.settings.api.MenuSetting;


import okyware.wtf.client.modules.api.setting.impl.BooleanSetting;
import okyware.wtf.utility.game.other.MouseButton;
import okyware.wtf.utility.render.display.Keyboard;
import okyware.wtf.utility.render.display.base.BorderRadius;
import okyware.wtf.utility.render.display.base.Rect;
import okyware.wtf.utility.render.display.base.UIContext;
import okyware.wtf.utility.render.display.base.color.ColorRGBA;

public class MenuKeySetting extends MenuSetting {
    @Getter
    private final KeySetting setting;
    private Rect bounds;
    private boolean binding = false;
    private final Animation clickAnimation = new Animation(150, 1.0f, Easing.QUAD_OUT);

    public MenuKeySetting(KeySetting setting) {
        this.setting = setting;
    }

    @Override
    public void render(UIContext ctx, float mouseX, float mouseY, float x, float settingY, float moduleWidth, float alpha, float animEnable, ColorRGBA themeColor, ColorRGBA textColor, ColorRGBA descriptionColor, Theme theme) {
        float settingHeight = 24;
        float settingX = x + 8;
        Font settingFont = Fonts.MEDIUM.getFont(7);
        Font descFont = Fonts.MEDIUM.getFont(6);
        float textY = settingY + (8 - settingFont.height()) / 2 - 0.5f;

        ctx.drawText(settingFont, setting.getName(), x + 8 + 10, textY, textColor);
        


        float iconSize = 6;
        float iconY = textY - 1;
        Font iconFont = Fonts.ICONS.getFont(6);

        ctx.drawText(Fonts.ICONS.getFont(5.5f), "L", settingX + 1.2f, iconY + 1.2f, theme.getGray().mix(theme.getColor(),animEnable).mulAlpha(alpha));
        
        String keyText = binding?"...":"n/a";
        int keyCode = setting.getKeyCode();
        if (keyCode != -1 && keyCode != 0 &&!binding) {
            try {
                String name = Keyboard.getKeyName(keyCode);
                if (name != null && !name.isBlank()) {
                    keyText = name.toLowerCase();
                    if(keyText.length()>6){
                        keyText =keyText.substring(0,6)+"..";
                    }
                }
            } catch (Exception ignored) {
            }
        }
        Font font = Fonts.MEDIUM.getFont(7);
        float toggleWitdht = 4 + font.width(keyText) + 4;
        float toggleHeight = 8;
        float toggleX = x + moduleWidth - toggleWitdht - 8;
        float toggleY = settingY;

        ColorRGBA colorToggle = theme.getForegroundLight().mix(theme.getColor(), animEnable).mulAlpha(alpha);
        if (binding) colorToggle = colorToggle.mix(theme.getWhite().mulAlpha(0.2f), 0.5f);
        
        ColorRGBA borderColor = theme.getForegroundLightStroke().mix(theme.getForegroundLightStroke().mulAlpha(0), animEnable).mulAlpha(alpha);
        
        clickAnimation.animateTo(1.0f);
        float scale = clickAnimation.update();
        
        ctx.pushMatrix();
        ctx.getMatrices().translate(toggleX + toggleWitdht / 2f, toggleY + toggleHeight / 2f, 0);
        ctx.getMatrices().scale(scale, scale, 1);
        ctx.getMatrices().translate(-(toggleX + toggleWitdht / 2f), -(toggleY + toggleHeight / 2f), 0);

        ctx.drawRoundedRect(toggleX, toggleY, toggleWitdht, toggleHeight, BorderRadius.all(2), colorToggle);
        ctx.drawRoundedBorder(toggleX, toggleY, toggleWitdht, toggleHeight, -0.1f, BorderRadius.all(2), borderColor);
        ctx.drawText(font, keyText, toggleX + 4, toggleY + 1, textColor);
        
        ctx.popMatrix();
        
        bounds = new Rect(toggleX, toggleY, toggleWitdht, toggleHeight);


    }


    @Override
    public void onMouseClicked(double mouseX, double mouseY, MouseButton button) {
        if (binding &&button.getButtonIndex()>=2) {
            setting.setKeyCode(button.getButtonIndex());
            binding = false;
            return;
        }
        if (bounds != null && bounds.contains(mouseX, mouseY)) {
            if (!binding) {
                clickAnimation.setValue(0.85f);
            }
            binding = true;
            return;
        }

    }

    @Override
    public boolean keyPressed(int keyCode, int scanCode, int modifiers) {

        if (binding) {
            if (keyCode == GLFW.GLFW_KEY_ESCAPE || keyCode == GLFW.GLFW_KEY_DELETE || keyCode == GLFW.GLFW_KEY_BACKSPACE) {
                keyCode = -1;
            }
            setting.setKeyCode(keyCode);
            binding = false;
            clickAnimation.setValue(0.85f);
            return true;
        }
        return false;
    }

    @Override
    public float getWidth() {
        return 0;
    }

    @Override
    public float getHeight() {
        return 8;
    }

    @Override
    public boolean isVisible() {
        return setting.getVisible().get();
    }
}
