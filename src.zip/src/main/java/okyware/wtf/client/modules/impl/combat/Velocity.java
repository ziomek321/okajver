package okyware.wtf.client.modules.impl.combat;

import com.darkmagician6.eventapi.EventTarget;
import okyware.wtf.base.events.impl.player.EventUpdate;
import okyware.wtf.base.events.impl.server.EventPacket;
import okyware.wtf.client.modules.api.Category;
import okyware.wtf.client.modules.api.Module;
import okyware.wtf.client.modules.api.ModuleAnnotation;
import okyware.wtf.client.modules.api.setting.impl.ModeSetting;
import okyware.wtf.client.modules.api.setting.impl.NumberSetting;
import okyware.wtf.utility.mixin.accessors.EntityVelocityUpdateS2CPacketAccessor;
import net.minecraft.network.packet.Packet;
import net.minecraft.network.packet.c2s.play.PlayerActionC2SPacket;
import net.minecraft.network.packet.s2c.play.EntityVelocityUpdateS2CPacket;
import net.minecraft.network.packet.s2c.play.ExplosionS2CPacket;
import net.minecraft.network.packet.s2c.common.CommonPingS2CPacket;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;

@ModuleAnnotation(name = "Velocity", category = Category.COMBAT, description = "Modifies player knockback with compensation support")
public final class Velocity extends Module {
    public static final Velocity INSTANCE = new Velocity();

    private final ModeSetting mode = new ModeSetting("Mode", "Cancel", "Modify", "Transaction", "Delay", "Compensation");
    private final NumberSetting horizontal = new NumberSetting("Horizontal", 0, 0, 100, 1, () -> mode.is("Modify") || mode.is("Cancel") || mode.is("Transaction") || mode.is("Delay"));
    private final NumberSetting vertical = new NumberSetting("Vertical", 0, 0, 100, 1, () -> mode.is("Modify") || mode.is("Cancel") || mode.is("Transaction") || mode.is("Delay"));
    private final NumberSetting delayTicks = new NumberSetting("Delay Ticks", 3, 1, 20, 1, () -> mode.is("Delay"));

    private int tickCounter = 0;
    private boolean hasQueuedVelocity = false;
    private double qx, qy, qz;
    private boolean waitingForTransaction = false;

    private Vec3d lastMotion = Vec3d.ZERO;
    private boolean gotVelocity;
    private boolean wasHurt;
    private boolean jumped;

    private Velocity() {}

    @Override
    public void onEnable() {
        hasQueuedVelocity = false;
        waitingForTransaction = false;
        tickCounter = 0;
        gotVelocity = false;
        wasHurt = false;
        jumped = false;
    }

    @EventTarget
    public void onUpdate(EventUpdate e) {
        if (mc.player == null) return;

        if (mode.is("Delay") && hasQueuedVelocity) {
            tickCounter++;
            if (tickCounter >= delayTicks.getCurrent()) {
                applyVelocity(qx, qy, qz);
                hasQueuedVelocity = false;
                tickCounter = 0;
            }
        }

        if (mode.is("Compensation") && gotVelocity) {
            if (mc.player.hurtTime > 0) {
                this.wasHurt = true;
            }

            if (this.wasHurt && mc.player.hurtTime == 0) {
                if (mc.player.isOnGround()) {
                    mc.player.jump();
                    this.jumped = true;
                }

                Vec3d moveDir = this.lastMotion.normalize();
                Vec3d updatedMotion = moveDir.multiply(-0.2f);
                mc.player.setVelocity(updatedMotion.x, updatedMotion.y, updatedMotion.z);
                this.wasHurt = false;
                this.gotVelocity = false;
            }

            if (this.jumped && mc.player.isOnGround()) {
                this.jumped = false;
            }
        }
    }

    @EventTarget
    public void onPacket(EventPacket e) {
        if (mc.player == null) return;

        if (e.isReceive()) {
            Packet<?> packet = e.getPacket();
            if (packet instanceof EntityVelocityUpdateS2CPacket velocityPacket) {
                if (velocityPacket.getEntityId() == mc.player.getId()) {
                    handleVelocity(e, velocityPacket);
                }
            } else if (packet instanceof ExplosionS2CPacket explosionPacket) {
                explosionPacket.playerKnockback().ifPresent(kb -> {
                    if (mode.is("Cancel")) e.cancel();
                    
                });
            } else if (mode.is("Transaction") && waitingForTransaction) {
                if (packet instanceof CommonPingS2CPacket || packet.getClass().getSimpleName().contains("Response")) {
                    waitingForTransaction = false;
                    if (hasQueuedVelocity) {
                        applyVelocity(qx, qy, qz);
                        hasQueuedVelocity = false;
                    }
                }
            }
        }
    }

    private void handleVelocity(EventPacket e, EntityVelocityUpdateS2CPacket packet) {
        if (mode.is("Cancel")) {
            e.cancel();
            return;
        }

        if (mode.is("Modify")) {
            EntityVelocityUpdateS2CPacketAccessor accessor = (EntityVelocityUpdateS2CPacketAccessor) packet;
            accessor.setVelocityX((int) (packet.getVelocityX() * horizontal.getCurrent() / 100f));
            accessor.setVelocityY((int) (packet.getVelocityY() * vertical.getCurrent() / 100f));
            accessor.setVelocityZ((int) (packet.getVelocityZ() * horizontal.getCurrent() / 100f));
            return;
        }

        double vx = packet.getVelocityX() / 8000.0;
        double vy = packet.getVelocityY() / 8000.0;
        double vz = packet.getVelocityZ() / 8000.0;

        double modifiedX = vx * (horizontal.getCurrent() / 100.0);
        double modifiedY = vy * (vertical.getCurrent() / 100.0);
        double modifiedZ = vz * (horizontal.getCurrent() / 100.0);

        if (mode.is("Compensation")) {
            this.lastMotion = new Vec3d(vx, vy, vz);
            this.gotVelocity = true;
            e.cancel();
            return;
        }

        e.cancel();

        switch (mode.get()) {
            case "Transaction":
                hasQueuedVelocity = true;
                qx = modifiedX;
                qy = modifiedY;
                qz = modifiedZ;
                waitingForTransaction = true;
                mc.player.networkHandler.sendPacket(new PlayerActionC2SPacket(PlayerActionC2SPacket.Action.ABORT_DESTROY_BLOCK, BlockPos.ORIGIN, Direction.DOWN));
                break;
            case "Delay":
                hasQueuedVelocity = true;
                qx = modifiedX;
                qy = modifiedY;
                qz = modifiedZ;
                tickCounter = 0;
                break;
            case "Cancel":
                
                break;
        }
    }

    private void applyVelocity(double x, double y, double z) {
        if (mc.player != null) {
            mc.player.setVelocity(x, y, z);
        }
    }
}
