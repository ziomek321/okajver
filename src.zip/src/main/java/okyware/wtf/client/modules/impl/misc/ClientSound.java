package okyware.wtf.client.modules.impl.misc;


import com.darkmagician6.eventapi.EventTarget;
import net.minecraft.entity.LivingEntity;
import net.minecraft.network.packet.c2s.play.PlayerInteractEntityC2SPacket;
import net.minecraft.network.packet.s2c.play.EntityStatusS2CPacket;
import net.minecraft.sound.SoundEvent;
import net.minecraft.sound.SoundEvents;
import net.minecraft.util.Hand;
import net.minecraft.util.math.Vec3d;
import net.minecraft.util.Identifier;
import net.minecraft.registry.entry.RegistryEntry;

import okyware.wtf.base.events.impl.other.EventModuleToggle;
import okyware.wtf.base.events.impl.server.EventPacket;
import okyware.wtf.client.modules.api.Category;
import okyware.wtf.client.modules.api.Module;
import okyware.wtf.client.modules.api.ModuleAnnotation;
import okyware.wtf.client.modules.api.setting.impl.BooleanSetting;
import okyware.wtf.client.modules.api.setting.impl.NumberSetting;
import okyware.wtf.client.modules.impl.combat.Aura;

@ModuleAnnotation(name = "ClientSound", category = Category.MISC, description = "Plays custom sound effects for module toggles, successful hits, and eliminations")
public final class ClientSound extends Module {

    public static final ClientSound INSTANCE = new ClientSound();
    private ClientSound() {}

    
    private final BooleanSetting soundOnToggle = new BooleanSetting("Toggle sound", true);
    private final BooleanSetting soundOnKill = new BooleanSetting("Kill sound", true);

    private final NumberSetting volume = new NumberSetting("Volume", 1.0f, 0.0f, 2.0f, 0.05f);
    private final NumberSetting pitch = new NumberSetting("Tone", 1.0f, 0.5f, 2.0f, 0.05f);

    @EventTarget
    public void onModuleToggle(EventModuleToggle e) {
        if (!soundOnToggle.isEnabled()) return;
        float p = e.isEnabled() ? pitch.getCurrent() + 0.2f : Math.max(0.5f, pitch.getCurrent() - 0.2f);
        String soundId = "stardlc:client." + (e.isEnabled() ? "toggle_on" : "toggle_off");
        SoundEvent se = getCustom(soundId);
        
        if (se != null) {
            play(se, volume.getCurrent(), p);
        } else {
            play(SoundEvents.UI_BUTTON_CLICK, volume.getCurrent(), p);
        }
    }

    @EventTarget
    public void onPacket(EventPacket e) {
        if (mc.player == null || mc.world == null) return;


        if (soundOnKill.isEnabled() && e.isReceive() && e.getPacket() instanceof EntityStatusS2CPacket status) {
            if (status.getStatus() == 3) {
                var entity = status.getEntity(mc.world);
                if (entity instanceof LivingEntity living) {
                    LivingEntity auraTarget = Aura.INSTANCE.getTarget();
                    if (auraTarget != null && auraTarget == living) {
                        SoundEvent se = getCustom("stardlc:client.kill");
                        if (se != null) play(se, volume.getCurrent(), pitch.getCurrent()); else play(SoundEvents.UI_TOAST_CHALLENGE_COMPLETE, volume.getCurrent(), pitch.getCurrent());
                    }
                }
            }
        }
    }

    private void play(SoundEvent event, float vol, float pit) {
        if (mc.player == null) return;
        mc.execute(() -> mc.player.playSound(event, vol, pit));
    }

    private void play(RegistryEntry<SoundEvent> entry, float vol, float pit) {
        if (entry == null) return;
        play(entry.value(), vol, pit);
    }

    private SoundEvent getCustom(String id) {
        try {
            Identifier identifier = Identifier.of(id);
            SoundEvent event = SoundEvent.of(identifier);
            return event;
        } catch (Exception ex) {
            return null;
        }
    }
}


