package okyware.wtf.client.modules.impl.combat;

import com.darkmagician6.eventapi.EventTarget;
import okyware.wtf.base.events.impl.player.EventUpdate;
import okyware.wtf.client.modules.api.Category;
import okyware.wtf.client.modules.api.Module;
import okyware.wtf.client.modules.api.ModuleAnnotation;
import okyware.wtf.client.modules.api.setting.impl.NumberSetting;
import net.minecraft.component.DataComponentTypes;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.component.type.PotionContentsComponent;
import net.minecraft.potion.Potions;
import net.minecraft.util.Hand;

@ModuleAnnotation(name = "AutoPotion", category = Category.COMBAT, description = "Automatically throws healing potions")
public class AutoPotion extends Module {
    public static final AutoPotion INSTANCE = new AutoPotion();

    private final NumberSetting health = new NumberSetting("Health", 15.0f, 1.0f, 20.0f, 0.5f);

    private AutoPotion() {}

    @EventTarget
    public void onUpdate(EventUpdate event) {
        if (mc.player == null) return;

        if (mc.player.getHealth() <= health.getCurrent() && mc.player.isOnGround()) {
            int potionSlot = findPotion();
            if (potionSlot != -1) {
                int oldSlot = mc.player.getInventory().selectedSlot;
                mc.player.getInventory().selectedSlot = potionSlot;
                mc.player.setPitch(90); 
                mc.interactionManager.interactItem(mc.player, Hand.MAIN_HAND);
                mc.player.getInventory().selectedSlot = oldSlot;
            }
        }
    }

    private int findPotion() {
        for (int i = 0; i < 9; i++) {
            ItemStack stack = mc.player.getInventory().getStack(i);
            if (stack.getItem() == Items.SPLASH_POTION) {
                PotionContentsComponent contents = stack.get(DataComponentTypes.POTION_CONTENTS);
                if (contents != null && contents.matches(Potions.HEALING)) {
                    return i;
                }
            }
        }
        return -1;
    }
}
