package okyware.wtf.client.modules.impl.render;

import com.darkmagician6.eventapi.EventTarget;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.LightningEntity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.util.math.Vec3d;
import okyware.wtf.base.events.impl.player.EventUpdate;
import okyware.wtf.base.events.impl.render.EventRender3D;
import okyware.wtf.client.modules.api.Category;
import okyware.wtf.client.modules.api.Module;
import okyware.wtf.client.modules.api.ModuleAnnotation;
import okyware.wtf.client.modules.api.setting.impl.BooleanSetting;
import okyware.wtf.client.modules.api.setting.impl.ColorSetting;
import okyware.wtf.client.modules.api.setting.impl.ModeSetting;
import okyware.wtf.client.modules.api.setting.impl.NumberSetting;
import okyware.wtf.utility.render.display.base.color.ColorRGBA;
import okyware.wtf.utility.render.level.Render3DUtil;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

@ModuleAnnotation(name = "KillEffect", category = Category.RENDER, description = "Spawns cool visual effects when players/mobs die")
public final class KillEffect extends Module {
    public static final KillEffect INSTANCE = new KillEffect();

    private final ModeSetting mode = new ModeSetting("Mode", "Orthodox", "FallingLava", "LightningBolt");
    private final NumberSetting speedSetting = new NumberSetting("Y Speed", 0, -10, 10, 1);
    private final NumberSetting volumeSetting = new NumberSetting("Volume", 100, 0, 100, 5);
    private final BooleanSetting playSound = new BooleanSetting("Play Sound", true);
    private final ColorSetting colorSetting = new ColorSetting("Color", new ColorRGBA(255, 255, 0, 150));
    private final BooleanSetting mobsSetting = new BooleanSetting("Mobs", false);

    private final Map<Entity, Long> renderEntities = new ConcurrentHashMap<>();
    private final Map<Entity, Long> lightingEntities = new ConcurrentHashMap<>();

    private KillEffect() {
    }

    @Override
    public void onDisable() {
        renderEntities.clear();
        lightingEntities.clear();
        super.onDisable();
    }

    @EventTarget
    public void onRender3D(EventRender3D event) {
        if (mc.world == null) return;

        if (mode.is("Orthodox")) {
            renderEntities.forEach((entity, time) -> {
                if (System.currentTimeMillis() - time > 3000) {
                    renderEntities.remove(entity);
                } else {
                    double currentSpeed = calculateSpeed();
                    Vec3d basePos = entity.getPos();
                    int color = colorSetting.getColor().getRGB();

                    Render3DUtil.drawLine(basePos.add(0, currentSpeed, 0), basePos.add(0, 3 + currentSpeed, 0), color, 2.0f, false);
                    Render3DUtil.drawLine(basePos.add(1, 2.3 + currentSpeed, 0), basePos.add(-1, 2.3 + currentSpeed, 0), color, 2.0f, false);
                    Render3DUtil.drawLine(basePos.add(0.5, 1.2 + currentSpeed, 0), basePos.add(-0.5, 0.8 + currentSpeed, 0), color, 2.0f, false);
                }
            });
        } else if (mode.is("FallingLava")) {
            renderEntities.keySet().forEach(entity -> {
                for (int i = 0; i < entity.getHeight() * 10; i++) {
                    for (int j = 0; j < entity.getWidth() * 10; j++) {
                        for (int k = 0; k < entity.getWidth() * 10; k++) {
                            mc.world.addParticle(ParticleTypes.FALLING_LAVA, entity.getX() + j * 0.1, entity.getY() + i * 0.1, entity.getZ() + k * 0.1, 0, 0, 0);
                        }
                    }
                }
                renderEntities.remove(entity);
            });
        } else if (mode.is("LightningBolt")) {
            renderEntities.forEach((entity, time) -> {
                LightningEntity lightningEntity = new LightningEntity(EntityType.LIGHTNING_BOLT, mc.world);
                lightningEntity.refreshPositionAfterTeleport(entity.getX(), entity.getY(), entity.getZ());
                mc.world.addEntity(lightningEntity);
                renderEntities.remove(entity);
                lightingEntities.put(entity, System.currentTimeMillis());
            });
        }
    }

    @EventTarget
    public void onUpdate(EventUpdate event) {
        if (mc.world == null) return;

        for (Entity entity : mc.world.getEntities()) {
            if (!(entity instanceof PlayerEntity) && !mobsSetting.isEnabled()) continue;
            if (!(entity instanceof LivingEntity liv)) continue;

            if (entity == mc.player || renderEntities.containsKey(entity) || lightingEntities.containsKey(entity))
                continue;
            if (entity.isAlive() || liv.getHealth() > 0) continue;

            if (playSound.isEnabled() && mode.is("Orthodox")) {
                mc.world.playSound(mc.player, entity.getBlockPos(), SoundEvents.ENTITY_LIGHTNING_BOLT_THUNDER, SoundCategory.BLOCKS, volumeSetting.getCurrent() / 100f, 1f);
            }

            renderEntities.put(entity, System.currentTimeMillis());
        }

        if (!lightingEntities.isEmpty()) {
            lightingEntities.forEach((entity, time) -> {
                if (System.currentTimeMillis() - time > 5000) {
                    lightingEntities.remove(entity);
                }
            });
        }
    }

    private double calculateSpeed() {
        return (double) speedSetting.getCurrent() / 100;
    }
}
