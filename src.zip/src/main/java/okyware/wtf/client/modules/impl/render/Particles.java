package okyware.wtf.client.modules.impl.render;

import com.darkmagician6.eventapi.EventTarget;
import net.minecraft.block.*;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.projectile.ProjectileEntity;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.Vec3d;
import okyware.wtf.Okyware;
import okyware.wtf.base.events.impl.player.EventAttack;
import okyware.wtf.base.events.impl.player.EventUpdate;
import okyware.wtf.base.events.impl.render.EventRender3D;
import okyware.wtf.client.modules.api.Category;
import okyware.wtf.client.modules.api.Module;
import okyware.wtf.client.modules.api.ModuleAnnotation;
import okyware.wtf.client.modules.api.setting.impl.BooleanSetting;
import okyware.wtf.client.modules.api.setting.impl.ModeSetting;
import okyware.wtf.client.modules.api.setting.impl.NumberSetting;
import okyware.wtf.utility.math.MathUtil;
import okyware.wtf.utility.math.Timer;
import okyware.wtf.utility.render.display.base.color.ColorRGBA;
import okyware.wtf.utility.render.level.Render3DUtil;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ThreadLocalRandom;

@ModuleAnnotation(name = "Particles", category = Category.RENDER, description = "Renders premium 3D particles on various triggers.")
public final class Particles extends Module {
    public static final Particles INSTANCE = new Particles();

    private final ModeSetting textureMode = new ModeSetting("Texture", "Bloom", "Random");
    private final BooleanSetting onAttack = new BooleanSetting("On Attack", true);
    private final BooleanSetting onWalk = new BooleanSetting("On Walk", true);
    private final BooleanSetting onJump = new BooleanSetting("On Jump", true);
    private final BooleanSetting onThrowable = new BooleanSetting("On Throwable", true);

    private final NumberSetting attackCount = new NumberSetting("Attack Count", 15, 1, 50, 1);
    private final NumberSetting walkCount = new NumberSetting("Walk Count", 3, 1, 10, 1);
    private final BooleanSetting randomColor = new BooleanSetting("Random Color", false);

    private final List<Particle3D> particles = new ArrayList<>();
    private final Identifier bloomTex = Identifier.of("okyware", "textures/eva/firefly.png");

    private Particles() {
    }

    @Override
    public void onEnable() {
        particles.clear();
        super.onEnable();
    }

    @EventTarget
    public void onAttack(EventAttack event) {
        if (!onAttack.isEnabled() || event.getAction() != EventAttack.Action.POST) return;
        Entity target = event.getTarget();
        if (target == null) return;

        float motion = 0.15f;
        int count = (int) attackCount.getCurrent();
        for (int i = 0; i < count; i++) {
            Vec3d pos = target.getPos().add(0, ThreadLocalRandom.current().nextDouble() * target.getHeight(), 0);
            Vec3d vel = new Vec3d(
                    (ThreadLocalRandom.current().nextDouble() - 0.5) * motion,
                    ThreadLocalRandom.current().nextDouble() * motion,
                    (ThreadLocalRandom.current().nextDouble() - 0.5) * motion
            );
            particles.add(new Particle3D(pos, vel, 2000, getRandomTexture(), getRandomColor()));
        }
    }

    @EventTarget
    public void onUpdate(EventUpdate event) {
        if (mc.player == null) return;

        if (onJump.isEnabled() && !mc.player.isOnGround() && mc.player.getVelocity().y > 0) {
            spawnWalkParticles(10, 0.1f);
        }

        if (onWalk.isEnabled() && mc.player.isOnGround() && (mc.player.prevX != mc.player.getX() || mc.player.prevZ != mc.player.getZ())) {
            spawnWalkParticles((int) walkCount.getCurrent(), 0.05f);
        }

        if (onThrowable.isEnabled()) {
            for (Entity entity : mc.world.getEntities()) {
                if (entity instanceof ProjectileEntity) {
                    Vec3d pos = entity.getPos();
                    particles.add(new Particle3D(pos, Vec3d.ZERO, 1000, getRandomTexture(), getRandomColor()));
                }
            }
        }

        particles.removeIf(p -> p.timer.finished(p.maxLife));
        particles.forEach(Particle3D::tick);
    }

    private void spawnWalkParticles(int count, float motion) {
        for (int i = 0; i < count; i++) {
            Vec3d pos = mc.player.getPos().add(
                    (ThreadLocalRandom.current().nextDouble() - 0.5) * 0.5,
                    ThreadLocalRandom.current().nextDouble() * 0.2,
                    (ThreadLocalRandom.current().nextDouble() - 0.5) * 0.5
            );
            Vec3d vel = new Vec3d(
                    (ThreadLocalRandom.current().nextDouble() - 0.5) * motion,
                    ThreadLocalRandom.current().nextDouble() * motion,
                    (ThreadLocalRandom.current().nextDouble() - 0.5) * motion
            );
            particles.add(new Particle3D(pos, vel, 1500, getRandomTexture(), getRandomColor()));
        }
    }

    @EventTarget
    public void onRender3D(EventRender3D event) {
        if (particles.isEmpty()) return;

        for (Particle3D p : particles) {
            float t = p.timer.getElapsedTime() / (float) p.maxLife;
            float alpha = 1f - (t * t);
            float size = 0.12f * (1f - t * 0.5f);
            
            ColorRGBA color = p.color.mulAlpha(alpha);
            Render3DUtil.drawTexture(p.texture, p.pos, size, color.getRGB());
        }
    }


    private Identifier getRandomTexture() {
        if (textureMode.is("Bloom")) return bloomTex;
        int r = ThreadLocalRandom.current().nextInt(1, 13);
        return Identifier.of("okyware", "textures/eva/particle/p" + r + ".png");
    }

    private ColorRGBA getRandomColor() {
        if (randomColor.isEnabled()) {
            return new ColorRGBA(
                    ThreadLocalRandom.current().nextInt(255),
                    ThreadLocalRandom.current().nextInt(255),
                    ThreadLocalRandom.current().nextInt(255),
                    255
            );
        }
        return Okyware.getInstance().getThemeManager().getClientColor(0);
    }

    private static class Particle3D {
        Vec3d pos;
        Vec3d vel;
        final long maxLife;
        final Timer timer = new Timer();
        final Identifier texture;
        final ColorRGBA color;

        Particle3D(Vec3d pos, Vec3d vel, long maxLife, Identifier texture, ColorRGBA color) {
            this.pos = pos;
            this.vel = vel;
            this.maxLife = maxLife;
            this.texture = texture;
            this.color = color;
        }

        void tick() {
            pos = pos.add(vel);
            vel = vel.multiply(0.95);
            vel = vel.add(0, -0.002, 0); 
        }
    }
}
