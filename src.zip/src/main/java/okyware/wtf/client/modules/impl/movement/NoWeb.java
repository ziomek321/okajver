package okyware.wtf.client.modules.impl.movement;

import okyware.wtf.client.modules.api.Category;
import okyware.wtf.client.modules.api.Module;
import okyware.wtf.client.modules.api.ModuleAnnotation;

@ModuleAnnotation(name = "NoWeb", category = Category.MOVEMENT, description = "Prevents cobwebs from slowing you down")
public final class NoWeb extends Module {
    public static final NoWeb INSTANCE = new NoWeb();

    private NoWeb() {
    }
}
