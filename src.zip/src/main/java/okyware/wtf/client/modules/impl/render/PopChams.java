package okyware.wtf.client.modules.impl.render;

import com.darkmagician6.eventapi.EventTarget;
import com.mojang.blaze3d.platform.GlStateManager;
import com.mojang.blaze3d.systems.RenderSystem;
import net.minecraft.client.network.AbstractClientPlayerEntity;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.network.packet.s2c.play.EntityStatusS2CPacket;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.Vec3d;
import okyware.wtf.Okyware;
import okyware.wtf.base.events.impl.player.EventUpdate;
import okyware.wtf.base.events.impl.render.EventRender3D;
import okyware.wtf.base.events.impl.server.EventPacket;
import okyware.wtf.client.modules.api.Category;
import okyware.wtf.client.modules.api.Module;
import okyware.wtf.client.modules.api.ModuleAnnotation;
import okyware.wtf.client.modules.api.setting.impl.BooleanSetting;
import okyware.wtf.client.modules.api.setting.impl.ColorSetting;
import okyware.wtf.client.modules.api.setting.impl.NumberSetting;
import okyware.wtf.utility.math.MathUtil;
import okyware.wtf.utility.render.display.base.color.ColorRGBA;
import okyware.wtf.utility.render.level.Render3DUtil;

import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;

@ModuleAnnotation(name = "PopChams", category = Category.RENDER, description = "Renders visual effects when players pop a totem")
public final class PopChams extends Module {
    public static final PopChams INSTANCE = new PopChams();

    private final ColorSetting colorSetting = new ColorSetting("Color", new ColorRGBA(136, 0, 255, 180));
    private final NumberSetting fadeSpeed = new NumberSetting("Fade Speed", 3.0f, 1.0f, 20.0f, 0.5f);
    private final NumberSetting ySpeed = new NumberSetting("Y Speed", 1.0f, 0.0f, 5.0f, 0.1f);
    private final NumberSetting rotSpeed = new NumberSetting("Rot Speed", 0.5f, 0.0f, 5.0f, 0.1f);
    private final NumberSetting scale = new NumberSetting("Scale", 1.2f, 0.5f, 3.0f, 0.1f);
    private final BooleanSetting glow = new BooleanSetting("Glow Ring", true);

    private final List<PopGhost> ghosts = new CopyOnWriteArrayList<>();
    private final Identifier bloomTex = Identifier.of("okyware", "textures/target/glow.png");

    private PopChams() {
    }

    @Override
    public void onDisable() {
        ghosts.clear();
        super.onDisable();
    }

    @EventTarget
    public void onUpdate(EventUpdate e) {
        ghosts.removeIf(ghost -> {
            ghost.alpha -= fadeSpeed.getCurrent();
            return ghost.alpha <= 0;
        });
    }

    @EventTarget
    public void onPacket(EventPacket event) {
        if (mc.world == null || mc.player == null) return;
        if (event.isReceive() && event.getPacket() instanceof EntityStatusS2CPacket packet) {
            if (packet.getStatus() == 35) {
                Entity entity = packet.getEntity(mc.world);
                if (entity instanceof PlayerEntity player && player != mc.player) {
                    Identifier skinTexture = null;
                    if (player instanceof AbstractClientPlayerEntity clientPlayer) {
                        skinTexture = clientPlayer.getSkinTextures().texture();
                    }
                    ghosts.add(new PopGhost(
                            player.getPos(),
                            player.bodyYaw,
                            player.getWidth(),
                            player.getHeight(),
                            skinTexture,
                            colorSetting.getColor().getAlpha(),
                            System.currentTimeMillis()
                    ));
                }
            }
        }
    }

    @EventTarget
    public void onRender3D(EventRender3D event) {
        if (ghosts.isEmpty()) return;

        long now = System.currentTimeMillis();

        for (PopGhost ghost : ghosts) {
            float elapsed = (now - ghost.spawnTime) / 1000f;
            float alpha = Math.max(0f, ghost.alpha / 255f);
            float yOffset = elapsed * ySpeed.getCurrent();
            float rotation = elapsed * 360f * rotSpeed.getCurrent();
            float s = scale.getCurrent();

            Vec3d base = ghost.pos.add(0, yOffset, 0);
            ColorRGBA baseColor = colorSetting.getColor();
            boolean isFriend = false;
            ColorRGBA color = isFriend
                    ? Okyware.getInstance().getThemeManager().getCurrentTheme().getFriendColor()
                    : baseColor;

            float w = ghost.width * s;
            float h = ghost.height * s;

            int segments = 32;
            for (int i = 0; i < segments; i++) {
                double a1 = Math.toRadians(rotation + (360.0 / segments) * i);
                double a2 = Math.toRadians(rotation + (360.0 / segments) * (i + 1));

                Vec3d p1Bottom = base.add(Math.cos(a1) * w, 0, Math.sin(a1) * w);
                Vec3d p2Bottom = base.add(Math.cos(a2) * w, 0, Math.sin(a2) * w);
                Vec3d p1Top = base.add(Math.cos(a1) * w * 0.6, h, Math.sin(a1) * w * 0.6);
                Vec3d p2Top = base.add(Math.cos(a2) * w * 0.6, h, Math.sin(a2) * w * 0.6);

                int wallColor = color.mulAlpha(alpha * 0.35f).getRGB();
                Render3DUtil.drawQuad(p1Bottom, p2Bottom, p2Top, p1Top, wallColor, false);
            }

            int coreLines = 48;
            float[] heights = {0f, h * 0.33f, h * 0.66f, h};
            float[] radii = {w, w * 0.85f, w * 0.7f, w * 0.55f};
            for (int ring = 0; ring < heights.length; ring++) {
                float ringY = heights[ring];
                float ringR = radii[ring];
                for (int i = 0; i < coreLines; i++) {
                    double a1 = Math.toRadians(rotation * (ring % 2 == 0 ? 1 : -1) + (360.0 / coreLines) * i);
                    double a2 = Math.toRadians(rotation * (ring % 2 == 0 ? 1 : -1) + (360.0 / coreLines) * (i + 1));
                    Vec3d p1 = base.add(Math.cos(a1) * ringR, ringY, Math.sin(a1) * ringR);
                    Vec3d p2 = base.add(Math.cos(a2) * ringR, ringY, Math.sin(a2) * ringR);
                    Render3DUtil.drawLine(p1, p2, color.mulAlpha(alpha).getRGB(), 2.0f, false);
                }
            }

            if (glow.isEnabled()) {
                Render3DUtil.drawTexture(bloomTex, base.add(0, h * 0.5, 0), h * 1.2f, color.mulAlpha(alpha * 0.3f).getRGB());
            }
        }
    }

    private static final class PopGhost {
        final Vec3d pos;
        final float bodyYaw;
        final float width;
        final float height;
        final Identifier texture;
        float alpha;
        final long spawnTime;

        PopGhost(Vec3d pos, float bodyYaw, float width, float height, Identifier texture, float alpha, long spawnTime) {
            this.pos = pos;
            this.bodyYaw = bodyYaw;
            this.width = width;
            this.height = height;
            this.texture = texture;
            this.alpha = alpha;
            this.spawnTime = spawnTime;
        }
    }
}
