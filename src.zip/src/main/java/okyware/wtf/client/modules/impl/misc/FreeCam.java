package okyware.wtf.client.modules.impl.misc;

import com.darkmagician6.eventapi.EventTarget;
import net.minecraft.client.option.Perspective;
import net.minecraft.network.packet.c2s.play.PlayerInteractBlockC2SPacket;
import net.minecraft.network.packet.c2s.play.PlayerMoveC2SPacket;
import net.minecraft.network.packet.s2c.play.GameJoinS2CPacket;
import net.minecraft.network.packet.s2c.play.PlayerRespawnS2CPacket;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;
import okyware.wtf.base.events.impl.player.EventMove;
import okyware.wtf.base.events.impl.player.EventMoveInput;
import okyware.wtf.base.events.impl.player.EventUpdate;
import okyware.wtf.base.events.impl.render.EventCameraPosition;
import okyware.wtf.base.events.impl.render.EventRender3D;
import okyware.wtf.base.events.impl.server.EventPacket;
import okyware.wtf.client.modules.api.Category;
import okyware.wtf.client.modules.api.Module;
import okyware.wtf.client.modules.api.ModuleAnnotation;
import okyware.wtf.client.modules.api.setting.impl.BooleanSetting;
import okyware.wtf.client.modules.api.setting.impl.NumberSetting;
import okyware.wtf.utility.game.player.MovingUtil;
import okyware.wtf.utility.game.player.PlayerInventoryComponent;
import okyware.wtf.utility.math.MathUtil;
import okyware.wtf.utility.render.level.Render3DUtil;

@ModuleAnnotation(name = "FreeCam",description = "Detaches your camera and lets you fly freely to scout your surroundings",category = Category.MISC)
public final class FreeCam extends Module {
    public static final FreeCam INSTANCE = new FreeCam();
    private final NumberSetting speedSetting = new NumberSetting("Speed",2.0F,0.5F, 5.0F,0.5f);
    private final BooleanSetting freezeSetting = new BooleanSetting("Hover", false);
    private final BooleanSetting interact = new BooleanSetting("Remote Interact", "Interact with blocks from camera pos", true);
    private final BooleanSetting chunkLoader = new BooleanSetting("Chunk Loader", "Loads chunks around camera", true);
    public Vec3d pos, prevPos;

    private FreeCam() {

    }

    
    @Override
    public void onEnable() {
        prevPos = pos = new Vec3d(mc.getEntityRenderDispatcher().camera.getPos().toVector3f());
        super.onEnable();
    }

    
    @EventTarget
    public void onPacket(EventPacket e) {
        switch (e.getPacket()) {
            case PlayerMoveC2SPacket move when freezeSetting.isEnabled() -> e.cancel();
            case PlayerInteractBlockC2SPacket interactBlock when interact.isEnabled() -> {
                double clampedY = Math.max(-64, Math.min(320, mc.player.getY()));
                mc.player.networkHandler.sendPacket(new PlayerMoveC2SPacket.PositionAndOnGround(
                        mc.player.getX(), clampedY, mc.player.getZ(), true, false));
            }
            case PlayerRespawnS2CPacket respawn -> this.toggle();
            case GameJoinS2CPacket join -> this.toggle();
            default -> {}
        }
    }

    
    @EventTarget
    public void onWorldRender(EventRender3D e) {
        Render3DUtil.drawBox(mc.player.getBoundingBox().offset(MathUtil.interpolate(mc.player).subtract(mc.player.getPos())), stardlc.getThemeManager().getClientColor(90).getRGB(), 1);
    }

    
    @EventTarget
    public void onMove(EventMove e) {

        if (freezeSetting.isEnabled()) {
            e.setMovePos(Vec3d.ZERO);
        }
    }

    
    @EventTarget
    public void onInput(EventMoveInput e) {
        float speed = speedSetting.getCurrent();
        double[] motion = MovingUtil.calculateDirection(speed);

        prevPos = pos;
        pos = pos.add(motion[0], e.getInput().jump() ? speed : e.getInput().sneak() ? -speed : 0, motion[1]);

        if (chunkLoader.isEnabled() && mc.player.age % 20 == 0) {
            double clampedY = Math.max(-64, Math.min(320, pos.y));
            mc.player.networkHandler.sendPacket(new PlayerMoveC2SPacket.PositionAndOnGround(
                    pos.x, clampedY, pos.z, true, false));
            mc.player.networkHandler.sendPacket(new PlayerMoveC2SPacket.PositionAndOnGround(
                    mc.player.getX(), mc.player.getY(), mc.player.getZ(), mc.player.isOnGround(), false));
        }


    }

    
    @EventTarget
    public void onCameraPosition(EventCameraPosition e) {
        e.setPos(MathUtil.interpolate(prevPos, pos));
        mc.options.setPerspective(Perspective.FIRST_PERSON);
    }
}
