package okyware.wtf.client.modules.impl.render;

import com.darkmagician6.eventapi.EventTarget;
import net.minecraft.entity.player.PlayerEntity;
import okyware.wtf.Okyware;
import okyware.wtf.base.events.impl.entity.EventEntityColor;
import okyware.wtf.client.modules.api.Category;
import okyware.wtf.client.modules.api.Module;
import okyware.wtf.client.modules.api.ModuleAnnotation;
import okyware.wtf.client.modules.api.setting.impl.BooleanSetting;
import okyware.wtf.client.modules.api.setting.impl.ColorSetting;
import okyware.wtf.utility.render.display.base.color.ColorRGBA;

@ModuleAnnotation(name = "Chams", category = Category.RENDER, description = "Renders players through walls with custom colors")
public final class Chams extends Module {
    public static final Chams INSTANCE = new Chams();

    private final ColorSetting playerColor = new ColorSetting("Player Color", new ColorRGBA(147, 23, 222, 100));
    private final ColorSetting friendColor = new ColorSetting("Friend Color", new ColorRGBA(45, 232, 48, 100));
    private final BooleanSetting players = new BooleanSetting("Players", true);

    private Chams() {
    }

    @EventTarget
    public void onEntityColor(EventEntityColor event) {
        if (event.getEntity() instanceof PlayerEntity player) {
            if (player == mc.player) return;
            if (!players.isEnabled()) return;

            boolean isFriend = Okyware.getInstance().getFriendManager().isFriend(player.getGameProfile().getName());
            ColorRGBA targetColor = isFriend ? friendColor.getColor() : playerColor.getColor();

            event.setColor(targetColor.getRGB());
            event.cancel();
        }
    }
}
