package okyware.wtf.client.modules.impl.render;

import com.darkmagician6.eventapi.EventTarget;
import net.minecraft.entity.Entity;
import net.minecraft.util.math.Vec3d;
import okyware.wtf.Okyware;
import okyware.wtf.base.events.impl.player.EventAttack;
import okyware.wtf.base.events.impl.render.EventRender3D;
import okyware.wtf.client.modules.api.Category;
import okyware.wtf.client.modules.api.Module;
import okyware.wtf.client.modules.api.ModuleAnnotation;
import okyware.wtf.client.modules.api.setting.impl.ModeSetting;
import okyware.wtf.client.modules.api.setting.impl.NumberSetting;
import okyware.wtf.utility.math.MathUtil;
import okyware.wtf.utility.render.display.base.color.ColorRGBA;
import okyware.wtf.utility.render.level.Render3DUtil;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.concurrent.ThreadLocalRandom;

@ModuleAnnotation(name = "HitParticles", category = Category.RENDER, description = "Spawns particles when you hit an entity")
public final class HitParticles extends Module {
    public static final HitParticles INSTANCE = new HitParticles();

    private final ModeSetting style = new ModeSetting("Style");
    private final ModeSetting.Value styleSpark = new ModeSetting.Value(style, "Spark").select();
    private final ModeSetting.Value styleBurst = new ModeSetting.Value(style, "Burst");
    private final ModeSetting.Value styleHelix = new ModeSetting.Value(style, "Helix");

    private final NumberSetting count = new NumberSetting("Count", 12, 3, 30, 1);
    private final NumberSetting particleSize = new NumberSetting("Size", 1.5f, 0.5f, 4.0f, 0.1f);
    private final NumberSetting lifeMs = new NumberSetting("Life (ms)", 600, 200, 2000, 50);
    private final NumberSetting spread = new NumberSetting("Spread", 0.6f, 0.1f, 2.0f, 0.05f);

    private final List<HitParticle> particles = new ArrayList<>();

    private HitParticles() {
    }

    @Override
    public void onDisable() {
        particles.clear();
        super.onDisable();
    }

    @EventTarget
    public void onAttack(EventAttack event) {
        if (event.getAction() != EventAttack.Action.POST) return;
        Entity target = event.getTarget();
        if (target == null) return;

        Vec3d pos = target.getPos().add(0, target.getHeight() * 0.5, 0);
        long now = System.currentTimeMillis();
        ThreadLocalRandom rng = ThreadLocalRandom.current();
        int n = (int) count.getCurrent();
        float sp = spread.getCurrent();

        for (int i = 0; i < n; i++) {
            float vx, vy, vz;
            if (styleBurst.isSelected()) {
                
                float theta = rng.nextFloat() * (float) (Math.PI * 2);
                float phi = (float) Math.acos(1 - 2 * rng.nextFloat());
                float speed = 0.3f + rng.nextFloat() * sp;
                vx = (float) (Math.sin(phi) * Math.cos(theta)) * speed;
                vy = (float) (Math.sin(phi) * Math.sin(theta)) * speed * 0.7f + 0.15f;
                vz = (float) Math.cos(phi) * speed;
            } else if (styleHelix.isSelected()) {
                
                float angle = (i / (float) n) * (float) (Math.PI * 4) + rng.nextFloat() * 0.3f;
                float r = 0.2f + rng.nextFloat() * sp * 0.5f;
                vx = (float) Math.cos(angle) * r * 0.3f;
                vy = 0.2f + rng.nextFloat() * 0.4f;
                vz = (float) Math.sin(angle) * r * 0.3f;
            } else {
                
                vx = (rng.nextFloat() - 0.5f) * sp;
                vy = 0.15f + rng.nextFloat() * sp * 0.8f;
                vz = (rng.nextFloat() - 0.5f) * sp;
            }
            particles.add(new HitParticle(pos, vx, vy, vz, now));
        }
    }

    @EventTarget
    public void onRender3D(EventRender3D event) {
        if (particles.isEmpty()) return;

        long now = System.currentTimeMillis();
        long life = (long) lifeMs.getCurrent();
        float sz = particleSize.getCurrent();

        Iterator<HitParticle> it = particles.iterator();
        while (it.hasNext()) {
            HitParticle p = it.next();
            long elapsed = now - p.start;
            if (elapsed > life) {
                it.remove();
                continue;
            }

            float t = elapsed / (float) life;
            float alpha = 1f - t * t; 
            float scale = sz * (1f - t * 0.5f);

            
            float dt = elapsed / 1000f;
            float px = (float) p.origin.x + p.vx * dt;
            float py = (float) p.origin.y + p.vy * dt - 0.8f * dt * dt;
            float pz = (float) p.origin.z + p.vz * dt;

            ColorRGBA base = Okyware.getInstance().getThemeManager().getClientColor(((int) (now / 10) + (int) (p.vx * 100)) % 360);
            int color = base.mulAlpha(Math.max(0f, alpha)).getRGB();

            
            float half = scale * 0.15f;
            Vec3d center = new Vec3d(px, py, pz);
            Render3DUtil.drawLine(center.add(-half, 0, 0), center.add(half, 0, 0), color, 2.5f, false);
            Render3DUtil.drawLine(center.add(0, -half, 0), center.add(0, half, 0), color, 2.5f, false);
            Render3DUtil.drawLine(center.add(0, 0, -half), center.add(0, 0, half), color, 2.5f, false);
        }
    }

    private static final class HitParticle {
        final Vec3d origin;
        final float vx, vy, vz;
        final long start;

        HitParticle(Vec3d origin, float vx, float vy, float vz, long start) {
            this.origin = origin;
            this.vx = vx;
            this.vy = vy;
            this.vz = vz;
            this.start = start;
        }
    }
}
