package okyware.wtf.client.modules.impl.render;

import com.darkmagician6.eventapi.EventTarget;
import okyware.wtf.Okyware;
import okyware.wtf.base.events.impl.render.EventRender3D;
import okyware.wtf.client.modules.api.Category;
import okyware.wtf.client.modules.api.Module;
import okyware.wtf.client.modules.api.ModuleAnnotation;
import okyware.wtf.utility.render.display.base.color.ColorRGBA;
import okyware.wtf.utility.render.level.Render3DUtil;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

@ModuleAnnotation(name = "PlaceHighlight", category = Category.RENDER, description = "Highlights blocks placed by Scaffold/AutoTrap/SelfTrap")
public final class PlaceHighlight extends Module {
    public static final PlaceHighlight INSTANCE = new PlaceHighlight();

    private static final long FADE_MS = 600L;

    private static final List<Entry> entries = new ArrayList<>();

    private PlaceHighlight() {
        
        setToggled(true);
    }

    public static void mark(BlockPos pos) {
        if (pos == null) return;
        synchronized (entries) {
            entries.add(new Entry(pos.toImmutable(), System.currentTimeMillis()));
        }
    }

    @EventTarget
    public void onRender(EventRender3D event) {
        long now = System.currentTimeMillis();
        ColorRGBA themeColor = Okyware.getInstance().getThemeManager().getCurrentTheme().getColor();

        synchronized (entries) {
            Iterator<Entry> it = entries.iterator();
            while (it.hasNext()) {
                Entry e = it.next();
                long age = now - e.placedAt;
                if (age >= FADE_MS) { it.remove(); continue; }
                float t = age / (float) FADE_MS;
                float alpha = 1f - t;
                Box box = new Box(e.pos);
                int fill = themeColor.mulAlpha(alpha * 0.35f).getRGB();
                int line = themeColor.mulAlpha(alpha).getRGB();
                Render3DUtil.drawBox(box, fill, 1.5f, false, true, false);
                Render3DUtil.drawBox(box, line, 2.0f, true, false, false);
            }
        }
    }

    private record Entry(BlockPos pos, long placedAt) {}
}
