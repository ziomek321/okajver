package okyware.wtf.client.modules.impl.misc;

import com.darkmagician6.eventapi.EventTarget;
import com.mojang.authlib.GameProfile;
import net.minecraft.client.network.OtherClientPlayerEntity;
import net.minecraft.entity.Entity;
import okyware.wtf.base.events.impl.player.EventUpdate;
import okyware.wtf.client.modules.api.Category;
import okyware.wtf.client.modules.api.Module;
import okyware.wtf.client.modules.api.ModuleAnnotation;

import java.util.UUID;

@ModuleAnnotation(name = "FakePlayer", category = Category.MISC, description = "Spawns A Fake Player")
public final class FakePlayer extends Module {
    public static final FakePlayer INSTANCE = new FakePlayer();
    private OtherClientPlayerEntity fakePlayer;

    private FakePlayer() {}

    @Override
    public void onEnable() {
        super.onEnable();
        if (mc.player == null || mc.world == null) return;

        fakePlayer = new OtherClientPlayerEntity(mc.world,
                new GameProfile(UUID.randomUUID(), ":3"));
        fakePlayer.copyPositionAndRotation(mc.player);
        fakePlayer.setHeadYaw(mc.player.getHeadYaw());
        fakePlayer.getInventory().clone(mc.player.getInventory());
        mc.world.addEntity(fakePlayer);
    }

    @Override
    public void onDisable() {
        if (fakePlayer != null && mc.world != null) {
            mc.world.removeEntity(fakePlayer.getId(), Entity.RemovalReason.DISCARDED);
            fakePlayer = null;
        }
        super.onDisable();
    }

    @EventTarget
    public void onUpdate(EventUpdate event) {
        if (fakePlayer == null || mc.player == null) return;
        if (mc.player.hurtTime > 0) {
            fakePlayer.hurtTime = mc.player.hurtTime;
            fakePlayer.maxHurtTime = mc.player.maxHurtTime;
        }
        fakePlayer.setHealth(mc.player.getHealth());
    }
}
