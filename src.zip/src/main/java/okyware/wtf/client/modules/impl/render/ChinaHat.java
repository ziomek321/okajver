package okyware.wtf.client.modules.impl.render;

import com.darkmagician6.eventapi.EventTarget;
import okyware.wtf.Okyware;
import okyware.wtf.base.events.impl.render.EventRender3D;
import okyware.wtf.client.modules.api.Category;
import okyware.wtf.client.modules.api.Module;
import okyware.wtf.client.modules.api.ModuleAnnotation;
import okyware.wtf.client.modules.api.setting.impl.BooleanSetting;
import okyware.wtf.client.modules.api.setting.impl.NumberSetting;
import okyware.wtf.utility.math.MathUtil;
import okyware.wtf.utility.render.display.base.color.ColorRGBA;
import okyware.wtf.utility.render.level.Render3DUtil;
import net.minecraft.client.option.Perspective;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;

@ModuleAnnotation(name = "ChinaHat", category = Category.RENDER, description = "Draws a glowing cone of stacked rings above each player's head, colored to match your theme.")
public final class ChinaHat extends Module {
    public static final ChinaHat INSTANCE = new ChinaHat();

    private final NumberSetting radius = new NumberSetting("Radius", 1.2f, 0.3f, 4.0f, 0.1f);
    private final NumberSetting height = new NumberSetting("Height", 0.8f, 0.0f, 4.0f, 0.1f);
    private final NumberSetting lineWidth = new NumberSetting("Line width", 2.0f, 1.0f, 5.0f, 0.5f);
    private final NumberSetting rotateSpeed = new NumberSetting("Rotate speed", 1.0f, 0.0f, 6.0f, 0.1f);
    private final BooleanSetting onlySelf = new BooleanSetting("Only self", false);
    private final okyware.wtf.client.modules.api.setting.impl.ColorSetting customColorSetting = new okyware.wtf.client.modules.api.setting.impl.ColorSetting("Color", new ColorRGBA(255, 255, 255));
    private final BooleanSetting useCustomColor = new BooleanSetting("Custom Color", false);

    private ChinaHat() {
    }

    @EventTarget
    public void onRender3D(EventRender3D event) {
        if (mc.player == null || mc.world == null) return;

        float tickDelta = Render3DUtil.getTickDelta();
        ColorRGBA base = useCustomColor.isEnabled() ? customColorSetting.getColor() : Okyware.getInstance().getThemeManager().getClientColor(0);
        float lw = lineWidth.getCurrent();
        float baseRadius = radius.getCurrent();
        float h = height.getCurrent();
        float rot = (float) Math.toRadians((System.currentTimeMillis() / 8.0) * rotateSpeed.getCurrent() % 360.0);

        if (onlySelf.isEnabled()) {
            if (mc.options.getPerspective() != Perspective.FIRST_PERSON) {
                renderHat(mc.player, tickDelta, base, baseRadius, h, lw, rot);
            }
        } else {
            for (PlayerEntity p : mc.world.getPlayers()) {
                if (p == mc.player && mc.options.getPerspective() == Perspective.FIRST_PERSON) continue;
                renderHat(p, tickDelta, base, baseRadius, h, lw, rot);
            }
        }
    }

    private void renderHat(PlayerEntity p, float tickDelta, ColorRGBA base, float baseRadius, float h, float lw, float rot) {
        double x = MathHelper.lerp(tickDelta, p.prevX, p.getX());
        double y = MathHelper.lerp(tickDelta, p.prevY, p.getY()) + p.getHeight() + 0.15;
        double z = MathHelper.lerp(tickDelta, p.prevZ, p.getZ());
        Vec3d center = new Vec3d(x, y + h, z);
        drawGlowRing(center, baseRadius, base, 1f, lw, rot, 64);
    }

    private void drawGlowRing(Vec3d center, float radius, ColorRGBA color, float alpha, float coreLw, float rot, int segments) {
        float[] widths = { coreLw * 4f, coreLw * 2.5f, coreLw };
        float[] alphas = { 0.18f, 0.42f, 1.0f };
        for (int i = 0; i < widths.length; i++) {
            drawRing(center, radius, color.mulAlpha(alpha * alphas[i]).getRGB(), widths[i], rot, segments);
        }
    }

    private void drawRing(Vec3d center, float radius, int color, float width, float rot, int segments) {
        for (int i = 0; i < segments; i++) {
            double a1 = rot + (i / (double) segments) * MathUtil.PI2;
            double a2 = rot + ((i + 1) / (double) segments) * MathUtil.PI2;
            Vec3d p1 = new Vec3d(Math.cos(a1) * radius, 0, Math.sin(a1) * radius);
            Vec3d p2 = new Vec3d(Math.cos(a2) * radius, 0, Math.sin(a2) * radius);
            Render3DUtil.drawLine(center.add(p1), center.add(p2), color, width, true);
        }
    }
}
