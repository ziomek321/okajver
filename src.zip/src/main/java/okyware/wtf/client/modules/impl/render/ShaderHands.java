package okyware.wtf.client.modules.impl.render;

import lombok.Getter;
import okyware.wtf.client.modules.api.Category;
import okyware.wtf.client.modules.api.Module;
import okyware.wtf.client.modules.api.ModuleAnnotation;
import okyware.wtf.client.modules.api.setting.impl.NumberSetting;
import okyware.wtf.utility.render.shader.ShaderHandsRenderer;

@Getter
@ModuleAnnotation(name = "ShaderHands", category = Category.RENDER, description = "Shader effect on hands and items")
public final class ShaderHands extends Module {
    public static final ShaderHands INSTANCE = new ShaderHands();
    private static final ShaderHandsRenderer RENDERER = ShaderHandsRenderer.getInstance();

    public final NumberSetting waveSpeed = new NumberSetting("Wave Speed", 1.2f, 0.1f, 5.0f, 0.1f);
    public final NumberSetting waveScale = new NumberSetting("Wave Scale", 1.0f, 1.0f, 3.0f, 0.1f);
    public final NumberSetting outline = new NumberSetting("Outline", 1.2f, 0.1f, 5.0f, 0.1f);
    public final NumberSetting glow = new NumberSetting("Glow", 1.0f, 0.0f, 5.0f, 0.1f);
    public final NumberSetting fill = new NumberSetting("Fill", 0.6f, 0.0f, 1.0f, 0.01f);
    public final NumberSetting alpha = new NumberSetting("Alpha", 1.0f, 0.0f, 1.0f, 0.05f);

    private ShaderHands() {}

    @Override
    public void onDisable() {
        RENDERER.invalidateState();
        super.onDisable();
    }
}
