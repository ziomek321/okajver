package okyware.wtf.client.modules.impl.render;

import com.darkmagician6.eventapi.EventTarget;
import net.minecraft.util.Identifier;
import org.lwjgl.glfw.GLFW;
import okyware.wtf.Okyware;

import okyware.wtf.base.events.impl.input.EventSetScreen;
import okyware.wtf.base.events.impl.player.EventUpdate;
import okyware.wtf.base.events.impl.render.EventRender2D;
import okyware.wtf.base.events.impl.render.EventRenderScreen;
import okyware.wtf.client.modules.api.Category;
import okyware.wtf.client.modules.api.Module;
import okyware.wtf.client.modules.api.ModuleAnnotation;
import okyware.wtf.client.modules.api.setting.impl.ModeSetting;
import okyware.wtf.client.screens.menu.MenuScreen;
import okyware.wtf.client.screens.menu.settings.impl.MenuSliderSetting;
import okyware.wtf.utility.render.display.base.color.ColorRGBA;
import okyware.wtf.utility.render.display.base.UIContext;

import java.awt.event.KeyEvent;

@ModuleAnnotation(name = "Menu", category = Category.RENDER, description = "Opens the main configuration menu for toggling and adjusting all modules")
public final class Menu extends Module {
    public static final Menu INSTANCE = new Menu();

    public final ModeSetting image = new ModeSetting("Image", "None", "Bdsm", "Cutie");

    private static final Identifier BDSM_TEX = Identifier.of("okyware", "textures/gui/images/bdsm.png");
    private static final Identifier CUTIE_TEX = Identifier.of("okyware", "textures/gui/images/cutie.png");

    private Menu() {
        this.setKeyCode(isFeather() ? GLFW.GLFW_KEY_LEFT_CONTROL : GLFW.GLFW_KEY_RIGHT_SHIFT);
    }

    private static boolean isFeather() {
        return net.fabricmc.loader.api.FabricLoader.getInstance().isModLoaded("feather");
    }

    @Override
    public void onEnable() {
        if (mc.world == null) {
            this.setEnabled(false);
            return;
        }

        if (mc.currentScreen == Okyware.getInstance().getMenuScreen()) return;

        mc.setScreen(Okyware.getInstance().getMenuScreen());

        super.onEnable();
    }

    @Override
    public void onDisable() {


        super.onDisable();

    }


    @Override
    public void setKeyCode(int keyCode) {
        if(keyCode == -1) return;
        super.setKeyCode(keyCode);
    }

    @EventTarget
    public void render2d(EventRenderScreen eventRender2D){
        UIContext uiContext =eventRender2D.getContext();
        Okyware.getInstance().getMenuScreen().renderTop(uiContext,uiContext.getMouseX(),uiContext.getMouseY());

        
        if (!image.is("None")) {
            Identifier tex = image.is("Bdsm") ? BDSM_TEX : CUTIE_TEX;
            float imgW = image.is("Bdsm") ? 200 : 150;
            float imgH = image.is("Bdsm") ? 116 : 154;
            float screenW = mc.getWindow().getScaledWidth();
            float screenH = mc.getWindow().getScaledHeight();
            float prog = Okyware.getInstance().getMenuScreen().getProgress();
            uiContext.drawTexture(tex, screenW - imgW, screenH - imgH, imgW, imgH, ColorRGBA.WHITE.mulAlpha(prog));
        }

        if(Okyware.getInstance().getMenuScreen().isFinish()){
            this.toggle();
        }
    }

}
