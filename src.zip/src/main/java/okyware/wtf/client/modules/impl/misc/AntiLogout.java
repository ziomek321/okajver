package okyware.wtf.client.modules.impl.misc;

import com.darkmagician6.eventapi.EventTarget;
import net.minecraft.network.packet.c2s.common.KeepAliveC2SPacket;
import net.minecraft.network.packet.c2s.play.PlayerMoveC2SPacket;
import net.minecraft.network.packet.s2c.common.DisconnectS2CPacket;
import net.minecraft.network.packet.s2c.play.DamageTiltS2CPacket;
import net.minecraft.network.packet.s2c.play.DeathMessageS2CPacket;
import net.minecraft.network.packet.s2c.play.HealthUpdateS2CPacket;
import net.minecraft.network.packet.s2c.play.PlayerPositionLookS2CPacket;
import okyware.wtf.base.events.impl.player.EventUpdate;
import okyware.wtf.base.events.impl.server.EventPacket;
import okyware.wtf.client.modules.api.Category;
import okyware.wtf.client.modules.api.Module;
import okyware.wtf.client.modules.api.ModuleAnnotation;
import okyware.wtf.client.modules.api.setting.impl.BooleanSetting;
import okyware.wtf.client.modules.api.setting.impl.NumberSetting;

@ModuleAnnotation(name = "AntiLogout", category = Category.MISC, description = "Bypasses server anti-logout/combat-log plugins")
public final class AntiLogout extends Module {
    public static final AntiLogout INSTANCE = new AntiLogout();

    private final NumberSetting timer = new NumberSetting("Timer", 15.0f, 1.0f, 20.0f, 1.0f);
    private final NumberSetting duration = new NumberSetting("Duration (s)", 5.0f, 1.0f, 30.0f, 1.0f);
    private final BooleanSetting cancelDeath = new BooleanSetting("Cancel Death", true);
    private final BooleanSetting cancelKick = new BooleanSetting("Cancel Kick", true);
    private final BooleanSetting cancelTP = new BooleanSetting("Cancel TP", true);

    private long timerActiveUntil = 0;

    private AntiLogout() {
    }

    @Override
    public void onEnable() {
        super.onEnable();
        timerActiveUntil = 0;
    }

    @EventTarget
    public void onUpdate(EventUpdate event) {
        if (mc.player == null) return;

        // Activate when hit
        if (mc.player.hurtTime == mc.player.maxHurtTime && mc.player.hurtTime > 0) {
            timerActiveUntil = System.currentTimeMillis() + (long)(duration.getCurrent() * 1000);
        }

        // Send extra movement packets to simulate timer (server sees you moving faster)
        if (System.currentTimeMillis() < timerActiveUntil) {
            int extraPackets = (int) timer.getCurrent() - 1;
            for (int i = 0; i < extraPackets; i++) {
                mc.player.networkHandler.sendPacket(new PlayerMoveC2SPacket.Full(
                        mc.player.getX(), mc.player.getY(), mc.player.getZ(),
                        mc.player.getYaw(), mc.player.getPitch(),
                        mc.player.isOnGround(), mc.player.horizontalCollision
                ));
            }
        }
    }

    @EventTarget
    public void onPacket(EventPacket event) {
        if (mc.player == null) return;

        if (event.isReceive()) {
            if (cancelKick.isEnabled() && event.getPacket() instanceof DisconnectS2CPacket) {
                event.cancel();
            }

            if (cancelDeath.isEnabled() && event.getPacket() instanceof HealthUpdateS2CPacket packet) {
                if (packet.getHealth() <= 0) {
                    event.cancel();
                }
            }

            if (cancelDeath.isEnabled() && event.getPacket() instanceof DeathMessageS2CPacket packet) {
                if (packet.playerId() == mc.player.getId()) {
                    event.cancel();
                }
            }

            if (cancelDeath.isEnabled() && event.getPacket() instanceof DamageTiltS2CPacket packet) {
                if (packet.id() == mc.player.getId()) {
                    event.cancel();
                }
            }

            if (cancelTP.isEnabled() && event.getPacket() instanceof PlayerPositionLookS2CPacket) {
                event.cancel();
            }
        }

        if (event.isSent() && event.getPacket() instanceof KeepAliveC2SPacket) {
            event.setCancelled(false);
        }
    }
}
