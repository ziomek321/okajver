package okyware.wtf.client.modules.impl.render;

import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.Arm;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.RotationAxis;
import okyware.wtf.base.animations.base.Easing;
import okyware.wtf.client.modules.api.Category;
import okyware.wtf.client.modules.api.Module;
import okyware.wtf.client.modules.api.ModuleAnnotation;
import okyware.wtf.client.modules.api.setting.impl.BooleanSetting;
import okyware.wtf.client.modules.api.setting.impl.ModeSetting;
import okyware.wtf.client.modules.api.setting.impl.NumberSetting;
import okyware.wtf.client.modules.impl.combat.BlockHit;

@ModuleAnnotation(name = "SwingAnimation", category = Category.RENDER, description = "Overrides the default hand swing with selectable premium animation styles")
public final class SwingAnimation extends Module {
    public static final SwingAnimation INSTANCE = new SwingAnimation();

    private SwingAnimation() {
    }

    public ModeSetting animationMode = new ModeSetting(
            "Mode",
            "Smooth",
            "Block Hit",
            "Bonk",
            "Rotate 360",
            "Stab",
            "Default",
            "First",
            "Second",
            "Third",
            "Fourth",
            "Fifth"
    );
    public NumberSetting swingPower = new NumberSetting("Power", 5.0f, 1.0f, 10.0f, 0.05f);
    public final BooleanSetting onlyAura = new BooleanSetting("Aura only", false);
    public final BooleanSetting swingBack = new BooleanSetting("Swing Back", true);

    private static final Easing SWING_EASING = Easing.generate(0.45, 1.45, 0.49, 1.15);

    public void renderSwordAnimation(MatrixStack matrices, float swingProgress, float equipProgress, Arm arm) {
        switch (animationMode.get()) {
            case "Smooth" -> renderSmooth(matrices, swingProgress);
            case "Block Hit" -> renderBlockHitAnim(matrices, swingProgress);
            case "Bonk" -> renderBonk(matrices, swingProgress);
            case "Rotate 360" -> renderRotate360(matrices, swingProgress);
            case "Stab" -> renderStab(matrices, swingProgress);
            case "Default" -> renderDefault(matrices, swingProgress);
            case "First" -> renderFirst(matrices, swingProgress, equipProgress, arm);
            case "Second" -> renderSecond(matrices, swingProgress, arm);
            case "Third" -> renderThird(matrices, swingProgress, arm);
            case "Fourth" -> renderFourth(matrices, swingProgress, arm);
            case "Fifth" -> renderFifth(matrices, swingProgress, arm);
        }

        if (BlockHit.INSTANCE.isEnabled() && mc.player.getMainHandStack().getItem() instanceof net.minecraft.item.SwordItem && mc.player.handSwingTicks > 0) {
            matrices.translate(-0.1f, 0.15f, 0.1f);
            matrices.multiply(RotationAxis.POSITIVE_X.rotationDegrees(-50f));
            matrices.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(-60f));
            matrices.multiply(RotationAxis.POSITIVE_Z.rotationDegrees(-40f));
        }
    }

    private float easeProgress(float progress) {
        float eased = SWING_EASING.ease(progress, 0, 1, 1);
        if (swingBack.isEnabled()) {
            eased = MathHelper.sin(MathHelper.sqrt(eased) * (float) Math.PI);
        }
        return eased;
    }

    private float lerp(float start, float end, float progress) {
        return start + (end - start) * progress;
    }

    private void renderSmooth(MatrixStack matrices, float swingProgress) {
        float p = easeProgress(swingProgress);
        matrices.translate(0.56F, -0.52F, -0.72F);
        matrices.multiply(RotationAxis.POSITIVE_X.rotationDegrees(p * -80.0F));
        matrices.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(p * -20.0F));
        matrices.multiply(RotationAxis.POSITIVE_Z.rotationDegrees(p * -10.0F));
    }

    private void renderBlockHitAnim(MatrixStack matrices, float swingProgress) {
        float p = easeProgress(swingProgress);
        matrices.translate(0.56F, -0.52F, -0.72F);
        matrices.multiply(RotationAxis.POSITIVE_X.rotationDegrees(-40.0F));
        matrices.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(p * -45.0F));
        matrices.multiply(RotationAxis.POSITIVE_Z.rotationDegrees(p * -15.0F));
    }

    private void renderBonk(MatrixStack matrices, float swingProgress) {
        float p = easeProgress(swingProgress);
        matrices.translate(0.56F, -0.52F, -0.72F);
        matrices.multiply(RotationAxis.POSITIVE_X.rotationDegrees(p * -60.0F));
    }

    private void renderRotate360(MatrixStack matrices, float swingProgress) {
        float p = SWING_EASING.ease(swingProgress, 0, 1, 1);
        matrices.translate(0.56F, -0.52F, -0.72F);
        matrices.multiply(RotationAxis.POSITIVE_Z.rotationDegrees(p * -360.0F));
    }

    private void renderStab(MatrixStack matrices, float swingProgress) {
        float p = easeProgress(swingProgress);
        matrices.translate(0.56F, -0.52F, -0.72F);
        matrices.translate(0.0F, 0.0F, p * -0.4F);
        matrices.multiply(RotationAxis.POSITIVE_X.rotationDegrees(p * -10.0F));
    }

    private void renderDefault(MatrixStack matrices, float swingProgress) {
        matrices.translate(0.56F, -0.52F, -0.72F);
        float g = MathHelper.sin(MathHelper.sqrt(swingProgress) * (float) Math.PI);
        matrices.multiply(RotationAxis.POSITIVE_X.rotationDegrees(g * -60.0F));
        matrices.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(g * -30.0F));
    }

    private void renderFirst(MatrixStack matrices, float swingProgress, float equipProgress, Arm arm) {
        if (swingProgress > 0) {
            float g = MathHelper.sin(MathHelper.sqrt(swingProgress) * (float) Math.PI);
            matrices.translate(0.56F, equipProgress * -0.2f - 0.5F, -0.7F);
            matrices.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(45));
            matrices.multiply(RotationAxis.POSITIVE_X.rotationDegrees(g * -85.0F));
            matrices.translate(-0.1F, 0.28F, 0.2F);
            matrices.multiply(RotationAxis.POSITIVE_X.rotationDegrees(-85.0F));
        } else {
            float n = -0.4f * MathHelper.sin(MathHelper.sqrt(swingProgress) * (float) Math.PI);
            float m = 0.2f * MathHelper.sin(MathHelper.sqrt(swingProgress) * ((float) Math.PI * 2));
            float f1 = -0.2f * MathHelper.sin(swingProgress * (float) Math.PI);
            matrices.translate(n, m, f1);
            applyEquipOffset(matrices, arm, equipProgress);
            applySwingOffset(matrices, arm, swingProgress);
        }
    }

    private void renderSecond(MatrixStack matrices, float swingProgress, Arm arm) {
        float g = MathHelper.sin(MathHelper.sqrt(swingProgress) * (float) Math.PI);
        applyEquipOffset(matrices, arm, 0);
        matrices.multiply(RotationAxis.POSITIVE_X.rotationDegrees(50f));
        matrices.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(-60f));
        matrices.multiply(RotationAxis.POSITIVE_Z.rotationDegrees(110f + 20f * g));
    }

    private void renderThird(MatrixStack matrices, float swingProgress, Arm arm) {
        float g = MathHelper.sin(MathHelper.sqrt(swingProgress) * (float) Math.PI);
        applyEquipOffset(matrices, arm, 0);
        matrices.multiply(RotationAxis.POSITIVE_X.rotationDegrees(50f));
        matrices.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(-30f * (1f - g) - 30f));
        matrices.multiply(RotationAxis.POSITIVE_Z.rotationDegrees(110f));
    }

    private void renderFourth(MatrixStack matrices, float swingProgress, Arm arm) {
        float g = MathHelper.sin(swingProgress * (float) Math.PI);
        applyEquipOffset(matrices, arm, 0);
        matrices.translate(0.1F, -0.2F, -0.3F);
        matrices.multiply(RotationAxis.POSITIVE_X.rotationDegrees(-30f * g - 36f));
        matrices.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(25f * g));
        matrices.multiply(RotationAxis.POSITIVE_Z.rotationDegrees(12f));
    }

    private void renderFifth(MatrixStack matrices, float swingProgress, Arm arm) {
        float g = MathHelper.sin(MathHelper.sqrt(swingProgress) * (float) Math.PI);
        applyEquipOffset(matrices, arm, 0);
        matrices.translate(0.0F, -0.2F, -0.4F);
        matrices.multiply(RotationAxis.POSITIVE_X.rotationDegrees(-120f * g - 3f));
    }

    private void applyEquipOffset(MatrixStack matrices, Arm arm, float equipProgress) {
        int i = arm == Arm.RIGHT ? 1 : -1;
        matrices.translate((float) i * 0.56F, -0.52F + equipProgress * -0.6F, -0.72F);
    }

    private void applySwingOffset(MatrixStack matrices, Arm arm, float swingProgress) {
        int i = arm == Arm.RIGHT ? 1 : -1;
        float f = MathHelper.sin(swingProgress * swingProgress * (float) Math.PI);
        matrices.multiply(RotationAxis.POSITIVE_Y.rotationDegrees((float) i * (45.0F + f * -20.0F)));
        float g = MathHelper.sin(MathHelper.sqrt(swingProgress) * (float) Math.PI);
        matrices.multiply(RotationAxis.POSITIVE_Z.rotationDegrees((float) i * g * -20.0F));
        matrices.multiply(RotationAxis.POSITIVE_X.rotationDegrees(g * -80.0F));
        matrices.multiply(RotationAxis.POSITIVE_Y.rotationDegrees((float) i * -45.0F));
    }
}
