package okyware.wtf.client.modules.impl.render;

import com.mojang.blaze3d.systems.RenderSystem;
import net.minecraft.client.render.DiffuseLighting;
import net.minecraft.client.render.entity.PlayerEntityRenderer;
import net.minecraft.component.DataComponentTypes;
import net.minecraft.component.type.NbtComponent;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityPose;
import net.minecraft.entity.ItemEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.scoreboard.ReadableScoreboardScore;
import net.minecraft.scoreboard.ScoreboardDisplaySlot;
import net.minecraft.scoreboard.ScoreboardObjective;
import net.minecraft.scoreboard.number.StyledNumberFormat;
import net.minecraft.text.MutableText;
import net.minecraft.text.OrderedText;
import net.minecraft.text.Style;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;
import org.joml.Vector4d;
import okyware.wtf.Okyware;
import com.darkmagician6.eventapi.EventTarget;
import okyware.wtf.base.events.impl.render.EventHudRender;
import okyware.wtf.base.events.impl.render.EventRender2D;
import okyware.wtf.base.events.impl.render.EventRender3D;
import okyware.wtf.base.font.Font;
import okyware.wtf.base.font.Fonts;
import okyware.wtf.base.theme.Theme;
import okyware.wtf.base.theme.ThemeManager;
import okyware.wtf.client.modules.api.Category;
import okyware.wtf.client.modules.api.Module;
import okyware.wtf.client.modules.api.ModuleAnnotation;
import okyware.wtf.client.modules.api.setting.impl.BooleanSetting;
import okyware.wtf.client.modules.api.setting.impl.ModeSetting;
import okyware.wtf.client.modules.api.setting.impl.MultiBooleanSetting;
import okyware.wtf.client.modules.api.setting.impl.NumberSetting;
import okyware.wtf.client.modules.impl.misc.NameProtect;
import okyware.wtf.utility.game.other.MessageUtil;
import okyware.wtf.utility.game.other.TextUtil;
import okyware.wtf.utility.game.player.PlayerIntersectionUtil;
import okyware.wtf.utility.math.MathUtil;
import okyware.wtf.utility.math.ProjectionUtil;
import okyware.wtf.utility.mixin.client.render.LivingEntityRendererMixin;
import okyware.wtf.utility.render.display.Render2DUtil;
import okyware.wtf.utility.render.display.base.BorderRadius;
import okyware.wtf.utility.render.display.base.CustomDrawContext;
import okyware.wtf.utility.render.display.base.color.ColorRGBA;
import okyware.wtf.utility.render.display.shader.DrawUtil;
import okyware.wtf.utility.render.level.Render3DUtil;

import java.awt.*;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.ArrayList;

import static java.util.Arrays.asList;

@ModuleAnnotation(name = "EntityESP", category = Category.RENDER, description = "Draws colored outlines and boxes around entities visible through terrain")
public final class EntityESP extends Module {
    public static final EntityESP INSTANCE = new EntityESP();

    private final MultiBooleanSetting elements = MultiBooleanSetting.create("Elements",
            asList("Names", "Items", "Armor","Triangles","Boxes","Hands"));

    private final ModeSetting textMode = new ModeSetting("Font");
    private final ModeSetting.Value mojo = new ModeSetting.Value(textMode, "Minecraft");
    private final ModeSetting.Value stardlc = new ModeSetting.Value(textMode, "Okyware").select();

    private final NumberSetting scale = new NumberSetting("Size", 1.0f, 0.5f, 2.0f, 0.1f);
    private final BooleanSetting blur = new BooleanSetting("Blur", "Requires good PC", false, Interface.INSTANCE::isBlur);
    private final BooleanSetting glow = new BooleanSetting("Glow", "Requires powerful PC", false, Interface.INSTANCE::isGlow);

    private EntityESP() {

    }

    public boolean isRenderName() {
        return this.isEnabled()&&this.elements.isEnable(0) ;
    }

    private boolean isElementEnabled(String elementName) {
        return elements.isEnable(elementName);
    }

    @EventTarget
    public void onHudRender(EventRender3D event) {
        if(!elements.isEnable(4)) return;
        for (Entity ent : mc.world.getPlayers()) {

            if (ent instanceof PlayerEntity entity) {
                if (entity == mc.player && mc.options.getPerspective().isFirstPerson()) continue;

                boolean friend = Okyware.getInstance().getFriendManager().isFriend(entity.getGameProfile().getName());
                int color = friend 
                        ? Okyware.getInstance().getThemeManager().getCurrentTheme().getFriendColor().getRGB() 
                        : Okyware.getInstance().getThemeManager().getCurrentTheme().getColor().getRGB();
                Render3DUtil.drawBox((entity.getBoundingBox().offset(MathUtil.interpolate(entity).subtract(entity.getPos()))), color, 1f);
            }
        }
    }

    @EventTarget
    public void onHudRender(EventRender2D event) {
        Render2DUtil.onRender(event.getContext());
        if (mc.player == null || mc.world == null || mc.getEntityRenderDispatcher().camera == null) return;
        try {
            RenderSystem.depthMask(false);
            CustomDrawContext context = event.getContext();

            for (Entity ent : mc.world.getEntities()) {

                if (ent instanceof PlayerEntity entity) {
                    if ( this.elements.isEnable(5)) {
                        if (elements.isEnable(5)) {

                            Vector4d vec4d = ProjectionUtil.getVector4D(entity);

                            drawHands(event.getContext(), entity, vec4d);
                        }
                    }
                    if ( this.elements.isEnable(0)) renderNameTag(context, entity, event.getTickDelta());

                    if (elements.isEnable(3)) renderEntityBox(context, entity, event.getTickDelta());

                }
                if (ent instanceof ItemEntity entity) {
                    if ( this.elements.isEnable(1)) renderItemESP(context, entity, event.getTickDelta());
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }finally {
            RenderSystem.depthMask(true);
        }
    }
    private void drawHands(CustomDrawContext context, PlayerEntity player, Vector4d vec) {
        if (player == mc.player && mc.options.getPerspective().isFirstPerson()) return;

        if(ProjectionUtil.canSee(vec) ) return;
        double posY = vec.w; 
        final float centerX = (float) ProjectionUtil.centerX(vec);

        for (ItemStack stack : player.getHandItems()) {
            if (stack == null || stack.isEmpty()) continue;

            MutableText text = stack.getName().copy();


            if(text.getSiblings().isEmpty()) {
                text = text.copy().setStyle(Style.EMPTY.withColor(Okyware.getInstance().getThemeManager().getCurrentTheme().getWhite().getRGB()));
            }
            if (!text.getString().isEmpty() ) {
                text = TextUtil.replaceLastChar(text, "");

            }

            if (stack.getCount() > 1) {
                text = text.copy().append(Text.of(" x" + stack.getCount()).copy().setStyle(Style.EMPTY.withColor(Okyware.getInstance().getThemeManager().getCurrentTheme().getColor().getRGB())));
                ;
            }




                Font font = Fonts.MEDIUM.getFont(8 * scale.getCurrent());
            posY += (font.height() / 2.0f) + 12 + 2;



            float textX = centerX - (font.width(text) / 2.0f);

            Theme theme = Okyware.getInstance().getThemeManager().getCurrentTheme();

            ColorRGBA rectColor = Okyware.getInstance().getFriendManager().isFriend(player.getGameProfile().getName())
                    ? theme.getColor().withAlpha(theme.getForegroundLight().getAlpha())
                    : theme.getForegroundLight();

            float actualTextWidth = font.width(text) * scale.getCurrent();
            float rectWidth = actualTextWidth + 16 * scale.getCurrent();
            float rectHeight = 12 * scale.getCurrent();
            float rectX = textX - 8 * scale.getCurrent();
            
            ColorRGBA bg = Okyware.getInstance().getFriendManager().isFriend(player.getGameProfile().getName())
                    ? new ColorRGBA(0, 80, 0, 120)
                    : new ColorRGBA(0, 0, 0, 120);

            DrawUtil.drawBlur(context.getMatrices(), rectX, (float) posY, rectWidth, rectHeight, 20f, BorderRadius.all(2f), ColorRGBA.WHITE);
            context.drawRoundedRect(rectX, (float) posY, rectWidth, rectHeight, BorderRadius.all(2f), bg);
            DrawUtil.drawRoundedCorner(context.getMatrices(), rectX, (float) posY, rectWidth, rectHeight, 0.1f, 9, theme.getColor(), BorderRadius.all(2f));

            context.pushMatrix();
            context.getMatrices().translate(textX, (float) posY + 3 * scale.getCurrent(), 0);
            context.drawText(font, text, 0, 0);
            context.popMatrix();
        }
    }
    private void renderNameTag(CustomDrawContext context, PlayerEntity player, float tickDelta) {
        if (player == mc.player && mc.options.getPerspective().isFirstPerson()) return;

        double x = interpolate(player.prevX, player.getX(), tickDelta);
        double y = interpolate(player.prevY, player.getY(), tickDelta);
        double z = interpolate(player.prevZ, player.getZ(), tickDelta);
        Vec3d projected = ProjectionUtil.worldSpaceToScreenSpace(new Vec3d(x, y + getPlayerHeight(player), z));

        if (projected.z <= 0 || projected.z >= 1) return;
        Theme theme = Okyware.getInstance().getThemeManager().getCurrentTheme();

        ColorRGBA bg = Okyware.getInstance().getFriendManager().isFriend(player.getGameProfile().getName())
                ? new ColorRGBA(0, 80, 0, 120)
                : new ColorRGBA(0, 0, 0, 120);
        float posX = 0;
        float posY = 0;
        float textWidth = 0;
        if (mojo.isSelected()) {
            Text playerName = (player == mc.player ||
                    (NameProtect.getCustomName() != null && Okyware.getInstance().getFriendManager().isFriend(player.getNameForScoreboard())))
                    ? Text.of(NameProtect.getCustomName(player.getNameForScoreboard()))
                    : player.getDisplayName();
            if (playerName == null) return;

            playerName = playerName.getString().contains(player.getGameProfile().getName()) ? TextUtil.truncateAfterSubstring(playerName, player.getGameProfile().getName(), false) : TextUtil.truncateAfterSecondSpace(playerName, false);

            playerName = playerName.copy().append(Text.of("  " + PlayerIntersectionUtil.getHealthString(player)).copy().getWithStyle(Style.EMPTY.withColor(getHealthColorRGBA(PlayerIntersectionUtil.getHealth(player)).getRGB())).get(0));


            textWidth = mc.textRenderer.getWidth(playerName);
            posX = (float) projected.x - textWidth / 2;
            posY = (float) projected.y - getPlayerHeight(player);

            context.pushMatrix();
            context.getMatrices().translate(posX + textWidth / 2, posY + 6.5f, 0);
            context.getMatrices().scale(0.9f * scale.getCurrent(), 0.9f * scale.getCurrent(), 1f);
            context.getMatrices().translate(-posX - textWidth / 2, -posY - 6.5f, 0);


            float actualTextWidth = mc.textRenderer.getWidth(playerName) * scale.getCurrent();
            float rectWidth = actualTextWidth + 12 * scale.getCurrent();
            float rectHeight = 12 * scale.getCurrent();
            float rectX = posX - 6 * scale.getCurrent();
            float rectY = posY - 13f * scale.getCurrent();
            
            DrawUtil.drawBlur(context.getMatrices(), rectX, rectY, rectWidth, rectHeight, 20f, BorderRadius.all(2f), ColorRGBA.WHITE);
            context.drawRoundedRect(rectX, rectY, rectWidth, rectHeight, BorderRadius.all(2f), bg);
            DrawUtil.drawRoundedCorner(context.getMatrices(), rectX, rectY, rectWidth, rectHeight, 0.1f, 9, theme.getColor(), BorderRadius.all(2f));

            
            context.pushMatrix();
            context.getMatrices().translate(posX, posY - 13f * scale.getCurrent() + 2 * scale.getCurrent(), 0);
            context.drawText(Fonts.MEDIUM.getFont(10 * scale.getCurrent()), Text.of(playerName), 0, 0);

            context.popMatrix();
        } else {
            Text playerName = (player == mc.player ||
                    (NameProtect.getCustomName() != null && Okyware.getInstance().getFriendManager().isFriend(player.getNameForScoreboard())))
                    ? Text.of(NameProtect.getCustomName(player.getGameProfile().getName()))
                    : player.getDisplayName();
            if (playerName == null) return;
            playerName = playerName.getString().contains(player.getGameProfile().getName()) ? TextUtil.truncateAfterSubstring(playerName, player.getGameProfile().getName(), false) : TextUtil.truncateAfterSecondSpace(playerName, false);
            Text finalText = Text.of("");
            for (Text text: playerName.getSiblings()){

                finalText =finalText.copy().append(text.copy().setStyle(text.getStyle().getColor()==null?Style.EMPTY.withColor(theme.getWhite().getRGB()):text.getStyle()));
            }
            playerName = finalText;
            float hp = PlayerIntersectionUtil.getHealth(player);
            String health = PlayerIntersectionUtil.getHealthString(hp);
            Font font = Fonts.MEDIUM.getFont(8 * scale.getCurrent());

            textWidth = font.width(playerName) + 8 + font.width(health);
            posX = (float) projected.x - textWidth / 2;
            posY = (float) projected.y - getPlayerHeight(player);

            context.pushMatrix();
            context.getMatrices().translate(posX + textWidth / 2, posY + 6.5f, 0);
            context.getMatrices().scale(0.9f * scale.getCurrent(), 0.9f * scale.getCurrent(), 1f);
            context.getMatrices().translate(-posX - textWidth / 2, -posY - 6.5f, 0);


            float actualNameWidth = font.width(playerName) * scale.getCurrent();
            float actualHealthWidth = font.width(health) * scale.getCurrent();
            float actualTotalWidth = actualNameWidth + 8 * scale.getCurrent() + actualHealthWidth;
            float rectWidth2 = actualTotalWidth + 16 * scale.getCurrent();
            float rectHeight2 = 12 * scale.getCurrent();
            float rectX2 = posX - 8 * scale.getCurrent();
            float rectY2 = posY - 13f * scale.getCurrent();
            
            DrawUtil.drawBlur(context.getMatrices(), rectX2, rectY2, rectWidth2, rectHeight2, 20f, BorderRadius.all(2f), ColorRGBA.WHITE);
            context.drawRoundedRect(rectX2, rectY2, rectWidth2, rectHeight2, BorderRadius.all(2f), bg);
            DrawUtil.drawRoundedCorner(context.getMatrices(), rectX2, rectY2, rectWidth2, rectHeight2, 0.1f, 9, theme.getColor(), BorderRadius.all(2f));

            
            context.pushMatrix();
            context.getMatrices().translate(posX, posY - 13f * scale.getCurrent() + 3 * scale.getCurrent(), 0);
            context.drawText(font, playerName, 0, 0);
            context.drawText(font, health, actualNameWidth + 8 * scale.getCurrent(), 0, getHealthColorRGBA(hp));

            context.popMatrix();
        }

        float stacksY = posY - 35 * scale.getCurrent();

        if ( this.elements.isEnable(2)) {
            ArrayList<ItemStack> stacks = new ArrayList<>();
            stacks.add(player.getOffHandStack());
            stacks.addAll(player.getInventory().armor);
            stacks.add(player.getMainHandStack());

            int nonEmpty = (int) stacks.stream().filter(stack -> !stack.isEmpty()).count();
            if (nonEmpty > 0) {
                float totalWidth = nonEmpty * 18 * scale.getCurrent();
                float centerX = posX + textWidth / 2;
                float rectX = centerX - totalWidth / 2 - 4 * scale.getCurrent();
                float rectY = stacksY;
                float rectHeight = 18 * scale.getCurrent();
                
                DrawUtil.drawBlur(context.getMatrices(), rectX, rectY, totalWidth, rectHeight, 20f, BorderRadius.all(2f), ColorRGBA.WHITE);
                context.drawRoundedRect(rectX, rectY, totalWidth, rectHeight, BorderRadius.all(2f), bg);

                DrawUtil.drawRoundedCorner(context.getMatrices(), rectX, rectY, totalWidth, rectHeight, 0.1f, 10f, theme.getColor(), BorderRadius.all(2f));

                float currentOffset = 0;
                for (ItemStack stack : stacks) {
                    if (!stack.isEmpty()) {
                        context.pushMatrix();
                        context.getMatrices().translate(centerX - totalWidth / 2 + currentOffset, rectY, 0);
                        context.getMatrices().scale(scale.getCurrent(), scale.getCurrent(), 1f);
                        DiffuseLighting.disableGuiDepthLighting();

                        context.drawItem(stack, 0, 1);
                        context.popMatrix();
                        currentOffset += 18 * scale.getCurrent();
                    }
                }
            }
        }



        context.popMatrix();
    }

    private void renderItemESP(CustomDrawContext context, ItemEntity ent, float tickDelta) {

        Vec3d[] corners = getPoints(ent, tickDelta);
        Vector4d screenBB = null;

        for (Vec3d v : corners) {
            Vec3d p = ProjectionUtil.worldSpaceToScreenSpace(v);
            if (p.z > 0 && p.z < 1) {
                if (screenBB == null) screenBB = new Vector4d(p.x, p.y, p.x, p.y);
                screenBB.x = Math.min(screenBB.x, p.x);
                screenBB.y = Math.min(screenBB.y, p.y);
                screenBB.z = Math.max(screenBB.z, p.x);
                screenBB.w = Math.max(screenBB.w, p.y);
            }
        }
        if (screenBB == null) return;


        Text label = ent.getStack().getName().copy();
        if(label.getSiblings().isEmpty()) {
            label = label.copy().setStyle(Style.EMPTY.withColor(Okyware.getInstance().getThemeManager().getCurrentTheme().getWhite().getRGB()));
        }
        if (!label.getString().isEmpty() && label.getString().charAt(label.getString().length() - 1) == ' ') {
            label = TextUtil.replaceLastChar(label, "");

        }

        if (ent.getStack().getCount() > 1) {
            label = label.copy().append(Text.of(" x" + ent.getStack().getCount()).copy().setStyle(Style.EMPTY.withColor(Okyware.getInstance().getThemeManager().getCurrentTheme().getColor().getRGB())));
            ;
        }


        Theme theme = Okyware.getInstance().getThemeManager().getCurrentTheme();


        Font font = Fonts.MEDIUM.getFont(10 * scale.getCurrent());

        float padX = 8f * scale.getCurrent();
        float padY = 12f * scale.getCurrent();
        float textW = font.width(label) * scale.getCurrent();
        float rectW = textW + padX * 2 + 16 * 0.7f * scale.getCurrent() + padX;
        float textH = 10f * scale.getCurrent();


        float boxMinX = (float) screenBB.x;
        float boxMaxX = (float) screenBB.z;
        float boxMinY = (float) screenBB.y;

        float posX = (boxMinX + (boxMaxX - boxMinX) / 2f) - (rectW / 2f);
        float posY = boxMinY - 13f;

        float rectX = posX - padX;
        float rectY = posY;

        float rectH = padY;


        context.pushMatrix();
        context.getMatrices().translate(rectX + rectW / 2f, rectY + 6.5f, 0);
        context.getMatrices().scale(0.9f * scale.getCurrent(), 0.9f * scale.getCurrent(), 1f);
        context.getMatrices().translate(-(rectX + rectW / 2f), -(rectY + 6.5f), 0);


        DrawUtil.drawBlur(
                context.getMatrices(),
                rectX, rectY,
                rectW, rectH,
                20f,
                BorderRadius.all(2f),
                ColorRGBA.WHITE
        );

        ColorRGBA rectColor = new ColorRGBA(0, 0, 0, 120);
        context.drawRoundedRect(rectX, rectY, rectW, rectH, BorderRadius.all(2f), rectColor);
        DrawUtil.drawRoundedCorner(
                context.getMatrices(),
                rectX, rectY,
                rectW, rectH,
                0.1f, 9f,
                theme.getColor(),
                BorderRadius.all(2f)
        );


        context.pushMatrix();
        context.getMatrices().translate(posX + 16 * 0.7f * scale.getCurrent() + 8 * scale.getCurrent(), rectY + 2f * scale.getCurrent(), 0);
        context.drawText(font, label, 0, 0);
        context.popMatrix();
        float itemX = rectX + padX;
        float itemY = rectY;
        context.pushMatrix();
        context.getMatrices().translate(itemX, itemY, 0);
        context.getMatrices().scale(0.7f * scale.getCurrent(), 0.7f * scale.getCurrent(), 1);
        DiffuseLighting.disableGuiDepthLighting();

        context.drawItem(ent.getStack(), 0, 0);

        context.popMatrix();
        context.popMatrix();
    }

    private void renderEntityBox(CustomDrawContext context, Entity entity, float tickDelta) {
        if (entity == mc.player && mc.options.getPerspective().isFirstPerson()) return;
        Vector4d vec4d = ProjectionUtil.getVector4D(entity);
        if (ProjectionUtil.canSee(vec4d)) return;
        drawFlatBox((entity instanceof PlayerEntity player && Okyware.getInstance().getFriendManager().isFriend(player.getGameProfile().getName())), vec4d);

    }

    private void drawFlatBox(boolean friend, Vector4d vec) {
        int clientColor = !friend 
                ? Okyware.getInstance().getThemeManager().getCurrentTheme().getColor().getRGB() 
                : Okyware.getInstance().getThemeManager().getCurrentTheme().getFriendColor().getRGB();

        float posX = (float) vec.x;
        float posY = (float) vec.y;
        float endPosX = (float) vec.z;
        float endPosY = (float) vec.w;
        float thickness = 1f * scale.getCurrent();

        Render2DUtil.drawQuad(posX - thickness, posY - thickness, (endPosX - posX) + thickness * 2, thickness, clientColor);
        Render2DUtil.drawQuad(posX - thickness, endPosY, (endPosX - posX) + thickness * 2, thickness, clientColor);
        Render2DUtil.drawQuad(posX - thickness, posY, thickness, (endPosY - posY), clientColor);
        Render2DUtil.drawQuad(endPosX, posY, thickness, (endPosY - posY), clientColor);
    }

    private float getPlayerHeight(PlayerEntity player) {
        return (float) player.getBoundingBox().getLengthY() + 0.2f;
    }

    private double interpolate(double prev, double current, float delta) {
        return prev + (current - prev) * delta;
    }


    private Vec3d[] getPoints(Entity entity, float tickDelta) {
        double x = entity.prevX + (entity.getX() - entity.prevX) * tickDelta;
        double y = entity.prevY + (entity.getY() - entity.prevY) * tickDelta;
        double z = entity.prevZ + (entity.getZ() - entity.prevZ) * tickDelta;

        Box box = entity.getBoundingBox();
        Box shifted = new Box(
                box.minX - entity.getX() + x - 0.05,
                box.minY - entity.getY() + y,
                box.minZ - entity.getZ() + z - 0.05,
                box.maxX - entity.getX() + x + 0.05,
                box.maxY - entity.getY() + y + 0.15,
                box.maxZ - entity.getZ() + z + 0.05
        );

        return new Vec3d[]{
                new Vec3d(shifted.minX, shifted.minY, shifted.minZ),
                new Vec3d(shifted.minX, shifted.maxY, shifted.minZ),
                new Vec3d(shifted.maxX, shifted.minY, shifted.minZ),
                new Vec3d(shifted.maxX, shifted.maxY, shifted.minZ),
                new Vec3d(shifted.minX, shifted.minY, shifted.maxZ),
                new Vec3d(shifted.minX, shifted.maxY, shifted.maxZ),
                new Vec3d(shifted.maxX, shifted.minY, shifted.maxZ),
                new Vec3d(shifted.maxX, shifted.maxY, shifted.maxZ)
        };
    }

    private ColorRGBA getHealthColorRGBA(float health) {
        if (health <= 7) return new ColorRGBA(255, 0, 0, 255);
        if (health <= 15) return new ColorRGBA(255, 255, 0, 255);
        return new ColorRGBA(0, 255, 0, 255);

    }


}

