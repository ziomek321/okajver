package okyware.wtf.client.modules.impl.combat;

import com.darkmagician6.eventapi.EventTarget;
import okyware.wtf.base.events.impl.player.EventUpdate;
import okyware.wtf.client.modules.api.Category;
import okyware.wtf.client.modules.api.Module;
import okyware.wtf.client.modules.api.ModuleAnnotation;
import okyware.wtf.client.modules.api.setting.impl.NumberSetting;
import net.minecraft.item.Items;
import net.minecraft.util.Hand;

@ModuleAnnotation(name = "AutoSoup", category = Category.COMBAT, description = "Automatically eats mushroom soup")
public class AutoSoup extends Module {
    public static final AutoSoup INSTANCE = new AutoSoup();

    private final NumberSetting health = new NumberSetting("Health", 15.0f, 1.0f, 20.0f, 0.5f);

    private AutoSoup() {}

    @EventTarget
    public void onUpdate(EventUpdate event) {
        if (mc.player == null) return;

        if (mc.player.getHealth() <= health.getCurrent()) {
            int soupSlot = findSoup();
            if (soupSlot != -1) {
                int oldSlot = mc.player.getInventory().selectedSlot;
                mc.player.getInventory().selectedSlot = soupSlot;
                mc.interactionManager.interactItem(mc.player, Hand.MAIN_HAND);
                mc.player.getInventory().selectedSlot = oldSlot;
            }
        }
    }

    private int findSoup() {
        for (int i = 0; i < 9; i++) {
            if (mc.player.getInventory().getStack(i).getItem() == Items.MUSHROOM_STEW) {
                return i;
            }
        }
        return -1;
    }
}
