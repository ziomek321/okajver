package okyware.wtf.client.modules.impl.combat;

import com.darkmagician6.eventapi.EventTarget;
import okyware.wtf.base.events.impl.player.EventUpdate;
import okyware.wtf.client.modules.api.Category;
import okyware.wtf.client.modules.api.Module;
import okyware.wtf.client.modules.api.ModuleAnnotation;
import okyware.wtf.client.modules.api.setting.impl.ModeSetting;
import net.minecraft.item.SwordItem;
import net.minecraft.util.Hand;

@ModuleAnnotation(name = "BlockHit", category = Category.COMBAT, description = "Simulates the legacy blocking animation when attacking.")
public final class BlockHit extends Module {
    public static final BlockHit INSTANCE = new BlockHit();

    private final ModeSetting mode = new ModeSetting("Mode", "Visual", "Packet");

    private BlockHit() {}

    @EventTarget
    public void onUpdate(EventUpdate event) {
        if (mc.player == null) return;
        
        
        
    }
    
    public boolean shouldBlock() {
        return this.isEnabled() && mc.player != null && mc.player.getMainHandStack().getItem() instanceof SwordItem;
    }
}
