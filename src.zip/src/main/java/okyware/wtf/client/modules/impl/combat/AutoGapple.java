package okyware.wtf.client.modules.impl.combat;

import com.darkmagician6.eventapi.EventTarget;
import okyware.wtf.base.events.impl.player.EventUpdate;
import okyware.wtf.client.modules.api.Category;
import okyware.wtf.client.modules.api.Module;
import okyware.wtf.client.modules.api.ModuleAnnotation;
import okyware.wtf.client.modules.api.setting.impl.ModeSetting;
import okyware.wtf.client.modules.api.setting.impl.NumberSetting;
import okyware.wtf.utility.game.player.PlayerInventoryUtil;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.screen.slot.Slot;
import net.minecraft.util.Hand;

@ModuleAnnotation(name = "AutoGapple", category = Category.COMBAT, description = "Automatically eats golden apples when health is low.")
public final class AutoGapple extends Module {
    public static final AutoGapple INSTANCE = new AutoGapple();

    private final ModeSetting mode = new ModeSetting("Mode");
    private final ModeSetting.Value modeGrim = new ModeSetting.Value(mode, "Grim").select();
    private final ModeSetting.Value modeNormal = new ModeSetting.Value(mode, "Normal");

    private final NumberSetting health = new NumberSetting("Health", 15, 1, 20, 1);

    private boolean eating;

    private AutoGapple() {
    }

    @Override
    public void onDisable() {
        stopEating();
        super.onDisable();
    }

    @EventTarget
    public void onUpdate(EventUpdate event) {
        if (mc.player == null) return;

        float hp = mc.player.getHealth() + mc.player.getAbsorptionAmount();
        boolean shouldEat = hp <= health.getCurrent();

        if (shouldEat) {
            ItemStack offhand = mc.player.getOffHandStack();
            if (isGapple(offhand)) {
                startEating();
            } else {
                Slot gappleSlot = PlayerInventoryUtil.getSlot(Items.GOLDEN_APPLE);
                if (gappleSlot == null) gappleSlot = PlayerInventoryUtil.getSlot(Items.ENCHANTED_GOLDEN_APPLE);

                if (gappleSlot != null) {
                    PlayerInventoryUtil.swapHand(gappleSlot, Hand.OFF_HAND, true);
                    startEating();
                }
            }
        } else {
            stopEating();
        }
    }

    private void startEating() {
        if (mc.player.getItemCooldownManager().isCoolingDown(Items.GOLDEN_APPLE.getDefaultStack())) return;
        
        eating = true;
        mc.options.useKey.setPressed(true);
    }

    private void stopEating() {
        if (eating) {
            mc.options.useKey.setPressed(false);
            eating = false;
        }
    }

    private boolean isGapple(ItemStack stack) {
        return stack.isOf(Items.GOLDEN_APPLE) || stack.isOf(Items.ENCHANTED_GOLDEN_APPLE);
    }
}
