package okyware.wtf.client.modules.impl.render;

import com.darkmagician6.eventapi.EventTarget;
import lombok.Getter;
import okyware.wtf.base.events.impl.entity.EventEntityColor;
import okyware.wtf.client.modules.api.Category;
import okyware.wtf.client.modules.api.Module;
import okyware.wtf.client.modules.api.ModuleAnnotation;
import okyware.wtf.client.modules.api.setting.impl.ColorSetting;
import okyware.wtf.utility.render.display.base.color.ColorRGBA;

@Getter
@ModuleAnnotation(name = "Anti Invisible", category = Category.RENDER, description = "Reveals invisible players")
public final class AntiInvisible extends Module {
    public static final AntiInvisible INSTANCE = new AntiInvisible();

    private AntiInvisible() {
    }

    private final ColorSetting colorSetting = new ColorSetting("Color", ColorRGBA.WHITE.mulAlpha(0.5f));

    @EventTarget
    public void onEntityColor(EventEntityColor e) {
        if (e.isInvisible()) {
            e.setColor(colorSetting.getColor().getRGB());
            e.cancel();
        }
    }
}