package okyware.wtf.client.modules.impl.combat;

import com.darkmagician6.eventapi.EventTarget;
import okyware.wtf.base.events.impl.player.EventUpdate;
import okyware.wtf.client.modules.api.Category;
import okyware.wtf.client.modules.api.Module;
import okyware.wtf.client.modules.api.ModuleAnnotation;
import okyware.wtf.client.modules.api.setting.impl.BooleanSetting;
import okyware.wtf.client.modules.api.setting.impl.NumberSetting;
import okyware.wtf.utility.game.player.rotation.Rotation;
import okyware.wtf.utility.game.player.rotation.RotationUtil;
import net.minecraft.entity.LivingEntity;
import net.minecraft.util.math.MathHelper;

import java.util.Random;

@ModuleAnnotation(name = "AimAssist", category = Category.COMBAT, description = "Smoothly assists your aim for a more legit look.")
public final class AimAssist extends Module {
    public static final AimAssist INSTANCE = new AimAssist();

    private final NumberSetting range = new NumberSetting("Range", 4, 1, 6, 0.1f);
    private final NumberSetting fov = new NumberSetting("FOV", 90, 10, 360, 5);
    private final NumberSetting speed = new NumberSetting("Speed", 5, 1, 100, 1);
    private final BooleanSetting onlyClicking = new BooleanSetting("Only Clicking", true);
    private final BooleanSetting randomCenter = new BooleanSetting("Randomize", true);

    private final Random random = new Random();

    private AimAssist() {}

    @EventTarget
    public void onUpdate(EventUpdate event) {
        if (mc.player == null || mc.world == null) return;
        if (onlyClicking.isEnabled() && !mc.options.attackKey.isPressed()) return;

        LivingEntity target = getTarget();
        if (target != null) {
            double xOff = 0, yOff = 0, zOff = 0;
            if (randomCenter.isEnabled()) {
                xOff = (random.nextDouble() - 0.5) * 0.2;
                yOff = (random.nextDouble() - 0.5) * 0.2;
                zOff = (random.nextDouble() - 0.5) * 0.2;
            }

            Rotation rotations = RotationUtil.fromVec3d(target.getBoundingBox().getCenter().add(xOff, yOff, zOff).subtract(mc.player.getEyePos()));
            
            float speedVal = (float) (speed.getCurrent() / 200.0f); 
            
            float yaw = MathHelper.lerpAngleDegrees(speedVal, mc.player.getYaw(), rotations.getYaw());
            float pitch = MathHelper.lerpAngleDegrees(speedVal, mc.player.getPitch(), rotations.getPitch());
            
            mc.player.setYaw(yaw);
            mc.player.setPitch(pitch);
        }
    }

    private LivingEntity getTarget() {
        return mc.world.getEntitiesByClass(LivingEntity.class, mc.player.getBoundingBox().expand(range.getCurrent()), 
                entity -> entity != mc.player && entity.isAlive() && isInFov(entity))
                .stream().min((e1, e2) -> Float.compare(mc.player.distanceTo(e1), mc.player.distanceTo(e2)))
                .orElse(null);
    }

    private boolean isInFov(LivingEntity entity) {
        float[] rotations = getRotations(entity);
        float yawDiff = getAngleDifference(mc.player.getYaw(), rotations[0]);
        float pitchDiff = getAngleDifference(mc.player.getPitch(), rotations[1]);
        return Math.sqrt(yawDiff * yawDiff + pitchDiff * pitchDiff) <= fov.getCurrent();
    }

    private float[] getRotations(LivingEntity entity) {
        double x = entity.getX() - mc.player.getX();
        double y = entity.getY() + entity.getStandingEyeHeight() - (mc.player.getY() + mc.player.getStandingEyeHeight());
        double z = entity.getZ() - mc.player.getZ();
        double dist = MathHelper.sqrt((float) (x * x + z * z));
        float yaw = (float) (MathHelper.atan2(z, x) * 180.0 / Math.PI) - 90.0f;
        float pitch = (float) (-(MathHelper.atan2(y, dist) * 180.0 / Math.PI));
        return new float[]{yaw, pitch};
    }

    private float getAngleDifference(float a, float b) {
        return ((((a - b) % 360.0f) + 540.0f) % 360.0f) - 180.0f;
    }
}
