package okyware.wtf.client.modules.impl.combat;

import com.darkmagician6.eventapi.EventTarget;
import okyware.wtf.base.events.impl.player.EventUpdate;
import okyware.wtf.client.modules.api.Category;
import okyware.wtf.client.modules.api.Module;
import okyware.wtf.client.modules.api.ModuleAnnotation;
import okyware.wtf.client.modules.api.setting.impl.BooleanSetting;
import okyware.wtf.client.modules.api.setting.impl.NumberSetting;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.util.hit.HitResult;

@ModuleAnnotation(name = "TriggerBot", category = Category.COMBAT, description = "Attacks entities automatically when your crosshair passes over them")
public final class TriggerBot extends Module {
    public static final TriggerBot INSTANCE = new TriggerBot();

    private final NumberSetting cooldown = new NumberSetting("Cooldown", 0.9f, 0.5f, 1.0f, 0.05f, "Min attack cooldown progress");
    private final NumberSetting range = new NumberSetting("Range", 3.0f, 1.0f, 6.0f, 0.1f);
    private final BooleanSetting onlyPlayers = new BooleanSetting("Only Players", true);
    private final BooleanSetting smartDelay = new BooleanSetting("Smart Delay", "Wait for full cooldown like legit", true);
    private final NumberSetting randomDelay = new NumberSetting("Random Delay", 2, 0, 5, 1, "Extra random ticks before hit");

    private int waitTicks = 0;

    private TriggerBot() {}

    @EventTarget
    public void onUpdate(EventUpdate event) {
        if (mc.player == null || mc.interactionManager == null) return;

        HitResult hit = mc.crosshairTarget;
        if (!(hit instanceof EntityHitResult entityHit)) { waitTicks = 0; return; }

        Entity entity = entityHit.getEntity();
        if (!(entity instanceof LivingEntity living) || !living.isAlive()) return;
        if (onlyPlayers.isEnabled() && !(entity instanceof PlayerEntity)) return;
        if (mc.player.distanceTo(entity) > range.getCurrent()) return;

        if (smartDelay.isEnabled() && mc.player.getAttackCooldownProgress(0.5f) < cooldown.getCurrent()) return;

        if (waitTicks > 0) { waitTicks--; return; }

        mc.interactionManager.attackEntity(mc.player, entity);
        mc.player.swingHand(Hand.MAIN_HAND);

        if (randomDelay.getCurrent() > 0) {
            waitTicks = (int) (Math.random() * randomDelay.getCurrent());
        }
    }
}
