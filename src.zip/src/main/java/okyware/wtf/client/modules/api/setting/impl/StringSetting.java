package okyware.wtf.client.modules.api.setting.impl;

import com.google.gson.JsonObject;
import lombok.Getter;
import lombok.Setter;
import okyware.wtf.client.modules.api.setting.Setting;

import java.util.function.Supplier;

@Getter
@Setter
public class StringSetting extends Setting {

    private String value;
    private final String defaultValue;
    private final int maxLength;

    public StringSetting(String name, String defaultValue) {
        this(name, defaultValue, 32);
    }

    public StringSetting(String name, String defaultValue, int maxLength) {
        super(name);
        this.defaultValue = defaultValue;
        this.value = defaultValue;
        this.maxLength = maxLength;
    }

    public StringSetting(String name, String defaultValue, int maxLength, Supplier<Boolean> visible) {
        this(name, defaultValue, maxLength);
        setVisible(visible);
    }

    @Override
    public void safe(JsonObject propertiesObject) {
        propertiesObject.addProperty(String.valueOf(name), value);
    }

    @Override
    public void load(JsonObject propertiesObject) {
        if (propertiesObject.has(String.valueOf(name))) {
            this.value = propertiesObject.get(String.valueOf(name)).getAsString();
        }
    }
}
