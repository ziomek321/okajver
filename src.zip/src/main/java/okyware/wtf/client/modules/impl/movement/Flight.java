package okyware.wtf.client.modules.impl.movement;

import com.darkmagician6.eventapi.EventTarget;
import net.minecraft.util.math.Vec3d;
import okyware.wtf.base.events.impl.player.EventUpdate;
import okyware.wtf.client.modules.api.Category;
import okyware.wtf.client.modules.api.Module;
import okyware.wtf.client.modules.api.ModuleAnnotation;
import okyware.wtf.client.modules.api.setting.impl.ModeSetting;
import okyware.wtf.client.modules.api.setting.impl.NumberSetting;
import okyware.wtf.utility.game.player.MovingUtil;

@ModuleAnnotation(name = "Flight", category = Category.MOVEMENT, description = "Allows you to fly")
public final class Flight extends Module {
    public static final Flight INSTANCE = new Flight();

    private final ModeSetting mode = new ModeSetting("Mode", "Motion", "Vulcan", "Polar", "Grim", "Matrix", "Grim Glide");
    private final NumberSetting speed = new NumberSetting("Speed", 1.0f, 0.1f, 5.0f, 0.1f);

    private int ticks = 0;

    private Flight() {
    }

    @Override
    public void onEnable() {
        ticks = 0;
        super.onEnable();
    }

    @EventTarget
    public void onUpdate(EventUpdate event) {
        float s = speed.getCurrent();
        ticks++;

        if (mode.is("Motion")) {
            mc.player.getAbilities().flying = false;
            mc.player.setVelocity(0, 0, 0);
            
            double y = 0;
            if (mc.options.jumpKey.isPressed()) y = s;
            if (mc.options.sneakKey.isPressed()) y = -s;

            MovingUtil.setVelocity(s, y);
        } else if (mode.is("Vulcan")) {
            if (mc.player.age % 2 == 0) {
                mc.player.setVelocity(mc.player.getVelocity().x, 0.01, mc.player.getVelocity().z);
            } else {
                mc.player.setVelocity(mc.player.getVelocity().x, -0.01, mc.player.getVelocity().z);
            }
            MovingUtil.setVelocity(0.25);
        } else if (mode.is("Polar")) {
            mc.player.setVelocity(mc.player.getVelocity().x, 0, mc.player.getVelocity().z);
            if (mc.player.age % 3 == 0) {
                MovingUtil.setVelocity(0.35);
            } else {
                MovingUtil.setVelocity(0.2);
            }
        } else if (mode.is("Grim")) {
            mc.player.setSprinting(false);
            
            if (mc.player.getVelocity().getY() < 0) {
                if (mc.player.age % 2 == 0) {
                    mc.player.setVelocity(mc.player.getVelocity().x, -0.05, mc.player.getVelocity().z);
                }
                MovingUtil.setVelocity(0.12);
            }
        } else if (mode.is("Matrix")) {
            
            double yVel;
            int phase = ticks % 4;
            if (mc.options.jumpKey.isPressed()) {
                
                yVel = phase < 2 ? 0.0625 : -0.0001;
            } else if (mc.options.sneakKey.isPressed()) {
                
                yVel = phase < 2 ? -0.0625 : 0.0001;
            } else {
                
                yVel = phase < 2 ? 0.04 : -0.04;
            }
            mc.player.setVelocity(mc.player.getVelocity().x, yVel, mc.player.getVelocity().z);
            MovingUtil.setVelocity(Math.min(s, 0.34));
        }
    }

    @Override
    public void onDisable() {
        super.onDisable();
        if (mc.player != null) {
            mc.player.getAbilities().flying = false;
            mc.player.setVelocity(0, 0, 0);
        }
    }
}
