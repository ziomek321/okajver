package okyware.wtf.client.modules.impl.combat;

import com.darkmagician6.eventapi.EventTarget;
import net.minecraft.entity.LivingEntity;
import net.minecraft.item.Items;
import net.minecraft.network.packet.c2s.play.PlayerInteractBlockC2SPacket;
import net.minecraft.network.packet.c2s.play.UpdateSelectedSlotC2SPacket;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;
import okyware.wtf.base.events.impl.player.EventUpdate;
import okyware.wtf.client.modules.api.Category;
import okyware.wtf.client.modules.api.Module;
import okyware.wtf.client.modules.api.ModuleAnnotation;
import okyware.wtf.client.modules.api.setting.impl.NumberSetting;

import java.util.Comparator;

@ModuleAnnotation(name = "AutoWeb", category = Category.COMBAT, description = "Places webs at target's feet")
public final class AutoWeb extends Module {
    public static final AutoWeb INSTANCE = new AutoWeb();

    private final NumberSetting range = new NumberSetting("Range", 4, 1, 6, 0.1f);

    private AutoWeb() {}

    @EventTarget
    public void onUpdate(EventUpdate event) {
        if (mc.player == null || mc.world == null) return;

        int slot = findWeb();
        if (slot == -1) return;

        LivingEntity target = mc.world.getEntitiesByClass(LivingEntity.class,
                mc.player.getBoundingBox().expand(range.getCurrent()),
                e -> e != mc.player && e.isAlive() && !e.isSpectator())
                .stream().min(Comparator.comparingDouble(e -> mc.player.distanceTo(e)))
                .orElse(null);
        if (target == null) return;

        BlockPos pos = target.getBlockPos();
        if (!mc.world.getBlockState(pos).isReplaceable()) return;

        Direction side = getPlaceSide(pos);
        if (side == null) return;

        BlockPos neighbor = pos.offset(side);
        Direction opposite = side.getOpposite();

        int prev = mc.player.getInventory().selectedSlot;
        mc.getNetworkHandler().sendPacket(new UpdateSelectedSlotC2SPacket(slot));
        mc.player.getInventory().selectedSlot = slot;

        BlockHitResult hit = new BlockHitResult(Vec3d.ofCenter(neighbor).add(
                opposite.getOffsetX() * 0.5, opposite.getOffsetY() * 0.5, opposite.getOffsetZ() * 0.5),
                opposite, neighbor, false);
        mc.getNetworkHandler().sendPacket(new PlayerInteractBlockC2SPacket(Hand.MAIN_HAND, hit, 0));
        mc.player.swingHand(Hand.MAIN_HAND);

        mc.getNetworkHandler().sendPacket(new UpdateSelectedSlotC2SPacket(prev));
        mc.player.getInventory().selectedSlot = prev;
    }

    private Direction getPlaceSide(BlockPos pos) {
        for (Direction d : Direction.values()) {
            BlockPos n = pos.offset(d);
            if (!mc.world.getBlockState(n).isReplaceable() && mc.world.getBlockState(n).isSolidBlock(mc.world, n))
                return d;
        }
        return null;
    }

    private int findWeb() {
        for (int i = 0; i < 9; i++) {
            if (mc.player.getInventory().getStack(i).getItem() == Items.COBWEB) return i;
        }
        return -1;
    }
}
