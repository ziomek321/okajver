package okyware.wtf.client.modules.impl.render;

import com.darkmagician6.eventapi.EventTarget;
import net.minecraft.entity.LivingEntity;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.Vec3d;
import okyware.wtf.Okyware;
import okyware.wtf.base.events.impl.player.EventAttack;
import okyware.wtf.base.events.impl.render.EventRender3D;
import okyware.wtf.client.modules.api.Category;
import okyware.wtf.client.modules.api.Module;
import okyware.wtf.client.modules.api.ModuleAnnotation;
import okyware.wtf.utility.math.Timer;
import okyware.wtf.utility.render.display.base.color.ColorRGBA;
import okyware.wtf.utility.render.level.Render3DUtil;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

@ModuleAnnotation(name = "HitBubbles", category = Category.RENDER, description = "Displays bubbles when you hit an entity.")
public final class HitBubbles extends Module {
    public static final HitBubbles INSTANCE = new HitBubbles();

    private final List<Bubble> bubbles = new ArrayList<>();
    private final Identifier bubbleTex = Identifier.of("okyware", "textures/eva/bubble.png");

    private HitBubbles() {
    }

    @Override
    public void onEnable() {
        bubbles.clear();
        super.onEnable();
    }

    @EventTarget
    public void onAttack(EventAttack event) {
        if (event.getAction() != EventAttack.Action.POST || event.getTarget() == null) return;
        if (!(event.getTarget() instanceof LivingEntity target)) return;

        Vec3d pos = target.getPos().add(0, target.getHeight() * 0.75, 0);
        bubbles.add(new Bubble(pos, Okyware.getInstance().getThemeManager().getClientColor(0)));
    }

    @EventTarget
    public void onRender3D(EventRender3D event) {
        if (bubbles.isEmpty()) return;

        Iterator<Bubble> it = bubbles.iterator();
        while (it.hasNext()) {
            Bubble b = it.next();
            if (b.timer.finished(1500)) {
                it.remove();
                continue;
            }

            float t = b.timer.getElapsedTime() / 1500f;
            float alpha = t < 0.2f ? t / 0.2f : (t > 0.8f ? 1f - (t - 0.8f) / 0.2f : 1f);
            float scale = t < 0.2f ? t / 0.2f : 1f;
            float yOffset = t * 0.5f;

            Render3DUtil.drawTexture(bubbleTex, b.pos.add(0, yOffset, 0), 0.5f * scale, b.color.mulAlpha(alpha).getRGB());
        }
    }


    private static class Bubble {
        final Vec3d pos;
        final Timer timer = new Timer();
        final ColorRGBA color;

        Bubble(Vec3d pos, ColorRGBA color) {
            this.pos = pos;
            this.color = color;
        }
    }
}
