package okyware.wtf.client.modules.impl.render;

import net.minecraft.client.option.Perspective;
import net.minecraft.util.hit.HitResult;
import com.darkmagician6.eventapi.EventTarget;
import okyware.wtf.base.events.impl.render.EventHudRender;
import okyware.wtf.client.modules.api.Category;
import okyware.wtf.client.modules.api.Module;
import okyware.wtf.client.modules.api.ModuleAnnotation;
import okyware.wtf.client.modules.api.setting.impl.BooleanSetting;
import okyware.wtf.client.modules.api.setting.impl.NumberSetting;
import okyware.wtf.utility.render.display.base.CustomDrawContext;
import okyware.wtf.utility.render.display.base.color.ColorRGBA;



@ModuleAnnotation(name = "Crosshair", category = Category.RENDER, description = "Replaces the default crosshair with a fully customizable dynamic indicator")
public final class Crosshair extends Module {
    public static final Crosshair INSTANCE = new Crosshair();
    
    private Crosshair() {
    }

    private final NumberSetting thickness = new NumberSetting("Thickness", 1.0f, 0.5f, 3.0f, 0.1f);
    private final NumberSetting length = new NumberSetting("Length", 3.0f, 1.0f, 8.0f, 0.5f);
    private final NumberSetting gap = new NumberSetting("Gap", 2.0f, 0.0f, 5.0f, 0.5f);
    private final BooleanSetting dynamicGap = new BooleanSetting("Dynamic gap", false);

    private final BooleanSetting useEntityColor = new BooleanSetting("Hover color", false);


    private final ColorRGBA entityColor = new ColorRGBA(255, 0, 0, 255);


    @EventTarget
    public void onRender(EventHudRender event) {
        if (mc.player == null || mc.world == null) {
            return;
        }

        if (mc.options.getPerspective() != Perspective.FIRST_PERSON) {
            return;
        }

        
        if (mc.options.hudHidden) {
            return;
        }

        CustomDrawContext ctx = event.getContext();
        float x = mc.getWindow().getScaledWidth() / 2f;
        float y = mc.getWindow().getScaledHeight() / 2f;

        float currentGap = gap.getCurrent();
        if (dynamicGap.isEnabled()) {
            float cooldown = 1 - mc.player.getAttackCooldownProgress(0);
            currentGap += 8 * cooldown;
        }

        float currentThickness = thickness.getCurrent();
        float currentLength = length.getCurrent();

        ColorRGBA color = useEntityColor.isEnabled() && mc.crosshairTarget != null && mc.crosshairTarget.getType() == HitResult.Type.ENTITY 
            ? entityColor 
            : new ColorRGBA(255, 255, 255, 255);
            
        
        drawLine(ctx, x - currentThickness / 2, y - currentGap - currentLength,
                currentThickness, currentLength, color);

        
        drawLine(ctx, x - currentThickness / 2, y + currentGap,
                currentThickness, currentLength, color);

        
        drawLine(ctx, x - currentGap - currentLength, y - currentThickness / 2,
                currentLength, currentThickness, color);

        
        drawLine(ctx, x + currentGap, y - currentThickness / 2,
                currentLength, currentThickness, color);
    }

    private void drawLine(CustomDrawContext ctx, float x, float y, float width, float height, ColorRGBA color) {
        ctx.drawRect(x, y, width, height, color);
    }
}
