package okyware.wtf.client.modules.impl.player;

import com.darkmagician6.eventapi.EventTarget;
import okyware.wtf.base.events.impl.player.EventUpdate;
import okyware.wtf.client.modules.api.Category;
import okyware.wtf.client.modules.api.Module;
import okyware.wtf.client.modules.api.ModuleAnnotation;
import okyware.wtf.client.modules.api.setting.impl.BooleanSetting;
import okyware.wtf.client.modules.api.setting.impl.NumberSetting;
import net.minecraft.client.gui.screen.ingame.GenericContainerScreen;
import net.minecraft.screen.GenericContainerScreenHandler;
import net.minecraft.screen.slot.Slot;
import net.minecraft.screen.slot.SlotActionType;
import net.minecraft.item.ItemStack;

@ModuleAnnotation(name = "ChestStealer", category = Category.PLAYER, description = "Rapidly transfers all items from opened containers into your inventory")
public final class ChestStealer extends Module {
    public static final ChestStealer INSTANCE = new ChestStealer();

    private final NumberSetting delay = new NumberSetting("Delay", 50, 0, 500, 10, "Delay between takes in ms");
    private final BooleanSetting autoClose = new BooleanSetting("Auto Close", true);

    private long lastTake = 0;

    private ChestStealer() {}

    @EventTarget
    public void onUpdate(EventUpdate event) {
        if (mc.player == null || !(mc.currentScreen instanceof GenericContainerScreen screen)) return;

        GenericContainerScreenHandler handler = screen.getScreenHandler();
        long now = System.currentTimeMillis();
        if (now - lastTake < delay.getCurrent()) return;

        int containerSlots = handler.getRows() * 9;
        boolean empty = true;

        for (int i = 0; i < containerSlots; i++) {
            Slot slot = handler.getSlot(i);
            ItemStack stack = slot.getStack();
            if (stack.isEmpty()) continue;
            empty = false;

            mc.interactionManager.clickSlot(handler.syncId, i, 0, SlotActionType.QUICK_MOVE, mc.player);
            lastTake = now;
            return;
        }

        if (empty && autoClose.isEnabled()) {
            mc.player.closeHandledScreen();
        }
    }
}
