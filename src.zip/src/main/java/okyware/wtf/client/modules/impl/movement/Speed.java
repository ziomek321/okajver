package okyware.wtf.client.modules.impl.movement;

import com.darkmagician6.eventapi.EventTarget;
import okyware.wtf.base.events.impl.player.EventUpdate;
import okyware.wtf.client.modules.api.Category;
import okyware.wtf.client.modules.api.Module;
import okyware.wtf.client.modules.api.ModuleAnnotation;
import okyware.wtf.client.modules.api.setting.impl.BooleanSetting;
import okyware.wtf.client.modules.api.setting.impl.ModeSetting;
import okyware.wtf.client.modules.api.setting.impl.NumberSetting;
import okyware.wtf.client.modules.impl.combat.Aura;
import okyware.wtf.utility.game.player.MovingUtil;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.vehicle.BoatEntity;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;

import okyware.wtf.utility.game.player.PlayerInventoryUtil;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

@ModuleAnnotation(name = "Speed", category = Category.MOVEMENT, description = "Moves you faster than vanilla using several different bypass methods.")
public class Speed extends Module {

    public static final Speed INSTANCE = new Speed();

    public final ModeSetting mode = new ModeSetting("Mode", "Collision", "GrimSpeed", "Grim", "Strafe", "Spooky Elytra", "Vanilla", "Matrix", "Polar");

    public final NumberSetting vanillaSpeed = new NumberSetting("Vanilla Speed", 1.0f, 0.1f, 5.0f, 0.1f, () -> mode.is("Vanilla"));
    public final NumberSetting polarSpeed = new NumberSetting("Polar Speed", 1.6f, 0.1f, 5.0f, 0.1f, () -> mode.is("Polar"));

    public final BooleanSetting onlyPlayers = new BooleanSetting("Only Players", true, () -> mode.is("Collision"));
    public final BooleanSetting requireMoving = new BooleanSetting("Require Moving", true, () -> mode.is("Collision"));

    public final BooleanSetting pauseInLiquids = new BooleanSetting("Pause in Liquid", false, () -> mode.is("GrimSpeed"));
    public final BooleanSetting pauseWhileSneaking = new BooleanSetting("Pause While Sneaking", false, () -> mode.is("GrimSpeed"));
    public final NumberSetting speedFactor = new NumberSetting("Speed Factor", 8.0f, 1.0f, 15.0f, 0.1f, () -> mode.is("GrimSpeed"));
    public final NumberSetting distance = new NumberSetting("Distance", 3.0f, 0.5f, 5.0f, 0.1f, () -> mode.is("GrimSpeed"));
    public final BooleanSetting bypassDistance = new BooleanSetting("Bypass distance", "Increases distance if target's back is to you", false, () -> mode.is("GrimSpeed"));
    public final NumberSetting bypassDistanceValue = new NumberSetting("Bypass distance value", 4.0f, 1.0f, 6.0f, 0.1f, () -> mode.is("GrimSpeed") && bypassDistance.isEnabled());
    public final NumberSetting bypassAngle = new NumberSetting("Bypass angle", 120, 10, 180, 5, () -> mode.is("GrimSpeed") && bypassDistance.isEnabled());
    public final BooleanSetting waterDistance = new BooleanSetting("Water distance", false, () -> mode.is("GrimSpeed"));
    public final NumberSetting waterDistanceValue = new NumberSetting("Distance (water)", 2.0f, 0.5f, 6.0f, 0.1f, () -> mode.is("GrimSpeed") && waterDistance.isEnabled());
    public final BooleanSetting elytraDistance = new BooleanSetting("Elytra distance", false, () -> mode.is("GrimSpeed"));
    public final NumberSetting elytraDistanceValue = new NumberSetting("Distance (elytra)", 5.0f, 0.5f, 10.0f, 0.1f, () -> mode.is("GrimSpeed") && elytraDistance.isEnabled());
    public final BooleanSetting predictMovement = new BooleanSetting("Predict movement", true, () -> mode.is("GrimSpeed"));
    public final NumberSetting predictionFactor = new NumberSetting("Prediction factor", 2.0f, 1.0f, 5.0f, 0.1f, () -> mode.is("GrimSpeed") && predictMovement.isEnabled());
    public final BooleanSetting smoothMovement = new BooleanSetting("Smooth movement", true, () -> mode.is("GrimSpeed"));

    public final BooleanSetting backtrack = new BooleanSetting("Backtrack", true, () -> mode.is("GrimSpeed"));
    public final NumberSetting backtrackTicks = new NumberSetting("Backtrack ticks", 3.0f, 1.0f, 10.0f, 0.5f, () -> mode.is("GrimSpeed") && backtrack.isEnabled());
    public final NumberSetting backtrackDistance = new NumberSetting("Max Backtrack Dist", 6.0f, 3.0f, 15.0f, 0.5f, () -> mode.is("GrimSpeed") && backtrack.isEnabled());

    public final NumberSetting movementThreshold = new NumberSetting("Movement Threshold", 0.1f, 0.01f, 0.5f, 0.01f, () -> mode.is("GrimSpeed"));
    public final NumberSetting staticBoostRange = new NumberSetting("Static Boost Range", 0.45f, 0.1f, 1.0f, 0.05f, () -> mode.is("GrimSpeed"));
    public final NumberSetting staticBoostForce = new NumberSetting("Static Boost Force", 0.085f, 0.01f, 0.2f, 0.005f, () -> mode.is("GrimSpeed"));
    public final BooleanSetting grimGlide = new BooleanSetting("Grim Glide", false, () -> mode.is("GrimSpeed"));
    public final BooleanSetting blockBoost = new BooleanSetting("Block Boost", false, () -> mode.is("GrimSpeed"));
    public final BooleanSetting entityBoost = new BooleanSetting("Entity Boost", false, () -> mode.is("GrimSpeed"));
    public final BooleanSetting disablePush = new BooleanSetting("Disable Player Push", true, () -> mode.is("GrimSpeed"));

    public final NumberSetting strafeSpeed = new NumberSetting("Strafe Speed", 0.28f, 0.1f, 1.0f, 0.01f, () -> mode.is("Strafe"));
    public final BooleanSetting strafeJump = new BooleanSetting("Strafe Jump", true, () -> mode.is("Strafe"));

    public final BooleanSetting grimTimer = new BooleanSetting("Timer", true, () -> mode.is("Grim"));
    public final NumberSetting grimTimerSpeed = new NumberSetting("Timer Speed", 1.088f, 1.0f, 1.2f, 0.001f, () -> mode.is("Grim") && grimTimer.isEnabled());

    private Speed() {
    }

    private final double expandBox = 0.45;
    private final double searchRange = 3.2;
    private final Random random = new Random();

    private Entity targetEntity = null;
    private Vec3d lastTargetPos = null;
    private Vec3d predictedPos = null;
    private double[] lastMotion = new double[]{0.0, 0.0};

    private int grimStage = 1;
    private int grimTicks = 0;
    private double grimBaseSpeed = 0.2873;
    private float grimPrevForward = 0;

    private final List<Vec3d> positionHistory = new ArrayList<>();
    private final List<Long> timeHistory = new ArrayList<>();
    private Vec3d backtrackPos = null;

    private Vec3d prevTargetPos = null;
    private double targetMovementSpeed = 0.0;
    private boolean isTargetStatic = false;

    @EventTarget
    public void onUpdate(EventUpdate event) {
        if (mc.player == null || mc.world == null) return;

        if (mode.is("Collision")) {
            handleCollisionMode();
        } else if (mode.is("GrimSpeed")) {
            handleGrimUpdate();
            handleGrimMotion();
        } else if (mode.is("Grim")) {
            handleGrimBhop();
        } else if (mode.is("Strafe")) {
            handleStrafeMode();
        } else if (mode.is("Spooky Elytra")) {
            handleSpookyElytra();
        } else if (mode.is("Vanilla")) {
            handleVanilla();
        } else if (mode.is("Matrix")) {
            handleMatrixMode();
        } else if (mode.is("Polar")) {
            handlePolarMode();
        }
    }

    private void handleGrimBhop() {
        if (mc.player.isGliding() || mc.player.isInLava() || mc.player.isTouchingWater()) return;
        if (mc.player.getAbilities().flying) return;
        if (!MovingUtil.hasPlayerMovement()) {
            grimBaseSpeed = 0.2873;
            return;
        }

        double baseMoveSpeed = 0.2873;
        if (mc.player.hasStatusEffect(net.minecraft.entity.effect.StatusEffects.SPEED)) {
            int amp = mc.player.getStatusEffect(net.minecraft.entity.effect.StatusEffects.SPEED).getAmplifier();
            baseMoveSpeed *= 1 + 0.2 * (amp + 1);
        }
        if (mc.player.hasStatusEffect(net.minecraft.entity.effect.StatusEffects.SLOWNESS)) {
            int amp = mc.player.getStatusEffect(net.minecraft.entity.effect.StatusEffects.SLOWNESS).getAmplifier();
            baseMoveSpeed /= 1 + 0.2 * (amp + 1);
        }

        float currentSpeed = (float) Math.hypot(mc.player.getVelocity().x, mc.player.getVelocity().z);

        if (grimStage == 1 && mc.player.isOnGround() && !mc.player.horizontalCollision) {
            mc.player.jump();
            grimBaseSpeed = currentSpeed * 2.149;
            grimStage = 2;
        } else if (grimStage == 2) {
            grimBaseSpeed = currentSpeed - (0.66 * (currentSpeed - baseMoveSpeed));
            grimStage = 3;
        } else {
            if (mc.player.verticalCollision || mc.player.isOnGround()) {
                grimStage = 1;
            }
            grimBaseSpeed = currentSpeed - currentSpeed / 159.0;
        }

        grimBaseSpeed = Math.max(grimBaseSpeed, baseMoveSpeed);

        
        double ncpSpeed = mc.player.input.movementForward < 1 ? 0.465 : 0.576;
        double ncpBypassSpeed = mc.player.input.movementForward < 1 ? 0.44 : 0.57;

        if (mc.player.hasStatusEffect(net.minecraft.entity.effect.StatusEffects.SPEED)) {
            double amp = mc.player.getStatusEffect(net.minecraft.entity.effect.StatusEffects.SPEED).getAmplifier();
            ncpSpeed *= 1 + (0.2 * (amp + 1));
            ncpBypassSpeed *= 1 + (0.2 * (amp + 1));
        }

        grimBaseSpeed = Math.min(grimBaseSpeed, grimTicks > 25 ? ncpSpeed : ncpBypassSpeed);

        if (grimTicks++ > 50) grimTicks = 0;

        MovingUtil.setVelocity(grimBaseSpeed);
        grimPrevForward = mc.player.input.movementForward;

        if (grimTimer.isEnabled()) {
            
        }
    }

    private void handleMatrixMode() {
        if (mc.player == null || mc.player.isGliding() || mc.player.isInLava() || mc.player.isTouchingWater()) return;
        if (!MovingUtil.hasPlayerMovement()) return;

        if (mc.player.isOnGround()) {
            mc.player.jump();
            MovingUtil.setVelocity(0.48); 
        } else {
            
            double current = Math.hypot(mc.player.getVelocity().x, mc.player.getVelocity().z);
            if (current > 0.22) {
                
                MovingUtil.setVelocity(current * 0.98);
            } else {
                MovingUtil.setVelocity(0.22);
            }
        }
    }

    private void handleVanilla() {
        if (mc.player == null) return;
        if (!MovingUtil.hasPlayerMovement()) return;
        if (mc.player.isGliding() || mc.player.isInLava() || mc.player.isTouchingWater()) return;
        MovingUtil.setVelocity(vanillaSpeed.getCurrent());
    }

    private void handlePolarMode() {
        if (mc.player == null) return;
        if (!MovingUtil.hasPlayerMovement()) return;
        if (mc.player.isGliding() || mc.player.isInLava() || mc.player.isTouchingWater()) return;
        if (mc.player.isSneaking() || mc.player.hurtTime > 0) return;

        double baseSpeed = 0.2873;
        if (mc.player.hasStatusEffect(net.minecraft.entity.effect.StatusEffects.SPEED)) {
            int amp = mc.player.getStatusEffect(net.minecraft.entity.effect.StatusEffects.SPEED).getAmplifier();
            baseSpeed *= 1 + 0.2 * (amp + 1);
        }
        if (mc.player.hasStatusEffect(net.minecraft.entity.effect.StatusEffects.SLOWNESS)) {
            int amp = mc.player.getStatusEffect(net.minecraft.entity.effect.StatusEffects.SLOWNESS).getAmplifier();
            baseSpeed /= 1 + 0.2 * (amp + 1);
        }

        Vec3d vel = mc.player.getVelocity();
        double currentSpeed = Math.hypot(vel.x, vel.z);
        double targetSpeed = baseSpeed * polarSpeed.getCurrent();

        if (mc.player.isOnGround()) {
            if (currentSpeed < targetSpeed && currentSpeed > 0.01) {
                double boost = Math.min(targetSpeed - currentSpeed, baseSpeed * 0.35);
                double factor = (currentSpeed + boost) / currentSpeed;
                mc.player.setVelocity(vel.x * factor, vel.y, vel.z * factor);
            }

            Entity collision = findPolarCollision();
            if (collision != null) {
                applyPolarCollisionBoost(collision, targetSpeed);
            }
        } else {
            if (currentSpeed > targetSpeed * 0.7 && currentSpeed > 0.01) {
                double airFactor = Math.max(targetSpeed * 0.95 / currentSpeed, 0.98);
                if (airFactor < 1.0) {
                    mc.player.setVelocity(vel.x * airFactor, vel.y, vel.z * airFactor);
                }
            }
        }
    }

    private Entity findPolarCollision() {
        Box box = mc.player.getBoundingBox().expand(0.16, 0.0, 0.16);
        Entity best = null;
        double bestDist = Double.MAX_VALUE;

        for (Entity entity : mc.world.getEntities()) {
            if (entity == mc.player || !entity.isAlive()) continue;
            if (!(entity instanceof PlayerEntity)) continue;
            if (!box.intersects(entity.getBoundingBox())) continue;

            double dist = mc.player.squaredDistanceTo(entity);
            if (dist < bestDist) {
                best = entity;
                bestDist = dist;
            }
        }
        return best;
    }

    private void applyPolarCollisionBoost(Entity collision, double maxSpeed) {
        Vec3d vel = mc.player.getVelocity();
        double currentSpeed = Math.hypot(vel.x, vel.z);
        if (currentSpeed >= maxSpeed) return;

        Vec3d away = mc.player.getPos().subtract(collision.getPos());
        Vec3d horizontal = new Vec3d(away.x, 0, away.z);
        double len = horizontal.length();
        if (len < 1.0E-4) return;
        Vec3d awayDir = horizontal.multiply(1.0 / len);

        double[] moveDir = MovingUtil.calculateDirection(1.0);
        double moveMag = Math.sqrt(moveDir[0] * moveDir[0] + moveDir[1] * moveDir[1]);
        if (moveMag < 1.0E-6) return;

        double inputX = moveDir[0] / moveMag;
        double inputZ = moveDir[1] / moveMag;

        double outward = inputX * awayDir.x + inputZ * awayDir.z;
        double safeX = inputX, safeZ = inputZ;
        if (outward > 0) {
            safeX -= awayDir.x * outward;
            safeZ -= awayDir.z * outward;
        }
        double safeLen = Math.sqrt(safeX * safeX + safeZ * safeZ);
        if (safeLen < 1.0E-6) return;
        safeX /= safeLen;
        safeZ /= safeLen;

        double targetSpeed = Math.min(maxSpeed, currentSpeed + maxSpeed * 0.22);
        mc.player.setVelocity(safeX * targetSpeed, vel.y, safeZ * targetSpeed);
    }

    private void handleSpookyElytra() {
        if (mc.player == null) return;
        
        net.minecraft.screen.slot.Slot elytraSlot = PlayerInventoryUtil.getSlot(net.minecraft.item.Items.ELYTRA);
        if (elytraSlot != null && mc.player.fallDistance > 1.0f) {
            int prevSlot = mc.player.getInventory().selectedSlot;
            
            mc.player.networkHandler.sendPacket(new net.minecraft.network.packet.c2s.play.UpdateSelectedSlotC2SPacket(elytraSlot.id));
            mc.interactionManager.interactItem(mc.player, net.minecraft.util.Hand.MAIN_HAND);
            
            if (mc.player.isSprinting() && mc.player.input.hasForwardMovement()) {
                mc.player.networkHandler.sendPacket(new net.minecraft.network.packet.c2s.play.ClientCommandC2SPacket(mc.player, net.minecraft.network.packet.c2s.play.ClientCommandC2SPacket.Mode.START_FALL_FLYING));
            }
            
            mc.player.networkHandler.sendPacket(new net.minecraft.network.packet.c2s.play.UpdateSelectedSlotC2SPacket(prevSlot));
        }
    }

    private void handleStrafeMode() {
        if (mc.player == null || mc.player.isGliding() || mc.player.isInLava() || mc.player.isTouchingWater()) return;
        if (!MovingUtil.hasPlayerMovement()) return;

        if (mc.player.isOnGround()) {
            if (strafeJump.isEnabled()) mc.player.jump();
            MovingUtil.setVelocity(strafeSpeed.getCurrent());
        } else {
            double current = Math.hypot(mc.player.getVelocity().x, mc.player.getVelocity().z);
            MovingUtil.setVelocity(current);
        }
    }

    private void handleCollisionMode() {
        if (requireMoving.isEnabled() && !MovingUtil.hasPlayerMovement()) return;

        boolean isSprinting = mc.player.isSprinting();
        double currentSkipChance = isSprinting ? 0.8 : 0.3;

        if (random.nextDouble() < currentSkipChance) {
            return;
        }

        int collisions = 0;
        Box checkBox = mc.player.getBoundingBox().expand(expandBox);

        for (Entity entity : mc.world.getEntities()) {
            if (entity == mc.player) continue;
            if (onlyPlayers.isEnabled() && !(entity instanceof PlayerEntity)) continue;
            if (!(entity instanceof LivingEntity) && !(entity instanceof BoatEntity)) continue;

            if (checkBox.intersects(entity.getBoundingBox())) {
                collisions++;
                if (collisions >= 1) {
                    collisions = 1;
                    break;
                }
            }
        }

        if (collisions <= 0) return;

        double speedMultiplier = 0.05;
        speedMultiplier *= (0.8 + random.nextDouble() * 0.4);

        Entity nearest = findNearestTarget();
        if (nearest == null) return;

        Vec3d directionToTarget = nearest.getPos().subtract(mc.player.getPos()).normalize();

        double angleRange = isSprinting ? 80.0 : 30.0;
        double randomAngle = (random.nextDouble() - 0.5) * Math.toRadians(angleRange);

        double sin = Math.sin(randomAngle);
        double cos = Math.cos(randomAngle);

        double nx = directionToTarget.x * cos - directionToTarget.z * sin;
        double nz = directionToTarget.x * sin + directionToTarget.z * cos;

        Vec3d finalDir = new Vec3d(nx, 0, nz).normalize();

        Vec3d currentVel = mc.player.getVelocity();
        Vec3d addVel = finalDir.multiply(speedMultiplier);
        Vec3d newVel = currentVel.add(addVel.x, 0, addVel.z);

        double hSpeed = Math.sqrt(newVel.x * newVel.x + newVel.z * newVel.z);
        double speedLimit = isSprinting ? 0.35 : 0.4;

        if (hSpeed > speedLimit) {
            double scale = speedLimit / hSpeed;
            newVel = new Vec3d(newVel.x * scale, newVel.y, newVel.z * scale);
        }

        mc.player.setVelocity(newVel);
    }

    private void handleGrimUpdate() {
        if ((mc.player.isInFluid() && pauseInLiquids.isEnabled()) ||
                (mc.player.isSneaking() && pauseWhileSneaking.isEnabled())) {
            return;
        }

        updateGrimTarget();
    }

    private void handleGrimMotion() {
        if ((mc.player.isInFluid() && pauseInLiquids.isEnabled()) ||
                (mc.player.isSneaking() && pauseWhileSneaking.isEnabled())) {
            return;
        }

        if (!MovingUtil.hasPlayerMovement()) return;

        if (isTargetStatic && targetEntity != null) {
            handleStaticTargetBoost();
        } else {
            handleGrimDistanceMode();
        }

        if (blockBoost.isEnabled()) {
            handleBlockBoost();
        }

        if (entityBoost.isEnabled()) {
            handleEntityBoost();
        }

        if (grimGlide.isEnabled()) {
            handleGrimGlide();
        }
    }

    private void handleGrimGlide() {
        if (mc.player.fallDistance > 0 && !mc.player.isOnGround() && !mc.player.isTouchingWater()) {
            Vec3d vel = mc.player.getVelocity();
            mc.player.setVelocity(vel.x, -0.01, vel.z);
        }
    }

    private void handleBlockBoost() {
        if (mc.player.isOnGround()) {
            net.minecraft.screen.slot.Slot iceSlot = PlayerInventoryUtil.getSlot(net.minecraft.item.Items.ICE);
            if (iceSlot != null) {
                
                net.minecraft.util.math.BlockPos pos = mc.player.getBlockPos().down();
                if (mc.world.getBlockState(pos).isSolidBlock(mc.world, pos)) {
                    mc.player.jump();
                    
                }
            }
        }
    }

    private void handleEntityBoost() {
        for (Entity entity : mc.world.getEntities()) {
            if (entity != mc.player && (entity instanceof LivingEntity || entity instanceof BoatEntity)) {
                if (mc.player.getBoundingBox().expand(0.1).intersects(entity.getBoundingBox())) {
                    double[] motion = getDirectionToPoint(mc.player.getPos(), entity.getPos(), -0.08);
                    mc.player.addVelocity(motion[0], 0.0, motion[1]);
                }
            }
        }
    }

    private void updateGrimTarget() {
        if (Aura.INSTANCE.isEnabled() && Aura.INSTANCE.getTarget() != null) {
            targetEntity = Aura.INSTANCE.getTarget();
        } else {
            resetGrimState();
            return;
        }

        if (targetEntity != null) {
            Vec3d currentPos = targetEntity.getPos();
            long currentTime = System.currentTimeMillis();

            if (prevTargetPos != null) {
                targetMovementSpeed = currentPos.distanceTo(prevTargetPos);
                isTargetStatic = targetMovementSpeed < movementThreshold.getCurrent();
            }
            prevTargetPos = currentPos;

            if (backtrack.isEnabled() && !isTargetStatic) {
                updateBacktrackHistory(currentPos, currentTime);
            }

            if (lastTargetPos == null) {
                predictedPos = lastTargetPos = currentPos;
            } else {
                Vec3d velocity = currentPos.subtract(lastTargetPos);

                if (predictMovement.isEnabled() && !isTargetStatic) {
                    predictedPos = currentPos.add(velocity.multiply(predictionFactor.getCurrent()));

                    if (!mc.world.isChunkLoaded((int)predictedPos.x >> 4, (int)predictedPos.z >> 4)) {
                        predictedPos = currentPos;
                    }
                } else {
                    predictedPos = currentPos;
                }

                lastTargetPos = currentPos;
            }
        }
    }

    private void handleStaticTargetBoost() {
        if (targetEntity == null) return;

        Box checkBox = mc.player.getBoundingBox().expand(staticBoostRange.getCurrent());
        if (!checkBox.intersects(targetEntity.getBoundingBox())) return;

        Vec3d directionToTarget = targetEntity.getPos().subtract(mc.player.getPos()).normalize();

        double randomAngle = (random.nextDouble() - 0.5) * 0.22;
        double sin = Math.sin(randomAngle);
        double cos = Math.cos(randomAngle);

        double nx = directionToTarget.x * cos - directionToTarget.z * sin;
        double nz = directionToTarget.x * sin + directionToTarget.z * cos;

        Vec3d finalDir = new Vec3d(nx, 0, nz).normalize();

        Vec3d currentVel = mc.player.getVelocity();
        Vec3d added = finalDir.multiply(staticBoostForce.getCurrent());

        Vec3d newVel = currentVel.add(added.x * 0.88, 0, added.z * 0.88);
        mc.player.setVelocity(newVel);
    }

    private void updateBacktrackHistory(Vec3d currentPos, long currentTime) {
        positionHistory.add(currentPos);
        timeHistory.add(currentTime);

        long maxAge = (long)(backtrackTicks.getCurrent() * 50);
        while (!timeHistory.isEmpty() && currentTime - timeHistory.get(0) > maxAge) {
            positionHistory.remove(0);
            timeHistory.remove(0);
        }

        backtrackPos = findBestBacktrackPosition(currentPos);
    }

    private Vec3d findBestBacktrackPosition(Vec3d currentPos) {
        if (positionHistory.isEmpty() || mc.player == null) {
            return currentPos;
        }

        Vec3d playerPos = mc.player.getPos();
        double maxBacktrackDist = backtrackDistance.getCurrent();
        Vec3d bestPos = currentPos;
        double bestDistance = playerPos.distanceTo(currentPos);

        for (int i = positionHistory.size() - 1; i >= 0; i--) {
            Vec3d historyPos = positionHistory.get(i);
            double distToPlayer = playerPos.distanceTo(historyPos);
            double distFromCurrent = currentPos.distanceTo(historyPos);

            if (distFromCurrent <= maxBacktrackDist && distToPlayer < bestDistance) {
                bestDistance = distToPlayer;
                bestPos = historyPos;
            }
        }

        return bestPos;
    }

    private float getEffectiveDistance() {
        if (targetEntity == null) return distance.getCurrent();
        if (waterDistance.isEnabled() && mc.player.isTouchingWater()) return waterDistanceValue.getCurrent();
        if (elytraDistance.isEnabled() && mc.player.isGliding()) return elytraDistanceValue.getCurrent();
        
        if (!bypassDistance.isEnabled()) return distance.getCurrent();

        if (isTargetFacingAway(targetEntity, bypassAngle.getCurrent())) {
            return bypassDistanceValue.getCurrent();
        }
        return distance.getCurrent();
    }

    private boolean isTargetFacingAway(Entity target, float angleDeg) {
        Vec3d toPlayer = mc.player.getPos().subtract(target.getPos()).normalize();
        Vec3d targetLook = target.getRotationVec(1.0f);
        double dot = toPlayer.dotProduct(targetLook);
        return dot <= MathHelper.cos((float) Math.toRadians(angleDeg));
    }

    private void handleGrimDistanceMode() {
        if (targetEntity == null) return;
        if (mc.player.hurtTime > 0) return;

        Vec3d targetPos;
        if (backtrack.isEnabled() && backtrackPos != null) {
            targetPos = backtrackPos;
        } else if (predictMovement.isEnabled() && predictedPos != null) {
            targetPos = predictedPos;
        } else {
            targetPos = targetEntity.getPos();
        }

        float effectiveDist = getEffectiveDistance();
        double dist = mc.player.squaredDistanceTo(targetPos);

        if (dist <= (effectiveDist * effectiveDist)) {
            float slipperiness = mc.world.getBlockState(mc.player.getVelocityAffectingPos()).getBlock().getSlipperiness();
            float horizontalFriction = mc.player.isOnGround() ? slipperiness * 0.91f : 0.91f;
            float verticalFriction = mc.player.isOnGround() ? slipperiness : 0.99f;

            double actualSpeed = speedFactor.getCurrent() * 0.01 * horizontalFriction * verticalFriction;

            double[] directionMotion = getDirectionToPoint(mc.player.getPos(), targetPos, actualSpeed);

            if (smoothMovement.isEnabled()) {
                double accelFactor = 0.6;
                directionMotion[0] = lastMotion[0] + (directionMotion[0] - lastMotion[0]) * accelFactor;
                directionMotion[1] = lastMotion[1] + (directionMotion[1] - lastMotion[1]) * accelFactor;
            }

            lastMotion[0] = directionMotion[0];
            lastMotion[1] = directionMotion[1];

            mc.player.addVelocity(directionMotion[0], 0.0, directionMotion[1]);
        }
    }

    private Entity findNearestTarget() {
        Entity nearest = null;
        double closestSq = Double.MAX_VALUE;
        double maxRangeSq = searchRange * searchRange;

        for (Entity entity : mc.world.getEntities()) {
            if (entity == mc.player) continue;
            if (onlyPlayers.isEnabled() && !(entity instanceof PlayerEntity)) continue;
            if (!(entity instanceof LivingEntity) && !(entity instanceof BoatEntity)) continue;

            double distSq = mc.player.squaredDistanceTo(entity);

            if (distSq <= maxRangeSq && distSq < closestSq) {
                closestSq = distSq;
                nearest = entity;
            }
        }

        return nearest;
    }

    private double[] getDirectionToPoint(Vec3d from, Vec3d to, double speed) {
        double dx = to.x - from.x;
        double dz = to.z - from.z;
        double len = Math.sqrt(dx * dx + dz * dz);

        if (len == 0.0) {
            return new double[]{0.0, 0.0};
        }

        return new double[]{dx / len * speed, dz / len * speed};
    }

    private void resetGrimState() {
        targetEntity = null;
        lastTargetPos = null;
        predictedPos = null;
        backtrackPos = null;
        prevTargetPos = null;
        targetMovementSpeed = 0.0;
        isTargetStatic = false;
        positionHistory.clear();
        timeHistory.clear();
    }

    @Override
    public void onEnable() {
        super.onEnable();
        resetGrimState();
        lastMotion = new double[]{0.0, 0.0};
        grimStage = 1;
        grimTicks = 0;
        grimBaseSpeed = 0.2873;
    }

    @Override
    public void onDisable() {
        super.onDisable();
        resetGrimState();
    }
}
