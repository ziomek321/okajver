package okyware.wtf.client.modules.impl.combat;

import com.darkmagician6.eventapi.EventTarget;
import lombok.Getter;
import net.minecraft.client.util.InputUtil;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.Items;
import net.minecraft.network.packet.c2s.play.UpdateSelectedSlotC2SPacket;
import net.minecraft.screen.slot.SlotActionType;
import net.minecraft.util.Pair;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;

import okyware.wtf.Okyware;
import okyware.wtf.base.events.impl.player.EventMoveInput;
import okyware.wtf.base.events.impl.player.EventRotate;
import okyware.wtf.base.player.AttackUtil;
import okyware.wtf.base.rotation.RotationTarget;
import okyware.wtf.base.rotation.mods.config.InterpolationRotationConfig;
import okyware.wtf.client.modules.api.Category;
import okyware.wtf.client.modules.api.Module;
import okyware.wtf.client.modules.api.ModuleAnnotation;
import okyware.wtf.client.modules.api.setting.impl.BooleanSetting;
import okyware.wtf.client.modules.api.setting.impl.ModeSetting;
import okyware.wtf.client.modules.api.setting.impl.MultiBooleanSetting;
import okyware.wtf.client.modules.api.setting.impl.NumberSetting;
import okyware.wtf.utility.game.other.MessageUtil;
import okyware.wtf.utility.game.player.*;
import okyware.wtf.utility.game.player.rotation.Rotation;
import okyware.wtf.utility.game.player.rotation.RotationUtil;

import java.util.List;

import static okyware.wtf.utility.game.player.MovingUtil.fixMovement;

@ModuleAnnotation(name = "Aura", category = Category.COMBAT, description = "Automatically attacks nearby entities with configurable reach and timing")
public final class Aura extends Module {

    public static final Aura INSTANCE = new Aura();
    private Aura() {}

    
    private final ModeSetting rotationMode = new ModeSetting("Rotation");
    private final ModeSetting.Value hvh = new ModeSetting.Value(rotationMode, "HvH");
    private final ModeSetting.Value hollyworld = new ModeSetting.Value(rotationMode, "HollyWorld").select();
    private final ModeSetting.Value polar = new ModeSetting.Value(rotationMode, "Polar");

    
    private final ModeSetting sprintMode = new ModeSetting("Sprint");
    private final ModeSetting.Value sprintHvh = new ModeSetting.Value(sprintMode, "HvH");
    private final ModeSetting.Value sprintNormal = new ModeSetting.Value(sprintMode, "Normal").select();
    private final ModeSetting.Value sprintLegit = new ModeSetting.Value(sprintMode, "Legit");
    private final ModeSetting.Value sprintNone = new ModeSetting.Value(sprintMode, "No");
    private final ModeSetting.Value sprintPolar = new ModeSetting.Value(sprintMode, "Polar");

    
    private final ModeSetting correction = new ModeSetting("Correction");
    private final ModeSetting.Value correctionFocus = new ModeSetting.Value(correction, "Focus");
    private final ModeSetting.Value correctionGood = new ModeSetting.Value(correction, "Free").select();
    private final ModeSetting.Value correctionNone = new ModeSetting.Value(correction, "No");

    
    private final NumberSetting distance = new NumberSetting("Distance", 3, 0.5f, 6, 0.1f, "Attack distance");
    private final NumberSetting distanceRotation = new NumberSetting("Pre-distance", 0.1f, 0, 6, 0.1f);

    
    private final MultiBooleanSetting settings = new MultiBooleanSetting("Settings");
    private final MultiBooleanSetting.Value shieldBreak = new MultiBooleanSetting.Value(settings, "Break shield", true);
    private final MultiBooleanSetting.Value shielRealese = new MultiBooleanSetting.Value(settings, "Disarm shield", true);
    private final MultiBooleanSetting.Value eatUseAttack = new MultiBooleanSetting.Value(settings, "Hit and eat", true);
    private final MultiBooleanSetting.Value attackIgnoreWals = new MultiBooleanSetting.Value(settings, "Hit through walls", true);

    
    private final MultiBooleanSetting targetTypeSetting = MultiBooleanSetting.create("Attack", List.of("Players", "Hostile", "Passive"));

    
    private final BooleanSetting onlyCrit = new BooleanSetting("Crits only", true);
    private final BooleanSetting smartCrit = new BooleanSetting("Smart crits", "Crits when jump key is held", false, onlyCrit::isEnabled);

    
    private final TargetSelector targetSelector = new TargetSelector();
    private final PointFinder pointFinder = new PointFinder();
    private final InterpolationRotationConfig polarRotationConfig = new InterpolationRotationConfig(
            new okyware.wtf.utility.math.IntRange(15, 25),
            new okyware.wtf.utility.math.IntRange(10, 20),
            new okyware.wtf.utility.math.IntRange(40, 60),
            0.5f
    );
    private LivingEntity target = null;
    private boolean legitBackStop = false; 
    @Getter
    private boolean preAttack =false;
    @Getter
    private boolean isCanAttack =false;

    
    private int previousSlot = -1;
    @EventTarget
    public void eventRotate(EventRotate e) {
        if (legitBackStop) {
            legitBackStop = false;
            mc.options.forwardKey.setPressed(
                    InputUtil.isKeyPressed(mc.getWindow().getHandle(), mc.options.forwardKey.getDefaultKey().getCode())
            );
        }

        target = updateTarget();
        preAttack = false;
        isCanAttack = false;
        if (target == null) {
            return;
        }

        Pair<Vec3d, Box> point = pointFinder.computeVector(
                target,
                distance.getCurrent(),
                rotationManager.getCurrentRotation(),
                new Vec3d(0, 0, 0),
                attackIgnoreWals.isEnabled()
        );

        Vec3d eyes = SimulatedPlayer.simulateLocalPlayer(1).pos.add(0, mc.player.getDimensions(mc.player.getPose()).eyeHeight(), 0);
        Rotation angle = RotationUtil.fromVec3d(point.getLeft().subtract(eyes));

        Box box = point.getRight();
        preAttack = updatePreAttack();
        isCanAttack = isAttack();

        
        if (target != null && target.isAlive() && mc.player.distanceTo(target) <= distance.getCurrent() + distanceRotation.getCurrent()) {
            if (hvh.isSelected()) {
                rotationManager.setRotation(
                        new RotationTarget(angle, () -> aimManager.rotate(aimManager.getInstantSetup(), angle), aimManager.getInstantSetup()),
                        3, this
                );
            }

            if (hollyworld.isSelected() && (preAttack || isCanAttack)) {
                rotationManager.setRotation(
                        new RotationTarget(angle, () -> aimManager.rotate(aimManager.getInstantSetup(), angle), aimManager.getAiSetup()),
                        3, this
                );
            }

            if (polar.isSelected() && (preAttack || isCanAttack)) {
                rotationManager.setRotation(
                        new RotationTarget(angle, () -> aimManager.rotate(polarRotationConfig, angle), polarRotationConfig),
                        3, this
                );
            }
        }

        
        if (RaytracingUtil.rayTrace(rotationManager.getCurrentRotation().toVector(), distance.getCurrent(), box)
                && isCanAttack
                && mc.player.distanceTo(target) <= distance.getCurrent()
                && (!Okyware.getInstance().getServerHandler().isServerSprint() ||mc.player.isGliding() || AttackUtil.hasMovementRestrictions() || sprintHvh.isSelected() || sprintNone.isSelected() || sprintPolar.isSelected())) {

            if (sprintHvh.isSelected()) {
                mc.player.setSprinting(false);
                mc.player.sendSprintingPacket();
            }

            if (sprintPolar.isSelected()) {
                // Polar: stop sprint before attack, re-sprint after
                mc.player.setSprinting(false);
                mc.player.sendSprintingPacket();
            }

            
            if (shieldBreak.isEnabled() && isTargetUsingShield(target)) {
                if (handleShieldBreakThunderHack(target)) {
                    return; 
                }
            }

            Criticals.INSTANCE.onAttack();
            AttackUtil.attackEntity(target);

            mc.options.sprintKey.setPressed(true);
        }

        if (preAttack || isCanAttack) {
            updateSprint();
        }
    }

    private boolean updatePreAttack() {
        SimulatedPlayer simulatedPlayer = SimulatedPlayer.simulateLocalPlayer(1);

        if (mc.player.isUsingItem() && !eatUseAttack.isEnabled()) return false;
        if (mc.player.getAttackCooldownProgress(1) < 0.9) return false;

        if (onlyCrit.isEnabled() && !AttackUtil.hasPreMovementRestrictions(simulatedPlayer)) {
            return AttackUtil.isPrePlayerInCriticalState(simulatedPlayer) || (smartCrit.isEnabled() && !mc.options.jumpKey.isPressed());
        }
        return true;
    }

    private boolean isAttack() {
        if (mc.player.isUsingItem() && !eatUseAttack.isEnabled()) return false;
        if (mc.player.getAttackCooldownProgress(1) < 0.9) return false;

        if (onlyCrit.isEnabled() && !AttackUtil.hasMovementRestrictions()) {
            return AttackUtil.isPlayerInCriticalState() || (smartCrit.isEnabled() && !mc.options.jumpKey.isPressed());
        }
        return true;
    }

    public void updateSprint() {
        if (!hasStopSprint()) return;

        boolean sprint = mc.options.sprintKey.isPressed();
        boolean forward = mc.options.forwardKey.isPressed();

        if (sprintLegit.isSelected()) {
            sprint = false;
            if (mc.player.isSprinting()) {

                forward = false;
                legitBackStop = true;
            }
        }

        if (sprintNormal.isSelected()) {
            if (mc.player.isSprinting()) mc.player.setSprinting(false);
            sprint = false;
        }

        mc.options.sprintKey.setPressed(sprint);
        mc.options.forwardKey.setPressed(forward);
    }

    public boolean hasStopSprint() {
        return !sprintNone.isSelected() && !sprintPolar.isSelected() && !AttackUtil.hasMovementRestrictions();
    }

    private LivingEntity updateTarget() {
        TargetSelector.EntityFilter filter = new TargetSelector.EntityFilter(targetTypeSetting.getSelectedNames());
        targetSelector.searchTargets(mc.world.getEntities(), distance.getCurrent() + distanceRotation.getCurrent(), attackIgnoreWals.isEnabled());
        targetSelector.validateTarget(filter::isValid);
        return targetSelector.getCurrentTarget();
    }

    @EventTarget
    private void setCorrection(EventMoveInput eventMoveInput) {
        if (correctionNone.isSelected() || polar.isSelected()) return;

        if (correctionFocus.isSelected()) {
            Rotation angle = RotationUtil.fromVec3d(target.getBoundingBox().getCenter().subtract(mc.player.getBoundingBox().getCenter()));
            fixMovement(eventMoveInput, rotationManager.getCurrentRotation().getYaw(), angle.getYaw());
        } else {
            fixMovement(eventMoveInput, rotationManager.getCurrentRotation().getYaw(), mc.player.getYaw());
        }
    }

    public LivingEntity getTarget() {
        return this.isEnabled()?target:null;
    }

    
    private boolean isTargetUsingShield(LivingEntity target) {
        if (!(target instanceof PlayerEntity player)) {
            return false;
        }

        
        boolean offHandShield = !player.getOffHandStack().isEmpty() &&
                               player.getOffHandStack().getItem() == Items.SHIELD;

        
        boolean mainHandShield = !player.getMainHandStack().isEmpty() &&
                                player.getMainHandStack().getItem() == Items.SHIELD;

        return (offHandShield || mainHandShield) && player.isUsingItem();
    }

    
    private boolean handleShieldBreakThunderHack(LivingEntity target) {
        if (!(target instanceof PlayerEntity player)) {
            return false;
        }

        
        int axeSlot = findAxeInHotbar();
        if (axeSlot == -1) {
            return false; 
        }

        
        previousSlot = mc.player.getInventory().selectedSlot;

        
        if (axeSlot >= 9) {
            
            mc.interactionManager.clickSlot(
                mc.player.currentScreenHandler.syncId,
                axeSlot,
                mc.player.getInventory().selectedSlot,
                SlotActionType.SWAP,
                mc.player
            );
            mc.getNetworkHandler().sendPacket(
                new net.minecraft.network.packet.c2s.play.CloseHandledScreenC2SPacket(
                    mc.player.currentScreenHandler.syncId
                )
            );

            
            AttackUtil.attackEntity(target);

            
            mc.interactionManager.clickSlot(
                mc.player.currentScreenHandler.syncId,
                axeSlot,
                mc.player.getInventory().selectedSlot,
                SlotActionType.SWAP,
                mc.player
            );
            mc.getNetworkHandler().sendPacket(
                new net.minecraft.network.packet.c2s.play.CloseHandledScreenC2SPacket(
                    mc.player.currentScreenHandler.syncId
                )
            );
        } else {
            
            mc.getNetworkHandler().sendPacket(new UpdateSelectedSlotC2SPacket(axeSlot));

            
            AttackUtil.attackEntity(target);

            
            mc.getNetworkHandler().sendPacket(new UpdateSelectedSlotC2SPacket(previousSlot));
        }

        
        if (shielRealese.isEnabled()) {
            mc.getNetworkHandler().sendPacket(
                new net.minecraft.network.packet.c2s.play.PlayerActionC2SPacket(
                    net.minecraft.network.packet.c2s.play.PlayerActionC2SPacket.Action.RELEASE_USE_ITEM,
                    player.getBlockPos(),
                    net.minecraft.util.math.Direction.DOWN
                )
            );
        }

        return true; 
    }

    
    private int findAxeInHotbar() {
        
        for (int i = 0; i < 9; i++) {
            Item item = mc.player.getInventory().getStack(i).getItem();
            if (isAxe(item)) {
                return i;
            }
        }

        
        for (int i = 9; i < 36; i++) {
            Item item = mc.player.getInventory().getStack(i).getItem();
            if (isAxe(item)) {
                return i;
            }
        }

        return -1;
    }

    
    private boolean isAxe(Item item) {
        return item == Items.WOODEN_AXE ||
               item == Items.STONE_AXE ||
               item == Items.IRON_AXE ||
               item == Items.GOLDEN_AXE ||
               item == Items.DIAMOND_AXE ||
               item == Items.NETHERITE_AXE;
    }

    @Override
    public void onDisable() {
        super.onDisable();
        
        previousSlot = -1;
    }


}
