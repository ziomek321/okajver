package okyware.wtf.client.modules.impl.render;

import okyware.wtf.client.modules.api.Category;
import okyware.wtf.client.modules.api.Module;
import okyware.wtf.client.modules.api.ModuleAnnotation;
import okyware.wtf.client.modules.api.setting.impl.MultiBooleanSetting;

import java.util.List;

@ModuleAnnotation(name = "NoRender", category = Category.RENDER,description = "Disables distracting vanilla HUD overlays like fire, pumpkin blur, and fog")
public final class NoRender extends Module {
    public static final NoRender INSTANCE = new NoRender();

    private final MultiBooleanSetting settings = MultiBooleanSetting.create("Remove", List.of(
            "Fire",
            "Bad effects",
            "Rain",
            "Snow", 
            "Fog",
            "Clouds",
            "Particles",
            "HUD",
            "Hurt cam",
            "Skybox",
            "Hand blocks",
            "Water effects",
            "Lava effects",
            "Portal effects",
            "Smoke",
            "Explosions",
            "Lightning",
            "Shadows",
            "NoHurtCam"
    ));


    private NoRender() {
    }


    public boolean isRemoveFire() {
        return this.isEnabled() && settings.isEnable(0);
    }
    public boolean isRemoveBadEffect() {
        return this.isEnabled() && settings.isEnable(1);
    }
    public boolean isRemoveRain() {
        return this.isEnabled() && settings.isEnable(2);
    }
    public boolean isRemoveSnow() {
        return this.isEnabled() && settings.isEnable(3);
    }
    public boolean isRemoveFog() {
        return this.isEnabled() && settings.isEnable(4);
    }
    public boolean isRemoveClouds() {
        return this.isEnabled() && settings.isEnable(5);
    }
    public boolean isRemoveParticles() {
        return this.isEnabled() && settings.isEnable(6);
    }
    public boolean isRemoveHUD() {
        return this.isEnabled() && settings.isEnable(7);
    }
    public boolean isRemoveDamage() {
        return this.isEnabled() && settings.isEnable(8);
    }
    public boolean isRemoveSkybox() {
        return this.isEnabled() && settings.isEnable(9);
    }
    public boolean isRemoveHandItems() {
        return this.isEnabled() && settings.isEnable(10);
    }
    public boolean isRemoveWaterEffects() {
        return this.isEnabled() && settings.isEnable(11);
    }
    public boolean isRemoveLavaEffects() {
        return this.isEnabled() && settings.isEnable(12);
    }
    public boolean isRemovePortalEffects() {
        return this.isEnabled() && settings.isEnable(13);
    }
    public boolean isRemoveSmoke() {
        return this.isEnabled() && settings.isEnable(14);
    }
    public boolean isRemoveExplosions() {
        return this.isEnabled() && settings.isEnable(15);
    }
    public boolean isRemoveLightning() {
        return this.isEnabled() && settings.isEnable(16);
    }
    public boolean isRemoveShadows() {
        return this.isEnabled() && settings.isEnable(17);
    }
    public boolean isRemoveHurtCam() {
        return this.isEnabled() && settings.isEnable(18);
    }
}
