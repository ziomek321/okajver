package okyware.wtf.client.modules.impl.misc;

import okyware.wtf.Okyware;
import com.darkmagician6.eventapi.EventTarget;
import okyware.wtf.base.events.impl.player.EventUpdate;
import okyware.wtf.client.modules.api.Category;
import okyware.wtf.client.modules.api.Module;
import okyware.wtf.client.modules.api.ModuleAnnotation;
import okyware.wtf.client.modules.api.setting.impl.BooleanSetting;
import okyware.wtf.client.modules.api.setting.impl.StringSetting;

import java.util.List;


@ModuleAnnotation(name = "NameProtect", category = Category.MISC, description = "Masks your username and other player names in chat and the tab list")
public final class NameProtect extends Module {
    public static final NameProtect INSTANCE = new NameProtect();

    private NameProtect() {
    }

    private final StringSetting customName = new StringSetting("Custom name", "FLUFFYDLC", 24);
    private final BooleanSetting hideFriends = new BooleanSetting("Hide friends", false);

    private String fakeName() {
        String v = customName.getValue();
        return v == null || v.isEmpty() ? "FLUFFYDLC" : v;
    }

    public static String getCustomName() {
        NameProtect module = NameProtect.INSTANCE;
        return module != null && module.isEnabled() ? module.fakeName() : mc.player.getNameForScoreboard();
    }

    public static String getCustomName(String originalName) {
        NameProtect module = NameProtect.INSTANCE;
        if (module == null || !module.isEnabled() || mc.player == null) {
            return originalName;
        }

        String fake = module.fakeName();
        String me = mc.player.getNameForScoreboard();
        if (originalName.contains(me)) {
            return originalName.replace(me, fake);
        }

        if (module.hideFriends.isEnabled()) {
            var friends = Okyware.getInstance().getFriendManager().getItems();
            for (String friend : friends) {
                if (originalName.contains(friend)) {
                    return originalName.replace(friend, fake);
                }
            }
        }

        return originalName;
    }
}
