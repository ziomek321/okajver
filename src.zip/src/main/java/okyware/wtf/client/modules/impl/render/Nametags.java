package okyware.wtf.client.modules.impl.render;

import com.darkmagician6.eventapi.EventTarget;
import com.mojang.blaze3d.systems.RenderSystem;
import net.minecraft.client.gui.screen.ChatScreen;
import net.minecraft.client.option.Perspective;
import net.minecraft.client.render.DiffuseLighting;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.ItemEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.text.Text;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import org.joml.Vector2f;
import okyware.wtf.Okyware;
import okyware.wtf.base.events.impl.render.EventRender2D;
import okyware.wtf.base.font.Font;
import okyware.wtf.base.font.Fonts;
import okyware.wtf.base.theme.Theme;
import okyware.wtf.client.modules.api.Category;
import okyware.wtf.client.modules.api.Module;
import okyware.wtf.client.modules.api.ModuleAnnotation;
import okyware.wtf.client.modules.api.setting.impl.BooleanSetting;
import okyware.wtf.client.modules.api.setting.impl.NumberSetting;
import okyware.wtf.client.modules.impl.misc.NameProtect;
import okyware.wtf.utility.math.ProjectionUtil;
import okyware.wtf.utility.render.display.base.BorderRadius;
import okyware.wtf.utility.render.display.base.CustomDrawContext;
import okyware.wtf.utility.render.display.base.color.ColorRGBA;

import java.util.ArrayList;
import java.util.List;

@ModuleAnnotation(name = "Nametags", category = Category.RENDER, description = "Shows player names with health, armor, items, team prefix, and shulker contents.")
public final class Nametags extends Module {
    public static final Nametags INSTANCE = new Nametags();

    private final NumberSetting scale = new NumberSetting("Size", 1.0f, 0.5f, 2.0f, 0.1f);
    private final BooleanSetting showArmor = new BooleanSetting("Armor", true);
    private final BooleanSetting showItems = new BooleanSetting("Items", true);
    private final BooleanSetting showHealth = new BooleanSetting("Health", true);
    private final BooleanSetting friendColor = new BooleanSetting("Friend color", true);
    private final BooleanSetting showPrefix = new BooleanSetting("Team Prefix", true);
    private final BooleanSetting showShulker = new BooleanSetting("Shulker Contents", true);

    private Nametags() {
    }

    @EventTarget
    public void onRender2D(EventRender2D event) {
        if (mc.player == null || mc.world == null || mc.getEntityRenderDispatcher().camera == null) return;

        CustomDrawContext ctx = event.getContext();
        float tickDelta = event.getTickDelta();

        for (Entity entity : mc.world.getEntities()) {
            if (entity == mc.player && mc.options.getPerspective() == Perspective.FIRST_PERSON) continue;
            if (entity instanceof PlayerEntity player) {
                drawPlayerTag(ctx, player, tickDelta);
            } else if (entity instanceof ItemEntity item && showItems.isEnabled()) {
                drawItemTag(ctx, item, tickDelta);
            }
        }
    }

    private void drawPlayerTag(CustomDrawContext ctx, PlayerEntity player, float tickDelta) {
        Vec3d pos = getInterpolatedPos(player, tickDelta).add(0, player.getHeight() + 0.5, 0);
        Vec3d projected = ProjectionUtil.worldSpaceToScreenSpace(pos);
        if (projected.z <= 0 || projected.z >= 1) return;

        float dist = (float) mc.player.getPos().distanceTo(player.getPos());
        float s = scale.getCurrent() * MathHelper.clamp(1.0f - dist / 50.0f, 0.5f, 1.0f);

        Theme theme = Okyware.getInstance().getThemeManager().getCurrentTheme();
        boolean isFriend = friendColor.isEnabled() && Okyware.getInstance().getFriendManager().isFriend(player.getGameProfile().getName());

        String name = NameProtect.getCustomName(player.getGameProfile().getName());
        Font font = Fonts.MEDIUM.getFont(10 * s);

        String prefix = "";
        if (showPrefix.isEnabled() && player.getScoreboardTeam() != null && player.getScoreboardTeam().getPrefix() != null) {
            String p = player.getScoreboardTeam().getPrefix().getString();
            if (!p.isEmpty()) prefix = p + " ";
        }

        int hp = (int) Math.ceil(player.getHealth() + player.getAbsorptionAmount());
        String hpText = showHealth.isEnabled() ? " [" + hp + "]" : "";

        float prefixW = font.width(prefix);
        float nameW = font.width(name);
        float hpW = font.width(hpText);
        float totalW = prefixW + nameW + hpW;
        
        float pad = 4f * s;
        float rectH = font.height() + pad;
        float rectW = totalW + pad * 2;
        float rectX = (float) projected.x - rectW / 2f;
        float rectY = (float) projected.y - rectH;

        
        ctx.drawBlur(rectX, rectY, rectW, rectH, 20f, BorderRadius.all(2f), ColorRGBA.WHITE);
        ColorRGBA bg = isFriend ? new ColorRGBA(0, 80, 0, 120) : new ColorRGBA(0, 0, 0, 120);
        ctx.drawRoundedRect(rectX, rectY, rectW, rectH, BorderRadius.all(2f), bg);

        float textX = rectX + pad;
        if (!prefix.isEmpty()) {
            ctx.drawText(font, prefix, textX, rectY + pad / 2f, theme.getWhite());
            textX += prefixW;
        }
        ctx.drawText(font, name, textX, rectY + pad / 2f, theme.getWhite());
        if (showHealth.isEnabled()) {
            ColorRGBA hpColor = hp <= 7 ? new ColorRGBA(255, 80, 80, 255)
                    : hp <= 15 ? new ColorRGBA(255, 220, 80, 255)
                    : new ColorRGBA(120, 230, 120, 255);
            ctx.drawText(font, hpText, textX + nameW, rectY + pad / 2f, hpColor);
        }

        float armorY = rectY - 18f * s;

        if (showArmor.isEnabled()) {
            renderArmor(ctx, player, (float) projected.x, armorY, s);
        }
    }

    private void renderArmor(CustomDrawContext ctx, PlayerEntity player, float x, float y, float s) {
        List<ItemStack> items = new ArrayList<>();
        items.add(player.getOffHandStack());
        items.add(player.getInventory().armor.get(0));
        items.add(player.getInventory().armor.get(1));
        items.add(player.getInventory().armor.get(2));
        items.add(player.getInventory().armor.get(3));
        items.add(player.getMainHandStack());
        items.removeIf(ItemStack::isEmpty);

        if (items.isEmpty()) return;

        float itemSize = 16 * s;
        float spacing = 2 * s;
        float totalW = items.size() * itemSize + (items.size() - 1) * spacing;
        float startX = x - totalW / 2f;

        ctx.pushMatrix();
        ctx.getMatrices().translate(startX, y, 0);
        ctx.getMatrices().scale(s, s, 1);
        
        for (int i = 0; i < items.size(); i++) {
            ItemStack stack = items.get(i);
            ctx.drawItem(stack, i * 18, 0);
        }
        ctx.popMatrix();
    }

    private void drawItemTag(CustomDrawContext ctx, ItemEntity item, float tickDelta) {
        Vec3d pos = getInterpolatedPos(item, tickDelta).add(0, item.getHeight() + 0.2, 0);
        Vec3d projected = ProjectionUtil.worldSpaceToScreenSpace(pos);
        if (projected.z <= 0 || projected.z >= 1) return;

        float dist = (float) mc.player.getPos().distanceTo(item.getPos());
        if (dist > 15) return;

        float s = scale.getCurrent() * MathHelper.clamp(1.0f - dist / 20.0f, 0.5f, 1.0f);
        Font font = Fonts.MEDIUM.getFont(9 * s);

        String text = item.getStack().getName().getString() + " x" + item.getStack().getCount();
        float w = font.width(text);
        float h = font.height();
        float pad = 3f * s;

        float rectX = (float) projected.x - (w + pad * 2) / 2f;
        float rectY = (float) projected.y - (h + pad);

        ctx.drawBlur(rectX, rectY, w + pad * 2, h + pad, 20f, BorderRadius.all(2f), ColorRGBA.WHITE);
        ctx.drawRoundedRect(rectX, rectY, w + pad * 2, h + pad, BorderRadius.all(2f), new ColorRGBA(0, 0, 0, 120));
        ctx.drawText(font, text, rectX + pad, rectY + pad / 2f, ColorRGBA.WHITE);

        if (showShulker.isEnabled() && isShulker(item.getStack())) {
            renderShulkerGrid(ctx, item.getStack(), (float) projected.x, rectY, s);
        }
    }

    private boolean isShulker(ItemStack stack) {
        return stack.getItem() instanceof net.minecraft.item.BlockItem
                && ((net.minecraft.item.BlockItem) stack.getItem()).getBlock() instanceof net.minecraft.block.ShulkerBoxBlock;
    }

    private java.util.List<ItemStack> getShulkerContents(ItemStack stack) {
        java.util.List<ItemStack> list = new ArrayList<>();
        net.minecraft.component.type.ContainerComponent c = stack.get(net.minecraft.component.DataComponentTypes.CONTAINER);
        if (c == null) return list;
        c.iterateNonEmpty().forEach(list::add);
        return list;
    }

    private void renderShulkerGrid(CustomDrawContext ctx, ItemStack shulkerStack, float centerX, float bottomY, float s) {
        java.util.List<ItemStack> items = getShulkerContents(shulkerStack);
        if (items.isEmpty()) return;

        int columns = Math.min(items.size(), 9);
        int rows = (int) Math.ceil(items.size() / 9f);
        float cell = 18f * s;
        float boxW = columns * cell + 4f * s;
        float boxH = rows * cell + 4f * s;
        float gridX = centerX - boxW / 2f;
        float gridY = bottomY - boxH - 2f * s;

        ctx.drawBlur(gridX, gridY, boxW, boxH, 20f, BorderRadius.all(2f), ColorRGBA.WHITE);
        ctx.drawRoundedRect(gridX, gridY, boxW, boxH, BorderRadius.all(2f), new ColorRGBA(0, 0, 0, 120));

        ctx.pushMatrix();
        ctx.getMatrices().translate(gridX + 2f * s, gridY + 2f * s, 0);
        ctx.getMatrices().scale(s, s, 1);
        for (int i = 0; i < items.size(); i++) {
            ItemStack stack = items.get(i);
            int col = i % 9;
            int row = i / 9;
            ctx.drawItem(stack, col * 18, row * 18);
        }
        ctx.popMatrix();
    }

    private Vec3d getInterpolatedPos(Entity entity, float tickDelta) {
        return new Vec3d(
                MathHelper.lerp(tickDelta, entity.prevX, entity.getX()),
                MathHelper.lerp(tickDelta, entity.prevY, entity.getY()),
                MathHelper.lerp(tickDelta, entity.prevZ, entity.getZ())
        );
    }
}
