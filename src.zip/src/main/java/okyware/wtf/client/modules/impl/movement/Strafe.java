package okyware.wtf.client.modules.impl.movement;

import com.darkmagician6.eventapi.EventTarget;
import okyware.wtf.base.events.impl.player.EventUpdate;
import okyware.wtf.client.modules.api.Category;
import okyware.wtf.client.modules.api.Module;
import okyware.wtf.client.modules.api.ModuleAnnotation;
import okyware.wtf.client.modules.api.setting.impl.NumberSetting;
import okyware.wtf.utility.game.player.MovingUtil;

@ModuleAnnotation(name = "Strafe", category = Category.MOVEMENT, description = "Bhop-style strafe: auto-jumps on ground and preserves air speed")
public final class Strafe extends Module {
    public static final Strafe INSTANCE = new Strafe();

    private final NumberSetting groundSpeed = new NumberSetting("Ground Speed", 0.28f, 0.1f, 0.6f, 0.01f);
    private final NumberSetting airMultiplier = new NumberSetting("Air Multiplier", 1.0f, 0.1f, 2.0f, 0.05f);

    private Strafe() {
    }

    @EventTarget
    public void onUpdate(EventUpdate event) {
        if (mc.player == null || mc.player.isGliding() || mc.player.isTouchingWater() || mc.player.isInLava()) {
            return;
        }

        if (!MovingUtil.hasPlayerMovement()) {
            return;
        }

        if (mc.player.isOnGround()) {
            mc.player.jump();
            MovingUtil.setVelocity(groundSpeed.getCurrent());
        } else {
            double current = Math.hypot(mc.player.getVelocity().x, mc.player.getVelocity().z);
            MovingUtil.setVelocity(current * airMultiplier.getCurrent());
        }
    }
}
