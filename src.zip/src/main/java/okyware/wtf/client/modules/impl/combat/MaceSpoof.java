package okyware.wtf.client.modules.impl.combat;

import com.darkmagician6.eventapi.EventTarget;
import net.minecraft.item.Items;
import net.minecraft.network.packet.c2s.play.PlayerMoveC2SPacket;
import okyware.wtf.base.events.impl.player.EventAttack;
import okyware.wtf.client.modules.api.Category;
import okyware.wtf.client.modules.api.Module;
import okyware.wtf.client.modules.api.ModuleAnnotation;
import okyware.wtf.client.modules.api.setting.impl.NumberSetting;

@ModuleAnnotation(name = "MaceSpoof", category = Category.COMBAT, description = "Spoofs fall distance for mace damage without jumping")
public final class MaceSpoof extends Module {
    public static final MaceSpoof INSTANCE = new MaceSpoof();

    private final NumberSetting fallDistance = new NumberSetting("Fall Distance", 10.0f, 1.0f, 50.0f, 1.0f);

    private MaceSpoof() {
    }

    @EventTarget
    public void onAttack(EventAttack event) {
        if (event.getAction() != EventAttack.Action.PRE) return;
        if (mc.player.getMainHandStack().getItem() != Items.MACE) return;

        double x = mc.player.getX();
        double y = mc.player.getY();
        double z = mc.player.getZ();
        float spoofHeight = fallDistance.getCurrent();

        
        for (int i = 0; i < (int)(spoofHeight / 10) + 1; i++) {
            double upY = y + Math.min(spoofHeight, (i + 1) * 10.0);
            mc.player.networkHandler.sendPacket(new PlayerMoveC2SPacket.PositionAndOnGround(x, upY, z, false, false));
        }

        
        for (int i = (int)(spoofHeight / 10); i >= 0; i--) {
            double downY = y + Math.max(0, i * 10.0);
            mc.player.networkHandler.sendPacket(new PlayerMoveC2SPacket.PositionAndOnGround(x, downY, z, false, false));
        }

        
        mc.player.fallDistance = spoofHeight;
    }
}
