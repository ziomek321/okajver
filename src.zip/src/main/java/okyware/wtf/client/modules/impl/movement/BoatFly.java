package okyware.wtf.client.modules.impl.movement;

import com.darkmagician6.eventapi.EventTarget;
import net.minecraft.entity.Entity;
import net.minecraft.entity.vehicle.BoatEntity;
import net.minecraft.network.packet.c2s.play.PlayerMoveC2SPacket;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import okyware.wtf.base.events.impl.player.EventUpdate;
import okyware.wtf.base.events.impl.server.EventPacket;
import okyware.wtf.client.modules.api.Category;
import okyware.wtf.client.modules.api.Module;
import okyware.wtf.client.modules.api.ModuleAnnotation;
import okyware.wtf.client.modules.api.setting.impl.BooleanSetting;
import okyware.wtf.client.modules.api.setting.impl.NumberSetting;
import okyware.wtf.utility.mixin.accessors.PlayerMoveC2SPacketAccessor;

@ModuleAnnotation(name = "BoatFly", category = Category.MOVEMENT, description = "Lets you fly while riding a boat without taking damage.")
public final class BoatFly extends Module {
    public static final BoatFly INSTANCE = new BoatFly();

    public final NumberSetting speed = new NumberSetting("Speed", 1.0f, 0.1f, 5.0f, 0.1f);
    public final NumberSetting verticalSpeed = new NumberSetting("Vertical Speed", 1.0f, 0.1f, 5.0f, 0.1f);
    public final BooleanSetting glide = new BooleanSetting("Glide", "Slowly drift down when not pressing keys", false);
    public final NumberSetting glideSpeed = new NumberSetting("Glide Speed", 0.05f, 0.0f, 0.5f, 0.01f, glide::isEnabled);
    public final BooleanSetting noFall = new BooleanSetting("No Fall", "Prevents fall damage on dismount.", true);

    private BoatFly() {
    }

    @EventTarget
    public void onUpdate(EventUpdate event) {
        if (mc.player == null) return;
        Entity vehicle = mc.player.getVehicle();
        if (!(vehicle instanceof BoatEntity boat)) return;

        float yaw = mc.player.getYaw();
        float forward = mc.player.input.movementForward;
        float sideways = mc.player.input.movementSideways;
        float s = speed.getCurrent();

        double mx = 0;
        double mz = 0;

        if (forward != 0f || sideways != 0f) {
            float sin = MathHelper.sin(yaw * 0.017453292f);
            float cos = MathHelper.cos(yaw * 0.017453292f);

            mx = (forward * s) * (-sin) + (sideways * s) * cos;
            mz = (forward * s) * cos + (sideways * s) * sin;

            double len = Math.sqrt(mx * mx + mz * mz);
            if (len > s) {
                mx = mx / len * s;
                mz = mz / len * s;
            }
        }

        double my;
        if (mc.options.jumpKey.isPressed()) {
            my = verticalSpeed.getCurrent();
        } else if (mc.options.sneakKey.isPressed()) {
            my = -verticalSpeed.getCurrent();
        } else if (glide.isEnabled()) {
            my = -glideSpeed.getCurrent();
        } else {
            my = 0.0;
        }

        boat.setVelocity(new Vec3d(mx, my, mz));
        boat.velocityModified = true;
    }

    @EventTarget
    public void onPacket(EventPacket event) {
        if (!noFall.isEnabled() || !event.isSent() || mc.player == null) return;
        if (!(event.getPacket() instanceof PlayerMoveC2SPacket packet)) return;
        if (mc.player.fallDistance > 0.5f) {
            ((PlayerMoveC2SPacketAccessor) packet).setOnGround(true);
        }
    }
}
