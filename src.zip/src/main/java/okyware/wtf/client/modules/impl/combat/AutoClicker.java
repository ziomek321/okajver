package okyware.wtf.client.modules.impl.combat;

import com.darkmagician6.eventapi.EventTarget;
import okyware.wtf.base.events.impl.player.EventUpdate;
import okyware.wtf.client.modules.api.Category;
import okyware.wtf.client.modules.api.Module;
import okyware.wtf.client.modules.api.ModuleAnnotation;
import okyware.wtf.client.modules.api.setting.impl.NumberSetting;
import net.minecraft.client.util.InputUtil;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.util.hit.HitResult;
import org.lwjgl.glfw.GLFW;

@ModuleAnnotation(name = "AutoClicker", category = Category.COMBAT, description = "Simulates mouse clicks at adjustable intervals for sustained combat")
public final class AutoClicker extends Module {
    public static final AutoClicker INSTANCE = new AutoClicker();
    
    private final NumberSetting cps = new NumberSetting("CPS", 10, 1, 20, 1);
    private long lastClick = 0;

    private AutoClicker() {}

    @EventTarget
    public void onUpdate(EventUpdate event) {
        if (mc.currentScreen != null) return;
        
        if (InputUtil.isKeyPressed(mc.getWindow().getHandle(), GLFW.GLFW_MOUSE_BUTTON_LEFT)) {
            long delay = (long) (1000 / cps.getCurrent());
            if (System.currentTimeMillis() - lastClick >= delay) {
                mc.player.swingHand(Hand.MAIN_HAND);
                if (mc.crosshairTarget != null && mc.crosshairTarget.getType() == HitResult.Type.ENTITY) {
                    mc.interactionManager.attackEntity(mc.player, ((EntityHitResult) mc.crosshairTarget).getEntity());
                }
                lastClick = System.currentTimeMillis();
            }
        }
    }
}
