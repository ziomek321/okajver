package okyware.wtf.client.modules.impl.movement;

import com.darkmagician6.eventapi.EventTarget;


import net.minecraft.util.Hand;
import okyware.wtf.base.events.impl.player.EventSlowWalking;
import okyware.wtf.base.events.impl.player.EventUpdate;
import okyware.wtf.client.modules.api.Category;
import okyware.wtf.client.modules.api.Module;
import okyware.wtf.client.modules.api.ModuleAnnotation;
import okyware.wtf.client.modules.api.setting.impl.BooleanSetting;
import okyware.wtf.client.modules.api.setting.impl.ModeSetting;
import okyware.wtf.utility.game.player.PlayerIntersectionUtil;

@ModuleAnnotation(name = "NoSlow", category = Category.MOVEMENT, description = "Removes slowdown while eating")
public final class NoSlow extends Module {
    public static final NoSlow INSTANCE = new NoSlow();

    private NoSlow() {
    }

    private final ModeSetting mode = new ModeSetting("Mode");
    private final ModeSetting.Value grimNew = new ModeSetting.Value(mode, "Grim New");
    private final ModeSetting.Value hw = new ModeSetting.Value(mode, "Grim old").select();
    private final ModeSetting.Value polar = new ModeSetting.Value(mode, "Polar");
    private BooleanSetting sprint = new BooleanSetting("Sprint",true, hw::isSelected);
    private  int ticks = 0;
    @EventTarget
    public void onItemUse(EventSlowWalking e) {
        if(grimNew.isSelected()){
            if(mc.player.getItemUseTime() %2==0){
                e.setCancelled(true);
            }
        }
        if (polar.isSelected()) {
            
            
            if (mc.player.getItemUseTime() % 3 != 0) {
                e.setCancelled(true);
            }
        }
        if(hw.isSelected()){
            Hand hand = mc.player.getActiveHand();
            if(sprint.isEnabled()){
                mc.player.setSprinting(mc.player.canSprint()	&& mc.player.isWalking() &&	 !mc.player.isBlind() && !mc.player.isGliding()&& (!mc.player.shouldSlowDown() || mc.player.isSubmergedInWater()));
            }
            PlayerIntersectionUtil.useItem(hand.equals(Hand.MAIN_HAND) ? Hand.OFF_HAND : Hand.MAIN_HAND);
            e.setCancelled(true);
        }

    }


    @EventTarget
    public void update(EventUpdate tickEvent) {
        if (mc.player.isUsingItem() &&mc.player.isOnGround()) {



         
        }else {
            ticks=0;
        }
    }
}


