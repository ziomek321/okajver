package okyware.wtf.client.modules.impl.movement;

import com.darkmagician6.eventapi.EventTarget;
import okyware.wtf.base.events.impl.player.EventUpdate;
import okyware.wtf.base.rotation.RotationTarget;
import okyware.wtf.base.rotation.mods.config.InterpolationRotationConfig;
import okyware.wtf.client.modules.api.Category;
import okyware.wtf.client.modules.api.Module;
import okyware.wtf.client.modules.api.ModuleAnnotation;
import okyware.wtf.client.modules.api.setting.impl.BooleanSetting;
import okyware.wtf.client.modules.api.setting.impl.ModeSetting;
import okyware.wtf.client.modules.api.setting.impl.NumberSetting;
import okyware.wtf.utility.game.player.rotation.Rotation;
import okyware.wtf.utility.game.player.rotation.RotationUtil;
import okyware.wtf.utility.math.IntRange;
import net.minecraft.item.BlockItem;
import net.minecraft.item.ItemStack;
import net.minecraft.network.packet.c2s.play.PlayerInteractBlockC2SPacket;
import net.minecraft.network.packet.c2s.play.UpdateSelectedSlotC2SPacket;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;
import okyware.wtf.client.modules.impl.render.PlaceHighlight;

@ModuleAnnotation(name = "Scaffold", category = Category.MOVEMENT, description = "Places blocks beneath you as you walk")
public final class Scaffold extends Module {
    public static final Scaffold INSTANCE = new Scaffold();

    private final ModeSetting mode = new ModeSetting("Mode", "Normal", "Legit", "Polar");
    private final BooleanSetting safeWalk = new BooleanSetting("Safe Walk", true);
    private final BooleanSetting silentSwitch = new BooleanSetting("Silent Switch", true, () -> !mode.is("Legit"));
    private final NumberSetting delay = new NumberSetting("Delay", 80, 0, 300, 5, () -> !mode.is("Normal"));
    private final BooleanSetting tower = new BooleanSetting("Tower", true, () -> mode.is("Polar"));

    private final InterpolationRotationConfig polarRotConfig = new InterpolationRotationConfig(
            new IntRange(20, 30), new IntRange(15, 25), new IntRange(40, 60), 0.5f
    );

    private long lastPlace = 0;
    private BlockHitResult pendingPlace = null;

    private Scaffold() {}

    @Override
    public void onDisable() {
        if (mc.player != null) {
            mc.options.sneakKey.setPressed(false);
        }
        pendingPlace = null;
        super.onDisable();
    }

    @EventTarget
    public void onUpdate(EventUpdate event) {
        if (mc.player == null || mc.world == null) return;

        switch (mode.get()) {
            case "Legit" -> handleLegit();
            case "Polar" -> handlePolar();
            default -> handleNormal();
        }
    }

    private void handlePolar() {
        BlockPos below = mc.player.getBlockPos().down();
        boolean overAir = mc.world.getBlockState(below).isReplaceable();

        // Safe walk on edge
        mc.options.sneakKey.setPressed(overAir && mc.player.isOnGround());

        // Try to place pending block if rotation is close enough
        if (pendingPlace != null && System.currentTimeMillis() - lastPlace >= (long) delay.getCurrent()) {
            int slot = findBlockSlot();
            if (slot != -1) {
                int prevSlot = mc.player.getInventory().selectedSlot;
                if (silentSwitch.isEnabled()) {
                    mc.getNetworkHandler().sendPacket(new UpdateSelectedSlotC2SPacket(slot));
                    mc.player.getInventory().selectedSlot = slot;
                } else {
                    mc.player.getInventory().selectedSlot = slot;
                }

                mc.getNetworkHandler().sendPacket(new PlayerInteractBlockC2SPacket(Hand.MAIN_HAND, pendingPlace, 0));
                mc.player.swingHand(Hand.MAIN_HAND);
                PlaceHighlight.mark(pendingPlace.getBlockPos().offset(pendingPlace.getSide()));
                lastPlace = System.currentTimeMillis();

                if (silentSwitch.isEnabled()) {
                    mc.getNetworkHandler().sendPacket(new UpdateSelectedSlotC2SPacket(prevSlot));
                    mc.player.getInventory().selectedSlot = prevSlot;
                }
            }
            pendingPlace = null;
        }

        if (!overAir) return;
        if (System.currentTimeMillis() - lastPlace < (long) delay.getCurrent()) return;

        // Find placement
        BlockHitResult hit = findPlacement(below);
        if (hit == null) return;

        // Rotate head toward placement point
        Vec3d eyes = mc.player.getEyePos();
        Rotation targetRot = RotationUtil.fromVec3d(hit.getPos().subtract(eyes));

        rotationManager.setRotation(
                new RotationTarget(targetRot, () -> aimManager.rotate(polarRotConfig, targetRot), polarRotConfig),
                2, this
        );

        // Queue the place for next tick (after rotation arrives)
        pendingPlace = hit;
    }

    private void handleLegit() {
        BlockPos below = mc.player.getBlockPos().down();
        boolean overAir = mc.world.getBlockState(below).isReplaceable();

        mc.options.sneakKey.setPressed(overAir);

        if (!overAir) return;
        if (System.currentTimeMillis() - lastPlace < (long) delay.getCurrent()) return;
        if (mc.crosshairTarget == null || mc.crosshairTarget.getType() != HitResult.Type.BLOCK) return;
        BlockHitResult crosshairHit = (BlockHitResult) mc.crosshairTarget;

        BlockPos placePos = crosshairHit.getBlockPos().offset(crosshairHit.getSide());
        if (placePos.getY() > below.getY()) return;

        int slot = findBlockSlot();
        if (slot == -1) return;

        int prevSlot = mc.player.getInventory().selectedSlot;
        if (prevSlot != slot) mc.player.getInventory().selectedSlot = slot;

        mc.interactionManager.interactBlock(mc.player, Hand.MAIN_HAND, crosshairHit);
        mc.player.swingHand(Hand.MAIN_HAND);
        PlaceHighlight.mark(placePos);
        lastPlace = System.currentTimeMillis();
    }

    private void handleNormal() {
        if (safeWalk.isEnabled() && !mc.player.isOnGround()) {
            mc.options.sneakKey.setPressed(true);
        }

        BlockPos below = mc.player.getBlockPos().down();
        if (!mc.world.getBlockState(below).isReplaceable()) return;

        int slot = findBlockSlot();
        if (slot == -1) return;

        BlockHitResult hit = findPlacement(below);
        if (hit == null) return;

        int prevSlot = mc.player.getInventory().selectedSlot;
        switchTo(slot);

        mc.getNetworkHandler().sendPacket(new PlayerInteractBlockC2SPacket(Hand.MAIN_HAND, hit, 0));
        mc.player.swingHand(Hand.MAIN_HAND);
        PlaceHighlight.mark(below);
        lastPlace = System.currentTimeMillis();

        if (silentSwitch.isEnabled()) switchTo(prevSlot);
    }

    private BlockHitResult findPlacement(BlockPos target) {
        for (Direction side : Direction.values()) {
            if (side == Direction.UP) continue;
            BlockPos neighbor = target.offset(side);
            if (mc.world.getBlockState(neighbor).isAir() || mc.world.getBlockState(neighbor).isReplaceable()) continue;

            Direction opposite = side.getOpposite();
            Vec3d hitVec = new Vec3d(
                    neighbor.getX() + 0.5 + opposite.getOffsetX() * 0.5,
                    neighbor.getY() + 0.5 + opposite.getOffsetY() * 0.5,
                    neighbor.getZ() + 0.5 + opposite.getOffsetZ() * 0.5);
            return new BlockHitResult(hitVec, opposite, neighbor, false);
        }
        return null;
    }

    private void switchTo(int slot) {
        mc.getNetworkHandler().sendPacket(new UpdateSelectedSlotC2SPacket(slot));
        mc.player.getInventory().selectedSlot = slot;
    }

    private int findBlockSlot() {
        for (int i = 0; i < 9; i++) {
            ItemStack stack = mc.player.getInventory().getStack(i);
            if (!stack.isEmpty() && stack.getItem() instanceof BlockItem) return i;
        }
        return -1;
    }
}
