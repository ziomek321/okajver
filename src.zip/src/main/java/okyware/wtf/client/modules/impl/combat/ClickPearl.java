package okyware.wtf.client.modules.impl.combat;

import com.darkmagician6.eventapi.EventTarget;
import net.minecraft.item.Items;
import net.minecraft.network.packet.c2s.play.PlayerInteractItemC2SPacket;
import net.minecraft.network.packet.c2s.play.UpdateSelectedSlotC2SPacket;
import net.minecraft.util.Hand;


import okyware.wtf.base.events.impl.player.EventUpdate;
import okyware.wtf.client.modules.api.Category;
import okyware.wtf.client.modules.api.Module;
import okyware.wtf.client.modules.api.ModuleAnnotation;
import okyware.wtf.utility.game.other.InventoryUtil;
import okyware.wtf.utility.game.other.NetworkUtils;
import okyware.wtf.utility.game.player.PlayerInventoryUtil;

@ModuleAnnotation(name = "ClickPearl", category = Category.COMBAT,description = "Instantly swaps to and throws an ender pearl on key press")
public final class ClickPearl extends Module {
    public static final ClickPearl INSTANCE = new ClickPearl();
    private ClickPearl() {
    }

    @Override
    public void onEnable() {
        PlayerInventoryUtil.swapAndUse(Items.ENDER_PEARL);
        super.onEnable();
        this.toggle();
    }
}
