package okyware.wtf.client.modules.impl.render;

import com.mojang.blaze3d.systems.RenderSystem;
import net.minecraft.client.gl.GlUniform;
import net.minecraft.client.render.*;
import org.joml.Matrix4f;
import okyware.wtf.Okyware;
import okyware.wtf.client.modules.api.Category;
import okyware.wtf.client.modules.api.Module;
import okyware.wtf.client.modules.api.ModuleAnnotation;
import okyware.wtf.client.modules.api.setting.impl.ColorSetting;
import okyware.wtf.client.modules.api.setting.impl.ModeSetting;
import okyware.wtf.client.modules.api.setting.impl.NumberSetting;
import okyware.wtf.utility.render.display.base.color.ColorRGBA;
import okyware.wtf.utility.render.display.shader.GlProgram;
import okyware.wtf.client.modules.api.setting.impl.ColorSetting;


@ModuleAnnotation(name = "CustomSky", category = Category.RENDER, description = "Custom shader sky")
public final class CustomSky extends Module {
    public static final CustomSky INSTANCE = new CustomSky();

    public final ModeSetting mode = new ModeSetting("Mode", "Water", "Caustic", "Plasma");
    public final NumberSetting speed = new NumberSetting("Speed", 1.0f, 0.1f, 5.0f, 0.1f);
    public final NumberSetting scale = new NumberSetting("Scale", 5.0f, 1.0f, 20.0f, 0.5f);
    public final NumberSetting intensity = new NumberSetting("Intensity", 0.01f, 0.001f, 0.05f, 0.001f);
    public final NumberSetting alpha = new NumberSetting("Alpha", 1.0f, 0.3f, 1.0f, 0.05f);
    public final ColorSetting skyColor = new ColorSetting("Color", new ColorRGBA(156, 255, 190));
    public final ColorSetting skyColor2 = new ColorSetting("Color 2", new ColorRGBA(255, 200, 135));

    private static final GlProgram WATER_SHADER = new GlProgram(Okyware.id("skyshader/water"), VertexFormats.POSITION);
    private static final GlProgram CAUSTIC_SHADER = new GlProgram(Okyware.id("skyshader/caustic"), VertexFormats.POSITION);
    private static final GlProgram PLASMA_SHADER = new GlProgram(Okyware.id("skyshader/sky_plasma"), VertexFormats.POSITION);

    private long startMillis = -1;

    private CustomSky() {}

    @Override
    public void onEnable() {
        startMillis = System.currentTimeMillis();
        super.onEnable();
    }

    @Override
    public void onDisable() {
        startMillis = -1;
        super.onDisable();
    }

    public void renderSkyShader() {
        if (mc.player == null || mc.world == null) return;
        if (startMillis < 0) startMillis = System.currentTimeMillis();

        float time = (System.currentTimeMillis() - startMillis) / 1000.0f;
        float fw = mc.getWindow().getFramebufferWidth();
        float fh = mc.getWindow().getFramebufferHeight();

        ColorRGBA c1 = skyColor.getColor();
        ColorRGBA c2 = skyColor2.getColor();
        float cr = c1.getRed() / 255f, cg = c1.getGreen() / 255f, cb = c1.getBlue() / 255f;
        float cr2 = c2.getRed() / 255f, cg2 = c2.getGreen() / 255f, cb2 = c2.getBlue() / 255f;

        GlProgram shader = mode.is("Plasma") ? PLASMA_SHADER : mode.is("Caustic") ? CAUSTIC_SHADER : WATER_SHADER;
        if (shader == null) return;

        shader.use();

        net.minecraft.client.render.Camera cam = mc.gameRenderer.getCamera();
        float yawRad = (float) Math.toRadians(-cam.getYaw());
        float pitchRad = (float) Math.toRadians(cam.getPitch());
        float fovDeg = (float) mc.options.getFov().getValue().intValue();

        if (mode.is("Plasma")) {
            setUniform(shader, "u_Color", cr, cg, cb, alpha.getCurrent());
            setUniform(shader, "u_Color2", cr2, cg2, cb2, alpha.getCurrent());
            setUniform(shader, "u_Resolution", fw, fh);
            setUniform(shader, "u_Scale", scale.getCurrent());
            setUniform(shader, "u_Time", time * speed.getCurrent());
            setUniform(shader, "u_Fov", fovDeg);
            setUniform(shader, "u_CameraDir", yawRad, pitchRad);
        } else {
            setUniform(shader, "uTime", time);
            setUniform(shader, "uResolution", fw, fh);
            setUniform(shader, "uColor", cr, cg, cb);
            setUniform(shader, "uAlpha", alpha.getCurrent());
            setUniform(shader, "uSpeed", speed.getCurrent());
            setUniform(shader, "uScale", scale.getCurrent());
            setUniform(shader, "uIntensity", intensity.getCurrent());
            setUniform(shader, "uCameraDir", yawRad, pitchRad);
            setUniform(shader, "uFov", fovDeg);
        }

        Matrix4f savedProj = new Matrix4f(RenderSystem.getProjectionMatrix());
        RenderSystem.setProjectionMatrix(new Matrix4f(), com.mojang.blaze3d.systems.ProjectionType.ORTHOGRAPHIC);
        RenderSystem.getModelViewStack().pushMatrix();
        RenderSystem.getModelViewStack().identity();
        RenderSystem.enableBlend();
        RenderSystem.defaultBlendFunc();
        RenderSystem.enableDepthTest();
        RenderSystem.depthFunc(org.lwjgl.opengl.GL11.GL_LEQUAL);
        RenderSystem.depthMask(false);
        RenderSystem.disableCull();

        Matrix4f identity = new Matrix4f();
        BufferBuilder buf = Tessellator.getInstance().begin(VertexFormat.DrawMode.QUADS, VertexFormats.POSITION);
        buf.vertex(identity, -1f, -1f, 0f);
        buf.vertex(identity, 1f, -1f, 0f);
        buf.vertex(identity, 1f, 1f, 0f);
        buf.vertex(identity, -1f, 1f, 0f);
        BufferRenderer.drawWithGlobalProgram(buf.end());

        RenderSystem.getModelViewStack().popMatrix();
        RenderSystem.depthMask(true);
        RenderSystem.enableCull();
        RenderSystem.disableBlend();
        RenderSystem.depthFunc(org.lwjgl.opengl.GL11.GL_LEQUAL);
        RenderSystem.setProjectionMatrix(savedProj, com.mojang.blaze3d.systems.ProjectionType.PERSPECTIVE);
    }

    private void setUniform(GlProgram program, String name, float... values) {
        GlUniform u = program.findUniform(name);
        if (u == null) return;
        if (values.length == 1) u.set(values[0]);
        else if (values.length == 2) u.set(values[0], values[1]);
        else if (values.length == 3) u.set(values[0], values[1], values[2]);
        else if (values.length == 4) u.set(values[0], values[1], values[2], values[3]);
    }
}
