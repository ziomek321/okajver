package okyware.wtf.client.modules.impl.render;

import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.Arm;
import okyware.wtf.client.modules.api.Category;
import okyware.wtf.client.modules.api.Module;
import okyware.wtf.client.modules.api.ModuleAnnotation;
import okyware.wtf.client.modules.api.setting.impl.NumberSetting;

@ModuleAnnotation(name = "ViewModel", category = Category.RENDER, description = "Adjusts the position, rotation, and scale of your held item model")
public final class ViewModel extends Module {
    public static final ViewModel INSTANCE = new ViewModel();

    private ViewModel() {
    }

    public final NumberSetting leftX = new NumberSetting("Left hand X", 0.0f, -1.0f, 1.0f, 0.1f);
    public final NumberSetting leftY = new NumberSetting("Left hand Y", 0.0f, -1.0f, 1.0f, 0.1f);
    public final NumberSetting leftZ = new NumberSetting("Left hand Z", 0.0f, -1.0f, 1.0f, 0.1f);
    public final NumberSetting leftScale = new NumberSetting("Left hand size", 1.0f, 0.5f, 1.5f, 0.05f);

    public final NumberSetting rightX = new NumberSetting("Right hand X", 0.0f, -1.0f, 1.0f, 0.1f);
    public final NumberSetting rightY = new NumberSetting("Right hand Y", 0.0f, -1.0f, 1.0f, 0.1f);
    public final NumberSetting rightZ = new NumberSetting("Right hand Z", 0.0f, -1.0f, 1.0f, 0.1f);
    public final NumberSetting rightScale = new NumberSetting("Right hand size", 1.0f, 0.5f, 1.5f, 0.05f);


    public void applyHandScale(MatrixStack matrices, Arm arm) {
        if (this.isEnabled()) {
            if (arm == Arm.RIGHT) {
                matrices.scale(rightScale.getCurrent(), rightScale.getCurrent(), rightScale.getCurrent());
            } else {
                matrices.scale(leftScale.getCurrent(), leftScale.getCurrent(), leftScale.getCurrent());
            }
        } else {
            matrices.scale(1.0f, 1.0f, 1.0f);
        }
    }

    public void applyHandPosition(MatrixStack matrices, Arm arm) {
        if (this.isEnabled()) {
            if (arm == Arm.RIGHT) {
                matrices.translate(rightX.getCurrent(), rightY.getCurrent(), rightZ.getCurrent());
            } else {
                matrices.translate(-leftX.getCurrent(), leftY.getCurrent(), leftZ.getCurrent());
            }
        } else {
            matrices.translate(0.0f, 0.0f, 0.0f);
        }
    }
}