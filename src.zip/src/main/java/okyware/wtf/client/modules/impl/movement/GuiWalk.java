package okyware.wtf.client.modules.impl.movement;

import com.darkmagician6.eventapi.EventTarget;
import net.minecraft.client.gui.screen.ChatScreen;
import net.minecraft.client.gui.screen.ingame.SignEditScreen;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;


import net.minecraft.network.packet.Packet;
import net.minecraft.network.packet.c2s.play.ClickSlotC2SPacket;
import net.minecraft.network.packet.s2c.play.CloseScreenS2CPacket;
import net.minecraft.screen.slot.Slot;
import net.minecraft.screen.slot.SlotActionType;

import okyware.wtf.base.events.impl.other.EventClickSlot;
import okyware.wtf.base.events.impl.other.EventCloseScreen;
import okyware.wtf.base.events.impl.player.EventUpdate;
import okyware.wtf.base.events.impl.server.EventPacket;
import okyware.wtf.client.modules.api.Category;
import okyware.wtf.client.modules.api.Module;
import okyware.wtf.client.modules.api.ModuleAnnotation;
import okyware.wtf.utility.game.player.MovingUtil;
import okyware.wtf.utility.game.player.PlayerIntersectionUtil;
import okyware.wtf.utility.game.player.PlayerInventoryComponent;
import okyware.wtf.utility.game.player.PlayerInventoryUtil;

import java.util.ArrayList;
import java.util.List;

import okyware.wtf.client.modules.api.setting.impl.ModeSetting;
import net.minecraft.network.packet.c2s.play.CloseHandledScreenC2SPacket;
import java.util.concurrent.CopyOnWriteArrayList;

@ModuleAnnotation(name = "Gui Walk", category = Category.MOVEMENT, description = "Walk while in inventory or container")
public final class GuiWalk extends Module {
    public static final GuiWalk INSTANCE = new GuiWalk();

    private final ModeSetting mode = new ModeSetting("Mode", "Vanilla", "Grim");

    private GuiWalk() {
    }

    private final List<Packet<?>> packets = new CopyOnWriteArrayList<>();

    @EventTarget
    public void onPacket(EventPacket e) {
        if (mode.is("Grim")) {
            if (e.getPacket() instanceof ClickSlotC2SPacket && mc.player.currentScreenHandler != null) {
                packets.add(e.getPacket());
                e.cancel();
            } else if (e.getPacket() instanceof CloseHandledScreenC2SPacket && !packets.isEmpty()) {
                e.cancel();
                new Thread(() -> {
                    try {
                        Thread.sleep(50L);
                        packets.forEach(p -> mc.getNetworkHandler().sendPacket(p));
                        packets.clear();
                        mc.getNetworkHandler().sendPacket(new CloseHandledScreenC2SPacket(0));
                    } catch (Exception ignored) {}
                }).start();
            }
            return;
        }

        switch (e.getPacket()) {
            case ClickSlotC2SPacket slot when (!packets.isEmpty() || MovingUtil.hasPlayerMovement()) && PlayerInventoryComponent.shouldSkipExecution() -> {

                packets.add(slot);
                e.cancel();

            }
            case CloseScreenS2CPacket screen when screen.getSyncId() == 0 -> e.cancel();
            default -> {
            }
        }
    }

    @EventTarget
    public void onTick(EventUpdate e) {

        if (!PlayerInventoryUtil.isServerScreen() && PlayerInventoryComponent.shouldSkipExecution() && (!packets.isEmpty() || mc.player.currentScreenHandler.getCursorStack().isEmpty())) {
            PlayerInventoryComponent.updateMoveKeys();
        }

    }

    @EventTarget
    public void onClickSlot(EventClickSlot e) {
        System.out.println(e.getSlotId() +" " + e.getButton());
        if (mc.player.currentScreenHandler.isValid(e.getSlotId())) {
            Slot slot = mc.player.currentScreenHandler.getSlot(e.getSlotId());
        }
        SlotActionType actionType = e.getActionType();
        if ((!packets.isEmpty() || MovingUtil.hasPlayerMovement()) && ((e.getButton() == 1 &&( !actionType.equals(SlotActionType.SWAP)   &&! actionType.equals(SlotActionType.THROW))  ))) {
            e.setCancelled(true);

        }
    }

    @EventTarget
    public void onCloseScreen(EventCloseScreen e) {
        if (!packets.isEmpty()) PlayerInventoryComponent.addTask(() -> {
            packets.forEach(PlayerIntersectionUtil::sendPacketWithOutEvent);
            packets.clear();
            PlayerInventoryUtil.updateSlots();

        });
    }
}