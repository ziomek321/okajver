package okyware.wtf.client.modules.impl.misc;

import okyware.wtf.client.modules.api.Module;
import okyware.wtf.client.modules.api.ModuleAnnotation;
import okyware.wtf.client.modules.api.Category;

@ModuleAnnotation(name = "NoInteract", category = Category.MISC, description = "Blocks accidental interactions with chests, crafting tables, and other containers")
public final class NoInteract extends Module {
    public static final NoInteract INSTANCE = new NoInteract();
    
    private NoInteract() {
    }
}
