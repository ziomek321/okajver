package okyware.wtf.client.modules.impl.render;

import com.darkmagician6.eventapi.EventTarget;
import com.google.gson.JsonObject;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.ChatScreen;
import net.minecraft.client.util.math.Vector2f;
import okyware.wtf.Okyware;

import okyware.wtf.base.events.impl.input.EventSetScreen;
import okyware.wtf.base.events.impl.other.EventWindowResize;
import okyware.wtf.base.events.impl.player.EventUpdate;
import okyware.wtf.base.events.impl.render.EventHudRender;
import okyware.wtf.base.events.impl.input.EventMouse;
import okyware.wtf.client.hud.elements.component.*;
import okyware.wtf.client.hud.elements.draggable.DraggableHudElement;
import okyware.wtf.client.modules.api.Category;
import okyware.wtf.client.modules.api.Module;
import okyware.wtf.client.modules.api.ModuleAnnotation;
import okyware.wtf.client.modules.api.setting.impl.BooleanSetting;
import okyware.wtf.client.modules.api.setting.impl.ModeSetting;
import okyware.wtf.client.modules.api.setting.impl.MultiBooleanSetting;
import okyware.wtf.client.modules.api.setting.impl.ColorSetting;
import okyware.wtf.client.modules.api.setting.impl.NumberSetting;
import okyware.wtf.utility.render.display.base.color.ColorRGBA;
import okyware.wtf.utility.game.other.TextUtil;
import okyware.wtf.utility.math.MathUtil;
import okyware.wtf.utility.render.display.base.CustomDrawContext;
import okyware.wtf.utility.render.display.base.GuiUtil;
import okyware.wtf.utility.render.display.base.UIContext;
import okyware.wtf.utility.render.display.base.ChangeRect;
import okyware.wtf.utility.game.other.MouseButton;
import okyware.wtf.client.screens.menu.settings.impl.popup.HudSettingsPopup;
import lombok.Getter;
import lombok.Setter;

import java.util.*;

import static okyware.wtf.utility.render.display.Render2DUtil.glowCache;

@ModuleAnnotation(name = "Interface", category = Category.RENDER, description = "Controls the on-screen HUD layout, watermark, and module list overlay")
public final class Interface extends Module {
    public static final Interface INSTANCE = new Interface();

    private final MultiBooleanSetting elementsSetting = MultiBooleanSetting.create("Elements", List.of(
            "Effects",         
            "Staff",           
            "Notifications",   
            "Inventory",       
            "Cooldowns",       
            "Keybinds",        
            "Tab",             
            "ArrayList",       
            "Watermark",       
            "TargetHUD",       
            "BPS",             
            "Music"            
            ));



    private final List<DraggableHudElement> elements = new ArrayList<>();
    private DraggableHudElement draggingElement = null;
    private HudSettingsPopup currentPopup = null;
    @Getter @Setter
    private okyware.wtf.client.screens.menu.settings.api.MenuPopupSetting currentColorPopup = null;
    private float dragOffsetX, dragOffsetY;
    private final NumberSetting scale = new NumberSetting("Size", autoScale(), 1, 6, 0.1f, ((oldValue, newValue) -> {
        float width = mc.getWindow().getWidth() / newValue;
        float height = mc.getWindow().getHeight() / newValue;

        for (DraggableHudElement element : elements) {
            element.windowResized(width, height);
        }
    }
    ));


    private static float autoScale() {
        try {
            int h = MinecraftClient.getInstance().getWindow().getHeight();
            
            return Math.max(2f, Math.min(6f, h / 540f));
        } catch (Throwable t) {
            return 2f;
        }
    }
    public boolean isBorders() {
        return false;
    }

    private Interface() {


        
        addElement(new PotionsComponent("Potions", 0.0f, 0.0f, 960.0f, 495.5f, 119.15234f, 73.0f, DraggableHudElement.Align.TOP_LEFT));       
        addElement(new StaffComponent("Staff", 0.0f, 0.0f, 960.0f, 495.5f, 10.0f, 73.0f, DraggableHudElement.Align.TOP_LEFT));                

        addElement(new InventoryComponent("Inventory", 269.0f, 229.0f, 960.0f, 495.5f, -11.5f, -74.0f, DraggableHudElement.Align.BOTTOM_RIGHT)); 
        addElement(new CooldownComponent("Cooldown", 349.0f, 0.0f, 960.0f, 495.5f, -11.5f, 73.0f, DraggableHudElement.Align.TOP_RIGHT));        
        addElement(new KeybindsComponent("Keybinds", 349.0f, 0.0f, 960.0f, 495.5f, -122.0f, 73.0f, DraggableHudElement.Align.TOP_RIGHT));      
        
        
        addElement(new PlayerListComponent("Tab"));      
        addElement(new ArrayListComponent("ArrayList", 0.0f, 0.0f, 960.0f, 495.5f, -10.0f, 10.0f, DraggableHudElement.Align.TOP_RIGHT)); 
        addElement(new WatermarkComponent("Watermark", 0.0f, 0.0f, 960.0f, 495.5f, 10.0f, 10.0f, DraggableHudElement.Align.TOP_LEFT)); 
        addElement(new TargetHudComponent("TargetHUD", 0.0f, 0.0f, 960.0f, 495.5f, 0.0f, 0.0f, DraggableHudElement.Align.CENTER)); 
        addElement(new BpsComponent("BPS", 0.0f, 0.0f, 960.0f, 495.5f, 0.0f, 60.0f, DraggableHudElement.Align.BOTTOM_CENTER)); 
        try {
            addElement(new MusicInfoComponent("Music", 0.0f, 0.0f, 960.0f, 495.5f, 10.0f, -10.0f, DraggableHudElement.Align.BOTTOM_LEFT)); 
        } catch (NoClassDefFoundError ignored) {
        }

    }

    long init = 0;

    @Override
    public void onEnable() {
        init = System.currentTimeMillis();
        super.onEnable();
    }

    @Override
    public JsonObject save() {
        JsonObject object = super.save();
        JsonObject propertiesObject = new JsonObject();

        for (DraggableHudElement element : elements) {
            propertiesObject.add(element.getName(), element.save());
        }

        object.add("HudElements", propertiesObject);
        return object;
    }

    @Override
    public void load(JsonObject object) {
        super.load(object);

        if (object.has("HudElements") && object.get("HudElements").isJsonObject()) {
            JsonObject propertiesObject = object.getAsJsonObject("HudElements");

            float width = mc.getWindow().getWidth() / getCustomScale();
            float height = mc.getWindow().getHeight() / getCustomScale();
            for (DraggableHudElement element : elements) {
                String key = element.getName();
                if (propertiesObject.has(key) && propertiesObject.get(key).isJsonObject()) {
                    element.load(propertiesObject.getAsJsonObject(key));
                    element.windowResized(width, height);
                }
            }
        }
    }


    private void addElement(DraggableHudElement element) {
        elements.add(element);
    }

    @EventTarget
    public void onRender(EventHudRender event) {
        if (!(mc.currentScreen instanceof ChatScreen)) {
            if(draggingElement!=null){
                draggingElement.release();
                draggingElement = null;
            }
            if (currentPopup != null && currentPopup.isClosing()) {
                currentPopup = null;
            }
            if (currentColorPopup != null && currentColorPopup.isClosing()) {
                currentColorPopup = null;
            }
        }
        CustomDrawContext ctx = event.getContext();

        float width = mc.getWindow().getWidth() / getCustomScale();
        float height = mc.getWindow().getHeight() / getCustomScale();
        
        
        if (!mc.options.hudHidden) {
            for (DraggableHudElement element : elements) {
                if (!shouldRender(element)) continue;

                try {
                    ctx.pushMatrix();
                    ctx.getMatrices().translate(element.getX(), element.getY(), 0);
                    ctx.getMatrices().scale(element.getScale(), element.getScale(), 1);
                    ctx.getMatrices().translate(-element.getX(), -element.getY(), 0);

                    float oldW = element.getWidth();
                    float oldH = element.getHeight();
                    
                    element.render(ctx);
                    
                    if (draggingElement != element && (oldW != element.getWidth() || oldH != element.getHeight())) {
                        element.windowResized(width, height);
                    }

                    if (mc.currentScreen instanceof ChatScreen) {
                        element.drawBorder(ctx);
                    }

                    ctx.popMatrix();
                } catch (Exception e) {
                    e.printStackTrace();
                }
                
                
                if (draggingElement != element && System.currentTimeMillis() - init < 5000) {
                    element.windowResized(width, height);
                }
            }
        }
        
        
        if (currentPopup != null && mc.currentScreen instanceof ChatScreen) {
            UIContext uiCtx = UIContext.of(ctx, (int) GuiUtil.getMouse(getCustomScale()).getX(), (int) GuiUtil.getMouse(getCustomScale()).getY(), event.getTickDelta());
            currentPopup.render(uiCtx, GuiUtil.getMouse(getCustomScale()).getX(), GuiUtil.getMouse(getCustomScale()).getY(), 1f, Okyware.getInstance().getThemeManager().getCurrentTheme());
            if (currentPopup.isClosing()) currentPopup = null;
        }

        if (currentColorPopup != null && mc.currentScreen instanceof ChatScreen) {
            UIContext uiCtx = UIContext.of(ctx, (int) GuiUtil.getMouse(getCustomScale()).getX(), (int) GuiUtil.getMouse(getCustomScale()).getY(), event.getTickDelta());
            currentColorPopup.render(uiCtx, GuiUtil.getMouse(getCustomScale()).getX(), GuiUtil.getMouse(getCustomScale()).getY(), 1f, Okyware.getInstance().getThemeManager().getCurrentTheme());
            if (currentColorPopup.isClosing()) currentColorPopup = null;
        }

        
        if ((mc.currentScreen instanceof ChatScreen)) {
            if (draggingElement != null && currentPopup == null && currentColorPopup == null) {
                Vector2f mousePos = GuiUtil.getMouse(getCustomScale());
                double mouseX = mousePos.getX();
                double mouseY = mousePos.getY();
                draggingElement.set(ctx, (float) mouseX - dragOffsetX, (float) mouseY - dragOffsetY, this, width, height);
            }
        }
    }


    private boolean shouldRender(DraggableHudElement element) {
        int index = elements.indexOf(element);
        if (index < 0 || index >= elementsSetting.getBooleanSettings().size()) return false;
        return elementsSetting.getBooleanSettings().get(index).isEnabled();
    }

    @EventTarget
    public void onMouse(EventMouse event) {
        if (!(mc.currentScreen instanceof ChatScreen)) {
            if (draggingElement != null) {
                draggingElement.release();
                draggingElement = null;
            }
            return;
        }
        
        Vector2f mousePos = GuiUtil.getMouse(getCustomScale());
        double mouseX = mousePos.getX();
        double mouseY = mousePos.getY();

        if (currentColorPopup != null && !currentColorPopup.isClosing()) {
            if (event.getAction() == 1) {
                currentColorPopup.onMouseClicked(mouseX, mouseY, MouseButton.fromButtonIndex(event.getButton()));
                ChangeRect b = currentColorPopup.getBounds();
                if (mouseX >= b.getX() && mouseX <= b.getX() + b.getWidth() && mouseY >= b.getY() && mouseY <= b.getY() + b.getHeight()) {
                    return; 
                } else {
                    currentColorPopup.getAnimationScale().update(0);
                    return;
                }
            } else if (event.getAction() == 0) {
                currentColorPopup.onMouseReleased(mouseX, mouseY, MouseButton.fromButtonIndex(event.getButton()));
            }
        }

        if (currentPopup != null && !currentPopup.isClosing()) {
            if (event.getAction() == 1) {
                currentPopup.onMouseClicked(mouseX, mouseY, MouseButton.fromButtonIndex(event.getButton()));
                ChangeRect b = currentPopup.getBounds();
                if (mouseX >= b.getX() && mouseX <= b.getX() + b.getWidth() && mouseY >= b.getY() && mouseY <= b.getY() + b.getHeight()) {
                    return; 
                } else {
                    currentPopup.getAnimationScale().update(0);
                    return;
                }
            } else if (event.getAction() == 0) {
                currentPopup.onMouseReleased(mouseX, mouseY, MouseButton.fromButtonIndex(event.getButton()));
            }
        }

        if (event.getAction() == 1 && event.getButton() == 0) {
            List<DraggableHudElement> reversedElements = new ArrayList<>(elements);
            Collections.reverse(reversedElements);

            for (DraggableHudElement element : reversedElements) {
                if (shouldRender(element) && element.isMouseOver(mouseX, mouseY)) {
                    draggingElement = element;
                    dragOffsetX = (float) mouseX - element.getX();
                    dragOffsetY = (float) mouseY - element.getY();

                    break;
                }
            }
        } else if (event.getAction() == 1 && event.getButton() == 1) { 
            List<DraggableHudElement> reversedElements = new ArrayList<>(elements);
            Collections.reverse(reversedElements);

            boolean clickedElement = false;
            for (DraggableHudElement element : reversedElements) {
                if (shouldRender(element) && element.isMouseOver(mouseX, mouseY)) {
                    if (!element.getSettings().isEmpty()) {
                        currentPopup = new HudSettingsPopup(new ChangeRect((float)mouseX, (float)mouseY, 130, 220), "", element.getSettings());
                    }
                    element.rightClick();
                    clickedElement = true;
                    break;
                }
            }
            
            if (!clickedElement) {
                
                currentPopup = new HudSettingsPopup(new ChangeRect((float)mouseX, (float)mouseY, 130, 220), "", this.getSettings());
            }
        } else if (event.getAction() == 0) {
            if (draggingElement != null) {
                draggingElement.release();
                draggingElement = null;
            }
        }
    }

    public float getCustomScale() {
        return scale.getCurrent();
    }

    public org.joml.Vector2f getNearest(float x, float y) {

        float minDeltaX = Float.MAX_VALUE;
        float minDeltaY = Float.MAX_VALUE;
        float thoroughness = 2;
        org.joml.Vector2f nearest = new org.joml.Vector2f(-1, -1);
        for (DraggableHudElement s : elements) {
            if (s.equals(draggingElement)) continue;
            float tempXA = s.getX();
            float tempYA = s.getY();

            float tempXB = s.getX() + s.getWidth();
            float tempYB = s.getY() + s.getHeight();

            float tempXC = s.getX() + s.getWidth() / 2;
            float tempYC = s.getY() + s.getHeight() / 2;
            float minX = getNearest(tempXA, tempXB, tempXC, x);
            float minY = getNearest(tempYA, tempYB, tempYC, y);
            float deltaX = MathUtil.goodSubtract(minX, x);
            float deltaY = MathUtil.goodSubtract(minY, y);
            if (deltaX < minDeltaX) {
                minDeltaX = deltaX;
                if (minDeltaX < thoroughness) {
                    nearest.x = minX;

                }
            }
            ;
            if (deltaY < minDeltaY) {
                minDeltaY = deltaY;
                if (minDeltaY < thoroughness) {

                    nearest.y = minY;
                }
            }

        }
        if (nearest.x == -1 || nearest.y == -1) {
            float tempXA = mc.getWindow().getScaledWidth() / 2f;
            float tempYA = mc.getWindow().getScaledHeight() / 2f;


            float minX = getNearest(tempXA, tempXA, tempXA, x);
            float minY = getNearest(tempYA, tempYA, tempYA, y);
            float deltaX = MathUtil.goodSubtract(minX, x);
            float deltaY = MathUtil.goodSubtract(minY, y);

            if (deltaX < minDeltaX && deltaX < thoroughness) {
                nearest.x = minX;
            }
            if (deltaY < minDeltaY && deltaY < thoroughness) {
                nearest.y = minY;
            }
        }
        return nearest;
    }

    public float getNearest(float a, float b, float c, float target) {
        float nearest = a;
        if (MathUtil.goodSubtract(b, target) < MathUtil.goodSubtract(nearest, target)) {
            nearest = b;
        }
        if (MathUtil.goodSubtract(c, target) < MathUtil.goodSubtract(nearest, target)) {
            nearest = c;
        }
        return nearest;
    }
    public boolean isEnableScoreBar() {
        return elementsSetting.isEnable(7);
    }
    public boolean isEnableHotBar() {
        return elementsSetting.isEnable(6); 
    }
    public boolean isEnableTab() {
        return elementsSetting.isEnable(8); 
    }

    @EventTarget
    public void resize(EventWindowResize eventWindowResize) {
        float width = mc.getWindow().getWidth() / getCustomScale();
        float height = mc.getWindow().getHeight() / getCustomScale();

        for (DraggableHudElement element : elements) {

            element.windowResized(width, height);

        }
    }

    @EventTarget
    public void update(EventUpdate eventUpdate) {

        if(glowCache.size()>400){
            glowCache.values().removeIf(v -> {
                if (v.tick()) {
                    v.destroy();
                    return true;
                } else {
                    return false;
                }
            });
        }
        for (DraggableHudElement draggableHudElement : elements) {
            draggableHudElement.tick();
        }
        

        ;
    }

    public boolean isBlur() {
        return true;
    }



    public boolean isTransparentBackdrop() {
        return false;
    }

    public okyware.wtf.utility.render.display.base.color.ColorRGBA fadeBackdrop(okyware.wtf.utility.render.display.base.color.ColorRGBA c) {
        return isTransparentBackdrop() ? c.mulAlpha(0f) : c;
    }

    public boolean isGlow() {
        return false;
    }

    public boolean isCorners() {
        return false;
    }
    @EventTarget
    public void screenEvent(EventSetScreen event) {
        if(event.getScreen() instanceof ChatScreen){
            this.init = System.currentTimeMillis();
        }

    }

    public int getGlowRadius() {
        return (int) 10;
    }

    public ColorRGBA getBgColor() {
        return Okyware.getInstance().getThemeManager().getCurrentTheme().getForegroundColor().mulAlpha(0.6f);
    }
}
