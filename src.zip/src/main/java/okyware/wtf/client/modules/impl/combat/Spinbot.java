package okyware.wtf.client.modules.impl.combat;

import com.darkmagician6.eventapi.EventTarget;
import net.minecraft.util.math.MathHelper;
import okyware.wtf.base.events.impl.player.EventMoveInput;
import okyware.wtf.base.events.impl.player.EventRotate;
import okyware.wtf.base.rotation.RotationTarget;
import okyware.wtf.client.modules.api.Category;
import okyware.wtf.client.modules.api.Module;
import okyware.wtf.client.modules.api.ModuleAnnotation;
import okyware.wtf.client.modules.api.setting.impl.BooleanSetting;
import okyware.wtf.client.modules.api.setting.impl.ModeSetting;
import okyware.wtf.client.modules.api.setting.impl.NumberSetting;
import okyware.wtf.utility.game.player.MovingUtil;
import okyware.wtf.utility.game.player.rotation.Rotation;

import java.util.concurrent.ThreadLocalRandom;

@ModuleAnnotation(name = "Spinbot", category = Category.COMBAT, description = "Silently spins the server-side rotation. Client view stays normal.")
public final class Spinbot extends Module {

    public static final Spinbot INSTANCE = new Spinbot();

    private final ModeSetting yawMode = new ModeSetting("Yaw");
    private final ModeSetting.Value yawLinear = new ModeSetting.Value(yawMode, "Linear").select();
    private final ModeSetting.Value yawSine = new ModeSetting.Value(yawMode, "Sine");
    private final ModeSetting.Value yawRandom = new ModeSetting.Value(yawMode, "Random");
    private final ModeSetting.Value yawJitter = new ModeSetting.Value(yawMode, "Jitter");

    private final NumberSetting yawSpeed = new NumberSetting("Yaw Speed", 36f, 1f, 180f, 1f);
    private final NumberSetting sineAmplitude = new NumberSetting("Sine Amp", 180f, 10f, 180f, 5f);
    private final NumberSetting sinePeriod = new NumberSetting("Sine Period", 20f, 4f, 120f, 1f);
    private final NumberSetting jitterStrength = new NumberSetting("Jitter Strength", 35f, 1f, 180f, 1f);
    private final NumberSetting randomPeriod = new NumberSetting("Random Period", 4f, 1f, 40f, 1f);

    private final ModeSetting pitchMode = new ModeSetting("Pitch");
    private final ModeSetting.Value pitchKeep = new ModeSetting.Value(pitchMode, "Keep").select();
    private final ModeSetting.Value pitchLock = new ModeSetting.Value(pitchMode, "Lock");
    private final ModeSetting.Value pitchRandom = new ModeSetting.Value(pitchMode, "Random");

    private final NumberSetting pitchValue = new NumberSetting("Pitch Value", 0f, -90f, 90f, 1f, pitchLock::isSelected);
    private final NumberSetting pitchRandomMin = new NumberSetting("Pitch Min", -45f, -90f, 90f, 1f, pitchRandom::isSelected);
    private final NumberSetting pitchRandomMax = new NumberSetting("Pitch Max", 45f, -90f, 90f, 1f, pitchRandom::isSelected);

    private final BooleanSetting onlyWhenMoving = new BooleanSetting("Only When Moving", false);
    private final BooleanSetting onlyOnGround = new BooleanSetting("Only On Ground", false);
    private final BooleanSetting fixMovement = new BooleanSetting("Fix Movement", "Reorient WASD so movement direction matches the real client yaw", true);

    private float spunYaw;
    private float spunPitch;
    private long ticks;
    private int randomCounter;

    private Spinbot() {
    }

    @Override
    public void onEnable() {
        super.onEnable();
        if (mc.player != null) {
            spunYaw = mc.player.getYaw();
            spunPitch = mc.player.getPitch();
        } else {
            spunYaw = 0f;
            spunPitch = 0f;
        }
        ticks = 0;
        randomCounter = 0;
    }

    @EventTarget
    public void onRotate(EventRotate event) {
        if (mc.player == null || mc.world == null) {
            return;
        }
        if (onlyWhenMoving.isEnabled() && !MovingUtil.hasPlayerMovement()) {
            return;
        }
        if (onlyOnGround.isEnabled() && !mc.player.isOnGround()) {
            return;
        }

        ticks++;

        spunYaw = MathHelper.wrapDegrees(computeYaw());
        spunPitch = MathHelper.clamp(computePitch(), -90f, 90f);

        Rotation target = new Rotation(spunYaw, spunPitch);
        rotationManager.setRotation(
                new RotationTarget(target, () -> target, aimManager.getInstantSetup()),
                10,
                this
        );
    }

    private float computeYaw() {
        float baseYaw = mc.player.getYaw();

        if (yawLinear.isSelected()) {
            return spunYaw + yawSpeed.getCurrent();
        }
        if (yawSine.isSelected()) {
            float period = Math.max(1f, sinePeriod.getCurrent());
            float phase = (float) (2.0 * Math.PI * (ticks % period) / period);
            return baseYaw + sineAmplitude.getCurrent() * (float) Math.sin(phase);
        }
        if (yawRandom.isSelected()) {
            int period = Math.max(1, (int) randomPeriod.getCurrent());
            if (randomCounter <= 0) {
                randomCounter = period;
                return ThreadLocalRandom.current().nextFloat() * 360f - 180f;
            }
            randomCounter--;
            return spunYaw;
        }
        if (yawJitter.isSelected()) {
            float strength = jitterStrength.getCurrent();
            float offset = (ThreadLocalRandom.current().nextFloat() * 2f - 1f) * strength;
            return baseYaw + offset;
        }
        return spunYaw;
    }

    private float computePitch() {
        if (pitchKeep.isSelected()) {
            return mc.player.getPitch();
        }
        if (pitchLock.isSelected()) {
            return pitchValue.getCurrent();
        }
        if (pitchRandom.isSelected()) {
            float min = Math.min(pitchRandomMin.getCurrent(), pitchRandomMax.getCurrent());
            float max = Math.max(pitchRandomMin.getCurrent(), pitchRandomMax.getCurrent());
            int period = Math.max(1, (int) randomPeriod.getCurrent());
            if (ticks % period == 0) {
                return min + ThreadLocalRandom.current().nextFloat() * (max - min);
            }
            return spunPitch;
        }
        return mc.player.getPitch();
    }

    @EventTarget
    public void onMoveInput(EventMoveInput event) {
        if (!fixMovement.isEnabled() || mc.player == null) {
            return;
        }
        MovingUtil.fixMovement(event, spunYaw, mc.player.getYaw());
    }
}
