package okyware.wtf.client.modules.impl.movement;

import com.darkmagician6.eventapi.EventTarget;
import okyware.wtf.base.events.impl.player.EventUpdate;
import okyware.wtf.client.modules.api.Category;
import okyware.wtf.client.modules.api.Module;
import okyware.wtf.client.modules.api.ModuleAnnotation;
import okyware.wtf.client.modules.api.setting.impl.BooleanSetting;
import okyware.wtf.client.modules.api.setting.impl.NumberSetting;
import okyware.wtf.client.modules.impl.combat.Aura;
import okyware.wtf.utility.game.player.MovingUtil;
import net.minecraft.entity.LivingEntity;
import net.minecraft.util.math.MathHelper;

@ModuleAnnotation(name = "TargetStrafe", category = Category.MOVEMENT, description = "Orbits around the combat target")
public final class TargetStrafe extends Module {
    public static final TargetStrafe INSTANCE = new TargetStrafe();

    private final NumberSetting range = new NumberSetting("Range", 3.0f, 1.0f, 6.0f, 0.1f);
    private final NumberSetting speed = new NumberSetting("Speed", 0.23f, 0.1f, 0.6f, 0.01f);
    private final BooleanSetting jumpOnly = new BooleanSetting("Jump only", true);

    private int direction = 1;

    private TargetStrafe() {}

    @EventTarget
    public void onUpdate(EventUpdate event) {
        LivingEntity target = Aura.INSTANCE.getTarget();
        if (target == null || !Aura.INSTANCE.isEnabled()) return;

        if (jumpOnly.isEnabled() && !mc.options.jumpKey.isPressed()) return;

        if (mc.player.horizontalCollision) {
            direction *= -1;
        }

        if (mc.options.leftKey.isPressed()) direction = 1;
        if (mc.options.rightKey.isPressed()) direction = -1;

        double dist = mc.player.distanceTo(target);
        
        
        
        float yaw = (float) Math.toDegrees(Math.atan2(mc.player.getZ() - target.getZ(), mc.player.getX() - target.getX())) - 90F;
        
        
        
        float diff = (float) (dist - range.getCurrent());
        float cos = (float) Math.cos(Math.toRadians(yaw)); 
        
        
        float angleToTarget = (float) Math.toDegrees(Math.atan2(target.getZ() - mc.player.getZ(), target.getX() - mc.player.getX())) - 90F;
        
        
        float orbitAngle = 90F;
        if (dist > range.getCurrent() + 0.1) {
            orbitAngle -= 45F;
        } else if (dist < range.getCurrent() - 0.1) {
            orbitAngle += 45F;
        }
        
        float finalYaw = angleToTarget + (orbitAngle * direction);
        
        MovingUtil.setVelocity(speed.getCurrent(), finalYaw);
        
        if (mc.player.isOnGround() && jumpOnly.isEnabled()) {
            mc.player.jump();
        }
    }
}
