package okyware.wtf.client.modules.impl.render;

import com.darkmagician6.eventapi.EventTarget;
import net.minecraft.client.option.Perspective;
import net.minecraft.util.math.Vec3d;
import okyware.wtf.base.events.impl.render.EventCamera;
import okyware.wtf.base.events.impl.render.EventCameraPosition;
import okyware.wtf.base.events.impl.player.EventUpdate;
import okyware.wtf.client.modules.api.Category;
import okyware.wtf.client.modules.api.Module;
import okyware.wtf.client.modules.api.ModuleAnnotation;
import okyware.wtf.client.modules.api.setting.impl.BooleanSetting;
import okyware.wtf.client.modules.api.setting.impl.NumberSetting;

@ModuleAnnotation(name = "SmoothCamera", category = Category.RENDER, description = "Smooth jumps and custom third person view.")
public final class SmoothCamera extends Module {
    public static final SmoothCamera INSTANCE = new SmoothCamera();

    private final BooleanSetting smoothJumps = new BooleanSetting("Smooth Jumps", true);
    private final NumberSetting smoothSpeed = new NumberSetting("Smooth Speed", 0.15f, 0.01f, 1.0f, 0.01f);
    

    private final BooleanSetting customOffset = new BooleanSetting("Custom Offset", true);
    private final NumberSetting distance = new NumberSetting("Distance", 4.0f, 1.0f, 10.0f, 0.1f, customOffset::isEnabled);
    private final NumberSetting offsetX = new NumberSetting("Offset X", 1.5f, -5.0f, 5.0f, 0.1f, customOffset::isEnabled);
    private final NumberSetting offsetY = new NumberSetting("Offset Y", 0.0f, -5.0f, 5.0f, 0.1f, customOffset::isEnabled);


    private double smoothedY;
    private boolean firstFrame = true;
    private Perspective previousPerspective;

    private SmoothCamera() {
    }

    @Override
    public void onEnable() {
        firstFrame = true;
        if (mc.options != null) {
            previousPerspective = mc.options.getPerspective();
            mc.options.setPerspective(Perspective.THIRD_PERSON_BACK);
        }
        super.onEnable();
    }

    @Override
    public void onDisable() {
        if (mc.options != null) {
            if (previousPerspective != null) {
                mc.options.setPerspective(previousPerspective);
            }
        }
        super.onDisable();
    }



    @EventTarget
    public void onCameraPosition(EventCameraPosition event) {
        if (!isEnabled() || !smoothJumps.isEnabled() || mc.player == null) return;

        Vec3d pos = event.getPos();

        if (firstFrame || Math.abs(pos.y - smoothedY) > 5.0) {
            smoothedY = pos.y;
            firstFrame = false;
        } else {
            double diff = pos.y - smoothedY;
            smoothedY += diff * smoothSpeed.getCurrent();
        }

        event.setPos(new Vec3d(pos.x, smoothedY, pos.z));
    }

    @EventTarget
    public void onCamera(EventCamera event) {
        if (!isEnabled() || !customOffset.isEnabled()) return;

        event.setCancelled(true);
        event.setDistance(distance.getCurrent());
        event.setOffsetX(offsetX.getCurrent());
        event.setOffsetY(offsetY.getCurrent());
    }
}
