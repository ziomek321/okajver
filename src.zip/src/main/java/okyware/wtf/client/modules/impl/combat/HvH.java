package okyware.wtf.client.modules.impl.combat;

import com.darkmagician6.eventapi.EventTarget;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Items;
import net.minecraft.network.packet.c2s.play.*;
import net.minecraft.util.Hand;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;
import okyware.wtf.base.events.impl.player.EventUpdate;
import okyware.wtf.base.events.impl.server.EventPacket;
import okyware.wtf.client.modules.api.Category;
import okyware.wtf.client.modules.api.Module;
import okyware.wtf.client.modules.api.ModuleAnnotation;
import okyware.wtf.client.modules.api.setting.impl.BooleanSetting;
import okyware.wtf.client.modules.api.setting.impl.NumberSetting;
import okyware.wtf.utility.game.player.MovingUtil;

@ModuleAnnotation(name = "HvH", category = Category.COMBAT, description = "Full HvH package - desync, double attack, sprint abuse, reach exploit")
public final class HvH extends Module {
    public static final HvH INSTANCE = new HvH();

    private final NumberSetting attackSpeed = new NumberSetting("Attack Speed", 2, 1, 5, 1);
    private final BooleanSetting desync = new BooleanSetting("Desync", true);
    private final BooleanSetting doubleHit = new BooleanSetting("Double Hit", true);
    private final BooleanSetting sprintAbuse = new BooleanSetting("Sprint Abuse", true);
    private final BooleanSetting autoGap = new BooleanSetting("Auto Gap", true);
    private final BooleanSetting antiAim = new BooleanSetting("Anti Aim", true);
    private final NumberSetting reach = new NumberSetting("Reach", 3.5f, 3.0f, 6.0f, 0.1f);

    private int ticks = 0;
    private boolean desyncToggle = false;

    private HvH() {
    }

    @Override
    public void onEnable() {
        super.onEnable();
        ticks = 0;
        desyncToggle = false;
    }

    @EventTarget
    public void onUpdate(EventUpdate event) {
        if (mc.player == null || mc.world == null) return;
        ticks++;

        PlayerEntity target = findTarget();
        if (target == null) return;

        double dist = mc.player.distanceTo(target);

        // Sprint abuse - max knockback every hit
        if (sprintAbuse.isEnabled()) {
            mc.player.networkHandler.sendPacket(new ClientCommandC2SPacket(mc.player, ClientCommandC2SPacket.Mode.STOP_SPRINTING));
            mc.player.networkHandler.sendPacket(new ClientCommandC2SPacket(mc.player, ClientCommandC2SPacket.Mode.START_SPRINTING));
        }

        // Attack at insane speed ignoring cooldown
        if (dist <= reach.getCurrent()) {
            int hits = (int) attackSpeed.getCurrent();
            for (int i = 0; i < hits; i++) {
                // Double hit - attack + crit packet
                if (doubleHit.isEnabled()) {
                    mc.player.networkHandler.sendPacket(new PlayerMoveC2SPacket.PositionAndOnGround(
                            mc.player.getX(), mc.player.getY() + 0.0625, mc.player.getZ(), false, mc.player.horizontalCollision));
                    mc.player.networkHandler.sendPacket(new PlayerMoveC2SPacket.PositionAndOnGround(
                            mc.player.getX(), mc.player.getY(), mc.player.getZ(), true, mc.player.horizontalCollision));
                }

                mc.interactionManager.attackEntity(mc.player, target);
                mc.player.swingHand(Hand.MAIN_HAND);
            }
        }

        // Desync - send fake position to confuse other clients
        if (desync.isEnabled() && ticks % 2 == 0) {
            desyncToggle = !desyncToggle;
            double offsetX = desyncToggle ? 0.5 : -0.5;
            mc.player.networkHandler.sendPacket(new PlayerMoveC2SPacket.PositionAndOnGround(
                    mc.player.getX() + offsetX, mc.player.getY(), mc.player.getZ() + offsetX,
                    mc.player.isOnGround(), mc.player.horizontalCollision));
        }

        // Anti-aim - send garbage rotation to confuse aura users
        if (antiAim.isEnabled()) {
            float fakeYaw = mc.player.getYaw() + (ticks % 2 == 0 ? 180 : -90);
            float fakePitch = -90 + (ticks % 4) * 45;
            mc.player.networkHandler.sendPacket(new PlayerMoveC2SPacket.LookAndOnGround(
                    fakeYaw, fakePitch, mc.player.isOnGround(), mc.player.horizontalCollision));
        }

        // Auto gap when low HP
        if (autoGap.isEnabled() && mc.player.getHealth() < 10) {
            int gapSlot = findGapple();
            if (gapSlot != -1 && !mc.player.isUsingItem()) {
                mc.player.getInventory().selectedSlot = gapSlot;
                mc.interactionManager.interactItem(mc.player, Hand.MAIN_HAND);
            }
        }
    }

    @EventTarget
    public void onPacket(EventPacket event) {
        if (mc.player == null) return;
        // Cancel incoming velocity to stay in place while attacking
        if (event.isReceive() && event.getPacket() instanceof net.minecraft.network.packet.s2c.play.EntityVelocityUpdateS2CPacket vel) {
            if (vel.getEntityId() == mc.player.getId()) {
                event.cancel();
            }
        }
    }

    private PlayerEntity findTarget() {
        PlayerEntity closest = null;
        double closestDist = reach.getCurrent() + 2;
        for (PlayerEntity player : mc.world.getPlayers()) {
            if (player == mc.player || !player.isAlive()) continue;
            double d = mc.player.distanceTo(player);
            if (d < closestDist) {
                closestDist = d;
                closest = player;
            }
        }
        return closest;
    }

    private int findGapple() {
        for (int i = 0; i < 9; i++) {
            if (mc.player.getInventory().getStack(i).getItem() == Items.GOLDEN_APPLE ||
                mc.player.getInventory().getStack(i).getItem() == Items.ENCHANTED_GOLDEN_APPLE) {
                return i;
            }
        }
        return -1;
    }
}
