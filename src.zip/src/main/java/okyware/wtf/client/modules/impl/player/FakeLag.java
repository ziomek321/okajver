package okyware.wtf.client.modules.impl.player;

import com.darkmagician6.eventapi.EventTarget;
import okyware.wtf.Okyware;
import okyware.wtf.base.events.impl.player.EventUpdate;
import okyware.wtf.base.events.impl.render.EventRender3D;
import okyware.wtf.base.events.impl.server.EventPacket;
import okyware.wtf.client.modules.api.Category;
import okyware.wtf.client.modules.api.Module;
import okyware.wtf.client.modules.api.ModuleAnnotation;
import okyware.wtf.client.modules.api.setting.impl.BooleanSetting;
import okyware.wtf.client.modules.api.setting.impl.ModeSetting;
import okyware.wtf.client.modules.api.setting.impl.NumberSetting;
import okyware.wtf.utility.render.display.base.color.ColorRGBA;
import okyware.wtf.utility.render.level.Render3DUtil;
import net.minecraft.network.packet.Packet;
import net.minecraft.network.packet.c2s.play.*;
import net.minecraft.network.packet.c2s.common.KeepAliveC2SPacket;
import net.minecraft.util.math.Vec3d;

import java.util.concurrent.CopyOnWriteArrayList;

@ModuleAnnotation(name = "FakeLag", category = Category.PLAYER, description = "Fakes ping by delaying all outgoing packets")
public final class FakeLag extends Module {
    public static final FakeLag INSTANCE = new FakeLag();

    private final NumberSetting ping = new NumberSetting("Ping", 200, 50, 2000, 10, "Extra ping in ms");
    private final ModeSetting mode = new ModeSetting("Mode", "Constant", "Spike", "Random");
    private final NumberSetting spikeMin = new NumberSetting("Spike Min", 50, 10, 1000, 10, () -> mode.is("Spike"));
    private final NumberSetting spikeMax = new NumberSetting("Spike Max", 500, 50, 2000, 10, () -> mode.is("Spike"));
    private final NumberSetting spikeInterval = new NumberSetting("Spike Interval", 2000, 500, 10000, 100, () -> mode.is("Spike"));
    private final BooleanSetting keepAlive = new BooleanSetting("Delay KeepAlive", false);
    private final BooleanSetting visual = new BooleanSetting("Visual", true);

    private final CopyOnWriteArrayList<Entry> queue = new CopyOnWriteArrayList<>();
    private final CopyOnWriteArrayList<Vec3d> positions = new CopyOnWriteArrayList<>();
    private boolean sending = false;
    private long lastSpike = 0;
    private boolean spiking = false;

    private FakeLag() {}

    @Override
    public void onEnable() {
        super.onEnable();
        queue.clear();
        positions.clear();
        sending = false;
        lastSpike = System.currentTimeMillis();
        spiking = false;
    }

    @Override
    public void onDisable() {
        flush();
        positions.clear();
        super.onDisable();
    }

    @EventTarget
    public void onUpdate(EventUpdate event) {
        if (mc.player == null) return;
        long now = System.currentTimeMillis();
        float currentDelay = getDelay(now);

        sending = true;
        queue.removeIf(e -> {
            if (now - e.time >= currentDelay) {
                mc.player.networkHandler.sendPacket(e.pkt);
                return true;
            }
            return false;
        });
        sending = false;

        // Track positions for visual
        if (visual.isEnabled()) {
            positions.add(mc.player.getPos());
            // Keep only recent positions matching current delay
            long maxAge = (long) currentDelay;
            long cutoff = now - maxAge;
            while (positions.size() > 200) positions.remove(0);
        }
    }

    @EventTarget
    public void onRender3D(EventRender3D event) {
        if (!visual.isEnabled() || mc.player == null || positions.size() < 2) return;

        ColorRGBA color = Okyware.getInstance().getThemeManager().getClientColor(0);
        int rgb = color.getRGB();

        for (int i = 1; i < positions.size(); i++) {
            Vec3d prev = positions.get(i - 1);
            Vec3d curr = positions.get(i);
            float alpha = (float) i / positions.size();
            int fadedColor = color.mulAlpha(alpha).getRGB();
            Render3DUtil.drawLine(prev, curr, fadedColor, fadedColor, 1.5f, false);
        }
    }

    @EventTarget
    public void onPacket(EventPacket event) {
        if (mc.player == null || sending || !event.isSent()) return;
        Packet<?> pkt = event.getPacket();
        if (!keepAlive.isEnabled() && pkt instanceof KeepAliveC2SPacket) return;

        event.setCancelled(true);
        queue.add(new Entry(pkt, System.currentTimeMillis()));
    }

    private float getDelay(long now) {
        return switch (mode.get()) {
            case "Spike" -> {
                if (now - lastSpike >= spikeInterval.getCurrent()) {
                    spiking = !spiking;
                    lastSpike = now;
                }
                yield spiking ? spikeMax.getCurrent() : spikeMin.getCurrent();
            }
            case "Random" -> ping.getCurrent() * (0.5f + (float) Math.random());
            default -> ping.getCurrent();
        };
    }

    private void flush() {
        if (mc.player == null || mc.player.networkHandler == null) return;
        sending = true;
        for (Entry e : queue) mc.player.networkHandler.sendPacket(e.pkt);
        queue.clear();
        sending = false;
    }

    private record Entry(Packet<?> pkt, long time) {}
}
