package okyware.wtf.client.modules.impl.render;

import net.minecraft.block.Block;
import net.minecraft.block.Blocks;
import okyware.wtf.client.modules.api.Category;
import okyware.wtf.client.modules.api.Module;
import okyware.wtf.client.modules.api.ModuleAnnotation;
import okyware.wtf.client.modules.api.setting.impl.BooleanSetting;

@ModuleAnnotation(name = "XRay", description = "Allows you to see ores through solid blocks", category = Category.RENDER)
public class XRay extends Module {

    public static XRay INSTANCE;

    public final BooleanSetting diamonds = new BooleanSetting("Diamonds", true);
    public final BooleanSetting ancientDebris = new BooleanSetting("Ancient Debris", true);
    public final BooleanSetting gold = new BooleanSetting("Gold", true);
    public final BooleanSetting iron = new BooleanSetting("Iron", true);
    public final BooleanSetting emerald = new BooleanSetting("Emerald", true);
    public final BooleanSetting lapis = new BooleanSetting("Lapis", false);
    public final BooleanSetting redstone = new BooleanSetting("Redstone", false);
    public final BooleanSetting coal = new BooleanSetting("Coal", false);

    public XRay() {
        INSTANCE = this;
    }

    @Override
    public void onEnable() {
        super.onEnable();
        reloadChunks();
    }

    @Override
    public void onDisable() {
        super.onDisable();
        reloadChunks();
    }

    private void reloadChunks() {
        if (mc.worldRenderer != null) {
            mc.worldRenderer.reload();
        }
    }

    public boolean isXRayBlock(Block block) {
        if (diamonds.isEnabled() && (block == Blocks.DIAMOND_ORE || block == Blocks.DEEPSLATE_DIAMOND_ORE || block == Blocks.DIAMOND_BLOCK)) return true;
        if (ancientDebris.isEnabled() && block == Blocks.ANCIENT_DEBRIS) return true;
        if (gold.isEnabled() && (block == Blocks.GOLD_ORE || block == Blocks.DEEPSLATE_GOLD_ORE || block == Blocks.NETHER_GOLD_ORE || block == Blocks.GOLD_BLOCK)) return true;
        if (iron.isEnabled() && (block == Blocks.IRON_ORE || block == Blocks.DEEPSLATE_IRON_ORE || block == Blocks.IRON_BLOCK || block == Blocks.RAW_IRON_BLOCK)) return true;
        if (emerald.isEnabled() && (block == Blocks.EMERALD_ORE || block == Blocks.DEEPSLATE_EMERALD_ORE || block == Blocks.EMERALD_BLOCK)) return true;
        if (lapis.isEnabled() && (block == Blocks.LAPIS_ORE || block == Blocks.DEEPSLATE_LAPIS_ORE || block == Blocks.LAPIS_BLOCK)) return true;
        if (redstone.isEnabled() && (block == Blocks.REDSTONE_ORE || block == Blocks.DEEPSLATE_REDSTONE_ORE || block == Blocks.REDSTONE_BLOCK)) return true;
        if (coal.isEnabled() && (block == Blocks.COAL_ORE || block == Blocks.DEEPSLATE_COAL_ORE || block == Blocks.COAL_BLOCK)) return true;

        return false;
    }
}
