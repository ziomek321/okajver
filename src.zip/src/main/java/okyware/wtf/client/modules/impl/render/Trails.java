package okyware.wtf.client.modules.impl.render;

import com.darkmagician6.eventapi.EventTarget;
import net.minecraft.block.AirBlock;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.FluidBlock;
import net.minecraft.client.option.Perspective;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;
import okyware.wtf.Okyware;
import okyware.wtf.base.events.impl.player.EventUpdate;
import okyware.wtf.base.events.impl.render.EventRender3D;
import okyware.wtf.client.modules.api.Category;
import okyware.wtf.client.modules.api.Module;
import okyware.wtf.client.modules.api.ModuleAnnotation;
import okyware.wtf.client.modules.api.setting.impl.BooleanSetting;
import okyware.wtf.client.modules.api.setting.impl.ModeSetting;
import okyware.wtf.client.modules.api.setting.impl.NumberSetting;
import okyware.wtf.utility.math.Timer;
import okyware.wtf.utility.render.display.base.color.ColorRGBA;
import okyware.wtf.utility.render.level.Render3DUtil;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

@ModuleAnnotation(name = "Trails", category = Category.RENDER, description = "Leaves a glowing trail or drifting particles behind your player as you move.")
public final class Trails extends Module {
    public static final Trails INSTANCE = new Trails();

    private final ModeSetting mode = new ModeSetting("Mode", "Glow", "Particles");
    private final NumberSetting length = new NumberSetting("Length (ms)", 1000, 500, 5000, 100);
    private final NumberSetting size = new NumberSetting("Size", 0.2f, 0.05f, 0.5f, 0.01f);
    private final BooleanSetting physics = new BooleanSetting("Physics", true, () -> mode.is("Particles"));
    private final NumberSetting fadeTime = new NumberSetting("Fade Time", 250, 100, 1000, 50, () -> mode.is("Particles"));
    private final BooleanSetting showFirstPerson = new BooleanSetting("First Person", false);

    private final List<TrailPoint> points = new ArrayList<>();
    private final List<TrailParticle> particles = new ArrayList<>();
    private final Identifier glowTex = Identifier.of("okyware", "textures/target/glow.png");
    private final Random random = new Random();

    private Trails() {
    }

    @Override
    public void onEnable() {
        points.clear();
        particles.clear();
        super.onEnable();
    }

    @EventTarget
    public void onUpdate(EventUpdate event) {
        if (mc.player == null) return;

        boolean isFirstPerson = mc.options.getPerspective() == Perspective.FIRST_PERSON;
        if (isFirstPerson && !showFirstPerson.isEnabled()) {
            points.clear();
            particles.clear();
            return;
        }

        if (mode.is("Glow")) {
            points.add(new TrailPoint(mc.player.getPos().add(0, mc.player.getHeight() * 0.4, 0)));
            points.removeIf(p -> p.timer.finished(length.getCurrent()));
        } else if (mode.is("Particles")) {
            Vec3d pp = mc.player.getPos();
            double yOff = mc.player.getHeight() * (isFirstPerson ? 0.2 : 0.5);
            particles.add(new TrailParticle(new Vec3d(pp.x, pp.y + yOff, pp.z), particles.size()));
            int maxLife = (int) length.getCurrent();
            int fade = (int) fadeTime.getCurrent();
            particles.removeIf(p -> p.shouldRemove(maxLife, fade));
        }
    }

    @EventTarget
    public void onRender3D(EventRender3D event) {
        if (mode.is("Glow")) {
            renderGlow();
        } else if (mode.is("Particles")) {
            renderParticles();
        }
    }

    private void renderGlow() {
        if (points.size() < 2) return;
        float len = length.getCurrent();
        ColorRGBA clientColor = Okyware.getInstance().getThemeManager().getClientColor(0);

        for (int i = 0; i < points.size() - 1; i++) {
            TrailPoint p1 = points.get(i);
            TrailPoint p2 = points.get(i + 1);
            float elapsed = p1.timer.getElapsedTime();
            float t = elapsed / len;
            if (t > 1f) t = 1f;
            float alpha = 1f - t;
            float lineWidth = size.getCurrent() * 20f * (1f - t * 0.5f);
            Render3DUtil.drawLine(p1.pos, p2.pos, clientColor.mulAlpha(alpha).getRGB(), lineWidth, true);
        }
    }

    private void renderParticles() {
        if (particles.isEmpty()) return;
        int maxLife = (int) length.getCurrent();
        int fade = (int) fadeTime.getCurrent();
        boolean usePhysics = physics.isEnabled();


        float baseSize = size.getCurrent();
        for (int i = 0; i < particles.size(); i++) {
            TrailParticle p = particles.get(i);
            p.update(usePhysics);
            p.tickAlpha(fade, maxLife);

            ColorRGBA c = Okyware.getInstance().getThemeManager().getClientColor((p.index * 30) % 360);
            int color = c.mulAlpha(p.alpha / 255f).getRGB();

            if (i > 0) {
                TrailParticle prev = particles.get(i - 1);
                Render3DUtil.drawLine(prev.pos, p.pos, color, baseSize * 45f, true);
            }
        }
    }

    private static class TrailPoint {
        final Vec3d pos;
        final Timer timer = new Timer();

        TrailPoint(Vec3d pos) {
            this.pos = pos;
        }
    }

    private class TrailParticle {
        Vec3d pos;
        Vec3d velocity;
        final int index;
        final Timer timer = new Timer();
        float alpha = 0f;
        boolean fadingOut = false;

        TrailParticle(Vec3d pos, int index) {
            this.pos = pos;
            this.index = index;
            double r = 0.01;
            this.velocity = new Vec3d(
                    (random.nextDouble() * 2 - 1) * r,
                    (random.nextDouble() * 2 - 1) * r,
                    (random.nextDouble() * 2 - 1) * r
            );
        }

        void tickAlpha(int fadeTime, int maxLife) {
            float elapsed = timer.getElapsedTime();
            if (!fadingOut) {
                alpha = Math.min(255f, alpha + 255f * (50f / Math.max(1, fadeTime)));
                if (elapsed >= maxLife - fadeTime) fadingOut = true;
            } else {
                alpha = Math.max(0f, alpha - 255f * (50f / Math.max(1, fadeTime)));
            }
        }

        boolean shouldRemove(int maxLife, int fadeTime) {
            if (mc.player != null && pos.distanceTo(mc.player.getPos()) > 80) return true;
            return timer.finished(maxLife) && alpha <= 0f;
        }

        void update(boolean enablePhysics) {
            if (enablePhysics) {
                if (isSolid(pos.x, pos.y, pos.z + velocity.z)) velocity = new Vec3d(velocity.x, velocity.y, -velocity.z * 0.8);
                if (isSolid(pos.x, pos.y + velocity.y, pos.z)) velocity = new Vec3d(velocity.x * 0.999, -velocity.y * 0.7, velocity.z * 0.999);
                if (isSolid(pos.x + velocity.x, pos.y, pos.z)) velocity = new Vec3d(-velocity.x * 0.8, velocity.y, velocity.z);
            }
            pos = pos.add(velocity);
            velocity = velocity.multiply(0.999);
        }

        private boolean isSolid(double x, double y, double z) {
            if (mc.world == null) return false;
            BlockState state = mc.world.getBlockState(BlockPos.ofFloored(x, y, z));
            Block block = state.getBlock();
            return !(block instanceof AirBlock) && !(block instanceof FluidBlock);
        }
    }
}
