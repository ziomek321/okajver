package okyware.wtf.client.modules.impl.combat;

import com.darkmagician6.eventapi.EventTarget;
import net.minecraft.block.Blocks;
import net.minecraft.entity.decoration.EndCrystalEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.network.packet.c2s.play.PlayerInteractBlockC2SPacket;
import net.minecraft.network.packet.c2s.play.UpdateSelectedSlotC2SPacket;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.RaycastContext;
import okyware.wtf.base.events.impl.player.EventUpdate;
import okyware.wtf.client.modules.api.Category;
import okyware.wtf.client.modules.api.Module;
import okyware.wtf.client.modules.api.ModuleAnnotation;
import okyware.wtf.client.modules.api.setting.Setting;
import okyware.wtf.client.modules.api.setting.impl.BooleanSetting;
import okyware.wtf.client.modules.api.setting.impl.NumberSetting;
import okyware.wtf.base.rotation.RotationTarget;
import okyware.wtf.utility.game.player.rotation.RotationUtil;
import okyware.wtf.utility.game.player.rotation.Rotation;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

@ModuleAnnotation(name = "AutoCrystal", description = "Places a crystal on obsidian and detonates it (via packets)", category = Category.COMBAT)
public final class AutoCrystal extends Module {

    public static final AutoCrystal INSTANCE = new AutoCrystal();

    private final BooleanSetting autoRotate = new BooleanSetting("Auto-rotation", true);
    private final BooleanSetting autoBreak = new BooleanSetting("Auto-explode", true);
    private final NumberSetting placeDelayMs = new NumberSetting("Obsi→Crystal delay", 40, 0, 200, 5);
    private final NumberSetting cycleDelayMs = new NumberSetting("Cycle delay", 120, 30, 1000, 10);

    private long lastCycleMs = 0L;

    private AutoCrystal() { }

    @Override
    public List<Setting> getSettings() {
        ArrayList<Setting> s = new ArrayList<>();
        s.add(autoRotate);
        s.add(autoBreak);
        s.add(placeDelayMs);
        s.add(cycleDelayMs);
        return s;
    }

    @Override
    public void onEnable() {
        super.onEnable();
        lastCycleMs = 0L;
    }

    private void runCycle() {
        if (mc.player == null || mc.world == null || mc.getNetworkHandler() == null) return;

        BlockHitResult hit = getPlacementRay();
        if (hit == null || hit.getType() != HitResult.Type.BLOCK) return;

        BlockPos target = hit.getBlockPos();
        boolean isObsidian = mc.world.getBlockState(target).isOf(Blocks.OBSIDIAN) || mc.world.getBlockState(target).isOf(Blocks.BEDROCK);

        if (isObsidian) {
            placeCrystalAndBreak(target);
        } else {
            placeObsidianThenCrystal(target, hit);
        }
    }

    private void placeObsidianThenCrystal(BlockPos supportPos, BlockHitResult supportHit) {
        int prev = mc.player.getInventory().selectedSlot;
        int obsSlot = findHotbar(Items.OBSIDIAN);
        int crySlot = findHotbar(Items.END_CRYSTAL);
        if (obsSlot == -1 || crySlot == -1) return;

        
        switchTo(obsSlot);
        if (autoRotate.isEnabled()) rotateToward(supportHit.getPos());
        mc.getNetworkHandler().sendPacket(new PlayerInteractBlockC2SPacket(Hand.MAIN_HAND, supportHit, 0));
        mc.player.swingHand(Hand.MAIN_HAND);

        
        long delay = (long) placeDelayMs.getCurrent();
        new Thread(() -> {
            try { if (delay > 0) Thread.sleep(delay); } catch (InterruptedException ignored) { }
            BlockPos obsiPos = supportPos.offset(supportHit.getSide());
            placeCrystalAndBreak(obsiPos);
            
            switchTo(prev);
        }).start();
    }

    private void placeCrystalAndBreak(BlockPos obsiPos) {
        int prev = mc.player.getInventory().selectedSlot;
        int crySlot = findHotbar(Items.END_CRYSTAL);
        if (crySlot == -1) return;

        
        Vec3d hitVec = new Vec3d(obsiPos.getX() + 0.5, obsiPos.getY() + 1.0, obsiPos.getZ() + 0.5);
        BlockHitResult crystalHit = new BlockHitResult(hitVec, Direction.UP, obsiPos, false);

        switchTo(crySlot);
        if (autoRotate.isEnabled()) rotateToward(hitVec);
        mc.getNetworkHandler().sendPacket(new PlayerInteractBlockC2SPacket(Hand.MAIN_HAND, crystalHit, 0));
        mc.player.swingHand(Hand.MAIN_HAND);

        if (autoBreak.isEnabled()) {
            
            new Thread(() -> {
                try { Thread.sleep(30); } catch (InterruptedException ignored) { }
                Box box = new Box(obsiPos.up()).expand(1.5);
                List<EndCrystalEntity> list = mc.world.getEntitiesByClass(EndCrystalEntity.class, box, e -> true);
                list.stream().min(Comparator.comparingDouble(e -> e.getPos().squaredDistanceTo(hitVec))).ifPresent(cr -> {
                    mc.interactionManager.attackEntity(mc.player, cr);
                    mc.player.swingHand(Hand.MAIN_HAND);
                });
                switchTo(prev);
            }).start();
        } else {
            switchTo(prev);
        }
    }

    private BlockHitResult getPlacementRay() {
        Vec3d start = mc.player.getEyePos();
        Vec3d end = start.add(mc.player.getRotationVec(1.0f).multiply(4.5));
        RaycastContext ctx = new RaycastContext(start, end, RaycastContext.ShapeType.COLLIDER, RaycastContext.FluidHandling.NONE, mc.player);
        HitResult res = mc.world.raycast(ctx);
        return res instanceof BlockHitResult bhr ? bhr : null;
    }

    private void rotateToward(Vec3d target) {
        if (mc.player == null) return;
        Rotation rot = RotationUtil.calculateAngle(target);
        RotationTarget rt = new RotationTarget(rot, () -> {
            return aimManager.rotate(aimManager.getInstantSetup(), rot);
        }, aimManager.getInstantSetup());
        rotationManager.setRotation(rt, 1, this);
    }

    private void switchTo(int hotbarSlot) {
        if (hotbarSlot < 0 || hotbarSlot > 8) return;
        mc.getNetworkHandler().sendPacket(new UpdateSelectedSlotC2SPacket(hotbarSlot));
        mc.player.getInventory().selectedSlot = hotbarSlot;
    }

    private int findHotbar(Item item) {
        for (int i = 0; i < 9; i++) {
            ItemStack stack = mc.player.getInventory().getStack(i);
            if (stack.getItem().equals(item)) return i;
        }
        return -1;
    }

    @EventTarget
    public void onTick(EventUpdate e) {
        long now = System.currentTimeMillis();
        if (now - lastCycleMs < (long) cycleDelayMs.getCurrent()) return;
        lastCycleMs = now;
        runCycle();
    }
}


