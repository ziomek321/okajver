package okyware.wtf.client.modules.api;

import lombok.Getter;

@Getter
public enum Category {
    COMBAT("Combat", "0"),
    MOVEMENT("Movement", "1"),
    PLAYER("Player", "2"),
    RENDER("Visuals", "3"),
    MISC("Misc", "4"),
    THEME("Theme", "\u1002"),
    CONFIG("Config", "6");

    private final String name;
    private final String icon;

    Category(String name, String icon) {
        this.name = name;
        this.icon = icon;
    }
}
