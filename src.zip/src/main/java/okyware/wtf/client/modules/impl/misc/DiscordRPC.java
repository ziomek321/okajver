package okyware.wtf.client.modules.impl.misc;

import okyware.wtf.client.modules.api.Category;
import okyware.wtf.client.modules.api.Module;
import okyware.wtf.client.modules.api.ModuleAnnotation;

@ModuleAnnotation(name = "DiscordRPC", category = Category.MISC, description = "Displays your in-game status and server information on your Discord profile")
public final class DiscordRPC extends Module {
    public static final DiscordRPC INSTANCE = new DiscordRPC();
    private DiscordRPC() {}
}
