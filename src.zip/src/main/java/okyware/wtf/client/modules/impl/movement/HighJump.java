package okyware.wtf.client.modules.impl.movement;

import com.darkmagician6.eventapi.EventTarget;
import okyware.wtf.base.events.impl.input.EventSetScreen;
import okyware.wtf.base.events.impl.player.EventUpdate;
import okyware.wtf.client.modules.api.Category;
import okyware.wtf.client.modules.api.Module;
import okyware.wtf.client.modules.api.ModuleAnnotation;
import okyware.wtf.client.modules.api.setting.impl.ModeSetting;
import okyware.wtf.client.modules.api.setting.impl.NumberSetting;
import net.minecraft.client.gui.screen.ingame.ShulkerBoxScreen;

@ModuleAnnotation(name = "HighJump", category = Category.MOVEMENT, description = "Boosts your jump height")
public final class HighJump extends Module {
    public static final HighJump INSTANCE = new HighJump();

    private final ModeSetting style = new ModeSetting("Style", "Default", "Shulker", "Grim");
    private final NumberSetting power = new NumberSetting("Power", 1.2f, 0.3f, 10.0f, 0.05f);

    private boolean wasOnGround = true;
    private boolean shulkerArmed = false;
    private int grimTicks = 0;

    private HighJump() {}

    @EventTarget
    public void onUpdate(EventUpdate e) {
        if (mc.player == null) return;

        if (style.is("Default")) {
            
            boolean onGround = mc.player.isOnGround();
            if (wasOnGround && !onGround && mc.player.getVelocity().y > 0) {
                mc.player.setVelocity(mc.player.getVelocity().x,
                        mc.player.getVelocity().y + power.getCurrent(),
                        mc.player.getVelocity().z);
            }
            wasOnGround = onGround;
        } else if (style.is("Shulker") && shulkerArmed) {
            
            mc.player.setVelocity(mc.player.getVelocity().x,
                    power.getCurrent() * 0.7f,
                    mc.player.getVelocity().z);
            shulkerArmed = false;
        } else if (style.is("Grim")) {
            boolean onGround = mc.player.isOnGround();
            if (wasOnGround && !onGround && mc.player.getVelocity().y > 0) {
                grimTicks = 3; 
            }
            if (grimTicks > 0) {
                mc.player.addVelocity(0, (power.getCurrent() / 3.0f), 0);
                grimTicks--;
            }
            wasOnGround = onGround;
        }
    }

    @EventTarget
    public void onScreen(EventSetScreen e) {
        if (style.is("Shulker") && e.getScreen() instanceof ShulkerBoxScreen
                && mc.player != null && mc.player.isOnGround()) {
            shulkerArmed = true;
        }
    }

    @Override
    public void onDisable() {
        wasOnGround = true;
        shulkerArmed = false;
        super.onDisable();
    }
}
