package okyware.wtf.client.modules.impl.player;

import com.darkmagician6.eventapi.EventTarget;
import net.minecraft.item.Items;
import net.minecraft.network.packet.c2s.play.PlayerMoveC2SPacket;
import net.minecraft.util.Hand;
import net.minecraft.util.math.BlockPos;
import okyware.wtf.base.events.impl.player.EventUpdate;
import okyware.wtf.base.events.impl.server.EventPacket;
import okyware.wtf.client.modules.api.Category;
import okyware.wtf.client.modules.api.Module;
import okyware.wtf.client.modules.api.ModuleAnnotation;
import okyware.wtf.client.modules.api.setting.impl.BooleanSetting;
import okyware.wtf.client.modules.api.setting.impl.ModeSetting;
import okyware.wtf.client.modules.api.setting.impl.NumberSetting;
import okyware.wtf.utility.mixin.accessors.PlayerMoveC2SPacketAccessor;

@ModuleAnnotation(name = "NoFall", category = Category.PLAYER, description = "Prevents you from taking fall damage.")
public final class NoFall extends Module {
    public static final NoFall INSTANCE = new NoFall();

    public final ModeSetting mode = new ModeSetting("Mode", "Rubberband", "Spoof", "OffGround", "Grim2b2t", "Items");
    public final ModeSetting fallDistance = new ModeSetting("FallDistance", "Calc", "Custom");
    public final NumberSetting fallDistanceValue = new NumberSetting("FallDistanceVal", 10, 2, 100, 1, () -> fallDistance.is("Custom"));
    private final BooleanSetting waterBucket = new BooleanSetting("WaterBucket", true, () -> mode.is("Items"));
    private final BooleanSetting retrieve = new BooleanSetting("Retrieve", true, () -> mode.is("Items") && waterBucket.isEnabled());
    private final BooleanSetting powderSnowBucket = new BooleanSetting("PowderSnowBucket", true, () -> mode.is("Items"));
    private final BooleanSetting enderPearl = new BooleanSetting("EnderPearl", true, () -> mode.is("Items"));
    private final BooleanSetting cobweb = new BooleanSetting("Cobweb", true, () -> mode.is("Items"));
    private final BooleanSetting twistingVines = new BooleanSetting("TwistingVines", true, () -> mode.is("Items"));

    private boolean cancelGround = false;
    private boolean retrieveFlag = false;
    private long lastPearlTime = 0;

    private NoFall() {
    }

    @Override
    public void onEnable() {
        super.onEnable();
        cancelGround = false;
        retrieveFlag = false;
    }

    @EventTarget
    public void onUpdate(EventUpdate e) {
        if (mc.player == null || mc.world == null) return;

        if (isFalling()) {
            switch (mode.get()) {
                case "Rubberband" -> mc.player.networkHandler.sendPacket(new PlayerMoveC2SPacket.OnGroundOnly(true, false));
                case "OffGround", "Spoof" -> cancelGround = true;
                case "Grim2b2t" -> {
                    mc.player.networkHandler.sendPacket(new PlayerMoveC2SPacket.Full(
                            mc.player.getX(), mc.player.getY() + 0.000000001,
                            mc.player.getZ(), mc.player.getYaw(), mc.player.getPitch(), false, false));
                    mc.player.onLanding();
                }
                case "Items" -> handleItems();
            }
        } else if (retrieveFlag) {
            int bucketSlot = findInHotbar(Items.BUCKET);
            if (bucketSlot != -1) {
                int prev = mc.player.getInventory().selectedSlot;
                mc.player.getInventory().selectedSlot = bucketSlot;
                mc.player.setPitch(90);
                mc.interactionManager.interactItem(mc.player, Hand.MAIN_HAND);
                mc.player.getInventory().selectedSlot = prev;
            }
            retrieveFlag = false;
        }
    }

    @EventTarget
    public void onPacket(EventPacket event) {
        if (!event.isSent() || mc.player == null) return;
        if (!(event.getPacket() instanceof PlayerMoveC2SPacket packet)) return;
        if (cancelGround && mode.is("OffGround")) {
            ((PlayerMoveC2SPacketAccessor) packet).setOnGround(false);
        } else if (cancelGround && mode.is("Spoof")) {
            ((PlayerMoveC2SPacketAccessor) packet).setOnGround(true);
        }
    }

    private void handleItems() {
        BlockPos playerPos = BlockPos.ofFloored(mc.player.getPos());

        int waterSlot = waterBucket.isEnabled() ? findInHotbar(Items.WATER_BUCKET) : -1;
        int pearlSlot = enderPearl.isEnabled() ? findInHotbar(Items.ENDER_PEARL) : -1;
        int webSlot = cobweb.isEnabled() ? findInHotbar(Items.COBWEB) : -1;
        int vinesSlot = twistingVines.isEnabled() ? findInHotbar(Items.TWISTING_VINES) : -1;
        int snowSlot = powderSnowBucket.isEnabled() ? findInHotbar(Items.POWDER_SNOW_BUCKET) : -1;

        boolean solidBelow = mc.world.getBlockState(playerPos.down()).isSolidBlock(mc.world, playerPos.down())
                || mc.world.getBlockState(playerPos.down().down()).isSolidBlock(mc.world, playerPos.down().down());

        if (waterSlot != -1 && solidBelow) {
            mc.player.setPitch(90);
            useItem(waterSlot);
            retrieveFlag = retrieve.isEnabled();
        } else if (pearlSlot != -1 && System.currentTimeMillis() - lastPearlTime > 5000) {
            mc.player.setPitch(90);
            useItem(pearlSlot);
            lastPearlTime = System.currentTimeMillis();
        } else if (webSlot != -1 && solidBelow) {
            mc.player.setPitch(90);
            useItem(webSlot);
        } else if (vinesSlot != -1 && solidBelow) {
            mc.player.setPitch(90);
            useItem(vinesSlot);
        } else if (snowSlot != -1 && solidBelow) {
            mc.player.setPitch(90);
            useItem(snowSlot);
        }
    }

    private void useItem(int slot) {
        int prev = mc.player.getInventory().selectedSlot;
        mc.player.getInventory().selectedSlot = slot;
        mc.interactionManager.interactItem(mc.player, Hand.MAIN_HAND);
        mc.player.swingHand(Hand.MAIN_HAND);
        mc.player.getInventory().selectedSlot = prev;
    }

    private int findInHotbar(net.minecraft.item.Item item) {
        for (int i = 0; i < 9; i++) {
            if (mc.player.getInventory().getStack(i).getItem() == item) return i;
        }
        return -1;
    }

    private boolean isFalling() {
        if (mc.player == null || mc.world == null) return false;
        if (mc.player.isGliding()) return false;

        if (mode.is("Grim2b2t")) return mc.player.fallDistance > 3f;

        return switch (fallDistance.get()) {
            case "Custom" -> mc.player.fallDistance > fallDistanceValue.getCurrent();
            case "Calc" -> ((mc.player.fallDistance - 3) / 2f + 3.5f) > mc.player.getHealth() / 3f;
            default -> mc.player.fallDistance > 3f;
        };
    }
}
