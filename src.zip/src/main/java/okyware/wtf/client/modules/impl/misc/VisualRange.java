package okyware.wtf.client.modules.impl.misc;

import com.darkmagician6.eventapi.EventTarget;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.util.Formatting;
import okyware.wtf.Okyware;
import okyware.wtf.base.events.impl.other.EventSpawnEntity;
import okyware.wtf.base.events.impl.player.EventUpdate;
import okyware.wtf.base.filemanager.impl.FriendManager;
import okyware.wtf.client.modules.api.Category;
import okyware.wtf.client.modules.api.Module;
import okyware.wtf.client.modules.api.ModuleAnnotation;
import okyware.wtf.client.modules.api.setting.impl.BooleanSetting;
import okyware.wtf.client.modules.api.setting.impl.ModeSetting;
import okyware.wtf.utility.game.other.MessageUtil;

import java.util.ArrayList;

@ModuleAnnotation(name = "VisualRange", category = Category.MISC, description = "Sends alerts when players enter or leave your configured visual range radius")
public final class VisualRange extends Module {
    public static final VisualRange INSTANCE = new VisualRange();
    private VisualRange() {}
    
    private static final ArrayList<String> entities = new ArrayList<>();
    private final BooleanSetting leave = new BooleanSetting("Leave notifications", true);
    private final BooleanSetting enter = new BooleanSetting("Join notifications", true);
    private final BooleanSetting friends = new BooleanSetting("Friend notifications", true);
    private final BooleanSetting sound = new BooleanSetting("Sound", true);
    private final ModeSetting mode = new ModeSetting("Mode");
    private final ModeSetting.Value chatMode = new ModeSetting.Value(mode, "Chat").select();
    private final ModeSetting.Value notificationMode = new ModeSetting.Value(mode, "Notifications");
    private final ModeSetting.Value bothMode = new ModeSetting.Value(mode, "Both");

    @EventTarget
    public void onEntityAdded(EventSpawnEntity event) {
        if (!isValid(event.getEntity())) return;

        if (!entities.contains(event.getEntity().getName().getString()))
            entities.add(event.getEntity().getName().getString());
        else return;

        if (enter.isEnabled()) notify(event.getEntity(), true);
    }

    @EventTarget
    public void onTick(EventUpdate event) {
        
        entities.removeIf(entityName -> {
            boolean found = mc.world.getPlayers().stream()
                .anyMatch(player -> player.getName().getString().equals(entityName));
            if (!found && leave.isEnabled()) {
                
                MessageUtil.displayMessage(MessageUtil.LogLevel.INFO, 
                    Formatting.GRAY + entityName + Formatting.RED + " вышел из радиуса!");
                return true;
            }
            return false;
        });
    }

    public void notify(Entity entity, boolean enter) {
        String message = "";
        FriendManager friendManager = Okyware.getInstance().getFriendManager();
        
        if (friendManager.isFriend(entity.getName().getString()))
            message = Formatting.AQUA + entity.getName().getString();
        else message = Formatting.GRAY + entity.getName().getString();

        if (enter) message += Formatting.GREEN + " вошел в радиус!";
        else message += Formatting.RED + " вышел из радиуса! X:" + (int) entity.getX() + " Z:" + (int) entity.getZ();

        if (chatMode.isSelected() || bothMode.isSelected()) {
            MessageUtil.displayMessage(MessageUtil.LogLevel.INFO, message);
        }

        if (notificationMode.isSelected() || bothMode.isSelected()) {
            Okyware.getInstance().getNotifyManager().addNotification("VR", net.minecraft.text.Text.literal(message));
        }

        if (sound.isEnabled()) {
            try {
                if (enter)
                    mc.world.playSound(mc.player, mc.player.getBlockPos(), SoundEvents.ENTITY_PLAYER_LEVELUP, SoundCategory.BLOCKS, 1f, 1f);
                else
                    mc.world.playSound(mc.player, mc.player.getBlockPos(), SoundEvents.ENTITY_EXPERIENCE_ORB_PICKUP, SoundCategory.BLOCKS, 1f, 1f);
            } catch (Exception ignored) {
            }
        }
    }

    public boolean isValid(Entity entity) {
        if (!(entity instanceof PlayerEntity)) return false;
        FriendManager friendManager = Okyware.getInstance().getFriendManager();
        return entity != mc.player && (!friendManager.isFriend(entity.getName().getString()) || friends.isEnabled());
    }
}
