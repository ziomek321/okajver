package okyware.wtf.client.modules.impl.combat;

import com.darkmagician6.eventapi.EventTarget;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.network.packet.c2s.play.ClientCommandC2SPacket;
import net.minecraft.network.packet.c2s.play.PlayerInteractEntityC2SPacket;
import okyware.wtf.base.events.impl.player.EventUpdate;
import okyware.wtf.client.modules.api.Category;
import okyware.wtf.client.modules.api.Module;
import okyware.wtf.client.modules.api.ModuleAnnotation;
import okyware.wtf.client.modules.api.setting.impl.BooleanSetting;
import okyware.wtf.client.modules.api.setting.impl.NumberSetting;
import net.minecraft.util.Hand;
import net.minecraft.util.math.Vec3d;

@ModuleAnnotation(name = "HitPush", category = Category.COMBAT, description = "Increases knockback dealt to targets and pushes back attackers")
public final class HitPush extends Module {
    public static final HitPush INSTANCE = new HitPush();

    private final NumberSetting extraPackets = new NumberSetting("Sprint Resets", 1, 1, 5, 1);
    private final BooleanSetting revenge = new BooleanSetting("Revenge Push", true);

    private HitPush() {
    }

    @EventTarget
    public void onUpdate(EventUpdate event) {
        if (mc.player == null || mc.world == null) return;

        // Sprint-reset before each hit to maximize knockback
        if (mc.player.handSwingTicks == 1) {
            int resets = (int) extraPackets.getCurrent();
            for (int i = 0; i < resets; i++) {
                mc.player.networkHandler.sendPacket(new ClientCommandC2SPacket(mc.player, ClientCommandC2SPacket.Mode.STOP_SPRINTING));
                mc.player.networkHandler.sendPacket(new ClientCommandC2SPacket(mc.player, ClientCommandC2SPacket.Mode.START_SPRINTING));
            }
        }

        // When hit, auto-attack the nearest player to push them back
        if (revenge.isEnabled() && mc.player.hurtTime == mc.player.maxHurtTime && mc.player.hurtTime > 0) {
            PlayerEntity attacker = null;
            double closest = 4.0;
            for (PlayerEntity player : mc.world.getPlayers()) {
                if (player == mc.player) continue;
                double dist = mc.player.distanceTo(player);
                if (dist < closest) {
                    closest = dist;
                    attacker = player;
                }
            }
            if (attacker != null) {
                mc.player.networkHandler.sendPacket(new ClientCommandC2SPacket(mc.player, ClientCommandC2SPacket.Mode.START_SPRINTING));
                mc.interactionManager.attackEntity(mc.player, attacker);
                mc.player.swingHand(Hand.MAIN_HAND);
            }
        }
    }
}
