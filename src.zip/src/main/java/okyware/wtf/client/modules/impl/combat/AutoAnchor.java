package okyware.wtf.client.modules.impl.combat;

import com.darkmagician6.eventapi.EventTarget;
import okyware.wtf.base.events.impl.player.EventUpdate;
import okyware.wtf.base.rotation.RotationTarget;
import okyware.wtf.client.modules.api.Category;
import okyware.wtf.client.modules.api.Module;
import okyware.wtf.client.modules.api.ModuleAnnotation;
import okyware.wtf.client.modules.api.setting.impl.BooleanSetting;
import okyware.wtf.client.modules.api.setting.impl.NumberSetting;
import okyware.wtf.utility.game.player.rotation.Rotation;
import okyware.wtf.utility.game.player.rotation.RotationUtil;
import net.minecraft.block.Blocks;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.network.packet.c2s.play.PlayerInteractBlockC2SPacket;
import net.minecraft.network.packet.c2s.play.UpdateSelectedSlotC2SPacket;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

@ModuleAnnotation(name = "AutoAnchor", description = "Automatically places, charges, and explodes respawn anchors.", category = Category.COMBAT)
public final class AutoAnchor extends Module {

    public static final AutoAnchor INSTANCE = new AutoAnchor();

    private final NumberSetting range = new NumberSetting("Range", 4.5f, 1.0f, 6.0f, 0.1f);
    private final NumberSetting actionDelayMs = new NumberSetting("Action Delay (ms)", 50, 0, 500, 10);
    private final BooleanSetting autoRotate = new BooleanSetting("Auto Rotate", true);

    private long lastActionTime = 0L;

    private AutoAnchor() {
    }

    @Override
    public java.util.List<okyware.wtf.client.modules.api.setting.Setting> getSettings() {
        return java.util.List.of(range, actionDelayMs, autoRotate);
    }

    @Override
    public void onEnable() {
        super.onEnable();
        lastActionTime = 0L;
    }

    @EventTarget
    public void onUpdate(EventUpdate event) {
        if (mc.player == null || mc.world == null) return;

        if (System.currentTimeMillis() - lastActionTime < (long) actionDelayMs.getCurrent()) {
            return;
        }

        PlayerEntity target = getTarget();
        if (target == null) return;

        int anchorSlot = findHotbar(Items.RESPAWN_ANCHOR);
        int glowstoneSlot = findHotbar(Items.GLOWSTONE);

        if (anchorSlot == -1 || glowstoneSlot == -1) return;

        
        BlockPos existingAnchor = getNearbyAnchor(target.getBlockPos());
        if (existingAnchor != null) {
            
            
            doAnchorCycle(existingAnchor, glowstoneSlot);
            return;
        }

        
        BlockPos placePos = findPlacementPos(target.getBlockPos());
        if (placePos != null) {
            placeBlock(placePos, anchorSlot);
            lastActionTime = System.currentTimeMillis();
        }
    }

    private void doAnchorCycle(BlockPos pos, int glowstoneSlot) {
        
        interactBlock(pos, glowstoneSlot);
        
        
        int detonateSlot = findNonExplosiveSlot(glowstoneSlot, findHotbar(Items.RESPAWN_ANCHOR));
        if (detonateSlot != -1) {
            
            
            long delay = (long) actionDelayMs.getCurrent();
            new Thread(() -> {
                try {
                    if (delay > 0) Thread.sleep(delay / 2);
                    interactBlock(pos, detonateSlot);
                } catch (InterruptedException ignored) {}
            }).start();
        }
        lastActionTime = System.currentTimeMillis();
    }

    private PlayerEntity getTarget() {
        return mc.world.getPlayers().stream()
                .filter(p -> p != mc.player && p.isAlive())
                .filter(p -> mc.player.distanceTo(p) <= range.getCurrent())
                .min(Comparator.comparingDouble(p -> mc.player.distanceTo(p)))
                .orElse(null);
    }

    private BlockPos getNearbyAnchor(BlockPos targetPos) {
        for (int x = -2; x <= 2; x++) {
            for (int y = -1; y <= 2; y++) {
                for (int z = -2; z <= 2; z++) {
                    BlockPos check = targetPos.add(x, y, z);
                    if (mc.world.getBlockState(check).isOf(Blocks.RESPAWN_ANCHOR)) {
                        return check;
                    }
                }
            }
        }
        return null;
    }

    private BlockPos findPlacementPos(BlockPos targetPos) {
        List<BlockPos> offsets = List.of(
                targetPos.up(2), 
                targetPos.up().north(),
                targetPos.up().south(),
                targetPos.up().east(),
                targetPos.up().west()
        );

        for (BlockPos pos : offsets) {
            if (mc.world.getBlockState(pos).isReplaceable() && mc.player.squaredDistanceTo(Vec3d.ofCenter(pos)) <= range.getCurrent() * range.getCurrent()) {
                
                for (Direction dir : Direction.values()) {
                    BlockPos neighbor = pos.offset(dir);
                    if (!mc.world.getBlockState(neighbor).isReplaceable()) {
                        return pos;
                    }
                }
            }
        }
        return null;
    }

    private void placeBlock(BlockPos pos, int slot) {
        for (Direction side : Direction.values()) {
            BlockPos neighbor = pos.offset(side);
            Direction opposite = side.getOpposite();

            if (mc.world.getBlockState(neighbor).isAir() || mc.world.getBlockState(neighbor).isReplaceable()) continue;

            Vec3d hitVec = new Vec3d(
                    neighbor.getX() + 0.5 + opposite.getOffsetX() * 0.5,
                    neighbor.getY() + 0.5 + opposite.getOffsetY() * 0.5,
                    neighbor.getZ() + 0.5 + opposite.getOffsetZ() * 0.5
            );

            if (autoRotate.isEnabled()) rotateToward(hitVec);

            int prevSlot = mc.player.getInventory().selectedSlot;
            switchTo(slot);

            BlockHitResult hit = new BlockHitResult(hitVec, opposite, neighbor, false);
            mc.getNetworkHandler().sendPacket(new PlayerInteractBlockC2SPacket(Hand.MAIN_HAND, hit, 0));
            mc.player.swingHand(Hand.MAIN_HAND);

            switchTo(prevSlot);
            return;
        }
    }

    private void interactBlock(BlockPos pos, int slot) {
        Vec3d hitVec = new Vec3d(pos.getX() + 0.5, pos.getY() + 0.5, pos.getZ() + 0.5);
        if (autoRotate.isEnabled()) rotateToward(hitVec);

        int prevSlot = mc.player.getInventory().selectedSlot;
        switchTo(slot);

        BlockHitResult hit = new BlockHitResult(hitVec, Direction.UP, pos, false);
        mc.getNetworkHandler().sendPacket(new PlayerInteractBlockC2SPacket(Hand.MAIN_HAND, hit, 0));
        mc.player.swingHand(Hand.MAIN_HAND);

        switchTo(prevSlot);
    }

    private void rotateToward(Vec3d target) {
        if (mc.player == null) return;
        Rotation rot = RotationUtil.calculateAngle(target);
        RotationTarget rt = new RotationTarget(rot, () -> aimManager.rotate(aimManager.getAiSetup(), rot), aimManager.getAiSetup());
        rotationManager.setRotation(rt, 1, this);
    }

    private void switchTo(int slot) {
        if (slot < 0 || slot > 8) return;
        mc.getNetworkHandler().sendPacket(new UpdateSelectedSlotC2SPacket(slot));
        mc.player.getInventory().selectedSlot = slot;
    }

    private int findHotbar(Item item) {
        for (int i = 0; i < 9; i++) {
            ItemStack stack = mc.player.getInventory().getStack(i);
            if (stack.getItem() == item) return i;
        }
        return -1;
    }

    private int findNonExplosiveSlot(int glowstoneSlot, int anchorSlot) {
        for (int i = 0; i < 9; i++) {
            if (i != glowstoneSlot && i != anchorSlot) {
                return i;
            }
        }
        return 0; 
    }
}
