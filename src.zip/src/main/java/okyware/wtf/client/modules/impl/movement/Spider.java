package okyware.wtf.client.modules.impl.movement;

import com.darkmagician6.eventapi.EventTarget;
import net.minecraft.block.Blocks;
import net.minecraft.item.BlockItem;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.network.packet.c2s.play.PlayerInteractBlockC2SPacket;
import net.minecraft.network.packet.c2s.play.UpdateSelectedSlotC2SPacket;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;
import okyware.wtf.base.events.impl.player.EventUpdate;
import okyware.wtf.client.modules.api.Category;
import okyware.wtf.client.modules.api.Module;
import okyware.wtf.client.modules.api.ModuleAnnotation;
import okyware.wtf.client.modules.api.setting.impl.ModeSetting;
import okyware.wtf.client.modules.api.setting.impl.NumberSetting;

@ModuleAnnotation(name = "Spider", category = Category.MOVEMENT, description = "Climb walls by placing blocks")
public final class Spider extends Module {
    public static final Spider INSTANCE = new Spider();

    private final ModeSetting mode = new ModeSetting("Mode", "Grim", "Vanilla");
    private final NumberSetting climbSpeed = new NumberSetting("Climb Speed", 0.35f, 0.1f, 1.0f, 0.05f);

    private Spider() {}

    @EventTarget
    public void onUpdate(EventUpdate event) {
        if (mc.player == null || mc.world == null) return;
        if (!mc.player.horizontalCollision) return;

        if (mode.is("Grim")) {
            
            
            grimSlimeClimb();
        } else {
            
            placeOnWall();
            mc.player.setVelocity(mc.player.getVelocity().x, climbSpeed.getCurrent(), mc.player.getVelocity().z);
        }
    }

    private void grimSlimeClimb() {
        int slimeSlot = findSlot(true);
        if (slimeSlot == -1) return;

        Direction facing = mc.player.getHorizontalFacing();
        BlockPos below = mc.player.getBlockPos().down();
        BlockPos wallBelow = below.offset(facing);

        
        if (mc.world.getBlockState(below).isReplaceable()) {
            placeBlock(below, slimeSlot);
        }
        
        BlockPos feetWall = mc.player.getBlockPos().offset(facing);
        if (mc.world.getBlockState(feetWall).isReplaceable()) {
            placeBlock(feetWall, slimeSlot);
        }

        
        
        
        if (mc.player.isOnGround()) {
            
            mc.player.jump();
        }
    }

    private void placeOnWall() {
        int slot = findSlot(false);
        if (slot == -1) return;

        Direction facing = mc.player.getHorizontalFacing();
        BlockPos feetPos = mc.player.getBlockPos();

        for (int yOff = 0; yOff <= 2; yOff++) {
            BlockPos placePos = feetPos.up(yOff).offset(facing);
            if (!mc.world.getBlockState(placePos).isReplaceable()) continue;
            placeBlock(placePos, slot);
            return;
        }
    }

    private void placeBlock(BlockPos pos, int slot) {
        for (Direction side : Direction.values()) {
            BlockPos neighbor = pos.offset(side);
            if (mc.world.getBlockState(neighbor).isReplaceable()) continue;

            int prevSlot = mc.player.getInventory().selectedSlot;
            switchTo(slot);

            Direction placeSide = side.getOpposite();
            Vec3d hitVec = new Vec3d(
                    neighbor.getX() + 0.5 + placeSide.getOffsetX() * 0.5,
                    neighbor.getY() + 0.5 + placeSide.getOffsetY() * 0.5,
                    neighbor.getZ() + 0.5 + placeSide.getOffsetZ() * 0.5);
            BlockHitResult hit = new BlockHitResult(hitVec, placeSide, neighbor, false);
            mc.getNetworkHandler().sendPacket(new PlayerInteractBlockC2SPacket(Hand.MAIN_HAND, hit, 0));
            mc.player.swingHand(Hand.MAIN_HAND);

            switchTo(prevSlot);
            return;
        }
    }

    private void switchTo(int slot) {
        mc.getNetworkHandler().sendPacket(new UpdateSelectedSlotC2SPacket(slot));
        mc.player.getInventory().selectedSlot = slot;
    }

    private int findSlot(boolean slimeOnly) {
        for (int i = 0; i < 9; i++) {
            ItemStack stack = mc.player.getInventory().getStack(i);
            if (stack.isEmpty()) continue;
            if (slimeOnly) {
                if (stack.getItem() == Items.SLIME_BLOCK) return i;
            } else {
                if (stack.getItem() instanceof BlockItem) return i;
            }
        }
        return -1;
    }
}
