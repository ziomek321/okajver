package okyware.wtf.client.modules.impl.combat;

import com.darkmagician6.eventapi.EventTarget;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.Hand;
import okyware.wtf.base.events.impl.player.EventUpdate;
import okyware.wtf.client.modules.api.Category;
import okyware.wtf.client.modules.api.Module;
import okyware.wtf.client.modules.api.ModuleAnnotation;
import okyware.wtf.client.modules.api.setting.impl.NumberSetting;

@ModuleAnnotation(name = "Cwel", category = Category.COMBAT, description = "cwel")
public final class Meow extends Module {
    public static final Meow INSTANCE = new Meow();
    private final NumberSetting range = new NumberSetting("Range", 3.0f, 1.0f, 30.0f, 0.1f);

    private Meow() {}

    @EventTarget
    public void onUpdate(EventUpdate event) {
        if (mc.player == null || mc.world == null) return;
        if (mc.player.getAttackCooldownProgress(0.5f) < 1.0f) return;

        for (PlayerEntity player : mc.world.getPlayers()) {
            if (player == mc.player || !player.isAlive()) continue;
            if (mc.player.distanceTo(player) <= range.getCurrent()) {
                mc.interactionManager.attackEntity(mc.player, player);
                mc.player.swingHand(Hand.MAIN_HAND);
                break;
            }
        }
    }
}

