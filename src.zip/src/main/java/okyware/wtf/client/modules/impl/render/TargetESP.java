package okyware.wtf.client.modules.impl.render;

import com.mojang.blaze3d.platform.GlStateManager.DstFactor;
import com.mojang.blaze3d.platform.GlStateManager.SrcFactor;
import com.mojang.blaze3d.systems.RenderSystem;
import okyware.wtf.Okyware;
import com.darkmagician6.eventapi.EventTarget;
import okyware.wtf.base.events.impl.render.EventRender3D;
import okyware.wtf.client.modules.api.Category;
import okyware.wtf.client.modules.api.ModuleAnnotation;
import okyware.wtf.client.modules.api.Module;
import okyware.wtf.client.modules.api.setting.impl.ColorSetting;
import okyware.wtf.client.modules.api.setting.impl.ModeSetting;
import okyware.wtf.client.modules.api.setting.impl.NumberSetting;
import okyware.wtf.client.modules.api.setting.impl.BooleanSetting;
import okyware.wtf.base.animations.base.Animation;
import okyware.wtf.base.animations.base.Easing;
import okyware.wtf.utility.render.display.base.color.ColorRGBA;
import okyware.wtf.utility.render.display.base.color.ColorRGBA;

import okyware.wtf.utility.math.MathUtil;
import okyware.wtf.utility.render.display.shader.DrawUtil;
import okyware.wtf.utility.render.display.shader.DrawUtil;
import okyware.wtf.utility.render.level.Render3DUtil;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gl.ShaderProgramKeys;
import net.minecraft.client.render.BufferBuilder;
import net.minecraft.client.render.BufferRenderer;
import net.minecraft.client.render.Camera;
import net.minecraft.client.render.Tessellator;
import net.minecraft.client.render.VertexFormats;
import net.minecraft.client.render.VertexFormat.DrawMode;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.LivingEntity;
import net.minecraft.util.Identifier;
import net.minecraft.util.hit.HitResult.Type;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.RotationAxis;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.RaycastContext;
import net.minecraft.world.RaycastContext.FluidHandling;
import net.minecraft.world.RaycastContext.ShapeType;
import org.joml.Matrix4f;
import org.joml.Quaternionf;
import org.joml.Vector3f;
import okyware.wtf.client.modules.impl.combat.Aura;
import org.lwjgl.opengl.GL11;

import java.util.ArrayList;
import java.util.concurrent.CopyOnWriteArrayList;

@ModuleAnnotation(name = "TargetESP", category = Category.RENDER, description = "Draws ESP on your combat target")
public class TargetESP extends Module {
    public static final TargetESP INSTANCE = new TargetESP();
    private final ModeSetting mode = new ModeSetting("Mode", "Ring", "Souls", "Cubes", "Crystals", "Rider");
    
    
    
    
    

    private final BooleanSetting hurtColor = new BooleanSetting("Hurt Color", true);
    private final NumberSetting ringRadius = new NumberSetting("Ring Radius", 0.5f, 0.3f, 1.5f, 0.05f, () -> !mode.is("Ring"));
    private final NumberSetting ringSpeed = new NumberSetting("Ring Speed", 1.0f, 0.3f, 3.0f, 0.1f, () -> !mode.is("Ring"));
    private final NumberSetting bmwGhostCount = new NumberSetting("Rider Count", 3.0f, 2.0f, 5.0f, 1.0f, () -> !mode.is("Rider"));
    private final NumberSetting bmwGhostLife = new NumberSetting("Rider Life (ms)", 350.0f, 150.0f, 500.0f, 25.0f, () -> !mode.is("Rider"));
    private final NumberSetting bmwStrengthXZ = new NumberSetting("Rider XZ Cycle", 2000.0f, 1000.0f, 5000.0f, 100.0f, () -> !mode.is("Rider"));
    private final NumberSetting bmwStrengthY = new NumberSetting("Rider Y Cycle", 1700.0f, 1000.0f, 5000.0f, 100.0f, () -> !mode.is("Rider"));

    private final ColorSetting colorTarget = new ColorSetting("Color", new ColorRGBA(255, 255, 255, 255));

    
    private final Animation animation = new Animation(300L, 0.0F, Easing.BOTH_CUBIC);
    private final Animation moving = new Animation(70L, 0.0F, Easing.LINEAR);
    private LivingEntity prevTarget;

    
    private float appearValue = 0f;
    private float scaleValue = 0f;
    private float rotProgress = 0f;
    private float rotFrom = -280f;
    private float rotTo = 280f;
    private long lastRotateUpdate = System.currentTimeMillis();
    private LivingEntity lastTarget = null;
    private LivingEntity lastHandledTarget = null;
    private Vec3d lastTargetPos = null;
    private float lastTargetHeight = 1.8f;
    private float lastTargetWidth = 0.6f;
    private final CopyOnWriteArrayList<GlowPoint> bmwPoints = new CopyOnWriteArrayList<>();

    private float spawnAccumulator = 0f;
    private long lastCubeTime = 0L;
    private final ArrayList<CubeParticle> cubeParticles = new ArrayList<>();
    private final ArrayList<CubeParticle> renderCubeParticles = new ArrayList<>();
    private static final float SPAWN_INTERVAL = 0.022f;
    private static final int PARTICLES_PER_SPAWN = 1;

    static final long CUBE_ATTACH_LIFE_MS = 560L;
    static final long CUBE_FADE_LIFE_MS = 320L;
    static final int MAX_CUBE_PARTICLES = 72;
    static final byte[][] CUBE_EDGES = {
            {-1, -1, -1, 1, -1, -1}, {1, -1, -1, 1, -1, 1}, {1, -1, 1, -1, -1, 1}, {-1, -1, 1, -1, -1, -1},
            {-1, 1, -1, 1, 1, -1}, {1, 1, -1, 1, 1, 1}, {1, 1, 1, -1, 1, 1}, {-1, 1, 1, -1, 1, -1},
            {-1, -1, -1, -1, 1, -1}, {1, -1, -1, 1, 1, -1}, {1, -1, 1, 1, 1, 1}, {-1, -1, 1, -1, 1, 1}
    };

    @EventTarget
    public void onRender3D(EventRender3D event) {
        if ((mc.world != null && mc.player != null)) {
            LivingEntity target = Aura.INSTANCE.getTarget();
            boolean hasTarget = target != null && target.isAlive();

            this.animation.setEasing(Easing.FIGMA_EASE_IN_OUT);
            this.animation.update(target != null);
            this.moving.update(this.moving.getValue() + 10.0F + 50.0F);
            if (target != null) {
                this.prevTarget = target;
            }

            float speed = 0.05f;
            appearValue = animateTo(appearValue, hasTarget ? 1f : 0f, speed);
            scaleValue = animateTo(scaleValue, hasTarget ? 1f : 0.5f, speed);

            if (hasTarget) {
                this.lastTarget = target;
                this.lastHandledTarget = target;
                
                float td = MinecraftClient.getInstance().getRenderTickCounter().getTickDelta(false);
                lastTargetPos = new Vec3d(
                        MathHelper.lerp(td, target.prevX, target.getX()),
                        MathHelper.lerp(td, target.prevY, target.getY()),
                        MathHelper.lerp(td, target.prevZ, target.getZ())
                );
                lastTargetHeight = target.getHeight();
                lastTargetWidth = target.getWidth();
            }

            if (appearValue <= 0.001f && !hasTarget && this.animation.getValue() <= 0.001f) {
                lastTarget = null;
                lastTargetPos = null;
                return;
            }

            if (lastTargetPos == null && this.prevTarget == null) return;

            MatrixStack ms = event.getMatrix();

            if (mode.is("Crystals")) {
                if (this.prevTarget != null && this.animation.getValue() != 0.0F) {
                    ms.push();
                    RenderSystem.enableBlend();
                    RenderSystem.blendFunc(SrcFactor.SRC_ALPHA, DstFactor.ONE);
                    RenderSystem.enableDepthTest();
                    if (mc.world.raycast(
                            new RaycastContext(mc.gameRenderer.getCamera().getPos(), this.prevTarget.getEyePos(), ShapeType.COLLIDER, FluidHandling.NONE, mc.player)
                        ).getType() != Type.MISS) {
                        RenderSystem.disableDepthTest();
                    }
                    RenderSystem.disableCull();
                    RenderSystem.depthMask(false);

                    this.drawCrystals(ms, this.prevTarget);

                    RenderSystem.depthMask(true);
                    RenderSystem.setShaderTexture(0, 0);
                    RenderSystem.disableBlend();
                    RenderSystem.enableCull();
                    RenderSystem.disableDepthTest();
                    ms.pop();
                }
            } else if (mode.is("Souls")) {
                if (this.prevTarget != null && this.animation.getValue() != 0.0F) {
                    ms.push();
                    RenderSystem.enableBlend();
                    RenderSystem.blendFunc(SrcFactor.SRC_ALPHA, DstFactor.ONE);
                    RenderSystem.enableDepthTest();
                    if (mc.world.raycast(
                            new RaycastContext(mc.gameRenderer.getCamera().getPos(), this.prevTarget.getEyePos(), ShapeType.COLLIDER, FluidHandling.NONE, mc.player)
                        ).getType() != Type.MISS) {
                        RenderSystem.disableDepthTest();
                    }
                    RenderSystem.disableCull();
                    RenderSystem.depthMask(false);

                    this.drawGhosts(ms, this.prevTarget);

                    RenderSystem.depthMask(true);
                    RenderSystem.setShaderTexture(0, 0);
                    RenderSystem.disableBlend();
                    RenderSystem.enableCull();
                    RenderSystem.disableDepthTest();
                    ms.pop();
                }
            } else if (mode.is("Ring")) {
                drawRing3D(event);
            } else if (mode.is("Rider")) {
                if (hasTarget && target != null) {
                    addBMWGhosts(target, MinecraftClient.getInstance().getRenderTickCounter().getTickDelta(false),
                            Math.max(1, Math.round(bmwGhostCount.getCurrent())),
                            Math.max(1, Math.round(bmwGhostLife.getCurrent())),
                            colorTarget.getColor().getRGB());
                }
                bmwPoints.removeIf(GlowPoint::shouldRemove);
                drawBMW3D(event);
            } else if (mode.is("Cubes")) {
                renderCubes(event, target, hasTarget);
            }
        }
    }

    private void drawRing3D(EventRender3D event) {
        if (appearValue <= 0.001f || lastTargetPos == null) return;

        float partialTicks = MinecraftClient.getInstance().getRenderTickCounter().getTickDelta(false);
        Vec3d vec;
        float entityHeight;
        LivingEntity target = lastTarget;

        if (target != null && target.isAlive()) {
            vec = new Vec3d(
                    MathHelper.lerp(partialTicks, target.prevX, target.getX()),
                    MathHelper.lerp(partialTicks, target.prevY, target.getY()),
                    MathHelper.lerp(partialTicks, target.prevZ, target.getZ())
            );
            entityHeight = target.getHeight();
        } else {
            vec = lastTargetPos;
            entityHeight = lastTargetHeight;
        }

        Vec3d cam = mc.gameRenderer.getCamera().getPos();
        double x = vec.x - cam.x;
        double y = vec.y - cam.y;
        double z = vec.z - cam.z;

        double duration = 2000.0 / ringSpeed.getCurrent();
        double elapsed = (double) (System.currentTimeMillis() % (long) duration);
        boolean side = elapsed > duration / 2.0;
        double progress = elapsed / (duration / 2.0);

        if (side) {
            progress -= 1.0;
        } else {
            progress = 1.0 - progress;
        }

        progress = progress < 0.5 ? 2.0 * progress * progress : 1.0 - Math.pow(-2.0 * progress + 2.0, 2.0) / 2.0;
        double eased = (double) entityHeight / 1.2 * (progress > 0.5 ? 1.0 - progress : progress) * (double) (side ? -1 : 1);

        int baseCol = colorTarget.getColor().getRGB();
        float hurtPC = getHurtPC(target);
        int redCol = rgb(255, 3, 3);
        int mainColor = overCol(baseCol, redCol, hurtPC);

        int colorWithAlpha = setAlpha(mainColor, 225.0f / 255.0f * appearValue);
        int colorTransparent = setAlpha(mainColor, 1.0f / 255.0f * appearValue);
        int colorFull = setAlpha(mainColor, appearValue);
        double radius = ringRadius.getCurrent();

        MatrixStack matrices = event.getMatrix();
        Matrix4f matrix = matrices.peek().getPositionMatrix();

        RenderSystem.depthMask(false);
        RenderSystem.disableDepthTest();
        RenderSystem.enableBlend();
        RenderSystem.blendFunc(GL11.GL_SRC_ALPHA, GL11.GL_ONE);
        RenderSystem.disableCull();
        RenderSystem.setShader(ShaderProgramKeys.POSITION_COLOR);

        BufferBuilder buffer = RenderSystem.renderThreadTesselator().begin(DrawMode.TRIANGLE_STRIP, VertexFormats.POSITION_COLOR);
        for (int i = 0; i <= 360; i++) {
            double rad = Math.toRadians(i);
            float px = (float) (x + Math.cos(rad) * radius);
            float pz = (float) (z + Math.sin(rad) * radius);
            float py1 = (float) (y + entityHeight * progress);
            float py2 = (float) (y + entityHeight * progress + eased);

            buffer.vertex(matrix, px, py1, pz).color(colorWithAlpha);
            buffer.vertex(matrix, px, py2, pz).color(colorTransparent);
        }
        BufferRenderer.drawWithGlobalProgram(buffer.end());

        RenderSystem.lineWidth(1.5f);
        BufferBuilder lineBuffer = RenderSystem.renderThreadTesselator().begin(DrawMode.DEBUG_LINE_STRIP, VertexFormats.POSITION_COLOR);
        for (int i = 0; i <= 360; i++) {
            double rad = Math.toRadians(i);
            float px = (float) (x + Math.cos(rad) * radius);
            float pz = (float) (z + Math.sin(rad) * radius);
            float py = (float) (y + entityHeight * progress);

            lineBuffer.vertex(matrix, px, py, pz).color(colorFull);
        }
        BufferRenderer.drawWithGlobalProgram(lineBuffer.end());

        RenderSystem.enableCull();
        RenderSystem.disableBlend();
        RenderSystem.depthMask(true);
        RenderSystem.enableDepthTest();
    }

    private void addBMWGhosts(LivingEntity entity, float partialTicks, int cornersCount, int maxTime, int colorBase) {
        float xzRange = 0.7f;
        float yRange = entity.getHeight();
        int delayXZ = (int) bmwStrengthXZ.getCurrent();
        int delayY = (int) bmwStrengthY.getCurrent();
        long time = System.currentTimeMillis();
        float rotateProgress = (float) (time % delayXZ) / (float) delayXZ;
        float xzRotate = rotateProgress * 360.0f;
        float yProgress = (float) (time % delayY) / (float) delayY;
        float yLrpPC = 0.5f - 0.5f * MathHelper.cos(yProgress * (float) (Math.PI * 2.0));

        for (int corner = 0; corner < cornersCount; corner++) {
            float cornersPC = (float) corner / (float) cornersCount;
            double yawRad = Math.toRadians(MathHelper.wrapDegrees(cornersPC * 360.0f + xzRotate));
            float offsetX = -(float) Math.sin(yawRad) * xzRange;
            float offsetY = yRange * yLrpPC;
            float offsetZ = (float) Math.cos(yawRad) * xzRange;
            bmwPoints.add(new GlowPoint(offsetX, offsetY, offsetZ, maxTime, colorBase));
        }
    }

    private void drawBMW3D(EventRender3D event) {
        if (bmwPoints.isEmpty() || appearValue <= 0.001f) return;

        LivingEntity renderTarget = lastTarget != null ? lastTarget : lastHandledTarget;
        if (renderTarget == null && lastTargetPos == null) return;

        float partialTicks = MinecraftClient.getInstance().getRenderTickCounter().getTickDelta(false);
        Vec3d basePos;
        if (renderTarget != null && renderTarget.isAlive()) {
            basePos = new Vec3d(
                    MathHelper.lerp(partialTicks, renderTarget.prevX, renderTarget.getX()),
                    MathHelper.lerp(partialTicks, renderTarget.prevY, renderTarget.getY()),
                    MathHelper.lerp(partialTicks, renderTarget.prevZ, renderTarget.getZ())
            );
        } else {
            basePos = lastTargetPos;
        }

        if (basePos == null) return;

        Vec3d cam = mc.gameRenderer.getCamera().getPos();
        float hurtPC = getHurtPC(renderTarget);
        float fixedScreenSize = 6f;

        RenderSystem.disableDepthTest();
        RenderSystem.enableBlend();
        RenderSystem.depthMask(false);
        RenderSystem.disableCull();
        RenderSystem.blendFunc(GL11.GL_SRC_ALPHA, GL11.GL_ONE);
        RenderSystem.setShader(ShaderProgramKeys.POSITION_TEX_COLOR);
        RenderSystem.setShaderTexture(0, getBloomTexture());

        MatrixStack matrices = event.getMatrix();

        for (GlowPoint point : bmwPoints) {
            float timePC = point.getTimeProgress();
            float trailFactor = 1.0f - timePC * 0.6f;

            double worldX = basePos.x + point.x;
            double worldY = basePos.y + point.y;
            double worldZ = basePos.z + point.z;

            float sz = fixedScreenSize * trailFactor;
            int alpha = (int) (255 * appearValue * trailFactor * 0.8f);
            alpha = Math.max(0, Math.min(255, alpha));
            int col = replAlpha(point.baseColor, alpha);
            int red = replAlpha(rgb(255, 3, 3), alpha);
            int finalColor = overCol(col, red, hurtPC);

            drawBillboard(matrices, cam, worldX, worldY, worldZ, sz, finalColor, 0);
        }

        RenderSystem.enableCull();
        RenderSystem.enableDepthTest();
        RenderSystem.defaultBlendFunc();
        RenderSystem.disableBlend();
        RenderSystem.depthMask(true);
    }

    private void renderCubes(EventRender3D event, LivingEntity target, boolean hasTarget) {
        long now = System.currentTimeMillis();
        if (lastCubeTime == 0L) lastCubeTime = now;
        float dt = Math.min((now - lastCubeTime) / 1000.0f, 0.1f);
        lastCubeTime = now;
        if (!Float.isFinite(dt) || mc.gameRenderer == null || mc.gameRenderer.getCamera() == null) {
            return;
        }

        if (hasTarget && target != null) {
            lastTarget = target;
            spawnAccumulator += dt;
            while (spawnAccumulator >= SPAWN_INTERVAL) {
                spawnAccumulator -= SPAWN_INTERVAL;
                if (cubeParticles.size() >= MAX_CUBE_PARTICLES) {
                    break;
                }
                for (int i = 0; i < PARTICLES_PER_SPAWN; i++) {
                    double rand = Math.random() * 360.0;
                    double px = Math.cos(Math.toRadians(rand)) * 0.7;
                    double py = 0.02 + Math.random() * 0.10;
                    double pz = Math.sin(Math.toRadians(rand)) * 0.7;
                    cubeParticles.add(new CubeParticle(target, px, py, pz));
                }
            }
        } else {
            spawnAccumulator = 0f;
        }

        renderCubeParticles.clear();
        for (int i = cubeParticles.size() - 1; i >= 0; i--) {
            CubeParticle particle = cubeParticles.get(i);
            try {
                particle.update(dt, now, hasTarget ? target : null);
                if (particle.shouldRemove(now)) {
                    cubeParticles.remove(i);
                } else {
                    renderCubeParticles.add(particle);
                }
            } catch (Throwable ignored) {
                cubeParticles.remove(i);
            }
        }

        if (renderCubeParticles.isEmpty()) {
            return;
        }

        float partialTicks = MinecraftClient.getInstance().getRenderTickCounter().getTickDelta(false);
        MatrixStack matrices = event.getMatrix();
        Vec3d camPos = mc.gameRenderer.getCamera().getPos();
        LivingEntity colorTarget = hasTarget ? target : lastTarget;
        float hurtPC = getHurtPC(colorTarget);
        int baseColor = colorTarget != null ? this.colorTarget.getColor().getRGB() : this.colorTarget.getColor().getRGB();
        int redColor = rgb(255, 3, 3);

        RenderSystem.enableBlend();
        RenderSystem.enableDepthTest();
        RenderSystem.disableCull();
        RenderSystem.depthMask(false);
        RenderSystem.blendFunc(GL11.GL_SRC_ALPHA, GL11.GL_ONE);
        RenderSystem.setShader(ShaderProgramKeys.POSITION_COLOR);

        BufferBuilder faceBuilder = RenderSystem.renderThreadTesselator().begin(DrawMode.QUADS, VertexFormats.POSITION_COLOR);
        boolean hasFaces = false;
        for (int i = 0, size = renderCubeParticles.size(); i < size; i++) {
            CubeParticle particle = renderCubeParticles.get(i);
            try {
                int particleColor = particle.getRenderColor(baseColor, redColor, hurtPC, now);
                if (((particleColor >> 24) & 0xFF) <= 0) continue;
                if (particle.appendCubeFaces(faceBuilder, matrices, camPos, partialTicks, particleColor)) {
                    hasFaces = true;
                }
            } catch (Throwable ignored) {
            }
        }
        if (hasFaces) BufferRenderer.drawWithGlobalProgram(faceBuilder.end());

        BufferBuilder lineBuilder = RenderSystem.renderThreadTesselator().begin(DrawMode.DEBUG_LINES, VertexFormats.POSITION_COLOR);
        boolean hasLines = false;
        for (int i = 0, size = renderCubeParticles.size(); i < size; i++) {
            CubeParticle particle = renderCubeParticles.get(i);
            try {
                int particleColor = particle.getRenderColor(baseColor, redColor, hurtPC, now);
                if (((particleColor >> 24) & 0xFF) <= 0) continue;
                if (particle.appendCubeLines(lineBuilder, matrices, camPos, partialTicks, particleColor)) {
                    hasLines = true;
                }
            } catch (Throwable ignored) {
            }
        }
        if (hasLines) BufferRenderer.drawWithGlobalProgram(lineBuilder.end());

        RenderSystem.setShader(ShaderProgramKeys.POSITION_TEX_COLOR);
        RenderSystem.setShaderTexture(0, getBloomTexture());
        BufferBuilder bloomBuilder = RenderSystem.renderThreadTesselator().begin(DrawMode.QUADS, VertexFormats.POSITION_TEXTURE_COLOR);
        boolean hasBloom = false;
        float camYaw = mc.gameRenderer.getCamera().getYaw();
        float camPitch = mc.gameRenderer.getCamera().getPitch();
        for (int i = 0, size = renderCubeParticles.size(); i < size; i++) {
            CubeParticle particle = renderCubeParticles.get(i);
            try {
                int particleColor = particle.getRenderColor(baseColor, redColor, hurtPC, now);
                if (particle.appendBloom(bloomBuilder, matrices, camPos, camYaw, camPitch, partialTicks, particleColor, now)) {
                    hasBloom = true;
                }
            } catch (Throwable ignored) {
            }
        }
        if (hasBloom) BufferRenderer.drawWithGlobalProgram(bloomBuilder.end());

        RenderSystem.depthMask(true);
        RenderSystem.defaultBlendFunc();
        RenderSystem.disableBlend();
        RenderSystem.enableCull();
        RenderSystem.enableDepthTest();
    }

    private Identifier getBloomTexture() {
        return Okyware.id("textures/bloom.png");
    }

    private void drawBillboard(MatrixStack matrices, Vec3d cameraPos, double worldX, double worldY, double worldZ, float baseScreenSize, int color, float rotation) {
        float distScale = getDistanceScale(cameraPos, worldX, worldY, worldZ);
        float half = baseScreenSize * distScale * 0.5f;
        drawBillboardInternal(matrices, cameraPos, worldX, worldY, worldZ, half, color, rotation);
    }

    private float getDistanceScale(Vec3d cameraPos, double worldX, double worldY, double worldZ) {
        double dx = worldX - cameraPos.x;
        double dy = worldY - cameraPos.y;
        double dz = worldZ - cameraPos.z;
        double distance = Math.sqrt(dx * dx + dy * dy + dz * dz);
        return (float) Math.max(0.1, distance * 0.007f);
    }

    private void drawBillboardInternal(MatrixStack matrices, Vec3d cameraPos, double worldX, double worldY, double worldZ, float half, int color, float rotation) {
        int r = (color >> 16) & 0xFF;
        int g = (color >> 8) & 0xFF;
        int b = color & 0xFF;
        int a = (color >> 24) & 0xFF;
        if (a <= 0) return;

        matrices.push();
        matrices.translate(worldX - cameraPos.x, worldY - cameraPos.y, worldZ - cameraPos.z);
        matrices.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(-mc.gameRenderer.getCamera().getYaw()));
        matrices.multiply(RotationAxis.POSITIVE_X.rotationDegrees(mc.gameRenderer.getCamera().getPitch()));
        if (rotation != 0) {
            matrices.multiply(RotationAxis.POSITIVE_Z.rotationDegrees(rotation));
        }

        Matrix4f matrix = matrices.peek().getPositionMatrix();
        BufferBuilder buffer = RenderSystem.renderThreadTesselator().begin(DrawMode.QUADS, VertexFormats.POSITION_TEXTURE_COLOR);
        buffer.vertex(matrix, -half, -half, 0).texture(0, 1).color(r, g, b, a);
        buffer.vertex(matrix, -half, half, 0).texture(0, 0).color(r, g, b, a);
        buffer.vertex(matrix, half, half, 0).texture(1, 0).color(r, g, b, a);
        buffer.vertex(matrix, half, -half, 0).texture(1, 1).color(r, g, b, a);
        BufferRenderer.drawWithGlobalProgram(buffer.end());
        matrices.pop();
    }

    private float animateTo(float current, float target, float delta) {
        if (current < target) {
            current = Math.min(current + delta, target);
        } else if (current > target) {
            current = Math.max(current - delta, target);
        }
        return current;
    }

    private int rgb(int r, int g, int b) {
        return 0xFF000000 | (r << 16) | (g << 8) | b;
    }

    private int multAlpha(int color, float mult) {
        int a = (int) (((color >> 24) & 0xFF) * mult);
        a = Math.max(0, Math.min(255, a));
        return (a << 24) | (color & 0x00FFFFFF);
    }

    private int replAlpha(int color, int alpha) {
        alpha = Math.max(0, Math.min(255, alpha));
        return (alpha << 24) | (color & 0x00FFFFFF);
    }

    private int setAlpha(int color, float alpha) {
        alpha = Math.max(0.0f, Math.min(1.0f, alpha));
        return (color & 0x00FFFFFF) | ((int) (alpha * 255) << 24);
    }

    public int overCol(int color1, int color2, float factor) {
        factor = Math.max(0f, Math.min(1f, factor));
        int r1 = (color1 >> 16) & 0xFF, g1 = (color1 >> 8) & 0xFF, b1 = color1 & 0xFF, a1 = (color1 >> 24) & 0xFF;
        int r2 = (color2 >> 16) & 0xFF, g2 = (color2 >> 8) & 0xFF, b2 = color2 & 0xFF, a2 = (color2 >> 24) & 0xFF;
        int r = (int) (r1 + (r2 - r1) * factor);
        int g = (int) (g1 + (g2 - g1) * factor);
        int b = (int) (b1 + (b2 - b1) * factor);
        int a = (int) (a1 + (a2 - a1) * factor);
        return (a << 24) | (r << 16) | (g << 8) | b;
    }

    private float getHurtPC(LivingEntity target) {
        if (!hurtColor.isEnabled() || target == null) return 0f;
        float partialTicks = MinecraftClient.getInstance().getRenderTickCounter().getTickDelta(false);
        float hurtTicks = MathHelper.clamp(target.hurtTime - partialTicks, 0.0f, 10.0f);
        float progress = hurtTicks / 10.0f;
        return progress * progress * (3.0f - 2.0f * progress);
    }

    private Vec3d getRenderPos(LivingEntity target) {
        float tickDelta = MinecraftClient.getInstance().getRenderTickCounter().getTickDelta(false);
        return new Vec3d(
                MathHelper.lerp(tickDelta, target.prevX, target.getX()),
                MathHelper.lerp(tickDelta, target.prevY, target.getY()),
                MathHelper.lerp(tickDelta, target.prevZ, target.getZ())
        );
    }

    private void drawQuad(MatrixStack ms, float half, ColorRGBA color) {
        Matrix4f matrix = ms.peek().getPositionMatrix();
        BufferBuilder buffer = RenderSystem.renderThreadTesselator().begin(DrawMode.QUADS, VertexFormats.POSITION_TEXTURE_COLOR);
        int r = color.getRed(), g = color.getGreen(), b = color.getBlue(), a = color.getAlpha();
        buffer.vertex(matrix, -half, half, 0).texture(0, 0).color(r, g, b, a);
        buffer.vertex(matrix, -half, -half, 0).texture(0, 1).color(r, g, b, a);
        buffer.vertex(matrix, half, -half, 0).texture(1, 1).color(r, g, b, a);
        buffer.vertex(matrix, half, half, 0).texture(1, 0).color(r, g, b, a);
        BufferRenderer.drawWithGlobalProgram(buffer.end());
    }

    private void drawCrystals(MatrixStack ms, LivingEntity target) {
        Camera camera = mc.gameRenderer.getCamera();
        Vec3d cameraPos = camera.getPos();
        ColorRGBA color = this.colorTarget.getColor();
        float width = this.prevTarget.getWidth() * 1.5F;
        Vec3d targetPos = this.getRenderPos(this.prevTarget);

        RenderSystem.setShaderTexture(0, getBloomTexture());
        RenderSystem.setShader(ShaderProgramKeys.POSITION_TEX_COLOR);

        ms.push();
        ms.translate(targetPos.x - cameraPos.x, targetPos.y - cameraPos.y, targetPos.z - cameraPos.z);

        float bigSize = 1.0F;

        for (int i = 0; i < 360; i += 20) {
            float val = 1.2F - 0.5F * this.animation.getValue();
            float sin = (float)(MathHelper.sin((float)Math.toRadians(i + this.moving.getValue() * 0.3F)) * width * val);
            float cos = (float)(MathHelper.cos((float)Math.toRadians(i + this.moving.getValue() * 0.3F)) * width * val);
            
            ms.push();
            ms.translate(sin, 0.1F + target.getHeight() * Math.abs(MathHelper.sin(i)), cos);
            ms.multiply(camera.getRotation());
            
            ColorRGBA c = color.mulAlpha(this.animation.getValue() * 0.2F);
            drawQuad(ms, bigSize / 2.0F, c);
            
            ms.pop();
        }
        ms.pop();
    }

    private void drawGhosts(MatrixStack ms, LivingEntity target) {
        Camera camera = mc.gameRenderer.getCamera();
        Vec3d cameraPos = camera.getPos();
        ColorRGBA color = this.colorTarget.getColor();
        float width = this.prevTarget.getWidth() * 1.5F;
        Vec3d targetPos = this.getRenderPos(this.prevTarget);
        
        RenderSystem.setShaderTexture(0, getBloomTexture());
        RenderSystem.setShader(ShaderProgramKeys.POSITION_TEX_COLOR);
        
        ms.push();
        ms.translate(targetPos.x - cameraPos.x, targetPos.y - cameraPos.y, targetPos.z - cameraPos.z);
        
        int step = 2;
        int wormTick = 0;
        int wormCD = 0;

        for (int i = 0; i < 360; i += step) {
            float size = 0.13F + 0.005F * wormTick;
            float bigSize = 0.7F + 0.005F * wormTick;
            if (wormCD > 0) {
                wormCD -= step;
            } else {
                wormTick += step;
                if (wormTick > 50) {
                    wormCD = 100;
                    wormTick = 0;
                } else {
                    float val = Math.max(0.5F, 1.2F - 0.5F * this.animation.getValue());
                    float sin = (float)(MathHelper.sin((float)Math.toRadians(i + this.moving.getValue() * 1.0F)) * width * val);
                    float cos = (float)(MathHelper.cos((float)Math.toRadians(i + this.moving.getValue() * 1.0F)) * width * val);
                    ms.push();
                    ms.translate(
                            sin,
                            this.prevTarget.getHeight() / 1.5F
                                    + this.prevTarget.getHeight() / 3.0F * (float)MathHelper.sin((float)Math.toRadians(i / 2.0F + this.moving.getValue() / 5.0F)),
                            cos
                    );
                    ms.multiply(camera.getRotation());
                    
                    ColorRGBA cBig = color.mulAlpha(this.animation.getValue() * 0.05F);
                    drawQuad(ms, bigSize / 2.0F, cBig);
                    
                    ColorRGBA cSmall = color.mulAlpha(this.animation.getValue());
                    drawQuad(ms, size / 2.0F, cSmall);
                    
                    ms.pop();
                }
            }
        }
        ms.pop();
    }

    public void tick() {
    }

    private static class GlowPoint {
        final float x, y, z;
        final long startTime;
        final int maxLife;
        final int baseColor;

        GlowPoint(float x, float y, float z, int maxLife, int baseColor) {
            this.x = x;
            this.y = y;
            this.z = z;
            this.startTime = System.currentTimeMillis();
            this.maxLife = maxLife;
            this.baseColor = baseColor;
        }

        boolean shouldRemove() {
            return System.currentTimeMillis() - startTime >= maxLife;
        }

        float getTimeProgress() {
            return MathHelper.clamp((System.currentTimeMillis() - startTime) / (float) maxLife, 0f, 1f);
        }

        int getColor(float timePC) {
            int a = (int) (((baseColor >> 24) & 0xFF) * (1.0f - timePC));
            a = Math.max(0, Math.min(255, a));
            return (a << 24) | (baseColor & 0x00FFFFFF);
        }
    }

    private static class CubeParticle {
        double x, y, z;
        double worldX, worldY, worldZ;
        long time;
        LivingEntity entity;
        boolean fading;
        long fadeStartTime;
        float vx, vy, vz;
        float rotX, rotY, rotZ;
        float rotSpeedX, rotSpeedY, rotSpeedZ;

        public CubeParticle(LivingEntity entity, double x, double y, double z) {
            this.entity = entity;
            this.x = x;
            this.y = y;
            this.z = z;
            this.time = System.currentTimeMillis();
            this.rotX = (float) (Math.random() * 360.0);
            this.rotY = (float) (Math.random() * 360.0);
            this.rotZ = (float) (Math.random() * 360.0);
            this.rotSpeedX = 1.4f + (float) Math.random() * 3.4f;
            this.rotSpeedY = 1.4f + (float) Math.random() * 3.4f;
            this.rotSpeedZ = 1.4f + (float) Math.random() * 3.4f;
            this.vx = (float) ((Math.random() - 0.5) * 0.0022);
            this.vy = 0.031f + (float) Math.random() * 0.020f;
            this.vz = (float) ((Math.random() - 0.5) * 0.0022);
        }

        public void update(float dt, long now, LivingEntity currentTarget) {
            float step = dt * 60.0f;
            rotX += rotSpeedX * step;
            rotY += rotSpeedY * step;
            rotZ += rotSpeedZ * step;

            if (!fading) {
                x += vx * step;
                y += vy * step;
                z += vz * step;
                vx *= 0.992f;
                vz *= 0.992f;
                vy *= 0.989f;

                if (entity != null) {
                    double shoulderHeight = Math.max(2.2, entity.getHeight() * 1.85);
                    if (y >= shoulderHeight) {
                        y = shoulderHeight;
                        beginFade(now);
                        return;
                    }
                }

                boolean targetLost = currentTarget == null || entity == null || !entity.isAlive() || entity != currentTarget;
                if (targetLost || now - time >= CUBE_ATTACH_LIFE_MS) {
                    beginFade(now);
                }
                return;
            }
        }

        public boolean shouldRemove(long now) {
            return fading && now - fadeStartTime >= CUBE_FADE_LIFE_MS;
        }

        public int getRenderColor(int baseColor, int redColor, float hurtPC, long now) {
            float alpha = getAlpha(now);
            if (alpha <= 0.001f) {
                return 0;
            }
            int color = replAlpha(baseColor, (int) (alpha * 255.0f));
            int hurt = replAlpha(redColor, (int) (alpha * 255.0f));
            
            int factor = Math.max(0, Math.min(1, (int)hurtPC));
            int r1 = (color >> 16) & 0xFF, g1 = (color >> 8) & 0xFF, b1 = color & 0xFF, a1 = (color >> 24) & 0xFF;
            int r2 = (hurt >> 16) & 0xFF, g2 = (hurt >> 8) & 0xFF, b2 = hurt & 0xFF, a2 = (hurt >> 24) & 0xFF;
            int r = (int) (r1 + (r2 - r1) * hurtPC);
            int g = (int) (g1 + (g2 - g1) * hurtPC);
            int b = (int) (b1 + (b2 - b1) * hurtPC);
            int a = (int) (a1 + (a2 - a1) * hurtPC);
            return (a << 24) | (r << 16) | (g << 8) | b;
        }

        private int replAlpha(int color, int alpha) {
            alpha = Math.max(0, Math.min(255, alpha));
            return (alpha << 24) | (color & 0x00FFFFFF);
        }

        public boolean appendCubeFaces(BufferBuilder faceBuilder, MatrixStack ms, Vec3d cam,
                                       float partialTicks, int color) {
            float alpha = ((color >> 24) & 0xFF) / 255.0f;
            if (alpha <= 0.001f) return false;

            Vec3d renderPos = getRenderPos(partialTicks);
            if (renderPos == null) return false;

            float fadeScale = fading
                    ? MathHelper.lerp(MathHelper.clamp((System.currentTimeMillis() - fadeStartTime) / (float) CUBE_FADE_LIFE_MS, 0.0f, 1.0f), 1.0f, 0.45f)
                    : 1.0f;
            float scale = 0.12f * fadeScale;

            ms.push();
            ms.translate(renderPos.x - cam.x, renderPos.y - cam.y, renderPos.z - cam.z);
            ms.multiply(RotationAxis.POSITIVE_X.rotationDegrees(rotX));
            ms.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(rotY));
            ms.multiply(RotationAxis.POSITIVE_Z.rotationDegrees(rotZ));
            ms.scale(scale, scale, scale);
            Matrix4f m = ms.peek().getPositionMatrix();

            appendFaces(faceBuilder, m, color);
            ms.pop();
            return true;
        }

        public boolean appendCubeLines(BufferBuilder lineBuilder, MatrixStack ms, Vec3d cam,
                                       float partialTicks, int color) {
            float alpha = ((color >> 24) & 0xFF) / 255.0f;
            if (alpha <= 0.001f) return false;

            Vec3d renderPos = getRenderPos(partialTicks);
            if (renderPos == null) return false;

            float fadeScale = fading
                    ? MathHelper.lerp(MathHelper.clamp((System.currentTimeMillis() - fadeStartTime) / (float) CUBE_FADE_LIFE_MS, 0.0f, 1.0f), 1.0f, 0.45f)
                    : 1.0f;
            float scale = 0.12f * fadeScale;

            ms.push();
            ms.translate(renderPos.x - cam.x, renderPos.y - cam.y, renderPos.z - cam.z);
            ms.multiply(RotationAxis.POSITIVE_X.rotationDegrees(rotX));
            ms.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(rotY));
            ms.multiply(RotationAxis.POSITIVE_Z.rotationDegrees(rotZ));
            ms.scale(scale, scale, scale);
            Matrix4f m = ms.peek().getPositionMatrix();

            appendEdges(lineBuilder, m, replAlpha(color, Math.max(1, (int) (((color >> 24) & 0xFF) * 0.7f))));
            ms.pop();
            return true;
        }

        public boolean appendBloom(BufferBuilder builder, MatrixStack ms, Vec3d camPos, float camYaw, float camPitch,
                                   float partialTicks, int colorInt, long now) {
            float alpha = getAlpha(now);
            if (alpha <= 0.001f) return false;

            Vec3d renderPos = getRenderPos(partialTicks);
            if (renderPos == null) return false;

            float fadeScale = fading
                    ? MathHelper.lerp(MathHelper.clamp((now - fadeStartTime) / (float) CUBE_FADE_LIFE_MS, 0.0f, 1.0f), 1.0f, 0.55f)
                    : 1.0f;
            float glowScale = 0.95f * fadeScale;
            int ai = (int) (alpha * 0.15f * 255.0f);
            if (ai <= 0) return false;

            int r = (colorInt >> 16) & 0xFF;
            int g = (colorInt >> 8) & 0xFF;
            int b = colorInt & 0xFF;

            ms.push();
            ms.translate(renderPos.x - camPos.x, renderPos.y - camPos.y, renderPos.z - camPos.z);
            ms.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(-camYaw));
            ms.multiply(RotationAxis.POSITIVE_X.rotationDegrees(camPitch));
            ms.scale(glowScale, glowScale, glowScale);
            Matrix4f m = ms.peek().getPositionMatrix();

            builder.vertex(m, -0.5f, 0.5f, 0).texture(0f, 1f).color(r, g, b, ai);
            builder.vertex(m, 0.5f, 0.5f, 0).texture(1f, 1f).color(r, g, b, ai);
            builder.vertex(m, 0.5f, -0.5f, 0).texture(1f, 0f).color(r, g, b, ai);
            builder.vertex(m, -0.5f, -0.5f, 0).texture(0f, 0f).color(r, g, b, ai);
            ms.pop();
            return true;
        }

        private void beginFade(long now) {
            if (fading) return;
            Vec3d renderPos = getRenderPos(1.0f);
            if (renderPos != null) {
                worldX = renderPos.x;
                worldY = renderPos.y;
                worldZ = renderPos.z;
            }
            fadeStartTime = now;
            fading = true;
            entity = null;
        }

        private float getAlpha(long now) {
            if (!fading) {
                float fadeIn = MathHelper.clamp((now - time) / 140.0f, 0.0f, 1.0f);
                float preFade = 1.0f - MathHelper.clamp((now - time - (CUBE_ATTACH_LIFE_MS - 120L)) / 120.0f, 0.0f, 0.35f);
                return fadeIn * preFade;
            }
            return 1.0f - MathHelper.clamp((now - fadeStartTime) / (float) CUBE_FADE_LIFE_MS, 0.0f, 1.0f);
        }

        private Vec3d getRenderPos(float partialTicks) {
            if (fading || entity == null) {
                return new Vec3d(worldX, worldY, worldZ);
            }
            return new Vec3d(
                    MathHelper.lerp(partialTicks, entity.prevX, entity.getX()) + x,
                    MathHelper.lerp(partialTicks, entity.prevY, entity.getY()) + y,
                    MathHelper.lerp(partialTicks, entity.prevZ, entity.getZ()) + z
            );
        }

        private void appendFaces(BufferBuilder fb, Matrix4f m, int color) {
            float min = -0.5f, max = 0.5f;
            int fillColor = replAlpha(color, Math.max(1, (int) (((color >> 24) & 0xFF) * 0.16f)));
            addFace(fb, m, min, min, min, max, max, max, fillColor);
        }

        private void appendEdges(BufferBuilder buf, Matrix4f m, int color) {
            for (byte[] edge : CUBE_EDGES) {
                buf.vertex(m, edge[0] * 0.5f, edge[1] * 0.5f, edge[2] * 0.5f).color(color);
                buf.vertex(m, edge[3] * 0.5f, edge[4] * 0.5f, edge[5] * 0.5f).color(color);
            }
        }

        private void addFace(BufferBuilder buf, Matrix4f m,
                             float x1, float y1, float z1, float x2, float y2, float z2,
                             int color) {
            buf.vertex(m, x1, y1, z1).color(color);
            buf.vertex(m, x2, y1, z1).color(color);
            buf.vertex(m, x2, y1, z2).color(color);
            buf.vertex(m, x1, y1, z2).color(color);

            buf.vertex(m, x1, y2, z1).color(color);
            buf.vertex(m, x1, y2, z2).color(color);
            buf.vertex(m, x2, y2, z2).color(color);
            buf.vertex(m, x2, y2, z1).color(color);

            buf.vertex(m, x1, y1, z1).color(color);
            buf.vertex(m, x1, y2, z1).color(color);
            buf.vertex(m, x2, y2, z1).color(color);
            buf.vertex(m, x2, y1, z1).color(color);

            buf.vertex(m, x1, y1, z2).color(color);
            buf.vertex(m, x2, y1, z2).color(color);
            buf.vertex(m, x2, y2, z2).color(color);
            buf.vertex(m, x1, y2, z2).color(color);

            buf.vertex(m, x1, y1, z1).color(color);
            buf.vertex(m, x1, y1, z2).color(color);
            buf.vertex(m, x1, y2, z2).color(color);
            buf.vertex(m, x1, y2, z1).color(color);

            buf.vertex(m, x2, y1, z1).color(color);
            buf.vertex(m, x2, y2, z1).color(color);
            buf.vertex(m, x2, y2, z2).color(color);
            buf.vertex(m, x2, y1, z2).color(color);
        }
    }
}


