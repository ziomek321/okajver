package okyware.wtf.client.modules.impl.combat;

import com.darkmagician6.eventapi.EventTarget;
import okyware.wtf.Okyware;
import okyware.wtf.base.events.impl.player.EventUpdate;
import okyware.wtf.base.events.impl.render.EventRender3D;
import okyware.wtf.client.modules.api.Category;
import okyware.wtf.client.modules.api.Module;
import okyware.wtf.client.modules.api.ModuleAnnotation;
import okyware.wtf.client.modules.api.setting.impl.BooleanSetting;
import okyware.wtf.client.modules.api.setting.impl.NumberSetting;
import okyware.wtf.utility.interfaces.BacktrackableEntity;
import okyware.wtf.utility.render.display.base.color.ColorRGBA;
import okyware.wtf.utility.render.level.Render3DUtil;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;

import java.util.List;

@ModuleAnnotation(name = "Backtrack", category = Category.COMBAT, description = "Records past target positions and shows a hitbox where they used to be a moment ago.")
public final class Backtrack extends Module {
    public static final Backtrack INSTANCE = new Backtrack();

    private final NumberSetting delay = new NumberSetting("Delay (ms)", 100, 50, 1000, 50);
    private final BooleanSetting visual = new BooleanSetting("Visual", true);
    private final BooleanSetting ignoreFriends = new BooleanSetting("Ignore Friends", true);

    private Backtrack() {
    }

    @Override
    public void onDisable() {
        if (mc.world == null) {
            super.onDisable();
            return;
        }
        for (PlayerEntity p : mc.world.getPlayers()) {
            if (p instanceof BacktrackableEntity bt) bt.getBackTracks().clear();
        }
        super.onDisable();
    }

    @EventTarget
    public void onUpdate(EventUpdate event) {
        if (mc.world == null) return;
        long now = System.currentTimeMillis();
        long maxAge = (long) delay.getCurrent();

        for (PlayerEntity p : mc.world.getPlayers()) {
            if (p == mc.player) continue;
            if (!(p instanceof BacktrackableEntity bt)) continue;
            List<BacktrackableEntity.Position> list = bt.getBackTracks();
            list.removeIf(pos -> now - pos.time() > maxAge);
        }
    }

    @EventTarget
    public void onRender3D(EventRender3D event) {
        if (!visual.isEnabled() || mc.world == null) return;

        ColorRGBA color = Okyware.getInstance().getThemeManager().getClientColor(0);
        for (PlayerEntity p : mc.world.getPlayers()) {
            if (p == mc.player) continue;
            if (ignoreFriends.isEnabled() && Okyware.getInstance().getFriendManager().isFriend(p.getGameProfile().getName())) continue;
            if (!(p instanceof BacktrackableEntity bt)) continue;
            List<BacktrackableEntity.Position> list = bt.getBackTracks();
            if (list.isEmpty()) continue;

            BacktrackableEntity.Position last = list.get(list.size() - 1);
            Vec3d offset = last.pos().subtract(p.getPos());
            Box box = p.getBoundingBox().offset(offset);
            Render3DUtil.drawBox(box, color.mulAlpha(0.7f).getRGB(), 1.5f, true, false, false);
        }
    }
}
