package okyware.wtf.client.modules.impl.combat;

import com.darkmagician6.eventapi.EventTarget;
import okyware.wtf.base.events.impl.player.EventUpdate;
import okyware.wtf.base.rotation.RotationTarget;
import okyware.wtf.client.modules.api.Category;
import okyware.wtf.client.modules.api.Module;
import okyware.wtf.client.modules.api.ModuleAnnotation;
import okyware.wtf.client.modules.api.setting.impl.ModeSetting;
import okyware.wtf.client.modules.api.setting.impl.MultiBooleanSetting;
import okyware.wtf.client.modules.api.setting.impl.NumberSetting;
import okyware.wtf.client.modules.impl.render.PlaceHighlight;
import okyware.wtf.utility.game.player.rotation.Rotation;
import okyware.wtf.utility.game.player.rotation.RotationUtil;
import net.minecraft.item.BlockItem;
import net.minecraft.item.ItemStack;
import net.minecraft.network.packet.c2s.play.PlayerInteractBlockC2SPacket;
import net.minecraft.network.packet.c2s.play.UpdateSelectedSlotC2SPacket;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;

@ModuleAnnotation(name = "SelfTrap", category = Category.COMBAT, description = "Builds a protective trap around yourself")
public final class SelfTrap extends Module {
    public static final SelfTrap INSTANCE = new SelfTrap();

    private final ModeSetting mode = new ModeSetting("Mode", "Silent", "Legit", "Blatant");
    private final NumberSetting blocksPerTick = new NumberSetting("Blocks/Tick", 8, 1, 15, 1);
    private final NumberSetting layers = new NumberSetting("Layers", 2, 1, 4, 1);
    private final MultiBooleanSetting blocks = new MultiBooleanSetting("Blocks",
            MultiBooleanSetting.Value.of("Obsidian", true),
            MultiBooleanSetting.Value.of("Cobweb", true),
            MultiBooleanSetting.Value.of("Planks", false),
            MultiBooleanSetting.Value.of("Wool", false));

    private final BlockPos[] sideOffsets = {
            new BlockPos(1, 0, 0), new BlockPos(-1, 0, 0),
            new BlockPos(0, 0, 1), new BlockPos(0, 0, -1)
    };

    private SelfTrap() {}

    @EventTarget
    public void onUpdate(EventUpdate event) {
        if (mc.player == null || mc.world == null) return;

        BlockPos targetPos = mc.player.getBlockPos();
        int cap = mode.is("Blatant") ? Math.max(20, (int) blocksPerTick.getCurrent() * 3) : (int) blocksPerTick.getCurrent();
        int totalLayers = mode.is("Blatant") ? Math.max((int) layers.getCurrent(), 3) : (int) layers.getCurrent();

        int placed = 0;
        for (int l = 0; l < totalLayers; l++) {
            for (BlockPos offset : sideOffsets) {
                if (placed >= cap) break;
                BlockPos pos = targetPos.add(offset.getX(), l, offset.getZ());
                if (mc.world.getBlockState(pos).isReplaceable()) {
                    if (placeBlock(pos)) placed++;
                }
            }
        }

        if (placed < cap) {
            BlockPos roofPos = targetPos.add(0, totalLayers, 0);
            if (mc.world.getBlockState(roofPos).isReplaceable()) {
                placeBlock(roofPos);
            }
        }
    }

    private boolean placeBlock(BlockPos pos) {
        int slot = findBlockSlot();
        if (slot == -1) return false;

        int prevSlot = mc.player.getInventory().selectedSlot;

        for (Direction side : Direction.values()) {
            BlockPos neighbor = pos.offset(side);
            Direction opposite = side.getOpposite();

            if (!mc.world.getBlockState(neighbor).isAir()) {
                Vec3d hitVec = new Vec3d(neighbor.getX() + 0.5 + opposite.getOffsetX() * 0.5,
                        neighbor.getY() + 0.5 + opposite.getOffsetY() * 0.5,
                        neighbor.getZ() + 0.5 + opposite.getOffsetZ() * 0.5);

                if (mode.is("Legit")) {
                    Rotation rot = RotationUtil.calculateAngle(hitVec);
                    RotationTarget rt = new RotationTarget(rot,
                            () -> aimManager.rotate(aimManager.getAiSetup(), rot),
                            aimManager.getAiSetup());
                    rotationManager.setRotation(rt, 1, this);
                }

                switchTo(slot);
                BlockHitResult hit = new BlockHitResult(hitVec, opposite, neighbor, false);
                mc.getNetworkHandler().sendPacket(new PlayerInteractBlockC2SPacket(Hand.MAIN_HAND, hit, 0));
                mc.player.swingHand(Hand.MAIN_HAND);
                switchTo(prevSlot);
                PlaceHighlight.mark(pos);
                return true;
            }
        }
        return false;
    }

    private void switchTo(int slot) {
        mc.getNetworkHandler().sendPacket(new UpdateSelectedSlotC2SPacket(slot));
        mc.player.getInventory().selectedSlot = slot;
    }

    private int findBlockSlot() {
        for (int i = 0; i < 9; i++) {
            ItemStack stack = mc.player.getInventory().getStack(i);
            if (!stack.isEmpty() && stack.getItem() instanceof BlockItem blockItem) {
                String name = blockItem.getBlock().getName().getString();
                if (blocks.getSelectedNames().stream().anyMatch(n -> name.toLowerCase().contains(n.toLowerCase()))) {
                    return i;
                }
            }
        }
        return -1;
    }
}
