package okyware.wtf.client.modules.impl.combat;

import com.darkmagician6.eventapi.EventTarget;
import okyware.wtf.base.events.impl.player.EventRotate;
import okyware.wtf.base.rotation.RotationTarget;
import okyware.wtf.client.modules.api.Category;
import okyware.wtf.client.modules.api.Module;
import okyware.wtf.client.modules.api.ModuleAnnotation;
import okyware.wtf.client.modules.api.setting.impl.NumberSetting;
import okyware.wtf.utility.game.player.rotation.Rotation;
import okyware.wtf.utility.game.player.rotation.RotationUtil;
import net.minecraft.entity.LivingEntity;

@ModuleAnnotation(name = "SilentAim", category = Category.COMBAT, description = "Corrects aim on the server side without moving your crosshair visually")
public final class SilentAim extends Module {
    public static final SilentAim INSTANCE = new SilentAim();

    private final NumberSetting range = new NumberSetting("Range", 4, 1, 6, 0.1f);

    private SilentAim() {}

    @EventTarget
    public void onRotate(EventRotate event) {
        LivingEntity target = getTarget();
        if (target != null) {
            Rotation rotations = RotationUtil.fromVec3d(target.getBoundingBox().getCenter().subtract(mc.player.getEyePos()));
            rotationManager.setRotation(new RotationTarget(rotations, () -> rotations, aimManager.getInstantSetup()), 1, this);
        }
    }

    private LivingEntity getTarget() {
        return mc.world.getEntitiesByClass(LivingEntity.class, mc.player.getBoundingBox().expand(range.getCurrent()), 
                entity -> entity != mc.player && entity.isAlive())
                .stream().min((e1, e2) -> Float.compare(mc.player.distanceTo(e1), mc.player.distanceTo(e2)))
                .orElse(null);
    }
}
