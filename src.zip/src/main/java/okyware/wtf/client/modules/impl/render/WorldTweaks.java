package okyware.wtf.client.modules.impl.render;

import com.darkmagician6.eventapi.EventTarget;
import okyware.wtf.Okyware;
import okyware.wtf.base.events.impl.render.EventFog;
import okyware.wtf.client.modules.api.Category;
import okyware.wtf.client.modules.api.Module;
import okyware.wtf.client.modules.api.ModuleAnnotation;
import okyware.wtf.client.modules.api.setting.impl.ColorSetting;
import okyware.wtf.client.modules.api.setting.impl.MultiBooleanSetting;
import okyware.wtf.client.modules.api.setting.impl.NumberSetting;
import okyware.wtf.utility.render.display.base.color.ColorRGBA;

import java.util.List;

@ModuleAnnotation(name = "WorldTweaks",description = "Modifies world rendering including ambient lighting, sky color, and weather effects", category =Category.RENDER)
public  final  class WorldTweaks extends Module {

    public final MultiBooleanSetting modeSetting =  MultiBooleanSetting.create("Settings", List.of("Brightness", "Fog","Time"));


    public final NumberSetting brightSetting = new NumberSetting("Brightness",1.0F,0.0F, 1.0F,0.1f,() -> modeSetting.isEnable(0));

    private final ColorSetting colorFog = new ColorSetting("Fog color", Okyware.getInstance().getThemeManager().getCurrentTheme().getColor());
    public final NumberSetting distanceSetting = new NumberSetting("Fog distance",80,10,255,5,() -> modeSetting.isEnable(1) );

    public final NumberSetting timeSetting = new NumberSetting("Time of day",12,0,24,1,() -> modeSetting.isEnable(2) );
    public static final WorldTweaks INSTANCE = new WorldTweaks();
    private WorldTweaks() {}
    @EventTarget
    public void onFog(EventFog e) {
        if (modeSetting.isEnable(1)) {
            e.setDistance(distanceSetting.getCurrent());
            e.setColor(colorFog.getIntColor());
            e.setCancelled(true);
        }
    }
}
