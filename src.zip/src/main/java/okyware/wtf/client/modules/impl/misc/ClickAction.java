package okyware.wtf.client.modules.impl.misc;

import com.darkmagician6.eventapi.EventTarget;
import net.minecraft.block.Blocks;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.Items;
import net.minecraft.network.packet.c2s.play.PlayerInteractBlockC2SPacket;
import net.minecraft.network.packet.c2s.play.UpdateSelectedSlotC2SPacket;
import net.minecraft.screen.slot.Slot;
import net.minecraft.text.Style;
import net.minecraft.text.Text;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.MathHelper;
import net.minecraft.world.RaycastContext;
import okyware.wtf.Okyware;
import okyware.wtf.base.events.impl.input.EventKey;
import okyware.wtf.base.events.impl.player.EventRotate;
import okyware.wtf.base.events.impl.render.EventRender3D;
import okyware.wtf.base.rotation.RotationTarget;
import okyware.wtf.client.modules.api.Category;
import okyware.wtf.client.modules.api.Module;
import okyware.wtf.client.modules.api.ModuleAnnotation;
import okyware.wtf.client.modules.api.setting.Setting;
import okyware.wtf.client.modules.api.setting.impl.BooleanSetting;
import okyware.wtf.client.modules.api.setting.impl.KeySetting;
import okyware.wtf.client.modules.api.setting.impl.NumberSetting;
import okyware.wtf.client.modules.impl.render.Predictions;
import okyware.wtf.utility.game.player.PlayerIntersectionUtil;
import okyware.wtf.utility.game.player.PlayerInventoryComponent;
import okyware.wtf.utility.game.player.PlayerInventoryUtil;
import okyware.wtf.utility.game.player.SimulatedPlayer;
import okyware.wtf.utility.game.player.rotation.Rotation;
import okyware.wtf.utility.game.player.rotation.RotationUtil;
import okyware.wtf.utility.math.Timer;
import okyware.wtf.utility.other.BooleanSettable;

import java.util.ArrayList;
import java.util.List;

@ModuleAnnotation(name = "ClickAction", description = "Binds custom actions to hotkeys for quick item usage and ability activation", category = Category.MISC)
public final class ClickAction extends Module {

    private final KeySetting friendBind = new KeySetting("Add friend");
    private final KeySetting expBind = new KeySetting("Пузырек опыта");

    
    private final KeySetting cobwebKey = new KeySetting("Паутина", 0);
    private final BooleanSetting cobwebSwitchBack = new BooleanSetting("Web - Recover", true);
    private final NumberSetting cobwebDelay = new NumberSetting("Web - Delay", 50, 0, 500, 1);

    

    private final BooleanSetting debug = new BooleanSetting("Debug", false);
    private final BooleanSetting autoRotate = new BooleanSetting("Auto-rotation", true);

    
    private boolean readyToUseCobweb = false;
    
    private int previousSlot = -1;

    private final List<KeyBind> keyBindings = new ArrayList<>();
    private final Timer timer = new Timer();
    public static final ClickAction INSTANCE = new ClickAction();

    private ClickAction() {
        keyBindings.add(new KeyBind(Items.ENDER_PEARL, new KeySetting("Эндер перл"), new BooleanSettable()));
        keyBindings.add(new KeyBind(Items.WIND_CHARGE, new KeySetting("Заряд ветра"), new BooleanSettable()));
    }

    @Override
    public List<Setting> getSettings() {
        ArrayList<Setting> settings = new ArrayList<>();
        settings.add(expBind);
        settings.add(friendBind);
        settings.addAll(keyBindings.stream().map(KeyBind::setting).toList());
        
        
        settings.add(cobwebKey);
        settings.add(cobwebSwitchBack);
        settings.add(cobwebDelay);
        
        settings.add(autoRotate);
        settings.add(debug);
        
        return settings;
    }

    @EventTarget
    public void onKey(EventKey e) {
        if (!this.isEnabled()) return;

        
        if (e.isKeyDown(friendBind.getKeyCode()) && mc.crosshairTarget instanceof EntityHitResult result && result.getEntity() instanceof PlayerEntity player) {
            if (Okyware.getInstance().getFriendManager().isFriend(player.getGameProfile().getName())) {
                Okyware.getInstance().getFriendManager().removeFriend(player.getGameProfile().getName());
            } else {
                Okyware.getInstance().getFriendManager().add(player.getGameProfile().getName());
            }
        }

        
        if (e.isKeyDown(cobwebKey.getKeyCode())) {
            handleKeyDown(Items.COBWEB, () -> readyToUseCobweb = true);
        } else if (e.isKeyReleased(cobwebKey.getKeyCode()) && readyToUseCobweb) {
            handleKeyUp(Items.COBWEB, () -> {
                performCobwebAction();
                readyToUseCobweb = false;
            });
        }

        

        

        
        keyBindings.stream().filter(bind -> bind.setting.getKeyCode() != 0 && e.isKeyDown(bind.setting.getKeyCode())).forEach(bind -> {
            Slot slot = PlayerInventoryUtil.getSlot(bind.item);
            if (slot != null) {
                bind.draw.setValue(true);
                if (debug.isEnabled()) {
                    System.out.println("ClickAction: Found " + bind.item.getName().getString() + " in slot " + slot.getIndex());
                }
            } else {
                if (debug.isEnabled()) {
                    System.out.println("ClickAction: " + bind.item.getName().getString() + " not found in inventory");
                }
                Okyware.getInstance().getNotifyManager().addNotification("M", Text.of(bind.item.getName().copy().setStyle(Style.EMPTY.withColor(Okyware.getInstance().getThemeManager().getCurrentTheme().getColor().getRGB())).append(Text.of(" not found").copy().setStyle(Style.EMPTY.withColor(Okyware.getInstance().getThemeManager().getCurrentTheme().getWhite().getRGB())))));
            }
        });

        keyBindings.stream().filter(bind -> bind.setting.getKeyCode() != 0 && e.isKeyReleased(bind.setting.getKeyCode())).forEach(bind -> {
            Slot slot = PlayerInventoryUtil.getSlot(bind.item);
            if (slot != null) {
                if (debug.isEnabled()) {
                    System.out.println("ClickAction: Using " + bind.item.getName().getString() + " from slot " + slot.getIndex());
                }
                PlayerInventoryUtil.swapAndUse(bind.item);
            } else {
                if (debug.isEnabled()) {
                    System.out.println("ClickAction: Cannot use " + bind.item.getName().getString() + " - not found");
                }
            }
            bind.draw.setValue(false);
        });

        
        if (e.isKeyDown(expBind.getKeyCode())) {
            Slot slot = PlayerInventoryUtil.getSlot(Items.EXPERIENCE_BOTTLE);
            if (slot == null) {
                Okyware.getInstance().getNotifyManager().addNotification("M", Text.of(Items.EXPERIENCE_BOTTLE.getName().copy().setStyle(Style.EMPTY.withColor(Okyware.getInstance().getThemeManager().getCurrentTheme().getColor().getRGB())).append(Text.of("not found").copy().setStyle(Style.EMPTY.withColor(Okyware.getInstance().getThemeManager().getCurrentTheme().getWhite().getRGB())))));
                return;
            }
        }
    }

    
    private void handleKeyDown(Item item, Runnable onReady) {
        if (mc.player == null) return;

        int slot = findItemInHotbar(item);
        if (slot == -1) {
            Okyware.getInstance().getNotifyManager().addNotification("exclamation", Text.literal("No " + item.getName().getString() + " in hotbar!"));
            if (debug.isEnabled()) {
                System.out.println("[ClickAction Debug] No " + item.getName().getString() + " found in hotbar");
            }
            return; 
        }

        previousSlot = mc.player.getInventory().selectedSlot;
        mc.getNetworkHandler().sendPacket(new UpdateSelectedSlotC2SPacket(slot));
        mc.player.getInventory().selectedSlot = slot;

        if (debug.isEnabled()) {
            System.out.println("[ClickAction Debug] Switched to slot " + slot + " for " + item.getName().getString());
        }

        
        if (mc.player.getItemCooldownManager().isCoolingDown(item.getDefaultStack())) {
            Okyware.getInstance().getNotifyManager().addNotification("exclamation", Text.literal(item.getName().getString() + " on cooldown!"));
            
            return;
        }

        onReady.run();
    }

    
    private void handleKeyUp(Item item, Runnable action) {
        if (mc.player == null || mc.player.getMainHandStack().getItem() != item) {
            if (debug.isEnabled()) {
                System.out.println("[ClickAction Debug] Item not in main hand for " + item.getName().getString());
            }
            return;
        }

        PlayerInventoryComponent.addTask(() -> {
            mc.execute(() -> {
                if (debug.isEnabled()) {
                    System.out.println("[ClickAction Debug] Executing action for " + item.getName().getString());
                }
                action.run();
                if (switchBackEnabledForItem(item)) {
                    switchBackToPreviousSlot();
                }
            });
        });
    }

    
    private int findItemInHotbar(Item item) {
        for (int i = 0; i < 9; i++) {
            if (mc.player.getInventory().getStack(i).getItem().equals(item)) {
                return i;
            }
        }
        return -1;
    }

    
    private boolean switchBackEnabledForItem(Item item) {
        if (item == Items.COBWEB) return cobwebSwitchBack.isEnabled();
        return true; 
    }


    private void switchBackToPreviousSlot() {
        if (mc.player == null || previousSlot == -1) return;

        mc.getNetworkHandler().sendPacket(new UpdateSelectedSlotC2SPacket(previousSlot));
        mc.player.getInventory().selectedSlot = previousSlot;

        if (debug.isEnabled()) {
            System.out.println("[ClickAction Debug] Switched back to previous slot " + previousSlot);
        }
    }

    
    private void performCobwebAction() {
        if (mc.player == null || mc.crosshairTarget == null) return;

        HitResult hit = mc.crosshairTarget;
        if (hit.getType() == HitResult.Type.BLOCK) {
            BlockHitResult blockHit = (BlockHitResult) hit;
            
            mc.getNetworkHandler().sendPacket(new PlayerInteractBlockC2SPacket(
                Hand.MAIN_HAND, blockHit, 0 
            ));
            mc.player.swingHand(Hand.MAIN_HAND);
            if (debug.isEnabled()) {
                System.out.println("[ClickAction Debug] Placed cobweb on block at " + blockHit.getBlockPos());
            }
        } else {
            
            PlayerIntersectionUtil.useItem(Hand.MAIN_HAND, new Rotation(mc.player.getYaw(), mc.player.getPitch()));
            if (debug.isEnabled()) {
                System.out.println("[ClickAction Debug] Used cobweb in air");
            }
        }
    }

    

    
    

    private Rotation getRotationToVec(Vec3d target) {
        Vec3d eyes = mc.player.getEyePos();
        Vec3d delta = target.subtract(eyes);
        double horizontal = Math.sqrt(delta.x * delta.x + delta.z * delta.z);
        float yaw = (float) (Math.toDegrees(Math.atan2(delta.z, delta.x)) - 90.0);
        float pitch = (float) (-Math.toDegrees(Math.atan2(delta.y, horizontal)));
        return new Rotation(MathHelper.wrapDegrees(yaw), MathHelper.wrapDegrees(pitch));
    }

    

    
    private void legacyCrystal() {
        Slot slot = PlayerInventoryUtil.getSlot(Items.END_CRYSTAL);
        if (slot == null) return;
        PlayerInventoryUtil.swapAndUse(slot, rotationManager.getCurrentRotation());
    }

    private void legacyAnchor() {
        Slot slot = PlayerInventoryUtil.getSlot(Items.RESPAWN_ANCHOR);
        if (slot == null) return;
        PlayerInventoryUtil.swapAndUse(slot, rotationManager.getCurrentRotation());
    }

    @EventTarget
    public void onWorldRender(EventRender3D e) {
        Predictions.INSTANCE.drawPredictionInHand(e.getMatrix(), keyBindings.stream().filter(keyBind -> keyBind.draw.isValue()).map(keyBind -> keyBind.item.getDefaultStack()).toList());
    }

    private Slot saveSlot = null;

    @EventTarget
    public void onTick(EventRotate e) {
        boolean isMainHandItem = mc.player.getMainHandStack().getItem().equals(Items.EXPERIENCE_BOTTLE);
        if (PlayerIntersectionUtil.isKey(expBind)) {
            Slot slot = PlayerInventoryUtil.getSlot(Items.EXPERIENCE_BOTTLE);

            SimulatedPlayer simulatedPlayer = SimulatedPlayer.simulateLocalPlayer(3);
            Rotation angle = new Rotation(mc.player.getYaw(), RotationUtil.calculateAngle(simulatedPlayer.boundingBox.getCenter()).getPitch());

            rotationManager.setRotation(new RotationTarget(angle, () -> {
                return aimManager.rotate(aimManager.getInstantSetup(), angle);
            }, aimManager.getInstantSetup()), 1, this);

            if (!isMainHandItem) {
                PlayerInventoryComponent.addTask(() -> {
                    if (saveSlot == null) {
                        saveSlot = slot;
                    }
                    PlayerInventoryUtil.swapHand(slot, Hand.MAIN_HAND, false);
                    PlayerInventoryUtil.closeScreen(true);
                });
            } else if (timer.finished(70) && rotationManager.getCurrentRotation().rotationDeltaTo(angle).isInRange(180, 10)) {
                PlayerIntersectionUtil.useItem(Hand.MAIN_HAND, angle);
                timer.reset();
            }
        } else {
            if (saveSlot != null) {
                PlayerInventoryComponent.addTask(() -> {
                    if (!PlayerIntersectionUtil.isKey(expBind)) {
                        PlayerInventoryUtil.swapHand(saveSlot, Hand.MAIN_HAND, false);
                        PlayerInventoryUtil.closeScreen(true);
                        saveSlot = null;
                    }
                });
            }
        }
    }

    public record KeyBind(Item item, KeySetting setting, BooleanSettable draw) {
    }
}