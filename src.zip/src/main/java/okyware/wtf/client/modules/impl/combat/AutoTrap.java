package okyware.wtf.client.modules.impl.combat;

import com.darkmagician6.eventapi.EventTarget;
import net.minecraft.entity.LivingEntity;
import net.minecraft.item.BlockItem;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.network.packet.c2s.play.PlayerInteractBlockC2SPacket;
import net.minecraft.network.packet.c2s.play.UpdateSelectedSlotC2SPacket;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;
import okyware.wtf.base.events.impl.player.EventUpdate;
import okyware.wtf.base.rotation.RotationTarget;
import okyware.wtf.client.modules.api.Category;
import okyware.wtf.client.modules.api.Module;
import okyware.wtf.client.modules.api.ModuleAnnotation;
import okyware.wtf.client.modules.api.setting.impl.BooleanSetting;
import okyware.wtf.client.modules.api.setting.impl.ModeSetting;
import okyware.wtf.client.modules.api.setting.impl.MultiBooleanSetting;
import okyware.wtf.client.modules.api.setting.impl.NumberSetting;
import okyware.wtf.client.modules.impl.render.PlaceHighlight;
import okyware.wtf.utility.game.player.rotation.Rotation;
import okyware.wtf.utility.game.player.rotation.RotationUtil;
import okyware.wtf.utility.game.player.PlayerInventoryUtil;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

@ModuleAnnotation(name = "AutoTrap", category = Category.COMBAT, description = "Encases nearby enemies in obsidian or other blocks to restrict their movement")
public final class AutoTrap extends Module {
    public static final AutoTrap INSTANCE = new AutoTrap();

    private final ModeSetting mode = new ModeSetting("Mode", "Legit", "Blatant", "Grim");
    private final NumberSetting range = new NumberSetting("Range", 4.5f, 1.0f, 6.0f, 0.1f);
    private final NumberSetting blocksPerTick = new NumberSetting("Blocks/Tick", 1, 1, 8, 1);
    private final NumberSetting placeDelay = new NumberSetting("Place Delay", 1, 0, 10, 1, () -> mode.is("Grim"));
    private final MultiBooleanSetting blocks = MultiBooleanSetting.create("Blocks", Arrays.asList("Obsidian", "Crying Obs", "Cobblestone", "Planks", "Wool", "Any"));
    private final BooleanSetting top = new BooleanSetting("Top", true);
    private final BooleanSetting rotate = new BooleanSetting("Rotate", true);

    private int grimDelay = 0;
    private BlockPos pendingPlace = null;

    private AutoTrap() {}

    @EventTarget
    public void onUpdate(EventUpdate event) {
        if (mc.player == null || mc.world == null) return;

        LivingEntity target = getTarget();
        if (target == null) return;

        int slot = findBlockSlot();
        if (slot == -1) return;

        BlockPos targetPos = target.getBlockPos();
        List<BlockPos> trapPositions = getTrapPositions(targetPos);

        if (mode.is("Grim")) {
            handleGrimPlace(trapPositions, slot);
            return;
        }

        int placed = 0;
        int cap = mode.is("Blatant") ? (int) blocksPerTick.getCurrent() : 1;

        for (BlockPos pos : trapPositions) {
            if (placed >= cap) break;
            if (!mc.world.getBlockState(pos).isReplaceable()) continue;

            if (getNeighbor(pos) == null) continue;

            if (placeBlock(pos, slot)) {
                placed++;
            }
        }
    }

    private void handleGrimPlace(List<BlockPos> trapPositions, int slot) {
        
        if (grimDelay > 0) {
            grimDelay--;
            
            if (pendingPlace != null) {
                placeBlockPacket(pendingPlace, slot);
                pendingPlace = null;
            }
            return;
        }

        for (BlockPos pos : trapPositions) {
            if (!mc.world.getBlockState(pos).isReplaceable()) continue;
            if (getNeighbor(pos) == null) continue;

            
            Direction side = getNeighbor(pos);
            BlockPos neighbor = pos.offset(side);
            Direction opposite = side.getOpposite();
            Vec3d hitVec = new Vec3d(
                    neighbor.getX() + 0.5 + opposite.getOffsetX() * 0.5,
                    neighbor.getY() + 0.5 + opposite.getOffsetY() * 0.5,
                    neighbor.getZ() + 0.5 + opposite.getOffsetZ() * 0.5
            );

            Rotation rot = RotationUtil.calculateAngle(hitVec);
            RotationTarget rt = new RotationTarget(rot,
                    () -> aimManager.rotate(aimManager.getInstantSetup(), rot),
                    aimManager.getInstantSetup());
            rotationManager.setRotation(rt, 1, this);

            pendingPlace = pos;
            grimDelay = (int) placeDelay.getCurrent();
            break;
        }
    }

    private void placeBlockPacket(BlockPos pos, int slot) {
        Direction side = getNeighbor(pos);
        if (side == null) return;

        BlockPos neighbor = pos.offset(side);
        Direction opposite = side.getOpposite();
        Vec3d hitVec = new Vec3d(
                neighbor.getX() + 0.5 + opposite.getOffsetX() * 0.5,
                neighbor.getY() + 0.5 + opposite.getOffsetY() * 0.5,
                neighbor.getZ() + 0.5 + opposite.getOffsetZ() * 0.5
        );

        int prevSlot = mc.player.getInventory().selectedSlot;
        switchTo(slot);
        BlockHitResult hit = new BlockHitResult(hitVec, opposite, neighbor, false);
        mc.getNetworkHandler().sendPacket(new PlayerInteractBlockC2SPacket(Hand.MAIN_HAND, hit, 0));
        mc.player.swingHand(Hand.MAIN_HAND);
        switchTo(prevSlot);
        PlaceHighlight.mark(pos);
    }

    private LivingEntity getTarget() {
        LivingEntity auraTarget = Aura.INSTANCE.getTarget();
        if (auraTarget != null && mc.player.distanceTo(auraTarget) <= range.getCurrent()) return auraTarget;

        return mc.world.getEntitiesByClass(LivingEntity.class, mc.player.getBoundingBox().expand(range.getCurrent()),
                entity -> entity != mc.player && entity.isAlive() && !entity.isSpectator())
                .stream().min((e1, e2) -> Float.compare(mc.player.distanceTo(e1), mc.player.distanceTo(e2)))
                .orElse(null);
    }

    private boolean placeBlock(BlockPos pos, int slot) {
        Direction side = getNeighbor(pos);
        if (side == null) return false;

        BlockPos neighbor = pos.offset(side);
        Direction opposite = side.getOpposite();

        Vec3d hitVec = new Vec3d(
                neighbor.getX() + 0.5 + opposite.getOffsetX() * 0.5,
                neighbor.getY() + 0.5 + opposite.getOffsetY() * 0.5,
                neighbor.getZ() + 0.5 + opposite.getOffsetZ() * 0.5
        );

        if (rotate.isEnabled()) {
            Rotation rot = RotationUtil.calculateAngle(hitVec);
            RotationTarget rt = new RotationTarget(rot,
                    () -> aimManager.rotate(mode.is("Blatant") ? aimManager.getInstantSetup() : aimManager.getAiSetup(), rot),
                    mode.is("Blatant") ? aimManager.getInstantSetup() : aimManager.getAiSetup());
            rotationManager.setRotation(rt, 1, this);
        }

        int prevSlot = mc.player.getInventory().selectedSlot;
        
        if (mode.is("Blatant")) {
            switchTo(slot);
            BlockHitResult hit = new BlockHitResult(hitVec, opposite, neighbor, false);
            mc.getNetworkHandler().sendPacket(new PlayerInteractBlockC2SPacket(Hand.MAIN_HAND, hit, 0));
            mc.player.swingHand(Hand.MAIN_HAND);
            switchTo(prevSlot);
        } else {
            mc.player.getInventory().selectedSlot = slot;
            BlockHitResult hit = new BlockHitResult(hitVec, opposite, neighbor, false);
            mc.interactionManager.interactBlock(mc.player, Hand.MAIN_HAND, hit);
            mc.player.swingHand(Hand.MAIN_HAND);
            mc.player.getInventory().selectedSlot = prevSlot;
        }

        PlaceHighlight.mark(pos);
        return true;
    }

    private Direction getNeighbor(BlockPos pos) {
        for (Direction d : Direction.values()) {
            BlockPos neighbor = pos.offset(d);
            if (!mc.world.getBlockState(neighbor).isAir() && !mc.world.getBlockState(neighbor).isReplaceable()) {
                return d;
            }
        }
        return null;
    }

    private List<BlockPos> getTrapPositions(BlockPos base) {
        List<BlockPos> positions = new ArrayList<>();
        positions.add(base.north());
        positions.add(base.south());
        positions.add(base.east());
        positions.add(base.west());
        positions.add(base.up().north());
        positions.add(base.up().south());
        positions.add(base.up().east());
        positions.add(base.up().west());
        if (top.isEnabled()) {
            positions.add(base.up(2));
        }
        return positions;
    }

    private void switchTo(int slot) {
        if (mc.player.getInventory().selectedSlot == slot) return;
        mc.getNetworkHandler().sendPacket(new UpdateSelectedSlotC2SPacket(slot));
        mc.player.getInventory().selectedSlot = slot;
    }

    private int findBlockSlot() {
        boolean useObsidian = blocks.isEnable("Obsidian");
        boolean useCrying = blocks.isEnable("Crying Obs");
        boolean useCobble = blocks.isEnable("Cobblestone");
        boolean usePlanks = blocks.isEnable("Planks");
        boolean useWool = blocks.isEnable("Wool");
        boolean useAny = blocks.isEnable("Any");

        for (int i = 0; i < 9; i++) {
            ItemStack stack = mc.player.getInventory().getStack(i);
            if (isValidBlock(stack, useObsidian, useCrying, useCobble, usePlanks, useWool, useAny)) {
                return i;
            }
        }
        
        for (net.minecraft.screen.slot.Slot slot : mc.player.currentScreenHandler.slots) {
            if (slot.inventory != mc.player.getInventory()) continue; 
            int invSlot = slot.getIndex(); 
            if (invSlot >= 9 && invSlot < 36) { 
                ItemStack stack = slot.getStack();
                if (isValidBlock(stack, useObsidian, useCrying, useCobble, usePlanks, useWool, useAny)) {
                    PlayerInventoryUtil.swapHand(slot, 8);
                    return 8;
                }
            }
        }
        
        return -1;
    }

    private boolean isValidBlock(ItemStack stack, boolean useObsidian, boolean useCrying, boolean useCobble, boolean usePlanks, boolean useWool, boolean useAny) {
        if (stack.isEmpty() || !(stack.getItem() instanceof BlockItem)) return false;
        if (useObsidian && stack.getItem() == Items.OBSIDIAN) return true;
        if (useCrying && stack.getItem() == Items.CRYING_OBSIDIAN) return true;
        if (useCobble && stack.getItem() == Items.COBBLESTONE) return true;
        if (usePlanks && isPlanks(stack)) return true;
        if (useWool && isWool(stack)) return true;
        if (useAny) return true;
        return false;
    }

    private boolean isPlanks(ItemStack stack) {
        return stack.isIn(net.minecraft.registry.tag.ItemTags.PLANKS);
    }

    private boolean isWool(ItemStack stack) {
        return stack.isIn(net.minecraft.registry.tag.ItemTags.WOOL);
    }
}
