package okyware.wtf.client.modules.impl.player;

import com.darkmagician6.eventapi.EventTarget;
import lombok.Getter;
import net.minecraft.network.packet.Packet;
import net.minecraft.network.packet.c2s.common.KeepAliveC2SPacket;
import net.minecraft.network.packet.c2s.play.*;
import net.minecraft.network.packet.s2c.play.EntityVelocityUpdateS2CPacket;
import net.minecraft.util.math.Vec3d;
import okyware.wtf.base.events.impl.player.EventUpdate;
import okyware.wtf.base.events.impl.server.EventPacket;
import okyware.wtf.client.modules.api.Category;
import okyware.wtf.client.modules.api.Module;
import okyware.wtf.client.modules.api.ModuleAnnotation;
import okyware.wtf.client.modules.api.setting.impl.BooleanSetting;
import okyware.wtf.client.modules.api.setting.impl.NumberSetting;

import java.util.LinkedList;
import java.util.Queue;

@ModuleAnnotation(name = "Blink", category = Category.PLAYER, description = "Queues all outgoing packets and teleports you forward when toggled off")
public final class Blink extends Module {
    public static final Blink INSTANCE = new Blink();

    private final BooleanSetting pulse = new BooleanSetting("Pulse", false);
    private final NumberSetting pulsePackets = new NumberSetting("Pulse Packets", 20, 1, 200, 1, () -> pulse.isEnabled());
    private final BooleanSetting autoDisable = new BooleanSetting("Auto Disable", false);
    private final NumberSetting maxPackets = new NumberSetting("Max Packets", 100, 10, 500, 5, () -> autoDisable.isEnabled());
    private final BooleanSetting disableOnVelocity = new BooleanSetting("Disable on Velocity", false);

    private final Queue<Packet<?>> storedPackets = new LinkedList<>();
    @Getter
    private Vec3d lastPos = null;
    private boolean sending = false;

    private Blink() {}

    @Override
    public void onEnable() {
        super.onEnable();
        if (mc.player == null) { toggle(); return; }
        storedPackets.clear();
        lastPos = mc.player.getPos();
        sending = false;
    }

    @Override
    public void onDisable() {
        if (mc.player != null && mc.player.networkHandler != null) {
            sending = true;
            while (!storedPackets.isEmpty()) {
                mc.player.networkHandler.sendPacket(storedPackets.poll());
            }
            sending = false;
        }
        storedPackets.clear();
        lastPos = null;
        super.onDisable();
    }

    @EventTarget
    public void onUpdate(EventUpdate event) {
        if (mc.player == null) return;

        if (pulse.isEnabled() && storedPackets.size() >= pulsePackets.getCurrent()) {
            sending = true;
            while (!storedPackets.isEmpty()) {
                mc.player.networkHandler.sendPacket(storedPackets.poll());
            }
            sending = false;
            lastPos = mc.player.getPos();
        }

        if (autoDisable.isEnabled() && storedPackets.size() >= maxPackets.getCurrent()) {
            toggle();
        }
    }

    @EventTarget
    public void onPacket(EventPacket event) {
        if (mc.player == null || sending) return;

        if (event.isSent()) {
            Packet<?> pkt = event.getPacket();
            
            if (pkt instanceof KeepAliveC2SPacket || pkt instanceof ChatMessageC2SPacket) return;

            event.setCancelled(true);
            storedPackets.add(pkt);
        }

        if (event.isReceive() && disableOnVelocity.isEnabled()) {
            if (event.getPacket() instanceof EntityVelocityUpdateS2CPacket vel) {
                if (mc.player != null && vel.getEntityId() == mc.player.getId()) {
                    toggle();
                }
            }
        }
    }
}
