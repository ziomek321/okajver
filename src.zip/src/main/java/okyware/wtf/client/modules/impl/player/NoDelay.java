package okyware.wtf.client.modules.impl.player;

import net.minecraft.item.ItemStack;
import net.minecraft.util.Hand;
import com.darkmagician6.eventapi.EventTarget;
import okyware.wtf.base.events.impl.player.EventUpdate;
import okyware.wtf.client.modules.api.Category;
import okyware.wtf.client.modules.api.Module;
import okyware.wtf.client.modules.api.ModuleAnnotation;

@ModuleAnnotation(name = "NoDelay", category = Category.PLAYER, description = "Eliminates the cooldown between consecutive item uses and block placements")
public final class NoDelay extends Module {
    public static final NoDelay INSTANCE = new NoDelay();
    
    private NoDelay() {

    }

    @EventTarget
    public void onUpdate(EventUpdate event) {
        if (mc.player == null || mc.world == null) return;
        if (!mc.options.useKey.isPressed()) return;

        Hand activeHand = mc.player.getActiveHand();
        if (activeHand != null) {
            mc.interactionManager.interactItem(mc.player, activeHand);
        }
    }
}
