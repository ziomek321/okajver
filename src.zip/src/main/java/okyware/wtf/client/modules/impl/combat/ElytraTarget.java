package okyware.wtf.client.modules.impl.combat;

import com.darkmagician6.eventapi.EventTarget;
import okyware.wtf.base.events.impl.player.EventUpdate;
import okyware.wtf.base.rotation.RotationTarget;
import okyware.wtf.client.modules.api.Category;
import okyware.wtf.client.modules.api.Module;
import okyware.wtf.client.modules.api.ModuleAnnotation;
import okyware.wtf.client.modules.api.setting.impl.BooleanSetting;
import okyware.wtf.client.modules.api.setting.impl.NumberSetting;
import okyware.wtf.utility.game.player.PlayerInventoryUtil;
import okyware.wtf.utility.game.player.rotation.Rotation;
import okyware.wtf.utility.game.player.rotation.RotationUtil;
import okyware.wtf.utility.math.Timer;
import net.minecraft.entity.LivingEntity;
import net.minecraft.item.Items;
import net.minecraft.util.Hand;
import net.minecraft.util.math.Vec3d;

import java.util.List;

@ModuleAnnotation(name = "ElytraTarget", category = Category.COMBAT, description = "Automatically follows and pursues targets during elytra flight")
public final class ElytraTarget extends Module {
    public static final ElytraTarget INSTANCE = new ElytraTarget();

    private final NumberSetting distance = new NumberSetting("Follow distance", 5.0f, 1.0f, 15.0f, 0.5f);
    private final BooleanSetting autoFirework = new BooleanSetting("Auto firework", true);
    private final NumberSetting fireworkDelay = new NumberSetting("Firework delay", 1500, 500, 5000, 100);

    private final Timer fireworkTimer = new Timer();

    private ElytraTarget() {}

    @Override
    public void onEnable() {
        fireworkTimer.reset();
        super.onEnable();
    }

    @EventTarget
    public void onUpdate(EventUpdate event) {
        if (mc.player == null || mc.world == null) return;
        if (!mc.player.isGliding()) return;

        LivingEntity target = Aura.INSTANCE.getTarget();
        if (target == null) return;

        double dist = mc.player.distanceTo(target);
        Vec3d targetPos = target.getPos().add(0, target.getEyeHeight(target.getPose()) / 2.0, 0);
        Vec3d playerPos = mc.player.getPos().add(0, mc.player.getEyeHeight(mc.player.getPose()), 0);

        
        Rotation angle = RotationUtil.fromVec3d(targetPos.subtract(playerPos));
        rotationManager.setRotation(new RotationTarget(angle, () -> aimManager.rotate(aimManager.getInstantSetup(), angle), aimManager.getInstantSetup()), 2, this);

        
        Vec3d dir = targetPos.subtract(playerPos).normalize();

        
        if (dist > distance.getCurrent()) {
            Vec3d currentVel = mc.player.getVelocity();
            double speed = currentVel.length();
            
            
            Vec3d newVel = currentVel.add(dir.multiply(0.05)).normalize().multiply(Math.max(speed, 0.1));
            mc.player.setVelocity(newVel);
        }

        
        if (autoFirework.isEnabled() && (dist > distance.getCurrent() + 8 || mc.player.getVelocity().length() < 0.2) && fireworkTimer.finished((long) fireworkDelay.getCurrent())) {
            int fireworkSlot = PlayerInventoryUtil.getHotbarItems(List.of(Items.FIREWORK_ROCKET));
            if (fireworkSlot != -1) {
                int oldSlot = mc.player.getInventory().selectedSlot;
                mc.player.getInventory().selectedSlot = fireworkSlot;
                mc.interactionManager.interactItem(mc.player, Hand.MAIN_HAND);
                mc.player.getInventory().selectedSlot = oldSlot;
                fireworkTimer.reset();
            }
        }
    }
}
