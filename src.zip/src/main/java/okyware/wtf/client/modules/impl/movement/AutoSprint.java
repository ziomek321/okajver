package okyware.wtf.client.modules.impl.movement;

import com.darkmagician6.eventapi.EventTarget;


import net.minecraft.block.Blocks;
import net.minecraft.util.math.BlockPos;
import okyware.wtf.base.events.impl.player.EventUpdate;
import okyware.wtf.client.modules.api.Category;
import okyware.wtf.client.modules.api.Module;
import okyware.wtf.client.modules.api.ModuleAnnotation;
import okyware.wtf.utility.game.player.PlayerIntersectionUtil;

import java.util.List;

@ModuleAnnotation(name = "AutoSprint", category = Category.MOVEMENT, description = "Automatically toggles sprint")
public final class AutoSprint extends Module {
    public static final AutoSprint INSTANCE = new AutoSprint();
    private AutoSprint() {
    }
    @EventTarget
    public void onUpdate(EventUpdate event) {
        mc.options.sprintKey.setPressed(true);
    }
}
