package okyware.wtf.client.modules.impl.render;

import com.darkmagician6.eventapi.EventTarget;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.Vec3d;
import okyware.wtf.Okyware;
import okyware.wtf.base.events.impl.player.EventUpdate;
import okyware.wtf.base.events.impl.render.EventRender3D;
import okyware.wtf.client.modules.api.Category;
import okyware.wtf.client.modules.api.Module;
import okyware.wtf.client.modules.api.ModuleAnnotation;
import okyware.wtf.client.modules.api.setting.impl.BooleanSetting;
import okyware.wtf.client.modules.api.setting.impl.ModeSetting;
import okyware.wtf.client.modules.api.setting.impl.NumberSetting;
import okyware.wtf.utility.math.MathUtil;
import okyware.wtf.utility.render.display.base.color.ColorRGBA;
import okyware.wtf.utility.render.level.Render3DUtil;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

@ModuleAnnotation(name = "JumpCircles", category = Category.RENDER, description = "Spawns an animated ring at jump origin.")
public final class JumpCircles extends Module {
    public static final JumpCircles INSTANCE = new JumpCircles();

    private final ModeSetting style = new ModeSetting("Style", "Default", "Bold", "Portal", "Soup", "Circle", "Texture", "Ghosts");
    private final ModeSetting texture = new ModeSetting("Texture", () -> style.is("Texture"), "Circle", "KonchalEbal", "Glow");

    private final NumberSetting radius = new NumberSetting("Radius", 0.6f, 0.1f, 4.0f, 0.05f);
    private final NumberSetting appearMs = new NumberSetting("Appear (ms)", 250, 50, 1500, 10);
    private final NumberSetting existMs = new NumberSetting("Hold (ms)", 350, 50, 2000, 10);
    private final NumberSetting disappearMs = new NumberSetting("Disappear (ms)", 500, 50, 2000, 10);
    private final NumberSetting rotateSpeed = new NumberSetting("Rotate speed", 2.0f, 0.0f, 6.0f, 0.1f);
    private final NumberSetting thickness = new NumberSetting("Thickness", 2.0f, 0.5f, 8.0f, 0.5f);
    private final BooleanSetting onlySelf = new BooleanSetting("Only self", true);
    private final okyware.wtf.client.modules.api.setting.impl.ColorSetting customColorSetting = new okyware.wtf.client.modules.api.setting.impl.ColorSetting("Color", new ColorRGBA(255, 255, 255));
    private final BooleanSetting useCustomColor = new BooleanSetting("Custom Color", false);

    private final List<Circle> circles = new ArrayList<>();
    private boolean wasOnGround = true;

    private JumpCircles() {
    }

    @Override
    public void onDisable() {
        circles.clear();
        super.onDisable();
    }

    @EventTarget
    public void onUpdate(EventUpdate e) {
        if (mc.player == null || mc.world == null) return;

        boolean onGround = mc.player.isOnGround();
        if (wasOnGround && !onGround && mc.player.getVelocity().y > 0) {
            circles.add(new Circle(mc.player.getPos(), System.currentTimeMillis(), mc.player));
        }
        wasOnGround = onGround;

        if (!onlySelf.isEnabled()) {
            for (PlayerEntity p : mc.world.getPlayers()) {
                if (p == mc.player) continue;
                JumpState state = JumpState.get(p);
                boolean wg = state.wasOnGround;
                boolean og = p.isOnGround();
                if (wg && !og && p.getVelocity().y > 0) {
                    circles.add(new Circle(p.getPos(), System.currentTimeMillis(), p));
                }
                state.wasOnGround = og;
            }
        }
    }

    @EventTarget
    public void onRender3D(EventRender3D event) {
        if (circles.isEmpty()) return;

        long total = (long) (appearMs.getCurrent() + existMs.getCurrent() + disappearMs.getCurrent());
        long now = System.currentTimeMillis();

        Iterator<Circle> it = circles.iterator();
        while (it.hasNext()) {
            Circle c = it.next();
            long elapsed = now - c.start;
            if (elapsed > total) {
                it.remove();
                continue;
            }
            renderCircle(c, elapsed, total);
        }
    }

    private void renderCircle(Circle c, long elapsed, long total) {
        long appear = (long) appearMs.getCurrent();
        long exist = (long) existMs.getCurrent();
        long disappear = (long) disappearMs.getCurrent();

        float alpha;
        float scale;
        if (elapsed < appear) {
            float t = elapsed / (float) appear;
            t = easeOutCubic(t);
            alpha = t;
            scale = t;
        } else if (elapsed < appear + exist) {
            alpha = 1.0f;
            scale = 1.0f;
        } else {
            float t = (elapsed - appear - exist) / (float) disappear;
            t = Math.min(1f, t);
            alpha = 1.0f - easeInCubic(t);
            scale = 1.0f - 0.2f * t;
        }

        float rad = radius.getCurrent() * scale;
        if (rad <= 0.001f) return;

        ColorRGBA base = useCustomColor.isEnabled() ? customColorSetting.getColor() : Okyware.getInstance().getThemeManager().getClientColor(0);
        float a = Math.max(0f, Math.min(1f, alpha));
        float rot = (float) Math.toRadians((System.currentTimeMillis() / 8.0) * rotateSpeed.getCurrent() % 360.0);
        float lw = thickness.getCurrent();

        if (style.is("Texture")) {
            Identifier id = Identifier.of("okyware", "textures/eva/jumpcircles/" + texture.get().toLowerCase() + ".png");
            float s = rad;
            Vec3d p1 = c.pos.add(-s, 0.01, -s);
            Vec3d p2 = c.pos.add(s, 0.01, -s);
            Vec3d p3 = c.pos.add(s, 0.01, s);
            Vec3d p4 = c.pos.add(-s, 0.01, s);
            Render3DUtil.drawTexturedQuad(id, p1, p2, p3, p4, base.mulAlpha(a).getRGB());
        } else if (style.is("Circle")) {
            
            drawRing(c.pos, rad, base.mulAlpha(a).getRGB(), lw, rot, 64);
        } else if (style.is("Bold")) {
            drawGlowRing(c.pos, rad, base, a, lw + 1f, rot, 64);
            drawRing(c.pos, rad * 0.78f, base.mulAlpha(a * 0.7f).getRGB(), lw, -rot, 64);
        } else if (style.is("Portal")) {
            drawDashedRing(c.pos, rad, base.mulAlpha(a).getRGB(), lw, rot, 32, 0.55f);
            drawDashedRing(c.pos, rad * 0.65f, base.mulAlpha(a * 0.7f).getRGB(), Math.max(1f, lw - 0.5f), -rot * 1.5f, 24, 0.45f);
            drawDashedRing(c.pos, rad * 0.32f, base.mulAlpha(a * 0.5f).getRGB(), Math.max(1f, lw - 1f), rot * 2.5f, 16, 0.4f);
        } else if (style.is("Soup")) {
            drawFilledDisc(c.pos, rad, base.mulAlpha(a * 0.25f).getRGB(), 32);
            drawGlowRing(c.pos, rad, base, a, lw, rot, 64);
            drawRing(c.pos, rad * 0.55f, base.mulAlpha(a * 0.6f).getRGB(), Math.max(1f, lw - 0.5f), -rot, 48);
        } else if (style.is("Ghosts")) {
            int ghostCount = 8;
            for (int i = 0; i < ghostCount; i++) {
                double ghostAngle = rot + (i / (double) ghostCount) * MathUtil.PI2;
                double gx = c.pos.x + Math.cos(ghostAngle) * rad;
                double gz = c.pos.z + Math.sin(ghostAngle) * rad;
                float size = 0.15f * (1f + 0.3f * (float) Math.sin(rot * 3 + i));
                Render3DUtil.drawTexture(Identifier.of("okyware", "textures/target/glow.png"),
                        new Vec3d(gx, c.pos.y + 0.05, gz), size, base.mulAlpha(a).getRGB());
            }
            drawRing(c.pos, rad, base.mulAlpha(a * 0.3f).getRGB(), 1f, rot, 48);
        } else {
            drawGlowRing(c.pos, rad, base, a, lw, rot, 64);
        }
    }

    private void drawGlowRing(Vec3d center, float radius, ColorRGBA color, float alpha, float coreLw, float rot, int segments) {
        float[] widths = { coreLw * 4f, coreLw * 2.5f, coreLw };
        float[] alphas = { 0.18f, 0.42f, 1.0f };
        for (int i = 0; i < widths.length; i++) {
            drawRing(center, radius, color.mulAlpha(alpha * alphas[i]).getRGB(), widths[i], rot, segments);
        }
    }

    private void drawRing(Vec3d center, float radius, int color, float width, float rot, int segments) {
        for (int i = 0; i < segments; i++) {
            double a1 = rot + (i / (double) segments) * MathUtil.PI2;
            double a2 = rot + ((i + 1) / (double) segments) * MathUtil.PI2;
            Vec3d p1 = new Vec3d(Math.cos(a1) * radius, 0, Math.sin(a1) * radius);
            Vec3d p2 = new Vec3d(Math.cos(a2) * radius, 0, Math.sin(a2) * radius);
            Render3DUtil.drawLine(center.add(p1), center.add(p2), color, width, true);
        }
    }

    private void drawDashedRing(Vec3d center, float radius, int color, float width, float rot, int segments, float fillFraction) {
        for (int i = 0; i < segments; i++) {
            if ((i & 1) == 1) continue;
            double a1 = rot + (i / (double) segments) * MathUtil.PI2;
            double a2 = a1 + (MathUtil.PI2 / segments) * fillFraction;
            Vec3d p1 = new Vec3d(Math.cos(a1) * radius, 0, Math.sin(a1) * radius);
            Vec3d p2 = new Vec3d(Math.cos(a2) * radius, 0, Math.sin(a2) * radius);
            Render3DUtil.drawLine(center.add(p1), center.add(p2), color, width, true);
        }
    }

    private void drawFilledDisc(Vec3d center, float radius, int color, int segments) {
        for (int i = 0; i < segments; i++) {
            double a1 = (i / (double) segments) * MathUtil.PI2;
            double a2 = ((i + 1) / (double) segments) * MathUtil.PI2;
            Vec3d p1 = new Vec3d(Math.cos(a1) * radius, 0, Math.sin(a1) * radius);
            Vec3d p2 = new Vec3d(Math.cos(a2) * radius, 0, Math.sin(a2) * radius);
            Render3DUtil.drawQuad(center, center.add(p1), center.add(p2), center, color, true);
        }
    }

    private static float easeOutCubic(float t) {
        float p = 1f - t;
        return 1f - p * p * p;
    }

    private static float easeInCubic(float t) {
        return t * t * t;
    }

    private static final class Circle {
        final Vec3d pos;
        final long start;
        final PlayerEntity player;

        Circle(Vec3d pos, long start, PlayerEntity player) {
            this.pos = pos;
            this.start = start;
            this.player = player;
        }
    }

    private static final class JumpState {
        boolean wasOnGround = true;
        private static final java.util.WeakHashMap<PlayerEntity, JumpState> MAP = new java.util.WeakHashMap<>();

        static JumpState get(PlayerEntity p) {
            return MAP.computeIfAbsent(p, k -> new JumpState());
        }
    }
}
