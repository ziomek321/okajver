
package okyware.wtf.client.modules.impl.combat;


import net.minecraft.item.Item;
import net.minecraft.item.Items;
import com.darkmagician6.eventapi.EventTarget;
import net.minecraft.screen.slot.Slot;
import net.minecraft.util.Hand;

import okyware.wtf.base.events.impl.input.EventKey;
import okyware.wtf.client.modules.api.Category;
import okyware.wtf.client.modules.api.Module;
import okyware.wtf.client.modules.api.ModuleAnnotation;
import okyware.wtf.client.modules.api.setting.impl.ModeSetting;
import okyware.wtf.client.modules.api.setting.impl.KeySetting;
import okyware.wtf.utility.game.player.PlayerInventoryComponent;
import okyware.wtf.utility.game.player.PlayerInventoryUtil;

import java.util.Comparator;

@ModuleAnnotation(name = "AutoSwap", category = Category.COMBAT, description = "Swaps to the optimal weapon or tool before attacking a target")
public final class AutoSwap extends Module {
    public static final AutoSwap INSTANCE = new AutoSwap();

    private final ModeSetting itemType = new ModeSetting("Item", "Shield", "Gapples", "Totem", "Sphere");
    private final ModeSetting swapType = new ModeSetting("Swap to", "Shield", "Gapples", "Totem", "Sphere");

    private final KeySetting keyToSwap = new KeySetting("Button", -1);

    private AutoSwap() {
    }

    @EventTarget
    public void onKey(EventKey event) {
        if (mc.currentScreen != null) return;
        if (event.getAction() != 1) return;

        if (event.is(keyToSwap.getKeyCode())) {
            Slot first = PlayerInventoryUtil.getSlot(getItemByType(itemType.get()), Comparator.comparing(s -> s.getStack().hasEnchantments()), s -> s.id != 46 && s.id != 45);
            Slot second = PlayerInventoryUtil.getSlot(getItemByType(swapType.get()), Comparator.comparing(s -> s.getStack().hasEnchantments()), s -> s.id != 46 && s.id != 45);
            Slot validSlot = first != null && mc.player.getOffHandStack().getItem() != first.getStack().getItem() ? first : second;
            PlayerInventoryComponent.addTask(() -> {
                PlayerInventoryUtil.swapHand(validSlot, Hand.OFF_HAND, false);
                PlayerInventoryUtil.closeScreen(true);
            });
        }
    }


    private Item getItemByType(String itemType) {
        return switch (itemType) {
            case "Shield" -> Items.SHIELD;
            case "Totem" -> Items.TOTEM_OF_UNDYING;
            case "Gapples" -> Items.GOLDEN_APPLE;
            case "Sphere" -> Items.PLAYER_HEAD;
            default -> Items.AIR;
        };
    }


}

