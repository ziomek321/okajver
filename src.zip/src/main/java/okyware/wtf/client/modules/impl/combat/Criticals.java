package okyware.wtf.client.modules.impl.combat;

import okyware.wtf.client.modules.api.Category;
import okyware.wtf.client.modules.api.Module;
import okyware.wtf.client.modules.api.ModuleAnnotation;
import net.minecraft.network.packet.c2s.play.PlayerMoveC2SPacket;

import java.util.concurrent.ThreadLocalRandom;

import okyware.wtf.client.modules.api.setting.impl.ModeSetting;

@ModuleAnnotation(name = "Criticals", category = Category.COMBAT, description = "Forces critical hits on every attack by spoofing fall distance")
public class Criticals extends Module {
    public static final Criticals INSTANCE = new Criticals();

    private final ModeSetting mode = new ModeSetting("Mode", "Packet", "Grim");

    private Criticals() {
    }

    public void onAttack() {
        if (!isEnabled()) return;
        if (mc.player == null || mc.player.isTouchingWater() || mc.player.isInLava()) return;

        if (mode.is("Grim")) {
            if (mc.player.isOnGround()) {
                mc.player.jump();
                ((okyware.wtf.utility.interfaces.LivingEntityAccessor) mc.player).setJumpingCooldown(0);
            }
            return;
        }

        if (mc.player.isOnGround()) {
            double[] offsets = {0.0625, 0.0};
            for (double offset : offsets) {
                mc.player.networkHandler.sendPacket(new PlayerMoveC2SPacket.PositionAndOnGround(
                        mc.player.getX(), mc.player.getY() + offset + (ThreadLocalRandom.current().nextDouble() * 1.0E-4), mc.player.getZ(), false, true
                ));
            }
        } else if (mc.player.fallDistance == 0.0F) {
            
             mc.player.networkHandler.sendPacket(new PlayerMoveC2SPacket.Full(
                    mc.player.getX(), mc.player.getY() - (ThreadLocalRandom.current().nextDouble() * 1.0E-4), mc.player.getZ(),
                    mc.player.getYaw(), mc.player.getPitch(), mc.player.isOnGround(), mc.player.horizontalCollision
            ));
        }
    }
    @com.darkmagician6.eventapi.EventTarget
    public void onUpdate(okyware.wtf.base.events.impl.player.EventUpdate event) {
        if (mode.is("Grim") && mc.player != null) {
            if (mc.player.fallDistance > 0 && mc.player.fallDistance < 1.2) {
                ((okyware.wtf.utility.interfaces.LivingEntityAccessor) mc.player).setJumpingCooldown(0);
            }
        }
    }
}
