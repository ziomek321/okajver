package okyware.wtf;

import okyware.wtf.base.license.LicenseManager;
import lombok.Getter;
import net.fabricmc.fabric.api.resource.ResourceManagerHelper;
import net.fabricmc.fabric.api.resource.SimpleSynchronousResourceReloadListener;
import net.minecraft.client.MinecraftClient;
import net.minecraft.resource.ResourceManager;
import net.minecraft.resource.ResourceType;
import net.minecraft.util.Identifier;



import okyware.wtf.base.comand.CommandManager;
import okyware.wtf.base.config.ConfigManager;
import okyware.wtf.base.filemanager.impl.FriendManager;
import okyware.wtf.base.filemanager.impl.StaffManager;
import okyware.wtf.base.modules.ModuleManager;
import okyware.wtf.base.request.ScriptManager;
import okyware.wtf.base.rotation.RotationManager;
import okyware.wtf.base.rotation.deeplearnig.DeepLearningManager;
import okyware.wtf.base.theme.ThemeManager;
import okyware.wtf.client.screens.menu.MenuScreen;
import okyware.wtf.utility.game.server.ServerHandler;
import okyware.wtf.base.notify.NotifyManager;
import okyware.wtf.base.repository.RCTRepository;
import okyware.wtf.utility.render.display.shader.DrawUtil;
import okyware.wtf.utility.render.display.shader.GlProgram;

import java.io.File;


@Getter
public enum Okyware {
    INSTANCE;

    public static final String NAME = "Okyware", VER = "2.0", TYPE = "DEV";
    private static final String MOD_ID = "okyware";
    public static final File DIRECTORY = new File(MinecraftClient.getInstance().runDirectory, Okyware.NAME);

    private ModuleManager moduleManager;

    private ThemeManager themeManager;
    private MenuScreen menuScreen;
    private ScriptManager scriptManager;

    private ServerHandler serverHandler;
    private FriendManager friendManager;
    private StaffManager staffManager;
    private DeepLearningManager deepLearningManager;
    private RotationManager rotationManager;

    private NotifyManager notifyManager;
    private CommandManager commandManager;
    private ConfigManager configManager;
    private RCTRepository rctRepository;

    public void init() {
        if (okyware.wtf.base.license.BuildFlavor.HWID_ENABLED) {
            LicenseManager.INSTANCE.verify();
        }
        Runtime.getRuntime().addShutdownHook(new Thread(() -> Okyware.getInstance().shutdown()));


        friendManager = new FriendManager();
        staffManager = new StaffManager();
        notifyManager = new NotifyManager();
        serverHandler = new ServerHandler();
        rctRepository = new RCTRepository();
        themeManager = new ThemeManager();
        moduleManager = new ModuleManager();




        deepLearningManager = new DeepLearningManager();
        rotationManager = new RotationManager();

        commandManager = new CommandManager();
        scriptManager = new ScriptManager();
        menuScreen = new MenuScreen();


        configManager = new ConfigManager();
        menuScreen.initialize();

        ResourceManagerHelper.get(ResourceType.CLIENT_RESOURCES).registerReloadListener(new SimpleSynchronousResourceReloadListener() {
            @Override
            public Identifier getFabricId() {
                return Okyware.id("after_shader_load");
            }

            @Override
            public void reload(ResourceManager manager) {
                GlProgram.loadAndSetupPrograms();
            }
        });
        DrawUtil.initializeShaders();

    }

    public void shutdown() {
        if (friendManager != null) friendManager.save();
        if (staffManager != null) staffManager.save();
        if (configManager != null) configManager.save();
    }

    public static Identifier id(String path) {
        return Identifier.of(MOD_ID, path);
    }

    public static Okyware getInstance() {
        return INSTANCE;
    }

    public RCTRepository getRCTRepository() {
        return rctRepository;
    }

}
