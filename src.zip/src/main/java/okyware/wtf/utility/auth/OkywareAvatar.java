package okyware.wtf.utility.auth;

import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URI;
import java.net.URL;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;


public final class OkywareAvatar {

    private OkywareAvatar() {}

    private static final String DEFAULT_BASE = "https://stardlc.wtf/api";
    private static final long REFRESH_MS = 5 * 60 * 1000L; 
    private static final ScheduledExecutorService POOL =
            Executors.newSingleThreadScheduledExecutor(r -> {
                Thread t = new Thread(r, "stardlc-avatar");
                t.setDaemon(true);
                return t;
            });

    private static volatile String baseUrl =
            System.getProperty("stardlc.api", DEFAULT_BASE);
    private static volatile int uid = -1;
    private static volatile BufferedImage cached;
    private static volatile long lastFetched;
    private static final ConcurrentHashMap<Integer, BufferedImage> mem = new ConcurrentHashMap<>();

    public static void setBaseUrl(String url) {
        if (url != null && !url.isEmpty()) baseUrl = url;
    }

    public static void setUid(int newUid) {
        if (newUid == uid) return;
        uid = newUid;
        cached = null;
        lastFetched = 0L;
        if (uid > 0) refreshAsync();
    }

    public static int getUid() {
        return uid;
    }

    
    public static BufferedImage getOrFetch() {
        if (uid <= 0) return null;
        BufferedImage img = cached;
        if (img == null) {
            
            BufferedImage onDisk = loadDisk(uid);
            if (onDisk != null) {
                cached = onDisk;
                mem.put(uid, onDisk);
                img = onDisk;
            }
            refreshAsync();
        } else if (System.currentTimeMillis() - lastFetched > REFRESH_MS) {
            refreshAsync();
        }
        return img;
    }

    public static BufferedImage forUid(int otherUid) {
        if (otherUid <= 0) return null;
        BufferedImage img = mem.get(otherUid);
        if (img != null) return img;
        BufferedImage disk = loadDisk(otherUid);
        if (disk != null) {
            mem.put(otherUid, disk);
            return disk;
        }
        POOL.submit(() -> fetch(otherUid));
        return null;
    }

    public static CompletableFuture<BufferedImage> refreshAsync() {
        final int snapshotUid = uid;
        if (snapshotUid <= 0) return CompletableFuture.completedFuture(null);
        return CompletableFuture.supplyAsync(() -> fetch(snapshotUid), POOL)
                .thenApply(img -> {
                    if (img != null && snapshotUid == uid) {
                        cached = img;
                        lastFetched = System.currentTimeMillis();
                    }
                    return img;
                });
    }

    

    private static BufferedImage fetch(int targetUid) {
        try {
            URL url = new URI(baseUrl + "/avatar/" + targetUid).toURL();
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setConnectTimeout(4000);
            conn.setReadTimeout(6000);
            conn.setRequestProperty("User-Agent", "Okyware-Client");
            int code = conn.getResponseCode();
            if (code != 200) {
                conn.disconnect();
                return null;
            }
            ByteArrayOutputStream buf = new ByteArrayOutputStream();
            try (InputStream in = conn.getInputStream()) {
                byte[] tmp = new byte[8192];
                int n;
                while ((n = in.read(tmp)) > 0) buf.write(tmp, 0, n);
            }
            conn.disconnect();
            byte[] bytes = buf.toByteArray();
            BufferedImage img = ImageIO.read(new java.io.ByteArrayInputStream(bytes));
            if (img == null) return null;
            saveDisk(targetUid, bytes);
            mem.put(targetUid, img);
            return img;
        } catch (Throwable t) {
            return null;
        }
    }

    private static Path cacheFile(int targetUid) {
        String home = System.getProperty("user.home", ".");
        Path dir = Paths.get(home, ".stardlc", "avatars");
        try {
            Files.createDirectories(dir);
        } catch (Throwable ignored) {}
        return dir.resolve("avatar_" + targetUid + ".img");
    }

    private static BufferedImage loadDisk(int targetUid) {
        try {
            Path p = cacheFile(targetUid);
            if (!Files.exists(p)) return null;
            
            if (System.currentTimeMillis() - Files.getLastModifiedTime(p).toMillis() >
                    TimeUnit.HOURS.toMillis(24)) {
                return null;
            }
            return ImageIO.read(p.toFile());
        } catch (Throwable t) {
            return null;
        }
    }

    private static void saveDisk(int targetUid, byte[] bytes) {
        try {
            Files.write(cacheFile(targetUid), bytes);
        } catch (Throwable ignored) {}
    }
}
