package okyware.wtf.utility.auth;

import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URI;
import java.nio.charset.StandardCharsets;


public final class OkywareSession {

    private OkywareSession() {}

    private static volatile String baseUrl =
            System.getProperty("stardlc.api", "https://stardlc.wtf/api");
    private static volatile int uid = -1;
    private static volatile String username = "";
    private static volatile String displayName = "";
    private static volatile String plan = "";
    private static volatile boolean authenticated = false;

    public static void setBaseUrl(String url) {
        if (url != null && !url.isEmpty()) baseUrl = url;
        OkywareAvatar.setBaseUrl(url);
    }

    public static int uid() { return uid; }
    public static String username() { return username; }
    public static String displayName() { return displayName; }
    public static String plan() { return plan; }
    public static boolean isAuthenticated() { return authenticated; }

    
    public static boolean authenticate(String hwid) {
        try {
            HttpURLConnection conn = (HttpURLConnection)
                    new URI(baseUrl + "/auth").toURL().openConnection();
            conn.setRequestMethod("POST");
            conn.setDoOutput(true);
            conn.setConnectTimeout(4000);
            conn.setReadTimeout(6000);
            conn.setRequestProperty("Content-Type", "application/json");
            conn.setRequestProperty("User-Agent", "Okyware-Client");
            String body = "{\"hwid\":\"" + escape(hwid) + "\"}";
            try (OutputStream out = conn.getOutputStream()) {
                out.write(body.getBytes(StandardCharsets.UTF_8));
            }
            int code = conn.getResponseCode();
            InputStream stream = code >= 200 && code < 300 ? conn.getInputStream() : conn.getErrorStream();
            ByteArrayOutputStream buf = new ByteArrayOutputStream();
            byte[] tmp = new byte[4096];
            int n;
            while (stream != null && (n = stream.read(tmp)) > 0) buf.write(tmp, 0, n);
            String resp = buf.toString(StandardCharsets.UTF_8);
            conn.disconnect();

            if (code != 200) {
                authenticated = false;
                return false;
            }
            JsonObject json = JsonParser.parseString(resp).getAsJsonObject();
            uid = json.get("uid").getAsInt();
            username = optString(json, "username");
            displayName = optString(json, "display_name");
            plan = optString(json, "plan");
            authenticated = true;
            OkywareAvatar.setUid(uid);
            return true;
        } catch (Throwable t) {
            authenticated = false;
            return false;
        }
    }

    private static String optString(JsonObject o, String k) {
        return o.has(k) && !o.get(k).isJsonNull() ? o.get(k).getAsString() : "";
    }

    private static String escape(String s) {
        if (s == null) return "";
        return s.replace("\\", "\\\\").replace("\"", "\\\"");
    }
}
