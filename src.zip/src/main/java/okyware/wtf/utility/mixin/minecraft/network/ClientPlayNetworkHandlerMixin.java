package okyware.wtf.utility.mixin.minecraft.network;

import com.mojang.brigadier.exceptions.CommandSyntaxException;
import okyware.wtf.client.modules.impl.combat.Backtrack;
import okyware.wtf.utility.interfaces.BacktrackableEntity;
import net.minecraft.client.network.ClientPlayNetworkHandler;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.entity.Entity;
import net.minecraft.network.packet.s2c.play.EntityS2CPacket;
import net.minecraft.util.math.Vec3d;
import org.jetbrains.annotations.NotNull;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import okyware.wtf.Okyware;


@Mixin(ClientPlayNetworkHandler.class)
public class ClientPlayNetworkHandlerMixin {

    @Inject(method = "onEntity", at = @At("TAIL"))
    private void stardlc$captureBacktrack(EntityS2CPacket packet, CallbackInfo ci) {
        if (!Backtrack.INSTANCE.isEnabled()) return;
        ClientPlayNetworkHandler self = (ClientPlayNetworkHandler) (Object) this;
        ClientWorld world = self.getWorld();
        if (world == null) return;
        Entity entity = packet.getEntity(world);
        if (!(entity instanceof BacktrackableEntity bt)) return;
        Vec3d newPos = entity.getPos();
        bt.getBackTracks().add(new BacktrackableEntity.Position(newPos, System.currentTimeMillis()));
    }

    @Inject(method = "sendChatMessage", at = @At("HEAD"), cancellable = true)
    private void sendChatMessageHook(@NotNull String message, CallbackInfo ci) {



        if (message.startsWith(Okyware.getInstance().getCommandManager().getPrefix())) {
            try {
                Okyware.getInstance().getCommandManager().getDispatcher().execute(
                        message.substring(Okyware.getInstance().getCommandManager().getPrefix().length()),
                        Okyware.getInstance().getCommandManager().getSource()
                );
            } catch (CommandSyntaxException ignored) {}

            ci.cancel();
        }
    }
}