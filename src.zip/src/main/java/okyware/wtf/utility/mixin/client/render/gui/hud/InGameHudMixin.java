package okyware.wtf.utility.mixin.client.render.gui.hud;

import com.darkmagician6.eventapi.EventManager;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.hud.InGameHud;
import net.minecraft.client.render.RenderTickCounter;
import net.minecraft.world.GameMode;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.ModifyVariable;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import okyware.wtf.base.events.impl.render.EventRender2D;
import okyware.wtf.client.modules.impl.render.Crosshair;
import okyware.wtf.client.modules.impl.render.Interface;
import okyware.wtf.utility.render.display.base.CustomDrawContext;
import okyware.wtf.utility.render.display.shader.DrawUtil;
import okyware.wtf.client.modules.api.Module;

import static okyware.wtf.utility.interfaces.IMinecraft.mc;

@Mixin(InGameHud.class)
public abstract class InGameHudMixin {

    @Inject(method = "render", at = @At("HEAD"))
    public void onRender(DrawContext context, RenderTickCounter tickCounter, CallbackInfo ci) {
        DrawUtil.blurProgram.draw();
        CustomDrawContext customDrawContext = new CustomDrawContext(mc.getBufferBuilders().getEntityVertexConsumers());
        EventManager.call(new EventRender2D(customDrawContext, tickCounter.getTickDelta(false)));

    }

    @Inject(method = "renderCrosshair", at = @At("HEAD"), cancellable = true)
    private void removeVanillaCrosshair(DrawContext context, RenderTickCounter tickCounter, CallbackInfo ci) {
        try {
            Module crosshairModule = Crosshair.INSTANCE;
            if (crosshairModule != null && crosshairModule.isEnabled()) {
                ci.cancel();
            }
        } catch (Exception e) {
            
            e.printStackTrace();
        }
    }





}
