package okyware.wtf.utility.mixin.minecraft.block;

import net.minecraft.block.AbstractBlock;
import net.minecraft.block.Block;
import net.minecraft.block.BlockRenderType;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.BlockView;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import okyware.wtf.client.modules.impl.render.XRay;

@Mixin(AbstractBlock.AbstractBlockState.class)
public abstract class AbstractBlockStateMixin {

    @Shadow public abstract Block getBlock();

    @Inject(method = "getRenderType", at = @At("HEAD"), cancellable = true)
    public void getRenderType(CallbackInfoReturnable<BlockRenderType> cir) {
        if (XRay.INSTANCE != null && XRay.INSTANCE.isEnabled()) {
            Block b = this.getBlock();
            String name = b.getTranslationKey().toLowerCase();
            // Show only valuable block entities like chests, shulkers, beds etc
            if (name.contains("chest") || name.contains("shulker") || name.contains("bed") || name.contains("barrel") || name.contains("spawner")) {
                return; // Let it render
            }
            // Hide everything else (including fake ores)
            cir.setReturnValue(BlockRenderType.INVISIBLE);
        }
    }

    @Inject(method = "isOpaqueFullCube", at = @At("HEAD"), cancellable = true)
    public void isOpaqueFullCube(CallbackInfoReturnable<Boolean> cir) {
        if (XRay.INSTANCE != null && XRay.INSTANCE.isEnabled()) {
            cir.setReturnValue(false);
        }
    }

    @Inject(method = "getLuminance", at = @At("HEAD"), cancellable = true)
    public void getLuminance(CallbackInfoReturnable<Integer> cir) {
        if (XRay.INSTANCE != null && XRay.INSTANCE.isEnabled()) {
            if (XRay.INSTANCE.isXRayBlock(this.getBlock())) {
                cir.setReturnValue(15);
            }
        }
    }
}
