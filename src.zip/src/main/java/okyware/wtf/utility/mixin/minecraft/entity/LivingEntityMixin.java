package okyware.wtf.utility.mixin.minecraft.entity;

import net.minecraft.entity.LivingEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;
import okyware.wtf.Okyware;
import okyware.wtf.utility.interfaces.IMinecraft;

import okyware.wtf.utility.interfaces.BacktrackableEntity;
import org.spongepowered.asm.mixin.Unique;
import java.util.ArrayList;
import java.util.List;

import org.spongepowered.asm.mixin.Shadow;

import okyware.wtf.utility.interfaces.LivingEntityAccessor;

@Mixin(LivingEntity.class)
public abstract class LivingEntityMixin implements IMinecraft, BacktrackableEntity, LivingEntityAccessor {

    @Shadow
    private int jumpingCooldown;

    public void setJumpingCooldown(int jumpingCooldown) {
        this.jumpingCooldown = jumpingCooldown;
    }

    @Unique
    private final List<Position> backTracks = new ArrayList<>();

    @Override
    public List<Position> getBackTracks() {
        return backTracks;
    }

    
    @Redirect(method = "jump", at = @At(value = "INVOKE", target = "Lnet/minecraft/entity/LivingEntity;getYaw()F"), require = 0)
    public float replaceMovePacketPitch(LivingEntity instance) {
        if ((Object) this != mc.player) {
            return instance.getYaw();
        }else{
            return Okyware.getInstance().getRotationManager().getCurrentRotation().getYaw();
        }




    }


}
