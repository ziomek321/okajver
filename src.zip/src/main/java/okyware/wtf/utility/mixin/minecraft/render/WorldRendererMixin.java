package okyware.wtf.utility.mixin.minecraft.render;

import net.minecraft.client.option.CloudRenderMode;
import net.minecraft.client.render.*;
import net.minecraft.util.math.Vec3d;
import org.joml.Matrix4f;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.Redirect;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import okyware.wtf.client.modules.impl.render.CustomSky;

@Mixin(WorldRenderer.class)
public class WorldRendererMixin {

    @Redirect(
        method = "renderSky",
        at = @At(value = "INVOKE", target = "Lnet/minecraft/client/render/RenderPass;setRenderer(Ljava/lang/Runnable;)V")
    )
    private void onSetRenderer(RenderPass renderPass, Runnable originalRenderer) {
        if (CustomSky.INSTANCE.isEnabled()) {
            renderPass.setRenderer(() -> CustomSky.INSTANCE.renderSkyShader());
        } else {
            renderPass.setRenderer(originalRenderer);
        }
    }

    @Inject(method = "renderClouds", at = @At("HEAD"), cancellable = true)
    private void onRenderClouds(FrameGraphBuilder frameGraphBuilder, Matrix4f matrix4f, Matrix4f matrix4f2, CloudRenderMode cloudRenderMode, Vec3d vec3d, float f, int i, float f2, CallbackInfo ci) {
        if (CustomSky.INSTANCE.isEnabled()) {
            ci.cancel();
        }
    }
}
