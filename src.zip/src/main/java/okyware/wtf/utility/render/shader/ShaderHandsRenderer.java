package okyware.wtf.utility.render.shader;

import com.mojang.blaze3d.systems.RenderSystem;
import lombok.Getter;
import net.minecraft.client.gl.GlUniform;
import net.minecraft.client.network.AbstractClientPlayerEntity;
import net.minecraft.client.render.*;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.item.ItemStack;
import net.minecraft.util.Hand;
import net.minecraft.util.math.MathHelper;
import okyware.wtf.Okyware;
import okyware.wtf.client.modules.impl.render.ShaderHands;
import okyware.wtf.utility.interfaces.IMinecraft;
import okyware.wtf.utility.render.display.base.color.ColorRGBA;
import okyware.wtf.utility.render.display.shader.CustomRenderTarget;
import okyware.wtf.utility.render.display.shader.GlProgram;

@Getter
public class ShaderHandsRenderer implements IMinecraft {
    private static final ShaderHandsRenderer INSTANCE = new ShaderHandsRenderer();
    public static volatile boolean renderingHands = false;

    private CustomRenderTarget handsTarget;
    private CustomRenderTarget blur1;
    private CustomRenderTarget blur2;

    private GlProgram kawaseDown;
    private GlProgram kawaseUp;
    private GlProgram glowProgram;
    private GlProgram waveProgram;

    private ShaderHandsRenderer() {}

    public static ShaderHandsRenderer getInstance() { return INSTANCE; }

    public static void initializeShaders() {
        INSTANCE.kawaseDown = new GlProgram(Okyware.id("hands/hands_kawase_down"), VertexFormats.POSITION_TEXTURE_COLOR);
        INSTANCE.kawaseUp = new GlProgram(Okyware.id("hands/hands_kawase_up"), VertexFormats.POSITION_TEXTURE_COLOR);
        INSTANCE.glowProgram = new GlProgram(Okyware.id("hands/hands_glow"), VertexFormats.POSITION_TEXTURE_COLOR);
        INSTANCE.waveProgram = new GlProgram(Okyware.id("hand_wave/hand_wave"), VertexFormats.POSITION_TEXTURE_COLOR);
    }

    @FunctionalInterface
    public interface HandRendererCallback {
        void render(AbstractClientPlayerEntity player, float tickDelta, float pitch, Hand hand, float swingProgress, ItemStack item, float equipProgress, MatrixStack matrices, VertexConsumerProvider vertexConsumers, int light);
    }

    public void captureHands(
            float tickDelta, MatrixStack matrices, AbstractClientPlayerEntity player, int light,
            boolean renderMainHand, boolean renderOffHand, float f, Hand hand, float g,
            HandRendererCallback callback,
            ItemStack mainHandItem, ItemStack offHandItem,
            float mainHandEquipProgress, float mainHandPrevEquipProgress,
            float offHandEquipProgress, float offHandPrevEquipProgress
    ) {
        int width = mc.getWindow().getFramebufferWidth();
        int height = mc.getWindow().getFramebufferHeight();

        ensureTargets(width, height);

        handsTarget.setClearColor(0, 0, 0, 0);
        handsTarget.setup();

        VertexConsumerProvider.Immediate consumers = mc.getBufferBuilders().getEntityVertexConsumers();

        if (renderMainHand) {
            float j = hand == Hand.MAIN_HAND ? f : 0;
            float k = 1f - MathHelper.lerp(tickDelta, mainHandPrevEquipProgress, mainHandEquipProgress);
            callback.render(player, tickDelta, g, Hand.MAIN_HAND, j, mainHandItem, k, matrices, consumers, light);
        }
        if (renderOffHand) {
            float j = hand == Hand.OFF_HAND ? f : 0;
            float k = 1f - MathHelper.lerp(tickDelta, offHandPrevEquipProgress, offHandEquipProgress);
            callback.render(player, tickDelta, g, Hand.OFF_HAND, j, offHandItem, k, matrices, consumers, light);
        }

        consumers.draw();
        handsTarget.stop();

        org.joml.Matrix4f origProj = RenderSystem.getProjectionMatrix();
        RenderSystem.getModelViewStack().pushMatrix();
        RenderSystem.getModelViewStack().identity();
        RenderSystem.setProjectionMatrix(new org.joml.Matrix4f(), com.mojang.blaze3d.systems.ProjectionType.ORTHOGRAPHIC);
        RenderSystem.enableBlend();
        RenderSystem.defaultBlendFunc();
        RenderSystem.disableDepthTest();
        RenderSystem.disableCull();

        // Kawase blur passes
        blur1.setup(true);
        RenderSystem.setShaderTexture(0, handsTarget.getColorAttachment());
        if (kawaseDown != null) {
            kawaseDown.use();
            setUniform(kawaseDown, "uOffset", 1f, 1f);
            setUniform(kawaseDown, "uHalfPixel", 0.5f / width, 0.5f / height);
            setUniform(kawaseDown, "uSize", (float) width, (float) height);
        }
        drawQuad();
        blur1.stop();

        blur2.setup(true);
        RenderSystem.setShaderTexture(0, blur1.getColorAttachment());
        if (kawaseDown != null) {
            kawaseDown.use();
            setUniform(kawaseDown, "uOffset", 2f, 2f);
            setUniform(kawaseDown, "uHalfPixel", 0.5f / width, 0.5f / height);
            setUniform(kawaseDown, "uSize", (float) width, (float) height);
        }
        drawQuad();
        blur2.stop();

        ColorRGBA c = Okyware.getInstance().getThemeManager().getCurrentTheme().getColor();
        float r = c.getRed() / 255f, gr = c.getGreen() / 255f, b = c.getBlue() / 255f;

        blur1.setup(true);
        RenderSystem.setShaderTexture(0, blur2.getColorAttachment());
        if (kawaseUp != null) {
            kawaseUp.use();
            setUniform(kawaseUp, "uOffset", 2f, 2f);
            setUniform(kawaseUp, "uHalfPixel", 0.5f / width, 0.5f / height);
            setUniform(kawaseUp, "uSize", (float) width, (float) height);
            setUniform(kawaseUp, "color", r, gr, b);
        }
        drawQuad();
        blur1.stop();

        blur2.setup(true);
        RenderSystem.setShaderTexture(0, blur1.getColorAttachment());
        if (kawaseUp != null) {
            kawaseUp.use();
            setUniform(kawaseUp, "uOffset", 1f, 1f);
            setUniform(kawaseUp, "uHalfPixel", 0.5f / width, 0.5f / height);
            setUniform(kawaseUp, "uSize", (float) width, (float) height);
            setUniform(kawaseUp, "color", r, gr, b);
        }
        drawQuad();
        blur2.stop();

        // Glow pass
        if (glowProgram != null) {
            glowProgram.use();
            RenderSystem.setShaderTexture(0, blur2.getColorAttachment());
            RenderSystem.setShaderTexture(1, handsTarget.getColorAttachment());
            setUniform(glowProgram, "color", r, gr, b);
            ColorRGBA c2 = Okyware.getInstance().getThemeManager().getCurrentTheme().getSecondColor();
            setUniform(glowProgram, "color2", c2.getRed() / 255f, c2.getGreen() / 255f, c2.getBlue() / 255f);
            setUniform(glowProgram, "exposure", ShaderHands.INSTANCE.getGlow().getCurrent() * 2f);
            drawQuad();
        }

        // Wave overlay
        ShaderHands mod = ShaderHands.INSTANCE;
        if (waveProgram != null) {
            waveProgram.use();
            RenderSystem.setShaderTexture(0, handsTarget.getColorAttachment());
            setUniform(waveProgram, "Time", (System.currentTimeMillis() % 1000000) / 1000f);
            setUniform(waveProgram, "Resolution", (float) width, (float) height);
            setUniform(waveProgram, "ThemeColor", r, gr, b, 1f);
            setUniform(waveProgram, "OutlineWidth", mod.getOutline().getCurrent());
            setUniform(waveProgram, "GlowStrength", mod.getGlow().getCurrent());
            setUniform(waveProgram, "FillAmount", mod.getFill().getCurrent());
            setUniform(waveProgram, "Alpha", mod.getAlpha().getCurrent());
            setUniform(waveProgram, "WaveSpeed", mod.getWaveSpeed().getCurrent());
            setUniform(waveProgram, "WaveScale", mod.getWaveScale().getCurrent());
            drawQuad();
        }

        RenderSystem.setProjectionMatrix(origProj, com.mojang.blaze3d.systems.ProjectionType.PERSPECTIVE);
        RenderSystem.getModelViewStack().popMatrix();
        RenderSystem.enableDepthTest();
        RenderSystem.enableCull();
        RenderSystem.disableBlend();
    }

    private void ensureTargets(int w, int h) {
        if (handsTarget == null) {
            handsTarget = new CustomRenderTarget(w, h, true);
            blur1 = new CustomRenderTarget(w, h, false);
            blur2 = new CustomRenderTarget(w, h, false);
        } else if (handsTarget.textureWidth != w || handsTarget.textureHeight != h) {
            handsTarget.resize(w, h);
            blur1.resize(w, h);
            blur2.resize(w, h);
        }
    }

    private void drawQuad() {
        BufferBuilder builder = Tessellator.getInstance().begin(VertexFormat.DrawMode.QUADS, VertexFormats.POSITION_TEXTURE_COLOR);
        org.joml.Matrix4f m = new org.joml.Matrix4f();
        builder.vertex(m, -1, -1, 0).texture(0, 0).color(-1);
        builder.vertex(m, -1, 1, 0).texture(0, 1).color(-1);
        builder.vertex(m, 1, 1, 0).texture(1, 1).color(-1);
        builder.vertex(m, 1, -1, 0).texture(1, 0).color(-1);
        BufferRenderer.drawWithGlobalProgram(builder.end());
    }

    private void setUniform(GlProgram program, String name, float... values) {
        GlUniform u = program.findUniform(name);
        if (u == null) return;
        if (values.length == 1) u.set(values[0]);
        else if (values.length == 2) u.set(values[0], values[1]);
        else if (values.length == 3) u.set(values[0], values[1], values[2]);
        else if (values.length == 4) u.set(values[0], values[1], values[2], values[3]);
    }

    public void invalidateState() {
        if (handsTarget != null) { handsTarget.delete(); handsTarget = null; }
        if (blur1 != null) { blur1.delete(); blur1 = null; }
        if (blur2 != null) { blur2.delete(); blur2 = null; }
    }
}
