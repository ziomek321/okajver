package okyware.wtf.utility.render.display.base;

import lombok.Getter;
import net.minecraft.util.Identifier;
import okyware.wtf.Okyware;

@Getter
public class CustomSprite {

    private final Identifier texture;

    public CustomSprite(String path) {
        if (path.contains(":")) {
            this.texture = Identifier.of(path);
        } else if (path.contains("/")) {
            this.texture = Okyware.id(path);
        } else {
            this.texture = Okyware.id("icons/category/" + path);
        }
    }
}