package okyware.wtf.utility.render.display.shader;

import com.mojang.blaze3d.systems.RenderSystem;
import lombok.experimental.UtilityClass;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gl.ShaderProgramKeys;
import net.minecraft.client.render.*;
import net.minecraft.client.texture.AbstractTexture;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.Identifier;
import org.lwjgl.opengl.GL11;
import org.lwjgl.opengl.GL30;
import net.minecraft.util.math.Vec2f;
import org.joml.Matrix4f;
import okyware.wtf.Okyware;
import okyware.wtf.client.modules.impl.render.Interface;
import okyware.wtf.utility.interfaces.IWindow;
import okyware.wtf.utility.math.MathUtil;
import okyware.wtf.utility.render.display.Render2DUtil;
import okyware.wtf.utility.render.display.base.BorderRadius;
import okyware.wtf.utility.render.display.base.CustomSprite;
import okyware.wtf.utility.render.display.base.Gradient;
import okyware.wtf.utility.render.display.base.color.ColorRGBA;

@UtilityClass
public class DrawUtil implements IWindow {

    public static final float DEFAULT_SMOOTHNESS = 0.8f;

    public GlProgram rectangleProgram;
    private GlProgram logoProgram;
    private GlProgram squircleProgram;
    private GlProgram roundedTextureProgram;
    private GlProgram squircleTextureProgram;
    private GlProgram borderProgram;
    private GlProgram figmaBorderProgram;
    private GlProgram loadingProgram;
    private GlProgram gradientRectangleProgram;
    public BlurProgram blurProgram;
    public GlProgram msdfFontProgram;

    private final CustomRenderTarget buffer = new CustomRenderTarget(false);

    public void initializeShaders() {
        rectangleProgram = new GlProgram(Okyware.id("rectangle/data"), VertexFormats.POSITION_COLOR);
        logoProgram = new GlProgram(Okyware.id("logo/data"), VertexFormats.POSITION_COLOR);
        squircleProgram = new GlProgram(Okyware.id("squircle/data"), VertexFormats.POSITION_COLOR);
        squircleTextureProgram = new GlProgram(Okyware.id("squircle_texture/data"),
                VertexFormats.POSITION_TEXTURE_COLOR);
        roundedTextureProgram = new GlProgram(Okyware.id("texture/data"), VertexFormats.POSITION_TEXTURE_COLOR);
        borderProgram = new GlProgram(Okyware.id("border/data"), VertexFormats.POSITION_COLOR);
        figmaBorderProgram = new GlProgram(Okyware.id("corner/data"), VertexFormats.POSITION_COLOR);
        msdfFontProgram = new GlProgram(Okyware.id("msdf_font/data"), VertexFormats.POSITION_TEXTURE_COLOR);

        loadingProgram = new GlProgram(Okyware.id("loading/data"), VertexFormats.POSITION_COLOR);
        gradientRectangleProgram = new GlProgram(Okyware.id("gradient_rectangle/data"), VertexFormats.POSITION_COLOR);
        blurProgram = new BlurProgram();
        blurProgram.initShaders();
    }

    public void updateBuffer() {
        buffer.setClearColor(0f, 0f, 0f, 1f);
        buffer.setup();
        RenderSystem.enableBlend();
        RenderSystem.defaultBlendFunc();
        mc.getFramebuffer().beginRead();
        RenderSystem.setShader(ShaderProgramKeys.POSITION_TEX_COLOR);
        RenderSystem.setShaderTexture(0, mc.getFramebuffer().getColorAttachment());
        drawQuad(0, 0, mw.getScaledWidth(), mw.getScaledHeight(), true);
        mc.getFramebuffer().endRead();
        RenderSystem.disableBlend();
        mc.getFramebuffer().beginWrite(true);
        buffer.stop();
    }

    private void drawQuad(float x, float y, float width, float height, boolean flip) {
        final BufferBuilder builder = Tessellator.getInstance().begin(VertexFormat.DrawMode.QUADS,
                VertexFormats.POSITION_TEXTURE_COLOR);
        final int color = -1;

        float vTop = flip ? 0f : 1f;
        float vBottom = flip ? 1f : 0f;

        builder.vertex(x, y, 0F).texture(0f, vBottom).color(color);
        builder.vertex(x, y + height, 0F).texture(0f, vTop).color(color);
        builder.vertex(x + width, y + height, 0F).texture(1f, vTop).color(color);
        builder.vertex(x + width, y, 0F).texture(1f, vBottom).color(color);

        BufferRenderer.drawWithGlobalProgram(builder.end());
    }

    public void drawLine(MatrixStack matrices, Vec2f from, Vec2f to, ColorRGBA color) {
        matrices.push();
        try {
            Matrix4f matrix4f = matrices.peek().getPositionMatrix();

            RenderSystem.enableBlend();
            RenderSystem.defaultBlendFunc();
            RenderSystem.setShader(ShaderProgramKeys.POSITION_COLOR);
            RenderSystem.lineWidth(1);

            drawSetup();

            BufferBuilder builder = RenderSystem.renderThreadTesselator().begin(VertexFormat.DrawMode.DEBUG_LINE_STRIP,
                    VertexFormats.POSITION_COLOR);
            builder.vertex(matrix4f, from.x, from.y, 0).color(color.getRGB());
            builder.vertex(matrix4f, to.x, to.y, 0).color(color.getRGB());
            BufferRenderer.drawWithGlobalProgram(builder.end());

            drawEnd();

        } finally {
            RenderSystem.disableBlend();
            RenderSystem.lineWidth(1.0f);
            matrices.pop();
        }
    }

    public void drawBezier(MatrixStack matrices, Vec2f p0, Vec2f p1, Vec2f p2, Vec2f p3, ColorRGBA color,
            int resolution) {
        matrices.push();
        try {
            Matrix4f matrix4f = matrices.peek().getPositionMatrix();

            RenderSystem.enableBlend();
            RenderSystem.defaultBlendFunc();
            RenderSystem.setShader(ShaderProgramKeys.POSITION_COLOR);
            RenderSystem.lineWidth(1);

            drawSetup();

            BufferBuilder builder = RenderSystem.renderThreadTesselator().begin(VertexFormat.DrawMode.DEBUG_LINE_STRIP,
                    VertexFormats.POSITION_COLOR);
            for (int i = 0; i <= resolution; i++) {
                float t = (float) i / resolution;
                float x = (float) MathUtil.cubicBezier(t, p0.x, p1.x, p2.x, p3.x);
                float y = (float) MathUtil.cubicBezier(t, p0.y, p1.y, p2.y, p3.y);
                builder.vertex(matrix4f, x, y, 0).color(color.getRGB());
            }
            BufferRenderer.drawWithGlobalProgram(builder.end());

            drawEnd();

        } finally {
            RenderSystem.disableBlend();
            RenderSystem.lineWidth(1.0f);
            matrices.pop();
        }
    }

    private float cubicBezier(float t, float p0, float p1, float p2, float p3) {
        float u = 1 - t;
        float tt = t * t;
        float uu = u * u;

        return (uu * u * p0) + (3 * uu * t * p1) + (3 * u * tt * p2) + (tt * t * p3);
    }

    public void drawRect(MatrixStack matrices, float x, float y, float width, float height, ColorRGBA color) {
        matrices.push();

        Matrix4f matrix4f = matrices.peek().getPositionMatrix();

        RenderSystem.setShader(ShaderProgramKeys.POSITION_COLOR);

        drawSetup();

        BufferBuilder builder = RenderSystem.renderThreadTesselator().begin(VertexFormat.DrawMode.QUADS,
                VertexFormats.POSITION_COLOR);
        builder.vertex(matrix4f, x, y + height, 0).color(color.getRGB());
        builder.vertex(matrix4f, x + width, y + height, 0).color(color.getRGB());
        builder.vertex(matrix4f, x + width, y, 0).color(color.getRGB());
        builder.vertex(matrix4f, x, y, 0).color(color.getRGB());
        BufferRenderer.drawWithGlobalProgram(builder.end());

        drawEnd();
        matrices.pop();
    }

    public void drawSquircle(MatrixStack matrices, float x, float y, float width, float height, float squirt,
            BorderRadius borderRadius, ColorRGBA color) {
        matrices.push();
        Matrix4f matrix4f = matrices.peek().getPositionMatrix();
        float smoothness = DEFAULT_SMOOTHNESS;

        squircleProgram.use();
        squircleProgram.findUniform("Size").set(width, height);
        squircleProgram.findUniform("Radius").set(
                borderRadius.topLeftRadius() * squirt / 2F,
                borderRadius.bottomLeftRadius() * squirt / 2F,
                borderRadius.topRightRadius() * squirt / 2F,
                borderRadius.bottomRightRadius() * squirt / 2F);
        squircleProgram.findUniform("Smoothness").set(smoothness);
        squircleProgram.findUniform("CornerSmoothness").set(squirt);

        drawSetup();

        float horizontalPadding = -smoothness / 2.0F + smoothness * 2.0F;
        float verticalPadding = smoothness / 2.0F + smoothness;
        float adjustedX = x - horizontalPadding / 2.0F;
        float adjustedY = y - verticalPadding / 2.0F;
        float adjustedWidth = width + horizontalPadding;
        float adjustedHeight = height + verticalPadding;

        BufferBuilder builder = RenderSystem.renderThreadTesselator().begin(VertexFormat.DrawMode.QUADS,
                VertexFormats.POSITION_COLOR);
        builder.vertex(matrix4f, adjustedX, adjustedY, 0.0F).color(color.getRGB());
        builder.vertex(matrix4f, adjustedX, adjustedY + adjustedHeight, 0.0F).color(color.getRGB());
        builder.vertex(matrix4f, adjustedX + adjustedWidth, adjustedY + adjustedHeight, 0.0F).color(color.getRGB());
        builder.vertex(matrix4f, adjustedX + adjustedWidth, adjustedY, 0.0F).color(color.getRGB());
        BufferRenderer.drawWithGlobalProgram(builder.end());

        drawEnd();
        matrices.pop();
    }

    public void drawLoadingRect(MatrixStack matrices, float x, float y, float width, float height, float progress,
            BorderRadius borderRadius, ColorRGBA color) {
        matrices.push();
        Matrix4f matrix4f = matrices.peek().getPositionMatrix();
        float smoothness = DEFAULT_SMOOTHNESS;

        loadingProgram.use();
        loadingProgram.findUniform("Size").set(width, height);
        loadingProgram.findUniform("Radius").set(
                borderRadius.topLeftRadius(),
                borderRadius.bottomLeftRadius(),
                borderRadius.topRightRadius(),
                borderRadius.bottomRightRadius());
        loadingProgram.findUniform("Smoothness").set(smoothness);
        loadingProgram.findUniform("Progress").set(progress);
        loadingProgram.findUniform("StripeWidth").set(0f);
        loadingProgram.findUniform("Fade").set(0.5f);

        drawSetup();

        float horizontalPadding = -smoothness / 2.0F + smoothness * 2.0F;
        float verticalPadding = smoothness / 2.0F + smoothness;
        float adjustedX = x - horizontalPadding / 2.0F;
        float adjustedY = y - verticalPadding / 2.0F;
        float adjustedWidth = width + horizontalPadding;
        float adjustedHeight = height + verticalPadding;

        BufferBuilder builder = RenderSystem.renderThreadTesselator().begin(VertexFormat.DrawMode.QUADS,
                VertexFormats.POSITION_COLOR);
        builder.vertex(matrix4f, adjustedX, adjustedY, 0.0F).color(color.getRGB());
        builder.vertex(matrix4f, adjustedX, adjustedY + adjustedHeight, 0.0F).color(color.getRGB());
        builder.vertex(matrix4f, adjustedX + adjustedWidth, adjustedY + adjustedHeight, 0.0F).color(color.getRGB());
        builder.vertex(matrix4f, adjustedX + adjustedWidth, adjustedY, 0.0F).color(color.getRGB());
        BufferRenderer.drawWithGlobalProgram(builder.end());

        drawEnd();
        matrices.pop();
    }

    public void drawRoundedRect(MatrixStack matrices, float x, float y, float width, float height,
            BorderRadius borderRadius, ColorRGBA color) {
        matrices.push();
        Matrix4f matrix4f = matrices.peek().getPositionMatrix();
        float smoothness = DEFAULT_SMOOTHNESS;

        rectangleProgram.use();
        rectangleProgram.findUniform("Size").set(width, height);
        rectangleProgram.findUniform("Radius").set(
                borderRadius.topLeftRadius(),
                borderRadius.bottomLeftRadius(),
                borderRadius.topRightRadius(),
                borderRadius.bottomRightRadius());
        rectangleProgram.findUniform("Smoothness").set(smoothness);

        drawSetup();

        float horizontalPadding = -smoothness / 2.0F + smoothness * 2.0F;
        float verticalPadding = smoothness / 2.0F + smoothness;
        float adjustedX = x - horizontalPadding / 2.0F;
        float adjustedY = y - verticalPadding / 2.0F;
        float adjustedWidth = width + horizontalPadding;
        float adjustedHeight = height + verticalPadding;

        BufferBuilder builder = RenderSystem.renderThreadTesselator().begin(VertexFormat.DrawMode.QUADS,
                VertexFormats.POSITION_COLOR);
        builder.vertex(matrix4f, adjustedX, adjustedY, 0.0F).color(color.getRGB());
        builder.vertex(matrix4f, adjustedX, adjustedY + adjustedHeight, 0.0F).color(color.getRGB());
        builder.vertex(matrix4f, adjustedX + adjustedWidth, adjustedY + adjustedHeight, 0.0F).color(color.getRGB());
        builder.vertex(matrix4f, adjustedX + adjustedWidth, adjustedY, 0.0F).color(color.getRGB());
        BufferRenderer.drawWithGlobalProgram(builder.end());

        drawEnd();
        matrices.pop();
    }

    public void drawLogo(MatrixStack matrices, float x, float y, float size, ColorRGBA color) {
        matrices.push();
        Matrix4f matrix4f = matrices.peek().getPositionMatrix();

        if (logoProgram == null)
            return;
        logoProgram.use();
        var sizeUniform = logoProgram.findUniform("Size");
        if (sizeUniform != null)
            sizeUniform.set(size, size);

        drawSetup();

        BufferBuilder builder = RenderSystem.renderThreadTesselator().begin(VertexFormat.DrawMode.QUADS,
                VertexFormats.POSITION_COLOR);
        builder.vertex(matrix4f, x, y, 0.0F).color(color.getRGB());
        builder.vertex(matrix4f, x, y + size, 0.0F).color(color.getRGB());
        builder.vertex(matrix4f, x + size, y + size, 0.0F).color(color.getRGB());
        builder.vertex(matrix4f, x + size, y, 0.0F).color(color.getRGB());
        BufferRenderer.drawWithGlobalProgram(builder.end());

        drawEnd();
        matrices.pop();
    }

    public void drawRoundedRect(MatrixStack matrices, float x, float y, float width, float height,
            BorderRadius borderRadius, ColorRGBA color1, ColorRGBA color2, ColorRGBA color3, ColorRGBA color4) {
        matrices.push();
        Matrix4f matrix4f = matrices.peek().getPositionMatrix();
        float smoothness = DEFAULT_SMOOTHNESS;

        gradientRectangleProgram.use();
        gradientRectangleProgram.findUniform("Size").set(width, height);
        gradientRectangleProgram.findUniform("Radius").set(
                borderRadius.topLeftRadius(),
                borderRadius.bottomLeftRadius(),
                borderRadius.topRightRadius(),
                borderRadius.bottomRightRadius());
        gradientRectangleProgram.findUniform("Smoothness").set(smoothness);

        gradientRectangleProgram.findUniform("TopLeftColor").set(
                color1.getRed() / 255.0f,
                color1.getGreen() / 255.0f,
                color1.getBlue() / 255.0f,
                color1.getAlpha() / 255.0f);
        gradientRectangleProgram.findUniform("BottomLeftColor").set(
                color2.getRed() / 255.0f,
                color2.getGreen() / 255.0f,
                color2.getBlue() / 255.0f,
                color2.getAlpha() / 255.0f);
        gradientRectangleProgram.findUniform("BottomRightColor").set(
                color3.getRed() / 255.0f,
                color3.getGreen() / 255.0f,
                color3.getBlue() / 255.0f,
                color3.getAlpha() / 255.0f);
        gradientRectangleProgram.findUniform("TopRightColor").set(
                color4.getRed() / 255.0f,
                color4.getGreen() / 255.0f,
                color4.getBlue() / 255.0f,
                color4.getAlpha() / 255.0f);

        drawSetup();

        float horizontalPadding = -smoothness / 2.0F + smoothness * 2.0F;
        float verticalPadding = smoothness / 2.0F + smoothness;
        float adjustedX = x - horizontalPadding / 2.0F;
        float adjustedY = y - verticalPadding / 2.0F;
        float adjustedWidth = width + horizontalPadding;
        float adjustedHeight = height + verticalPadding;

        BufferBuilder builder = RenderSystem.renderThreadTesselator().begin(VertexFormat.DrawMode.QUADS,
                VertexFormats.POSITION_COLOR);

        
        
        
        
        builder.vertex(matrix4f, adjustedX, adjustedY, 0.0F).color(color1.getRGB());
        builder.vertex(matrix4f, adjustedX, adjustedY + adjustedHeight, 0.0F).color(color2.getRGB());
        builder.vertex(matrix4f, adjustedX + adjustedWidth, adjustedY + adjustedHeight, 0.0F).color(color3.getRGB());
        builder.vertex(matrix4f, adjustedX + adjustedWidth, adjustedY, 0.0F).color(color4.getRGB());

        BufferRenderer.drawWithGlobalProgram(builder.end());

        drawEnd();
        matrices.pop();
    }

    public void drawRoundedRect(MatrixStack matrices, float x, float y, float width, float height,
            BorderRadius borderRadius, Gradient gradient) {
        drawRoundedRect(matrices, x, y, width, height, borderRadius,
                gradient.getTopLeftColor(),
                gradient.getBottomLeftColor(),
                gradient.getBottomRightColor(),
                gradient.getTopRightColor());
    }

    
    public void drawRoundedBorder(MatrixStack matrices, float x, float y, float width, float height,
            float borderThickness, BorderRadius borderRadius, ColorRGBA borderColor) {
        
    }

    public void drawRoundedCorner(MatrixStack matrices, float x, float y, float width, float height,
            float borderThikenes, float delta, ColorRGBA color, BorderRadius radius) {
        if (!Interface.INSTANCE.isCorners())
            return;
        
        x -= 0.3f;
        y -= 0.3f;
        width += 0.3f * 2;
        height += 0.3f * 2;
        drawRoundedCornerOnly(matrices, x, y, delta, delta, borderThikenes, radius, color, 0);
        drawRoundedCornerOnly(matrices, x + width - delta, y, delta, delta, borderThikenes, radius, color, 1);

        drawRoundedCornerOnly(matrices, x, y + height - delta, delta, delta, borderThikenes, radius, color, 2);
        drawRoundedCornerOnly(matrices, x + width - delta, y + height - delta, delta, delta, borderThikenes, radius,
                color, 3);

    }

    public void drawRoundedCornerOnly(MatrixStack matrices, float x, float y, float width, float height,
            float borderThickness, BorderRadius borderRadius, ColorRGBA borderColor, float cornerIdex) {
        matrices.push();
        Matrix4f matrix4f = matrices.peek().getPositionMatrix();
        float internalSmoothness = DEFAULT_SMOOTHNESS, externalSmoothness = 1.0F;

        figmaBorderProgram.use();
        figmaBorderProgram.findUniform("Size").set(width, height);
        figmaBorderProgram.findUniform("Radius").set(
                borderRadius.topLeftRadius(),
                borderRadius.bottomLeftRadius(),
                borderRadius.topRightRadius(),
                borderRadius.bottomRightRadius());
        figmaBorderProgram.findUniform("Smoothness").set(internalSmoothness, externalSmoothness);
        figmaBorderProgram.findUniform("Thickness").set(borderThickness);
        figmaBorderProgram.findUniform("CornerIndex").set(cornerIdex);

        drawSetup();

        float horizontalPadding = -externalSmoothness / 2.0F + externalSmoothness * 2.0F;
        float verticalPadding = externalSmoothness / 2.0F + externalSmoothness;
        float adjustedX = x - horizontalPadding / 2.0F;
        float adjustedY = y - verticalPadding / 2.0F;
        float adjustedWidth = width + horizontalPadding;
        float adjustedHeight = height + verticalPadding;

        BufferBuilder builder = RenderSystem.renderThreadTesselator().begin(VertexFormat.DrawMode.QUADS,
                VertexFormats.POSITION_COLOR);
        builder.vertex(matrix4f, adjustedX, adjustedY, 0.0F).color(borderColor.getRGB());
        builder.vertex(matrix4f, adjustedX, adjustedY + adjustedHeight, 0.0F).color(borderColor.getRGB());
        builder.vertex(matrix4f, adjustedX + adjustedWidth, adjustedY + adjustedHeight, 0.0F)
                .color(borderColor.getRGB());
        builder.vertex(matrix4f, adjustedX + adjustedWidth, adjustedY, 0.0F).color(borderColor.getRGB());
        BufferRenderer.drawWithGlobalProgram(builder.end());

        drawEnd();
        matrices.pop();
    }

    public void drawTexture(MatrixStack matrices, Identifier identifier, float x, float y, float width, float height,
            ColorRGBA textureColor) {
        matrices.push();

        Matrix4f matrix4f = matrices.peek().getPositionMatrix();

        RenderSystem.setShader(ShaderProgramKeys.POSITION_TEX_COLOR);
        RenderSystem.setShaderTexture(0, identifier);

        drawSetup();

        BufferBuilder builder = RenderSystem.renderThreadTesselator().begin(VertexFormat.DrawMode.QUADS,
                VertexFormats.POSITION_TEXTURE_COLOR);
        builder.vertex(matrix4f, x, y, 0.0F).texture(0.0F, 0.0F).color(textureColor.getRGB());
        builder.vertex(matrix4f, x, y + height, 0.0F).texture(0.0F, 1.0F).color(textureColor.getRGB());
        builder.vertex(matrix4f, x + width, y + height, 0.0F).texture(1.0F, 1.0F).color(textureColor.getRGB());
        builder.vertex(matrix4f, x + width, y, 0.0F).texture(1.0F, 0.0F).color(textureColor.getRGB());
        BufferRenderer.drawWithGlobalProgram(builder.end());

        drawEnd();

        
        RenderSystem.setShaderTexture(0, 0);
        matrices.pop();
    }

    public void drawTexture(MatrixStack matrices, Identifier identifier, float x, float y, float width, float height,
            Gradient textureColor) {
        matrices.push();

        Matrix4f matrix4f = matrices.peek().getPositionMatrix();

        RenderSystem.setShader(ShaderProgramKeys.POSITION_TEX_COLOR);
        RenderSystem.setShaderTexture(0, identifier);

        drawSetup();

        BufferBuilder builder = RenderSystem.renderThreadTesselator().begin(VertexFormat.DrawMode.QUADS,
                VertexFormats.POSITION_TEXTURE_COLOR);
        builder.vertex(matrix4f, x, y, 0.0F).texture(0.0F, 0.0F).color(textureColor.getTopLeftColor().getRGB());
        builder.vertex(matrix4f, x, y + height, 0.0F).texture(0.0F, 1.0F)
                .color(textureColor.getBottomLeftColor().getRGB());
        builder.vertex(matrix4f, x + width, y + height, 0.0F).texture(1.0F, 1.0F)
                .color(textureColor.getBottomRightColor().getRGB());
        builder.vertex(matrix4f, x + width, y, 0.0F).texture(1.0F, 0.0F)
                .color(textureColor.getTopRightColor().getRGB());
        BufferRenderer.drawWithGlobalProgram(builder.end());

        drawEnd();

        
        RenderSystem.setShaderTexture(0, 0);
        matrices.pop();
    }

    public void drawTexture(MatrixStack matrices, Identifier identifier, float x, float y, float width, float height,
            float u1, float u2, float v1, float v2, ColorRGBA clor) {
        RenderSystem.enableBlend();
        RenderSystem.defaultBlendFunc();

        matrices.push();
        int color = clor.getRGB();

        
        

        Matrix4f matrix4f = matrices.peek().getPositionMatrix();

        float x2 = x + width;
        float y2 = y + height;

        RenderSystem.setShader(ShaderProgramKeys.POSITION_TEX_COLOR);
        RenderSystem.setShaderTexture(0, identifier);

        BufferBuilder builder = RenderSystem.renderThreadTesselator().begin(VertexFormat.DrawMode.QUADS,
                VertexFormats.POSITION_TEXTURE_COLOR);
        builder.vertex(matrix4f, x, y, 0.0F).texture(u1, v1).color(color);
        builder.vertex(matrix4f, x, y2, 0.0F).texture(u1, v2).color(color);
        builder.vertex(matrix4f, x2, y2, 0.0F).texture(u2, v2).color(color);
        builder.vertex(matrix4f, x2, y, 0.0F).texture(u2, v1).color(color);
        BufferRenderer.drawWithGlobalProgram(builder.end());

        drawEnd();

        
        RenderSystem.setShaderTexture(0, 0);
        matrices.pop();
        RenderSystem.disableBlend();
    }

    public void drawSprite(MatrixStack matrices, CustomSprite sprite, float x, float y, float width, float height,
            ColorRGBA color) {
        drawTexture(matrices, sprite.getTexture(), x, y, width, height, 0, 1, 0, 1, color);
    }

    public void drawRoundedTexture(MatrixStack matrices, Identifier identifier, float x, float y, float width,
            float height, BorderRadius borderRadius) {
        drawRoundedTexture(matrices, identifier, x, y, width, height, borderRadius, ColorRGBA.WHITE);
    }

    public void drawRoundedTextureSmooth(MatrixStack matrices, Identifier identifier, float x, float y, float width,
            float height, BorderRadius borderRadius, ColorRGBA color) {
        AbstractTexture texture = MinecraftClient.getInstance().getTextureManager().getTexture(identifier);
        texture.bindTexture();
        
        
        
        if (!mippedTextures.contains(identifier)) {
            GL30.glGenerateMipmap(GL11.GL_TEXTURE_2D);
            mippedTextures.add(identifier);
        }
        GL11.glTexParameteri(GL11.GL_TEXTURE_2D, GL11.GL_TEXTURE_MIN_FILTER, GL11.GL_LINEAR_MIPMAP_LINEAR);
        GL11.glTexParameteri(GL11.GL_TEXTURE_2D, GL11.GL_TEXTURE_MAG_FILTER, GL11.GL_LINEAR);
        drawRoundedTexture(matrices, identifier, x, y, width, height, borderRadius, color);
    }

    private final java.util.Set<Identifier> mippedTextures = new java.util.HashSet<>();

    public void drawRoundedTexture(MatrixStack matrices, Identifier identifier, float x, float y, float width,
            float height, BorderRadius borderRadius, ColorRGBA color) {
        matrices.push();
        Matrix4f matrix4f = matrices.peek().getPositionMatrix();
        float smoothness = DEFAULT_SMOOTHNESS;

        roundedTextureProgram.use();
        RenderSystem.setShaderTexture(0, identifier);

        roundedTextureProgram.findUniform("Size").set(width, height);
        roundedTextureProgram.findUniform("Radius").set(
                borderRadius.topLeftRadius(),
                borderRadius.bottomLeftRadius(),
                borderRadius.topRightRadius(),
                borderRadius.bottomRightRadius());
        roundedTextureProgram.findUniform("Smoothness").set(smoothness);

        drawSetup();

        float horizontalPadding = -smoothness / 2.0F + smoothness * 2.0F;
        float verticalPadding = smoothness / 2.0F + smoothness;
        float adjustedX = x - horizontalPadding / 2.0F;
        float adjustedY = y - verticalPadding / 2.0F;
        float adjustedWidth = width + horizontalPadding;
        float adjustedHeight = height + verticalPadding;

        BufferBuilder builder = RenderSystem.renderThreadTesselator().begin(VertexFormat.DrawMode.QUADS,
                VertexFormats.POSITION_TEXTURE_COLOR);
        builder.vertex(matrix4f, adjustedX, adjustedY, 0.0F).texture(0.0F, 0.0F).color(color.getRGB());
        builder.vertex(matrix4f, adjustedX, adjustedY + adjustedHeight, 0.0F).texture(0.0F, 1.0F).color(color.getRGB());
        builder.vertex(matrix4f, adjustedX + adjustedWidth, adjustedY + adjustedHeight, 0.0F).texture(1.0F, 1.0F)
                .color(color.getRGB());
        builder.vertex(matrix4f, adjustedX + adjustedWidth, adjustedY, 0.0F).texture(1.0F, 0.0F).color(color.getRGB());
        BufferRenderer.drawWithGlobalProgram(builder.end());
        drawEnd();

        
        RenderSystem.setShaderTexture(0, 0);
        matrices.pop();
    }

    
    public void drawShadow(MatrixStack matrices, float x, float y, float width, float height, float softness,
            BorderRadius borderRadius, ColorRGBA color) {
        matrices.push();
        Matrix4f matrix4f = matrices.peek().getPositionMatrix();

        rectangleProgram.use();
        rectangleProgram.findUniform("Size").set(width, height);
        rectangleProgram.findUniform("Radius").set(
                borderRadius.topLeftRadius() * 3,
                borderRadius.bottomLeftRadius() * 3,
                borderRadius.topRightRadius() * 3,
                borderRadius.bottomRightRadius() * 3);
        rectangleProgram.findUniform("Smoothness").set(softness);

        drawSetup();

        float horizontalPadding = -softness / 2.0F + softness * 2.0F;
        float verticalPadding = softness / 2.0F + softness;
        float adjustedX = x - horizontalPadding / 2.0F;
        float adjustedY = y - verticalPadding / 2.0F;
        float adjustedWidth = width + horizontalPadding;
        float adjustedHeight = height + verticalPadding;

        BufferBuilder builder = RenderSystem.renderThreadTesselator().begin(VertexFormat.DrawMode.QUADS,
                VertexFormats.POSITION_COLOR);
        builder.vertex(matrix4f, adjustedX, adjustedY, 0.0F).color(color.getRGB());
        builder.vertex(matrix4f, adjustedX, adjustedY + adjustedHeight, 0.0F).color(color.getRGB());
        builder.vertex(matrix4f, adjustedX + adjustedWidth, adjustedY + adjustedHeight, 0.0F).color(color.getRGB());
        builder.vertex(matrix4f, adjustedX + adjustedWidth, adjustedY, 0.0F).color(color.getRGB());
        BufferRenderer.drawWithGlobalProgram(builder.end());

        drawEnd();
        matrices.pop();
    }

    public void drawBlur(MatrixStack matrices, float x, float y, float width, float height, float blurRadius,
            float squirt, BorderRadius borderRadius, ColorRGBA color) {
        matrices.push();
        Matrix4f matrix4f = matrices.peek().getPositionMatrix();
        float smoothness = 0.03f;

        blurRadius /= 22.5f;

        if (blurRadius <= 0)
            return;

        blurProgram.setBlurRadius(2);
        squircleTextureProgram.use();
        RenderSystem.setShaderTexture(0, BlurProgram.getTexture());
        squircleTextureProgram.findUniform("Size").set(width, height);
        squircleTextureProgram.findUniform("Radius").set(
                borderRadius.topLeftRadius() * squirt / 2F,
                borderRadius.bottomLeftRadius() * squirt / 2F,
                borderRadius.topRightRadius() * squirt / 2F,
                borderRadius.bottomRightRadius() * squirt / 2F);
        squircleTextureProgram.findUniform("Smoothness").set(0.1f);
        squircleTextureProgram.findUniform("CornerSmoothness").set(squirt);

        drawSetup();

        float horizontalPadding = -smoothness / 2.0F + smoothness * 2.0F;
        float verticalPadding = smoothness / 2.0F + smoothness;
        float adjustedX = x - horizontalPadding / 2.0F;
        float adjustedY = y - verticalPadding / 2.0F;
        float adjustedWidth = width + horizontalPadding;
        float adjustedHeight = height + verticalPadding;

        int screenWidth = mc.getWindow().getScaledWidth();
        int screenHeight = mc.getWindow().getScaledHeight();

        float u = adjustedX / screenWidth;
        float v = (screenHeight - adjustedY - adjustedHeight) / screenHeight;
        float texWidth = adjustedWidth / screenWidth;
        float texHeight = adjustedHeight / screenHeight;

        BufferBuilder builder = RenderSystem.renderThreadTesselator().begin(VertexFormat.DrawMode.QUADS,
                VertexFormats.POSITION_TEXTURE_COLOR);
        builder.vertex(matrix4f, adjustedX, adjustedY, 0.0F).texture(u, v + texHeight).color(color.getRGB());
        builder.vertex(matrix4f, adjustedX, adjustedY + adjustedHeight, 0.0F).texture(u, v).color(color.getRGB());
        builder.vertex(matrix4f, adjustedX + adjustedWidth, adjustedY + adjustedHeight, 0.0F).texture(u + texWidth, v)
                .color(color.getRGB());
        builder.vertex(matrix4f, adjustedX + adjustedWidth, adjustedY, 0.0F).texture(u + texWidth, v + texHeight)
                .color(color.getRGB());
        BufferRenderer.drawWithGlobalProgram(builder.end());

        drawEnd();

        RenderSystem.setShaderTexture(0, 0);
        matrices.pop();
    }

    public void drawBlurHud(MatrixStack matrices, float x, float y, float width, float height, float blurRadius,
            BorderRadius borderRadius, ColorRGBA color) {
        drawBlurHudBooleanCheck(matrices, x, y, width, height, blurRadius, borderRadius, color,
                Interface.INSTANCE.isBlur(), Interface.INSTANCE.isGlow());
    }

    public void drawBlurHudBooleanCheck(MatrixStack matrices, float x, float y, float width, float height,
            float blurRadius, BorderRadius borderRadius, ColorRGBA color, boolean blur, boolean glow) {
        if (blur) {

            matrices.push();
            Matrix4f matrix4f = matrices.peek().getPositionMatrix();

            blurRadius /= 22.5f;

            if (blurRadius <= 0)
                return;

            blurProgram.setBlurRadius(2);
            roundedTextureProgram.use();
            RenderSystem.setShaderTexture(0, BlurProgram.getTexture());

            roundedTextureProgram.findUniform("Size").set(width, height);
            roundedTextureProgram.findUniform("Radius").set(
                    borderRadius.topLeftRadius(),
                    borderRadius.bottomLeftRadius(),
                    borderRadius.topRightRadius(),
                    borderRadius.bottomRightRadius());
            roundedTextureProgram.findUniform("Smoothness").set(0.01f);

            drawSetup();

            int screenWidth = mc.getWindow().getScaledWidth();
            int screenHeight = mc.getWindow().getScaledHeight();

            float u = x / screenWidth;
            float v = (screenHeight - y - height) / screenHeight;
            float texWidth = width / screenWidth;
            float texHeight = height / screenHeight;

            BufferBuilder builder = RenderSystem.renderThreadTesselator().begin(VertexFormat.DrawMode.QUADS,
                    VertexFormats.POSITION_TEXTURE_COLOR);
            builder.vertex(matrix4f, x, y, 0.0F).texture(u, v + texHeight).color(color.getRGB());
            builder.vertex(matrix4f, x, y + height, 0.0F).texture(u, v).color(color.getRGB());
            builder.vertex(matrix4f, x + width, y + height, 0.0F).texture(u + texWidth, v).color(color.getRGB());
            builder.vertex(matrix4f, x + width, y, 0.0F).texture(u + texWidth, v + texHeight).color(color.getRGB());
            BufferRenderer.drawWithGlobalProgram(builder.end());
            drawEnd();

            
            RenderSystem.setShaderTexture(0, 0);
            matrices.pop();
        }
        if (glow) {
            drawGlow(matrices, x, y, width, height, Interface.INSTANCE.getGlowRadius());
        }
    }

    public static void drawGlow(MatrixStack matrixStack, float x, float y, float width, float height, int glowRadius) {

        Render2DUtil.drawGradientBlurredShadow(matrixStack, x, y, width, height, glowRadius,
                Okyware.getInstance().getThemeManager().getClientColor());

    }

    public void drawFullScreenBlur(MatrixStack matrices, float width, float height, float opacity) {
        if (blurProgram == null)
            return;

        blurProgram.setBlurRadius(2);
        blurProgram.draw();

        matrices.push();
        Matrix4f matrix4f = matrices.peek().getPositionMatrix();

        RenderSystem.enableBlend();
        RenderSystem.defaultBlendFunc();
        RenderSystem.setShader(ShaderProgramKeys.POSITION_TEX_COLOR);
        RenderSystem.setShaderTexture(0, BlurProgram.getTexture());

        BufferBuilder builder = RenderSystem.renderThreadTesselator().begin(VertexFormat.DrawMode.QUADS,
                VertexFormats.POSITION_TEXTURE_COLOR);
        builder.vertex(matrix4f, 0, 0, 0.0F).texture(0, 1).color(1f, 1f, 1f, opacity);
        builder.vertex(matrix4f, 0, height, 0.0F).texture(0, 0).color(1f, 1f, 1f, opacity);
        builder.vertex(matrix4f, width, height, 0.0F).texture(1, 0).color(1f, 1f, 1f, opacity);
        builder.vertex(matrix4f, width, 0, 0.0F).texture(1, 1).color(1f, 1f, 1f, opacity);
        BufferRenderer.drawWithGlobalProgram(builder.end());

        RenderSystem.setShaderTexture(0, 0);
        RenderSystem.disableBlend();
        matrices.pop();
    }

    public void drawBlur(MatrixStack matrices, float x, float y, float width, float height, float blurRadius,
            BorderRadius borderRadius, ColorRGBA color) {
        matrices.push();
        Matrix4f matrix4f = matrices.peek().getPositionMatrix();

        blurRadius /= 22.5f;

        if (blurRadius <= 0)
            return;

        blurProgram.setBlurRadius(2);
        roundedTextureProgram.use();
        RenderSystem.setShaderTexture(0, BlurProgram.getTexture());

        roundedTextureProgram.findUniform("Size").set(width, height);
        roundedTextureProgram.findUniform("Radius").set(
                borderRadius.topLeftRadius(),
                borderRadius.bottomLeftRadius(),
                borderRadius.topRightRadius(),
                borderRadius.bottomRightRadius());
        roundedTextureProgram.findUniform("Smoothness").set(0.01f);

        drawSetup();

        int screenWidth = mc.getWindow().getScaledWidth();
        int screenHeight = mc.getWindow().getScaledHeight();

        float u = x / screenWidth;
        float v = (screenHeight - y - height) / screenHeight;
        float texWidth = width / screenWidth;
        float texHeight = height / screenHeight;

        BufferBuilder builder = RenderSystem.renderThreadTesselator().begin(VertexFormat.DrawMode.QUADS,
                VertexFormats.POSITION_TEXTURE_COLOR);
        builder.vertex(matrix4f, x, y, 0.0F).texture(u, v + texHeight).color(color.getRGB());
        builder.vertex(matrix4f, x, y + height, 0.0F).texture(u, v).color(color.getRGB());
        builder.vertex(matrix4f, x + width, y + height, 0.0F).texture(u + texWidth, v).color(color.getRGB());
        builder.vertex(matrix4f, x + width, y, 0.0F).texture(u + texWidth, v + texHeight).color(color.getRGB());
        BufferRenderer.drawWithGlobalProgram(builder.end());
        drawEnd();

        
        RenderSystem.setShaderTexture(0, 0);
        matrices.pop();

    }

    public void drawImage(MatrixStack matrices, BufferBuilder builder, double x, double y, double z, double width,
            double height, ColorRGBA color) {
        Matrix4f matrix = matrices.peek().getPositionMatrix();

        builder.vertex(matrix, (float) x, (float) (y + height), (float) z).texture(0, 1).color(color.getRGB());
        builder.vertex(matrix, (float) (x + width), (float) (y + height), (float) z).texture(1, 1)
                .color(color.getRGB());
        builder.vertex(matrix, (float) (x + width), (float) y, (float) z).texture(1, 0).color(color.getRGB());
        builder.vertex(matrix, (float) x, (float) y, (float) z).texture(0, 0).color(color.getRGB());
    }

    public void drawImage(MatrixStack matrices, Identifier identifier, double x, double y, double z, double width,
            double height, ColorRGBA color) {
        RenderSystem.setShaderTexture(0, identifier);
        BufferBuilder builder = RenderSystem.renderThreadTesselator().begin(VertexFormat.DrawMode.QUADS,
                VertexFormats.POSITION_TEXTURE_COLOR);

        Matrix4f matrix = matrices.peek().getPositionMatrix();

        builder.vertex(matrix, (float) x, (float) (y + height), (float) z).texture(0, 1).color(color.getRGB());
        builder.vertex(matrix, (float) (x + width), (float) (y + height), (float) z).texture(1, 1)
                .color(color.getRGB());
        builder.vertex(matrix, (float) (x + width), (float) y, (float) z).texture(1, 0).color(color.getRGB());
        builder.vertex(matrix, (float) x, (float) y, (float) z).texture(0, 0).color(color.getRGB());

        BufferRenderer.drawWithGlobalProgram(builder.end());
    }

    public void drawPlayerHeadWithRoundedShader(MatrixStack matrices, Identifier skinTexture, float x, float y,
            float size, BorderRadius borderRadius, ColorRGBA color) {
        drawRoundedTextureWithUV(matrices, skinTexture, x, y, size, size, borderRadius, color,
                8.0f / 64.0f, 
                8.0f / 64.0f, 
                16.0f / 64.0f, 
                16.0f / 64.0f 
        );
    }

    private void drawPlayerHatLayerWithRoundedShader(MatrixStack matrices, Identifier skinTexture, float x, float y,
            float size, BorderRadius borderRadius, ColorRGBA color) {
        
        RenderSystem.enableBlend();
        RenderSystem.defaultBlendFunc();

        drawRoundedTextureWithUV(matrices, skinTexture, x, y, size, size, borderRadius, color,
                40.0f / 64.0f, 
                8.0f / 64.0f, 
                48.0f / 64.0f, 
                16.0f / 64.0f 
        );

        RenderSystem.disableBlend();
    }

    public void drawRoundedTextureWithUV(MatrixStack matrices, Identifier identifier, float x, float y, float width,
            float height, BorderRadius borderRadius, ColorRGBA color, float u1, float v1, float u2, float v2) {
        matrices.push();
        Matrix4f matrix4f = matrices.peek().getPositionMatrix();
        float smoothness = DEFAULT_SMOOTHNESS;

        roundedTextureProgram.use();
        RenderSystem.setShaderTexture(0, identifier);

        roundedTextureProgram.findUniform("Size").set(width, height);
        roundedTextureProgram.findUniform("Radius").set(
                borderRadius.topLeftRadius(),
                borderRadius.bottomLeftRadius(),
                borderRadius.topRightRadius(),
                borderRadius.bottomRightRadius());
        roundedTextureProgram.findUniform("Smoothness").set(smoothness);

        drawSetup();

        float horizontalPadding = -smoothness / 2.0F + smoothness * 2.0F;
        float verticalPadding = smoothness / 2.0F + smoothness;
        float adjustedX = x - horizontalPadding / 2.0F;
        float adjustedY = y - verticalPadding / 2.0F;
        float adjustedWidth = width + horizontalPadding;
        float adjustedHeight = height + verticalPadding;

        BufferBuilder builder = RenderSystem.renderThreadTesselator().begin(VertexFormat.DrawMode.QUADS,
                VertexFormats.POSITION_TEXTURE_COLOR);

        
        builder.vertex(matrix4f, adjustedX, adjustedY, 0.0F).texture(u1, v1).color(color.getRGB());
        builder.vertex(matrix4f, adjustedX, adjustedY + adjustedHeight, 0.0F).texture(u1, v2).color(color.getRGB());
        builder.vertex(matrix4f, adjustedX + adjustedWidth, adjustedY + adjustedHeight, 0.0F).texture(u2, v2)
                .color(color.getRGB());
        builder.vertex(matrix4f, adjustedX + adjustedWidth, adjustedY, 0.0F).texture(u2, v1).color(color.getRGB());

        BufferRenderer.drawWithGlobalProgram(builder.end());
        drawEnd();

        RenderSystem.setShaderTexture(0, 0);
        matrices.pop();
    }

    public void drawMSDFIcon(MatrixStack matrices, Identifier identifier, float x, float y, float width, float height,
            float range, float thickness, float smoothness, ColorRGBA color) {
        matrices.push();
        Matrix4f matrix4f = matrices.peek().getPositionMatrix();

        msdfFontProgram.use();
        RenderSystem.setShaderTexture(0, identifier);

        msdfFontProgram.findUniform("Range").set(range);
        msdfFontProgram.findUniform("Thickness").set(thickness);
        msdfFontProgram.findUniform("Smoothness").set(smoothness);
        msdfFontProgram.findUniform("Outline").set(0);
        msdfFontProgram.findUniform("ColorModulator").set(1f, 1f, 1f, 1f);
        msdfFontProgram.findUniform("EnableFadeout").set(0);

        drawSetup();

        BufferBuilder builder = RenderSystem.renderThreadTesselator().begin(VertexFormat.DrawMode.QUADS,
                VertexFormats.POSITION_TEXTURE_COLOR);
        builder.vertex(matrix4f, x, y, 0.0F).texture(0.0F, 0.0F).color(color.getRGB());
        builder.vertex(matrix4f, x, y + height, 0.0F).texture(0.0F, 1.0F).color(color.getRGB());
        builder.vertex(matrix4f, x + width, y + height, 0.0F).texture(1.0F, 1.0F).color(color.getRGB());
        builder.vertex(matrix4f, x + width, y, 0.0F).texture(1.0F, 0.0F).color(color.getRGB());
        BufferRenderer.drawWithGlobalProgram(builder.end());

        drawEnd();
        RenderSystem.setShaderTexture(0, 0);
        matrices.pop();
    }

    public void drawSetup() {
        RenderSystem.enableBlend();
        RenderSystem.defaultBlendFunc();
    }

    public void drawEnd() {
        RenderSystem.disableBlend();
    }

    record HeadUV(float u1, float v1, float uSize, float vSize) {
    }
}