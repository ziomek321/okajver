package okyware.wtf.utility.server;

import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import java.io.ByteArrayOutputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.net.Socket;
import java.nio.charset.StandardCharsets;
import java.util.Base64;


public final class ServerStatusPinger {

    private ServerStatusPinger() {}

    public static byte[] fetchFavicon(String address) {
        if (address == null || address.isEmpty()) return null;
        String host = address;
        int port = 25565;
        int colon = address.lastIndexOf(':');
        if (colon > 0 && address.indexOf(':') == colon) {
            try {
                port = Integer.parseInt(address.substring(colon + 1));
                host = address.substring(0, colon);
            } catch (NumberFormatException ignored) {}
        }

        try (Socket socket = new Socket()) {
            socket.connect(new java.net.InetSocketAddress(host, port), 4000);
            socket.setSoTimeout(4000);
            DataOutputStream out = new DataOutputStream(socket.getOutputStream());
            DataInputStream in = new DataInputStream(socket.getInputStream());

            
            ByteArrayOutputStream hs = new ByteArrayOutputStream();
            DataOutputStream hsOut = new DataOutputStream(hs);
            writeVarInt(hsOut, 0x00);
            writeVarInt(hsOut, -1);
            writeString(hsOut, host);
            hsOut.writeShort(port);
            writeVarInt(hsOut, 1);
            writePacket(out, hs.toByteArray());

            
            ByteArrayOutputStream req = new ByteArrayOutputStream();
            DataOutputStream reqOut = new DataOutputStream(req);
            writeVarInt(reqOut, 0x00);
            writePacket(out, req.toByteArray());

            
            int length = readVarInt(in);
            if (length <= 0) return null;
            int packetId = readVarInt(in);
            if (packetId != 0x00) return null;
            String json = readString(in);

            JsonObject obj = JsonParser.parseString(json).getAsJsonObject();
            if (!obj.has("favicon")) return null;
            String fav = obj.get("favicon").getAsString();
            int comma = fav.indexOf(',');
            String b64 = comma >= 0 ? fav.substring(comma + 1) : fav;
            b64 = b64.replaceAll("\\s+", "");
            return Base64.getDecoder().decode(b64);
        } catch (Exception e) {
            return null;
        }
    }

    private static void writePacket(DataOutputStream out, byte[] data) throws Exception {
        writeVarInt(out, data.length);
        out.write(data);
        out.flush();
    }

    private static void writeVarInt(DataOutputStream out, int value) throws Exception {
        while ((value & 0xFFFFFF80) != 0) {
            out.writeByte((value & 0x7F) | 0x80);
            value >>>= 7;
        }
        out.writeByte(value & 0x7F);
    }

    private static int readVarInt(DataInputStream in) throws Exception {
        int value = 0;
        int shift = 0;
        while (true) {
            int b = in.readByte();
            value |= (b & 0x7F) << shift;
            if ((b & 0x80) == 0) break;
            shift += 7;
            if (shift >= 32) throw new RuntimeException("VarInt too big");
        }
        return value;
    }

    private static void writeString(DataOutputStream out, String s) throws Exception {
        byte[] bytes = s.getBytes(StandardCharsets.UTF_8);
        writeVarInt(out, bytes.length);
        out.write(bytes);
    }

    private static String readString(DataInputStream in) throws Exception {
        int len = readVarInt(in);
        byte[] buf = new byte[len];
        in.readFully(buf);
        return new String(buf, StandardCharsets.UTF_8);
    }
}
