package okyware.wtf.utility.game.player.rotation;

import net.minecraft.util.math.MathHelper;

import java.util.Random;

public class HumanRotation {
    private static final Random random = new Random();
    private static float lastYaw = Float.NaN;
    private static float lastPitch = Float.NaN;
    private static float velocityYaw = 0.0f;
    private static float velocityPitch = 0.0f;

    public static void reset() {
        lastYaw = Float.NaN;
        lastPitch = Float.NaN;
        velocityYaw = 0.0f;
        velocityPitch = 0.0f;
    }

    public static float[] compute(float currentYaw, float currentPitch, float targetYaw, float targetPitch, boolean canAttack, long time) {
        if (Float.isNaN(lastYaw)) {
            lastYaw = currentYaw;
            lastPitch = currentPitch;
        }

        float deltaYaw = MathHelper.wrapDegrees(targetYaw - lastYaw);
        float deltaPitch = targetPitch - lastPitch;

        float distance = (float) Math.hypot(deltaYaw, deltaPitch);

        float speed;
        if (distance > 45f) {
            speed = 0.78f + random.nextFloat() * 0.08f;
        } else if (distance > 18f) {
            speed = 0.84f + random.nextFloat() * 0.08f;
        } else if (distance > 5f) {
            speed = 0.90f + random.nextFloat() * 0.06f;
        } else {
            speed = 0.72f + random.nextFloat() * 0.10f;
        }
        if (!canAttack) {
            speed *= 0.78f;
        }

        float gcd = GCDFixer.getGCDValue();
        float microYaw = (float) (Math.sin(time / 73.0) * gcd * 0.18f) + (random.nextFloat() - 0.5f) * gcd * 0.12f;
        float microPitch = (float) (Math.cos(time / 89.0) * gcd * 0.14f) + (random.nextFloat() - 0.5f) * gcd * 0.10f;

        float wantedYawStep = deltaYaw * speed + microYaw;
        float wantedPitchStep = deltaPitch * speed + microPitch;

        float maxYawStep = canAttack ? 42.0f : 32.0f;
        float maxPitchStep = canAttack ? 28.0f : 22.0f;
        wantedYawStep = MathHelper.clamp(wantedYawStep, -maxYawStep, maxYawStep);
        wantedPitchStep = MathHelper.clamp(wantedPitchStep, -maxPitchStep, maxPitchStep);

        velocityYaw = velocityYaw * 0.35f + wantedYawStep * 0.65f;
        velocityPitch = velocityPitch * 0.38f + wantedPitchStep * 0.62f;

        float nextYaw = lastYaw + velocityYaw;
        float nextPitch = MathHelper.clamp(lastPitch + velocityPitch, -90f, 90f);

        float diffYaw = nextYaw - currentYaw;
        float diffPitch = nextPitch - currentPitch;

        float fixedYaw = currentYaw + GCDFixer.getFixRotate(diffYaw);
        float fixedPitch = currentPitch + GCDFixer.getFixRotate(diffPitch);

        fixedPitch = MathHelper.clamp(fixedPitch, -90f, 90f);

        velocityYaw = MathHelper.wrapDegrees(fixedYaw - lastYaw);
        velocityPitch = fixedPitch - lastPitch;
        lastYaw = fixedYaw;
        lastPitch = fixedPitch;

        return new float[]{fixedYaw, fixedPitch};
    }
}
