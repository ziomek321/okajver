package okyware.wtf.utility.interfaces;

import okyware.wtf.Okyware;
import okyware.wtf.base.rotation.AimManager;
import okyware.wtf.base.rotation.RotationManager;
import okyware.wtf.base.rotation.deeplearnig.DeepLearningManager;

public interface IClient extends IWindow{
    Okyware stardlc = Okyware.getInstance();
    DeepLearningManager deepLearningManager = Okyware.getInstance().getDeepLearningManager();
    RotationManager rotationManager = Okyware.getInstance().getRotationManager();
    AimManager aimManager = rotationManager.getAimManager();

}
