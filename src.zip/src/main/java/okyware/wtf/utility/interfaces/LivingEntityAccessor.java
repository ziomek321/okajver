package okyware.wtf.utility.interfaces;

public interface LivingEntityAccessor {
    void setJumpingCooldown(int cooldown);
}
