package okyware.wtf.utility.interfaces;

import net.minecraft.util.math.Vec3d;
import java.util.List;

public interface BacktrackableEntity {
    List<Position> getBackTracks();

    record Position(Vec3d pos, long time) {}
}
